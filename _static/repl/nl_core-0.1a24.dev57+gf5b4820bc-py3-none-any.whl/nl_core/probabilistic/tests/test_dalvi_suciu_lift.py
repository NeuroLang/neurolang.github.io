from operator import eq, gt, lt
from typing import AbstractSet

import pytest

from ...datalog.translate_to_named_ra import TranslateToNamedRA
from nl_expr.config import config
from nl_expr.exceptions import (
    NonLiftableException,
    NotInFONegE,
    UnsupportedSolverError,
)
from nl_expr.expressions import Constant, Symbol
from nl_expr.logic import (
    Conjunction,
    Disjunction,
    ExistentialPredicate,
    Implication,
    Negation,
    Union,
    UniversalPredicate,
)
from nl_expr.logic.expression_processing import (
    extract_logic_atoms,
    extract_logic_free_variables,
)
from ...relational_algebra import (
    ColumnInt,
    ColumnStr,
    Difference,
    ExtendedProjection,
    Materialise,
    NameColumns,
    Projection,
    str2columnstr_constant
)
from ...relational_algebra_provenance import (
    DisjointProjection,
    IndependentProjection
)
from ...utils.relational_algebra_set import NamedRelationalAlgebraFrozenSet
from .. import dalvi_suciu_lift, transforms
from ..cplogic import testing
from ..cplogic.program import CPLogicProgram
from ..probabilistic_ra_utils import (
    DeterministicFactSet,
    ProbabilisticChoiceSet,
    ProbabilisticFactSet,
    generate_probabilistic_symbol_table_for_query,
)
from ..transforms import convert_rule_to_ucq
from .test_lifted_negation import check

TNRA = TranslateToNamedRA()
EQ = Constant(eq)
GT = Constant(gt)
LT = Constant(lt)


def test_has_separator_variable_existential():
    A = Symbol('A')
    B = Symbol('B')
    C = Symbol('C')
    x = Symbol('x')
    y = Symbol('y')

    expression = ExistentialPredicate(
        y,
        Disjunction((B(x, y), Conjunction((A(y), B(x, y))), C(y)))
    )

    sv, _ = dalvi_suciu_lift.find_separator_variables(expression, {})
    assert sv == {y}

    expression = ExistentialPredicate(
        y,
        Disjunction((B(x, y), Conjunction((A(y), B(y, x))), C(y)))
    )

    sv, _ = dalvi_suciu_lift.find_separator_variables(expression, {})
    assert sv == set()

    expression = Disjunction((B(x, y), Conjunction((A(y), B(x, y))), C(y)))

    sv, _ = dalvi_suciu_lift.find_separator_variables(expression, {})
    assert sv == set()

    R = Symbol('R')
    S = Symbol('S')
    T = Symbol('T')
    x1 = Symbol('x1')
    x2 = Symbol('x2')
    y1 = Symbol('y1')
    y2 = Symbol('y2')

    expression = ExistentialPredicate(x1, ExistentialPredicate(
        x2,
        ExistentialPredicate(y1, ExistentialPredicate(
            y2,
            Disjunction((
                Conjunction((R(x1), S(x1, y1))),
                Conjunction((T(x2), S(x2, y2)))
            ))
        ))
    ))

    assert dalvi_suciu_lift.has_separator_variables(expression, {})
    assert (
        dalvi_suciu_lift.find_separator_variables(expression, {})[0] &
        {x1, x2}
    )


def test_lifted_bcq_fig_4_4():
    Q = Symbol('Q')
    R = Symbol('R')
    S = Symbol('S')
    T = Symbol('T')
    x1 = Symbol('x1')
    x2 = Symbol('x2')
    y1 = Symbol('y1')
    y2 = Symbol('y2')
    z = Symbol('z')

    cq = Implication(Q(z), Conjunction((
         R(z, x1), S(x1, y1), T(z, x2), S(x2, y2)
    )))
    cq = convert_rule_to_ucq(cq)
    plan = dalvi_suciu_lift.dalvi_suciu_lift(cq, {})
    res = dalvi_suciu_lift.is_pure_lifted_plan(plan)
    assert res


def test_lifted_separator_variable():
    R = Symbol('R')
    x1 = Symbol('x1')
    z = Symbol('z')

    cq = ExistentialPredicate(x1, R(x1, z))
    plan = dalvi_suciu_lift.dalvi_suciu_lift(cq, {})
    res = dalvi_suciu_lift.is_pure_lifted_plan(plan)
    assert res


def test_lifted_join():
    Q = Symbol('Q')
    R = Symbol('R')
    S = Symbol('S')
    T = Symbol('T')
    x1 = Symbol('x1')
    x2 = Symbol('x2')
    z = Symbol('z')

    cq = Implication(Q(z), Conjunction((R(x1, z), S(x1, x2), T(x1, z))))
    ucq = convert_rule_to_ucq(cq)
    plan = dalvi_suciu_lift.dalvi_suciu_lift(ucq, {})
    res = dalvi_suciu_lift.is_pure_lifted_plan(plan)
    assert res


def test_another_liftable_join():
    Q = Symbol('Q')
    R = Symbol('R')
    S = Symbol('S')
    x1 = Symbol('x1')
    x2 = Symbol('x2')
    z = Symbol('z')

    cq = Implication(Q(z), Conjunction((R(x1, z), S(x1, x2), S(x1, z))))
    plan = dalvi_suciu_lift.dalvi_suciu_lift(convert_rule_to_ucq(cq), {})
    res = dalvi_suciu_lift.is_pure_lifted_plan(plan)
    assert res


def test_non_liftable_join():
    Q = Symbol('Q')
    R = Symbol('R')
    S = Symbol('S')
    x1 = Symbol('x1')
    x2 = Symbol('x2')
    z = Symbol('z')

    cq = Implication(Q(z), Conjunction((R(x1, z), S(x2, x1), S(x1, z))))
    symbol_table = {
        symbol: ProbabilisticFactSet(Symbol.fresh(), 'p') for symbol in (R, S)
    }
    plan = dalvi_suciu_lift.dalvi_suciu_lift(
        convert_rule_to_ucq(cq), symbol_table
    )
    res = dalvi_suciu_lift.is_pure_lifted_plan(plan)
    assert not res


def test_non_liftable_within_an_extended_projection():
    """The plan of the answers with x = y of `different_free_variables_plan`
    is an extended projection, which may hold a non-liftable query."""
    R = Symbol('R')
    x = Symbol('x')
    plan = ExtendedProjection(dalvi_suciu_lift.NonLiftable(R(x)), ())
    assert not dalvi_suciu_lift.is_pure_lifted_plan(plan)


def test_lifted_cq_fig_4_5():
    Q = Symbol('Q')
    R = Symbol('R')
    S = Symbol('S')
    T = Symbol('T')
    x1 = Symbol('x1')
    x2 = Symbol('x2')
    x3 = Symbol('x3')
    y1 = Symbol('y1')
    y2 = Symbol('y2')
    y3 = Symbol('y3')
    z = Symbol('z')

    cq = Implication(Q(z), Disjunction((
        Conjunction((R(z, x1), S(x1, y1))),
        Conjunction((S(x2, y2), T(z, y2))),
        Conjunction((R(z, x3), T(z, y3))),
    )))

    plan = dalvi_suciu_lift.dalvi_suciu_lift(convert_rule_to_ucq(cq), {})
    res = dalvi_suciu_lift.is_pure_lifted_plan(plan)
    assert res


def test_minimize_component_conjunction():
    Q = Symbol('Q')
    R = Symbol('R')
    T = Symbol('T')
    x1 = Symbol('x1')
    y1 = Symbol('y1')
    y2 = Symbol('y2')

    expr = Conjunction((Q(x1),))
    res = transforms.minimize_component_conjunction(expr)
    assert res == expr

    expr = Conjunction((Q(x1, y1), R(x1, y2)))
    res = transforms.minimize_component_conjunction(expr)
    assert res == expr

    expr = Conjunction((
        ExistentialPredicate(y1, Q(x1, y1)),
        ExistentialPredicate(y2, Q(x1, y2))
    ))
    res = transforms.minimize_component_conjunction(expr)
    assert res in (
        Conjunction((q,)) for q in
        (
            ExistentialPredicate(y1, Q(x1, y1)),
            ExistentialPredicate(y2, Q(x1, y2))
        )
    )

    expr = Conjunction((
        ExistentialPredicate(y2, Q(x1, y2)),
        Disjunction((
            ExistentialPredicate(y1, Q(x1, y1)),
            T(x1)
        ))
    ))
    res = transforms.minimize_component_conjunction(expr)
    assert res == Conjunction((ExistentialPredicate(y2, Q(x1, y2)),))

    expr = Conjunction((
        Disjunction((
            ExistentialPredicate(y1, Q(x1, y1)),
            T(x1)
        )),
        ExistentialPredicate(y2, Q(x1, y2)),
    ))
    res = transforms.minimize_component_conjunction(expr)
    assert res == Conjunction((ExistentialPredicate(y2, Q(x1, y2)),))


def test_minimize_component_disjunction():
    Q = Symbol('Q')
    R = Symbol('R')
    T = Symbol('T')
    x1 = Symbol('x1')
    y1 = Symbol('y1')
    y2 = Symbol('y2')

    expr = Disjunction((Q(x1),))
    res = transforms.minimize_component_disjunction(expr)
    assert res == expr

    expr = Disjunction((Q(x1, y1), R(x1, y2)))
    res = transforms.minimize_component_disjunction(expr)
    assert res == expr

    expr = Disjunction((
        ExistentialPredicate(y1, Q(x1, y1)),
        ExistentialPredicate(y2, Q(x1, y2))
    ))
    res = transforms.minimize_component_disjunction(expr)
    assert res in (
        Disjunction((q,)) for q in
        (
            ExistentialPredicate(y1, Q(x1, y1)),
            ExistentialPredicate(y2, Q(x1, y2))
        )
    )

    expr = Disjunction((
        ExistentialPredicate(y2, Q(x1, y2)),
        Disjunction((
            ExistentialPredicate(y1, Q(x1, y1)),
            T(x1)
        ))
    ))
    res = transforms.minimize_component_disjunction(expr)
    assert res == Disjunction((
        ExistentialPredicate(y1, Q(x1, y1)),
        T(x1)
        ))

    expr = Disjunction((
        Disjunction((
            ExistentialPredicate(y1, Q(x1, y1)),
            T(x1)
        )),
        ExistentialPredicate(y2, Q(x1, y2)),
    ))
    res = transforms.minimize_component_disjunction(expr)
    assert res == Disjunction((
        ExistentialPredicate(y1, Q(x1, y1)),
        T(x1)
    ))


def test_intractable_queries():
    """
    Queries that are "intractable", in that they are #P-hard, as defined in
    section 3.2 of [1]_.

    The lifted query processing algorithm should return a NonLiftable object
    containing the unprocessed query.

    [1] Suciu, D. Probabilistic Databases for All. in Proceedings of the
    39th ACM SIGMOD-SIGACT-SIGAI Symposium on Principles of Database Systems
    19–31 (ACM, 2020).
    """
    R = Symbol('R')
    S = Symbol('S')
    S1 = Symbol('S1')
    S2 = Symbol('S2')
    S3 = Symbol('S3')
    T = Symbol('T')
    x = Symbol("x")
    x0 = Symbol('x0')
    x1 = Symbol('x1')
    x2 = Symbol('x2')
    x3 = Symbol('x3')
    y = Symbol("y")
    y0 = Symbol("y0")
    y1 = Symbol('y1')
    y2 = Symbol('y2')
    y3 = Symbol('y3')
    h0 = ExistentialPredicate(
        x,
        Conjunction(
            (
                R(x),
                ExistentialPredicate(y, Conjunction((S(x, y), T(y)))),
            )
        ),
    )
    h1 = Disjunction(
        (
            ExistentialPredicate(
                x0, Conjunction((R(x0), ExistentialPredicate(y0, S(x0, y0))))
            ),
            ExistentialPredicate(
                y1, Conjunction((ExistentialPredicate(x1, S(x1, y1)), T(y1)))
            ),
        )
    )
    h2 = Disjunction(
        (
            ExistentialPredicate(
                x0,
                Conjunction((R(x0), S1(x0, y0))),
            ),
            ExistentialPredicate(
                x1,
                ExistentialPredicate(
                    y1,
                    Conjunction((S1(x1, y1), S2(x1, y1))),
                )
            ),
            ExistentialPredicate(
                y2,
                Conjunction((ExistentialPredicate(x2, S2(x2, y2)), T(y2))),
            ),
        )
    )
    h3 = Disjunction(
        (
            ExistentialPredicate(
                x0,
                Conjunction((R(x0), S1(x0, y0))),
            ),
            ExistentialPredicate(
                x1,
                ExistentialPredicate(
                    y1,
                    Conjunction((S1(x1, y1), S2(x1, y1))),
                )
            ),
            ExistentialPredicate(
                x2,
                ExistentialPredicate(
                    y2,
                    Conjunction((S2(x2, y2), S3(x2, y2))),
                )
            ),
            ExistentialPredicate(
                y3,
                Conjunction((ExistentialPredicate(x3, S3(x3, y3)), T(y3))),
            ),
        )
    )
    symbol_table = {
        symbol: ProbabilisticFactSet(Symbol.fresh(), 'p')
        for symbol in (R, S, S1, S2, S3, T)
    }
    for h in (h0, h1, h2, h3):
        plan = dalvi_suciu_lift.dalvi_suciu_lift(h, symbol_table)
        assert not dalvi_suciu_lift.is_pure_lifted_plan(plan)


def test_example_4_6_a_really_simple_query():
    R = Symbol("R")
    S = Symbol("S")
    x = Symbol("x")
    y = Symbol("y")
    query = ExistentialPredicate(
        x, Conjunction((R(x), ExistentialPredicate(y, S(x, y))))
    )
    resulting_plan = dalvi_suciu_lift.dalvi_suciu_lift(query, {})
    assert dalvi_suciu_lift.is_pure_lifted_plan(resulting_plan)


def test_example_4_7_a_query_with_self_joins():
    R = Symbol("R")
    S = Symbol("S")
    T = Symbol("T")
    x1 = Symbol("x1")
    x2 = Symbol("x2")
    y1 = Symbol("y1")
    y2 = Symbol("y2")
    Q1 = ExistentialPredicate(
        x1,
        ExistentialPredicate(
            y1,
            Conjunction((R(x1), S(x1, y1))),
        ),
    )
    Q2 = ExistentialPredicate(
        x2,
        ExistentialPredicate(
            y2,
            Conjunction((T(x2), S(x2, y2))),
        ),
    )
    query = Conjunction((Q1, Q2))
    resulting_plan = dalvi_suciu_lift.dalvi_suciu_lift(query, {})
    assert dalvi_suciu_lift.is_pure_lifted_plan(resulting_plan)


@pytest.mark.skip
def test_example_4_8_tractable_query_intractable_subquery():
    """
    We test the query

        R(x1), S(x1, y1) ∨ S(x2, y2), T(y2) ∨ R(x3), T(y3)

    whose first two disjuncts correspond to the hard H1 query, but the third
    disjunct makes the query tractable by using distributivity and logical
    equivalence.

    """
    R = Symbol("R")
    S = Symbol("S")
    T = Symbol("T")
    x1 = Symbol("x1")
    x2 = Symbol("x2")
    x3 = Symbol("x3")
    y1 = Symbol("y1")
    y2 = Symbol("y2")
    y3 = Symbol("y3")
    query = Disjunction(
        (
            ExistentialPredicate(
                x1,
                Conjunction(
                    (
                        R(x1),
                        ExistentialPredicate(y1, S(x1, y1)),
                    )
                ),
            ),
            ExistentialPredicate(
                y2,
                Conjunction(
                    (
                        ExistentialPredicate(x2, S(x2, y2)),
                        T(y2),
                    )
                ),
            ),
            Conjunction(
                (
                    ExistentialPredicate(x3, R(x3)),
                    ExistentialPredicate(y3, T(y3)),
                )
            ),
        )
    )
    resulting_plan = dalvi_suciu_lift.dalvi_suciu_lift(query, {})
    assert dalvi_suciu_lift.is_pure_lifted_plan(resulting_plan)


def test_single_disjoint_project_one_variable():
    P = Symbol("P")
    x = Symbol("x")
    pchoice_relation = NamedRelationalAlgebraFrozenSet(
        iterable=[
            (0.2, "a"),
            (0.7, "b"),
            (0.1, "c"),
        ],
        columns=("_p_", "x"),
    )
    symbol_table = {
        P: ProbabilisticChoiceSet(
            Constant[AbstractSet](pchoice_relation),
            str2columnstr_constant("_p_"),
        ),
    }
    query = ExistentialPredicate(x, P(x))
    plan = dalvi_suciu_lift.dalvi_suciu_lift(query, symbol_table)
    assert isinstance(plan, DisjointProjection)


def test_single_disjoint_project_two_variables():
    P = Symbol("P")
    x = Symbol("x")
    y = Symbol("y")
    pchoice_relation = NamedRelationalAlgebraFrozenSet(
        iterable=[
            (0.2, "a", "b"),
            (0.7, "b", "b"),
            (0.1, "b", "c"),
        ],
        columns=("_p_", "x", "y"),
    )
    symbol_table = {
        P: ProbabilisticChoiceSet(
            Constant[AbstractSet](pchoice_relation),
            str2columnstr_constant("_p_"),
        ),
    }
    query = ExistentialPredicate(y, P(x, y))
    plan = dalvi_suciu_lift.dalvi_suciu_lift(query, symbol_table)
    assert isinstance(plan, DisjointProjection)


def test_simple_existential_query_plan():
    R = Symbol("R")
    x = Symbol("x")
    y = Symbol("y")
    relation = Constant[AbstractSet](
        NamedRelationalAlgebraFrozenSet(
            iterable=[
                ("a", "b"),
                ("b", "a"),
                ("c", "a"),
            ],
            columns=("x", "y"),
        )
    )
    symbol_table = {R: DeterministicFactSet(relation)}
    query = ExistentialPredicate(x, R(x, y))
    plan = dalvi_suciu_lift.dalvi_suciu_lift(query, symbol_table)
    assert dalvi_suciu_lift.is_pure_lifted_plan(plan)


def test_extract_probabilistic_root_variables_no_probabilistic_atom():
    res = dalvi_suciu_lift.extract_probabilistic_root_variables(set(), dict())
    assert len(res) == 0

    P = Symbol("P")
    x = Symbol("x")
    y = Symbol("y")
    formulas = [
        P(x, y),
    ]
    relation = Constant[AbstractSet](
        NamedRelationalAlgebraFrozenSet(
            iterable=[
                ("a", "b"),
                ("b", "a"),
                ("c", "a"),
            ],
            columns=("x", "y"),
        )
    )
    symbol_table = {
        P: DeterministicFactSet(relation)
    }
    res = dalvi_suciu_lift.extract_probabilistic_root_variables(
        formulas, symbol_table
    )
    assert len(res) == 0


def test_lifted_negation():
    R = Symbol('R')
    S = Symbol('S')
    x = Symbol('x')
    y = Symbol('y')

    query = ExistentialPredicate(
        y,
        Conjunction((
            R(x, y),
            Negation(S(y))
        ))
    )

    symbol_table = {
        symbol: ProbabilisticFactSet(Symbol.fresh(), 'p')
        for symbol in (R, S)
    }
    res = dalvi_suciu_lift.dalvi_suciu_lift(query, symbol_table)
    expected = IndependentProjection(
        Difference(
            NameColumns(
                Projection(
                    R,
                    (Constant(ColumnInt(0)), Constant(ColumnInt(1))),
                ),
                (Constant(ColumnStr('x')), Constant(ColumnStr('y'))),
            ),
            NameColumns(
                Projection(
                    S,
                    (Constant(ColumnInt(0)),)
                ),
                (Constant(ColumnStr('y')),)
            ),
        ),
        (Constant(ColumnStr('x')),)
    )

    assert res == expected


def test_lifted_disjunction_with_negation():
    R = Symbol('R')
    S = Symbol('S')
    T = Symbol('T')
    x = Symbol('x')
    y = Symbol('y')

    query = Disjunction((
        ExistentialPredicate(
            y,
            Conjunction((
                R(x, y),
                Negation(S(y))
            ))
        ),
        ExistentialPredicate(
            y,
            T(x, y)
        )
    ))

    symbol_table = {
        symbol: ProbabilisticFactSet(Symbol.fresh(), 'p')
        for symbol in (R, S, T)
    }
    res = dalvi_suciu_lift.dalvi_suciu_lift(query, symbol_table)

    assert dalvi_suciu_lift.is_pure_lifted_plan(res)


def test_lifted_disjunction_cross_product_with_negation():
    R = Symbol('R')
    S = Symbol('S')
    T = Symbol('T')
    V = Symbol('V')
    x = Symbol('x')
    y = Symbol('y')

    query = Disjunction((
        ExistentialPredicate(
            y,
            Conjunction((
                R(x),
                Negation(S(y)),
                V(y)
            ))
        ),
        ExistentialPredicate(
            y,
            T(x, y)
        )
    ))

    symbol_table = {
        symbol: ProbabilisticFactSet(Symbol.fresh(), 'p')
        for symbol in (R, S, T, V)
    }
    res = dalvi_suciu_lift.dalvi_suciu_lift(query, symbol_table)

    assert dalvi_suciu_lift.is_pure_lifted_plan(res)


def test_lifted_conjunction_existential_negation():
    R = Symbol('R')
    S = Symbol('S')
    T = Symbol('T')
    x = Symbol('x')
    y = Symbol('y')

    query = Conjunction((
        Negation(
            ExistentialPredicate(
                x,
                Conjunction((
                    R(x),
                    S(x, y),
                ))
            )
        ),
        T(y)
    ))

    symbol_table = {
        symbol: ProbabilisticFactSet(Symbol.fresh(), 'p')
        for symbol in (R, S, T)
    }
    res = dalvi_suciu_lift.dalvi_suciu_lift(query, symbol_table)

    assert dalvi_suciu_lift.is_pure_lifted_plan(res)


def test_lifted_conjunction_existential_negation_constant():
    R = Symbol('R')
    S = Symbol('S')
    T = Symbol('T')
    Q = Symbol('Q')
    x = Symbol('x')
    y = Symbol('y')

    query = Conjunction((
        Negation(
            ExistentialPredicate(
                x,
                Conjunction((
                    R(x),
                    S(x, y, Constant('2'))
                ))
            )
        ),
        Q(x, y),
        T(y)
    ))

    symbol_table = {
        symbol: ProbabilisticFactSet(Symbol.fresh(), 'p')
        for symbol in (R, S, T)
    }
    symbol_table[Q] = DeterministicFactSet(Symbol.fresh())

    res = dalvi_suciu_lift.dalvi_suciu_lift(query, symbol_table)

    assert dalvi_suciu_lift.is_pure_lifted_plan(res)


def test_mixed_probabilistic_deterministic_safe():
    R = Symbol("R")
    S = Symbol("S")
    T = Symbol("T")
    x = Symbol("x")
    y = Symbol("y")
    R_relation = Constant[AbstractSet](
        NamedRelationalAlgebraFrozenSet(iterable=[], columns=("x",))
    )
    S_relation = Constant[AbstractSet](
        NamedRelationalAlgebraFrozenSet(iterable=[], columns=("_p_", "x", "y"))
    )
    T_relation = Constant[AbstractSet](
        NamedRelationalAlgebraFrozenSet(iterable=[], columns=("_p_", "x",))
    )
    symbol_table = {
        R: DeterministicFactSet(R_relation),
        S: ProbabilisticFactSet(S_relation, Constant(ColumnStr("_p_"))),
        T: ProbabilisticFactSet(T_relation, Constant(ColumnStr("_p_"))),
    }
    query = ExistentialPredicate(
        x,
        ExistentialPredicate(
            y,
            Conjunction((R(x), S(x, y), T(y))),
        )
    )
    plan = dalvi_suciu_lift.dalvi_suciu_lift(query, symbol_table)
    assert dalvi_suciu_lift.is_pure_lifted_plan(plan)


def test_mixed_probabilistic_deterministic_unsafe():
    """S is a function neither of x nor of y."""
    R = Symbol("R")
    S = Symbol("S")
    T = Symbol("T")
    x = Symbol("x")
    y = Symbol("y")
    R_relation = Constant[AbstractSet](
        NamedRelationalAlgebraFrozenSet(iterable=[], columns=("x",))
    )
    S_relation = Constant[AbstractSet](NamedRelationalAlgebraFrozenSet(
        iterable=[(1, 1), (1, 2), (2, 1)], columns=("x", "y")
    ))
    T_relation = Constant[AbstractSet](
        NamedRelationalAlgebraFrozenSet(iterable=[], columns=("_p_", "x",))
    )
    symbol_table = {
        R: ProbabilisticFactSet(R_relation, Constant(ColumnStr("_p_"))),
        S: DeterministicFactSet(S_relation),
        T: ProbabilisticFactSet(T_relation, Constant(ColumnStr("_p_"))),
    }
    query = ExistentialPredicate(
        x,
        ExistentialPredicate(
            y,
            Conjunction((R(x), S(x, y), T(y))),
        )
    )
    plan = dalvi_suciu_lift.dalvi_suciu_lift(query, symbol_table)
    assert not dalvi_suciu_lift.is_pure_lifted_plan(plan)


def test_interaction_deterministic_probfact_probchoice_safe():
    Det = Symbol("Det")
    Pchoice = Symbol("Pchoice")
    Pfact = Symbol("Pfact")
    x = Symbol("x")
    y = Symbol("y")
    Det_relation = Constant[AbstractSet](
        NamedRelationalAlgebraFrozenSet(iterable=[], columns=("x",))
    )
    Pchoice_relation = Constant[AbstractSet](
        NamedRelationalAlgebraFrozenSet(iterable=[], columns=("_p_", "y"))
    )
    Pfact_relation = Constant[AbstractSet](
        NamedRelationalAlgebraFrozenSet(iterable=[], columns=("_p_", "x",))
    )
    symbol_table = {
        Det: ProbabilisticFactSet(Det_relation, Constant(ColumnStr("_p_"))),
        Pchoice: DeterministicFactSet(Pchoice_relation),
        Pfact: ProbabilisticFactSet(
            Pfact_relation, Constant(ColumnStr("_p_"))
        ),
    }
    query = ExistentialPredicate(
        x,
        ExistentialPredicate(
            y,
            Conjunction((Det(x, y), Pchoice(y), Pfact(x))),
        )
    )
    plan = dalvi_suciu_lift.dalvi_suciu_lift(query, symbol_table)
    assert dalvi_suciu_lift.is_pure_lifted_plan(plan)


@pytest.mark.parametrize("rules", (
    "S(x), S(y)",
    "S(x), S(y) | R(y, x), S(w)",
    "S(w), R(x, x) | S(y), S(x), S(w)",
), ids=(
    "self-join", "union implying the self-join",
    "three equivalent conjuncts",
))
def test_inclusion_exclusion_on_equivalent_formulas(rules):
    """∃x S(x) ∧ ∃y S(y) is ∃x S(x): its two conjuncts and their
    disjunction are equivalent, and the Möbius weights of their lattice
    must count them once. The union adds R(y, x) ∧ S(w), which implies
    ∃x S(x). The CNF of the last one has three conjuncts equivalent to
    ∃x S(x), of which minimisation must keep one."""
    R, S, Z, ans = (Symbol(n) for n in ("R", "S", "Z", "ans"))
    w, x, y = (Symbol(n) for n in ("w", "x", "y"))
    bodies = {
        "S(x), S(y)": (Conjunction((S(x), S(y))),),
        "S(x), S(y) | R(y, x), S(w)": (
            Conjunction((S(x), S(y))), Conjunction((R(y, x), S(w)))
        ),
        "S(w), R(x, x) | S(y), S(x), S(w)": (
            Conjunction((S(w), R(x, x))), Conjunction((S(y), S(x), S(w)))
        ),
    }[rules]
    cpl_program = CPLogicProgram()
    cpl_program.add_probabilistic_facts_from_tuples(
        R, [(0.5, "a", "b"), (0.4, "b", "a"), (0.2, "a", "a")]
    )
    cpl_program.add_probabilistic_facts_from_tuples(
        S, [(0.3, "a"), (0.6, "b")]
    )
    cpl_program.walk(Union(tuple(Implication(Z(), b) for b in bodies)))
    result = dalvi_suciu_lift.solve_succ_query(
        Implication(ans(), Z()), cpl_program
    )
    expected = 1 - (1 - 0.3) * (1 - 0.6)
    assert testing.eq_prov_relations(
        result, testing.make_prov_set([(expected,)], ("_p_",))
    )


def test_symbols_of_relations_to_materialise_are_kept_in_plans():
    """Like constant sets, relations marked to be materialised are left
    behind their symbols, rather than inlined in the plan.
    """
    relation = Materialise(Constant[AbstractSet](
        NamedRelationalAlgebraFrozenSet(("x",), [(1,)])
    ))
    symbol = Symbol.fresh()
    replace = dalvi_suciu_lift.ReplaceAllSymbolsButConstantSets(
        {symbol: relation}
    )

    assert replace.walk(symbol) == symbol


@pytest.mark.parametrize("rules", (
    "S(x), S(y)",
    "S(x), S(y) | R(y, x), S(w)",
    "S(w), R(x, x) | S(y), S(x), S(w)",
), ids=(
    "self-join", "union implying the self-join",
    "three equivalent conjuncts",
))
def test_inclusion_exclusion_on_equivalent_formulas(rules):
    """∃x S(x) ∧ ∃y S(y) is ∃x S(x): its two conjuncts and their
    disjunction are equivalent, and the Möbius weights of their lattice
    must count them once. The union adds R(y, x) ∧ S(w), which implies
    ∃x S(x). The CNF of the last one has three conjuncts equivalent to
    ∃x S(x), of which minimisation must keep one."""
    R, S, Z, ans = (Symbol(n) for n in ("R", "S", "Z", "ans"))
    w, x, y = (Symbol(n) for n in ("w", "x", "y"))
    bodies = {
        "S(x), S(y)": (Conjunction((S(x), S(y))),),
        "S(x), S(y) | R(y, x), S(w)": (
            Conjunction((S(x), S(y))), Conjunction((R(y, x), S(w)))
        ),
        "S(w), R(x, x) | S(y), S(x), S(w)": (
            Conjunction((S(w), R(x, x))), Conjunction((S(y), S(x), S(w)))
        ),
    }[rules]
    cpl_program = CPLogicProgram()
    cpl_program.add_probabilistic_facts_from_tuples(
        R, [(0.5, "a", "b"), (0.4, "b", "a"), (0.2, "a", "a")]
    )
    cpl_program.add_probabilistic_facts_from_tuples(
        S, [(0.3, "a"), (0.6, "b")]
    )
    cpl_program.walk(Union(tuple(Implication(Z(), b) for b in bodies)))
    result = dalvi_suciu_lift.solve_succ_query(
        Implication(ans(), Z()), cpl_program
    )
    expected = 1 - (1 - 0.3) * (1 - 0.6)
    assert testing.eq_prov_relations(
        result, testing.make_prov_set([(expected,)], ("_p_",))
    )

@pytest.mark.parametrize("answer", (False, True))
def test_choice_with_a_repeated_variable(answer):
    """C(x, x) on a probabilistic choice C is ranked into a selection of C,
    which is still a choice: its tuples are mutually exclusive."""
    C, Z, ans, x = (Symbol(n) for n in ("C", "Z", "ans", "x"))
    cpl_program = CPLogicProgram()
    cpl_program.add_probabilistic_choice_from_tuples(
        C, [(0.5, "a", "b"), (0.3, "b", "b"), (0.2, "a", "a")]
    )
    if answer:
        cpl_program.walk(Union((Implication(Z(x), C(x, x)),)))
        query = Implication(ans(x), Z(x))
        expected = testing.make_prov_set(
            [(0.3, "b"), (0.2, "a")], ("_p_", "x")
        )
    else:
        cpl_program.walk(Union((Implication(Z(), C(x, x)),)))
        query = Implication(ans(), Z())
        expected = testing.make_prov_set([(0.5,)], ("_p_",))
    result = dalvi_suciu_lift.solve_succ_query(query, cpl_program)
    assert testing.eq_prov_relations(result, expected)


def _choice_table():
    s = Symbol("s")
    C, M = Symbol("C"), Symbol("M")
    return s, C, M, {
        C: ProbabilisticChoiceSet(
            Constant[AbstractSet](NamedRelationalAlgebraFrozenSet(
                columns=("p", "v"), iterable=[(0.5, 1), (0.5, 2)]
            )),
            Constant(ColumnStr("p")),
        ),
        M: Constant[AbstractSet](NamedRelationalAlgebraFrozenSet(
            columns=("v", "w"), iterable=[(1, "a"), (2, "b")]
        )),
    }


def test_disjoint_separator_aligns_the_choice_atoms():
    s, C, M, symbol_table = _choice_table()
    f = Symbol("f")
    union = Disjunction((
        ExistentialPredicate(s, Conjunction((C(s), M(s, Constant("a"))))),
        ExistentialPredicate(f, Conjunction((C(f), M(f, Constant("b"))))),
    ))
    applies, plan = dalvi_suciu_lift.disjoint_separator(union, symbol_table)
    assert applies and isinstance(plan, DisjointProjection)


def test_disjoint_separator_declines():
    """No separator: a disjunct without the choice, a choice of two
    columns aligned on one only, or a disjunct without a free variable of
    the query."""
    s, C, M, symbol_table = _choice_table()
    f, u, t = Symbol("f"), Symbol("u"), Symbol("t")
    C2 = Symbol("C2")
    symbol_table[C2] = ProbabilisticChoiceSet(
        Constant[AbstractSet](NamedRelationalAlgebraFrozenSet(
            columns=("p", "v", "w"), iterable=[(0.5, 1, "a"), (0.5, 2, "b")]
        )),
        Constant(ColumnStr("p")),
    )
    queries = [
        Disjunction((
            ExistentialPredicate(s, Conjunction((C(s), M(s, t)))),
            ExistentialPredicate(f, M(f, t)),
        )),
        Disjunction((
            ExistentialPredicate(s, Conjunction((C2(s, t), M(s, t)))),
            ExistentialPredicate(f, ExistentialPredicate(u, Conjunction((
                C2(f, u), M(f, t)
            )))),
        )),
        Disjunction((
            ExistentialPredicate(s, Conjunction((C(s), M(s, t)))),
            ExistentialPredicate(f, Conjunction((C(f), M(f, Constant("a"))))),
        )),
    ]
    for query in queries:
        assert dalvi_suciu_lift.disjoint_separator(
            query, symbol_table
        ) == (False, None), query


def test_disjoint_separator_lifts_queries_with_a_negation():
    """
    The sum over the choice is sound whatever the sign of the other
    literals, and the plan of the deterministic rest has the negation as a
    difference of sets: the choice atoms in it are replaced by their
    support, so that every label is 0 or 1.
    """
    s, C, M, symbol_table = _choice_table()
    f, t = Symbol("f"), Symbol("t")
    for query in [
        ExistentialPredicate(s, Conjunction((
            C(s), Negation(M(s, Constant("a")))
        ))),
        Disjunction((
            ExistentialPredicate(s, Conjunction((
                C(s), M(s, t), Negation(M(s, Constant("a")))
            ))),
            ExistentialPredicate(f, Conjunction((C(f), M(f, t)))),
        )),
    ]:
        applies, plan = dalvi_suciu_lift.disjoint_separator(
            query, symbol_table
        )
        assert applies, query
        assert isinstance(plan, DisjointProjection)


@pytest.mark.parametrize("answer", (False, True))
def test_disjoint_separator_with_a_rest_of_different_columns(answer):
    """∃x, y C(x, y) ∧ (R(x) ∨ T(y)), the second rule having C(y, x):
    the rest R(a) ∨ T(b) of the tuple (a, b) of C has disjuncts with
    different columns, and is lifted joined with the tuples of C:
    Σ_(a, b) P[C(a, b)] P[R(a) ∨ T(b)]."""
    C, R, T, Z, ans = (Symbol(n) for n in ("C", "R", "T", "Z", "ans"))
    x, y, z = (Symbol(n) for n in ("x", "y", "z"))
    cpl_program = CPLogicProgram()
    cpl_program.add_probabilistic_choice_from_tuples(
        C, [(0.5, "a", "b"), (0.3, "b", "a"), (0.2, "a", "a")]
    )
    cpl_program.add_probabilistic_facts_from_tuples(
        R, [(0.4, "a", 1), (0.7, "b", 1)]
    )
    cpl_program.add_probabilistic_facts_from_tuples(
        T, [(0.6, "a", 1), (0.5, "b", 2)]
    )
    head = Z(z) if answer else Z()
    cpl_program.walk(Union((
        Implication(head, Conjunction((C(x, y), R(x, z)))),
        Implication(head, Conjunction((C(y, x), T(x, z)))),
    )))
    if answer:
        query = Implication(ans(z), Z(z))
        expected = [(0.5 * 0.4 + 0.3 * 0.88 + 0.2 * 0.76, 1), (0.25, 2)]
        columns = ("_p_", "z")
    else:
        query = Implication(ans(), Z())
        expected = [(0.5 * 0.7 + 0.3 * 0.88 + 0.2 * 0.76,)]
        columns = ("_p_",)
    result = dalvi_suciu_lift.solve_succ_query(query, cpl_program)
    assert testing.eq_prov_relations(
        result, testing.make_prov_set(expected, columns)
    )


@pytest.mark.parametrize("negated", (False, True))
def test_disjoint_separator_rest_with_another_atom_of_the_choice(negated):
    """The rest R(s) ∨ T(t) of C(s, t) is joined with the tuples of C
    only when it has no other atom of C, here ¬C(t, s), which depends on
    C(s, t)."""
    C, R, T = Symbol("C"), Symbol("R"), Symbol("T")
    s, t = Symbol("s"), Symbol("t")
    cpl_program = CPLogicProgram()
    cpl_program.add_probabilistic_choice_from_tuples(
        C, [(0.5, "a", "b"), (0.5, "b", "a")]
    )
    cpl_program.add_probabilistic_facts_from_tuples(R, [(0.4, "a")])
    cpl_program.add_probabilistic_facts_from_tuples(T, [(0.6, "a")])
    rest = (Negation(C(t, s)), R(s)) if negated else (R(s),)
    query = Disjunction((
        ExistentialPredicate(s, ExistentialPredicate(t, Conjunction(
            (C(s, t),) + rest
        ))),
        ExistentialPredicate(s, ExistentialPredicate(t, Conjunction(
            (C(t, s), T(s))
        ))),
    ))
    symbol_table = generate_probabilistic_symbol_table_for_query(
        cpl_program, query
    )
    applies, plan = dalvi_suciu_lift.disjoint_separator(query, symbol_table)
    assert applies
    assert dalvi_suciu_lift.is_pure_lifted_plan(plan) != negated


def test_clauses_are_range_restricted():
    """
    A clause that is a disjunction with a negated atom whose variable no
    positive atom of the disjunct binds is not safe range; a negation
    alone, a clause of a conjunction, is not a disjunction.
    """
    f, t = Symbol("f"), Symbol("t")
    A, B = Symbol("A"), Symbol("B")
    unsafe = Conjunction((
        ExistentialPredicate(f, A(f, t)),
        Disjunction((ExistentialPredicate(f, A(f, t)), Negation(B(t)))),
    ))
    safe = Conjunction((
        ExistentialPredicate(f, A(f, t)),
        Disjunction((
            ExistentialPredicate(f, A(f, t)),
            Conjunction((B(t), A(f, t))),
        )),
    ))
    negation_alone = Conjunction((
        ExistentialPredicate(f, A(f, t)), Negation(B(t))
    ))
    assert not dalvi_suciu_lift._clauses_are_range_restricted(unsafe)
    assert dalvi_suciu_lift._clauses_are_range_restricted(safe)
    assert dalvi_suciu_lift._clauses_are_range_restricted(negation_alone)


def test_choice_terms_as_equalities():
    """C(s) ≡ ∃f' (C(f') ∧ f' = s) at a position where another disjunct
    has a quantified variable, and C(f) ∧ C(f') ≡ C(f) ∧ f = f', whose
    fresh f' is then substituted."""
    C, M = Symbol("C"), Symbol("M")
    s, f = Symbol("s"), Symbol("f")
    rewriter = dalvi_suciu_lift.ChoiceTermsAsEqualities({C}, {(C, 0)}, {f})
    rewritten = rewriter.walk(Conjunction((C(s), M(s))))
    fresh, = rewriter.fresh
    assert set(rewritten.formulas) == {C(fresh), M(s), EQ(fresh, s)}
    rewriter = dalvi_suciu_lift.ChoiceTermsAsEqualities({C}, {(C, 0)}, {f})
    rewritten = rewriter.walk(Conjunction((C(f), M(f), C(s))))
    assert rewriter.fresh == set()
    assert set(rewritten.formulas) == {C(f), M(f), EQ(f, s)}


@pytest.mark.parametrize("function", (True, False))
def test_separator_determined_by_a_functional_dependency(function):
    """∃x∃y R(x) ∧ F(x, y) ∧ T(y), with F deterministic: y separates the
    query when F is a function of x, each tuple of R then being in the
    subquery of one y only; the query is #P-hard otherwise."""
    R, F, T, Z, ans = (Symbol(n) for n in ("R", "F", "T", "Z", "ans"))
    x, y = Symbol("x"), Symbol("y")
    cpl_program = CPLogicProgram()
    cpl_program.add_probabilistic_facts_from_tuples(
        R, [(0.5, 1), (0.4, 2), (0.3, 3)]
    )
    cpl_program.add_probabilistic_facts_from_tuples(
        T, [(0.6, "a"), (0.7, "b")]
    )
    cpl_program.add_extensional_predicate_from_tuples(
        F, [(1, "a"), (2, "a"), (3, "b")] + ([] if function else [(3, "a")])
    )
    cpl_program.walk(Union((
        Implication(Z(), Conjunction((R(x), F(x, y), T(y)))),
    )))
    query = Implication(ans(), Z())
    if not function:
        with pytest.raises(NonLiftableException):
            dalvi_suciu_lift.solve_succ_query(query, cpl_program)
        return
    result = dalvi_suciu_lift.solve_succ_query(query, cpl_program)
    expected = 1 - (1 - 0.6 * (1 - 0.5 * 0.6)) * (1 - 0.7 * 0.3)
    assert testing.eq_prov_relations(
        result, testing.make_prov_set([(expected,)], ("_p_",))
    )


def test_functional_dependency_in_one_disjunct_only():
    """A tuple of R in the subqueries of f(x) and of g(x): y is not a
    separator of ∃y (∃x R(x) ∧ F(x, y) ∧ T(y)) ∨ (∃x R(x) ∧ G(x, y))."""
    R, F, G, T = (Symbol(n) for n in ("R", "F", "G", "T"))
    x, y = Symbol("x"), Symbol("y")
    symbol_table = {
        R: ProbabilisticFactSet(Symbol("r"), Constant(0)),
        T: ProbabilisticFactSet(Symbol("t"), Constant(0)),
        F: DeterministicFactSet(Constant[AbstractSet](
            NamedRelationalAlgebraFrozenSet(("a", "b"), [(1, 1), (2, 2)])
        )),
        G: DeterministicFactSet(Constant[AbstractSet](
            NamedRelationalAlgebraFrozenSet(("a", "b"), [(1, 2), (2, 1)])
        )),
    }
    conjunction = Conjunction((R(x), F(x, y), T(y)))
    query = ExistentialPredicate(y, ExistentialPredicate(x, Disjunction((
        conjunction, Conjunction((R(x), G(x, y)))
    ))))
    assert y not in dalvi_suciu_lift.find_separator_variables(
        query, symbol_table
    )[0]
    assert y in dalvi_suciu_lift.find_separator_variables(
        ExistentialPredicate(y, ExistentialPredicate(x, conjunction)),
        symbol_table
    )[0]


@pytest.mark.parametrize("function", (True, False))
def test_functional_dependency_through_the_same_path_in_disjuncts(function):
    """∃y (∃x R(x) ∧ F(x, y) ∧ T(y)) ∨ (∃x R(x) ∧ F(x, y) ∧ U(y)): a tuple
    of R is in the subqueries of f(x) only, through F in both disjuncts,
    when F is a function of x, and y then separates the query."""
    R, F, T, U, Z, ans = (
        Symbol(n) for n in ("R", "F", "T", "U", "Z", "ans")
    )
    x, y = Symbol("x"), Symbol("y")
    cpl_program = CPLogicProgram()
    cpl_program.add_probabilistic_facts_from_tuples(
        R, [(0.5, 1), (0.4, 2), (0.3, 3)]
    )
    cpl_program.add_probabilistic_facts_from_tuples(
        T, [(0.6, "a"), (0.7, "b")]
    )
    cpl_program.add_probabilistic_facts_from_tuples(
        U, [(0.2, "a"), (0.9, "b")]
    )
    cpl_program.add_extensional_predicate_from_tuples(
        F, [(1, "a"), (2, "a"), (3, "b")] + ([] if function else [(3, "a")])
    )
    cpl_program.walk(Union((
        Implication(Z(), Conjunction((R(x), F(x, y), T(y)))),
        Implication(Z(), Conjunction((R(x), F(x, y), U(y)))),
    )))
    query = Implication(ans(), Z())
    if not function:
        with pytest.raises(NonLiftableException):
            dalvi_suciu_lift.solve_succ_query(query, cpl_program)
        return
    result = dalvi_suciu_lift.solve_succ_query(query, cpl_program)
    expected = 1 - (
        (1 - (1 - 0.5 * 0.6) * (1 - 0.8 * 0.4)) *
        (1 - 0.3 * (1 - 0.3 * 0.1))
    )
    assert testing.eq_prov_relations(
        result, testing.make_prov_set([(expected,)], ("_p_",))
    )


def test_set_partitions():
    partitions = list(dalvi_suciu_lift._set_partitions([1, 2, 3]))
    assert sorted(sorted(map(sorted, p)) for p in partitions) == [
        [[1], [2], [3]], [[1], [2, 3]], [[1, 2], [3]], [[1, 2, 3]],
        [[1, 3], [2]],
    ]
    assert [len(list(dalvi_suciu_lift._set_partitions(list(range(k)))))
            for k in range(5)] == [1, 1, 2, 5, 15]


@pytest.fixture
def check_unate_off():
    check_unate = config.get_probabilistic_solver_check_unate()
    config.disable_probabilistic_solver_check_unate()
    yield
    if check_unate:
        config.enable_probabilistic_solver_check_unate()


def _program_to_decline():
    T, R, S = Symbol("T"), Symbol("R"), Symbol("S")
    cpl_program = CPLogicProgram()
    cpl_program.add_probabilistic_facts_from_tuples(
        T, [(0.5, "a"), (0.6, "b")]
    )
    cpl_program.add_probabilistic_facts_from_tuples(
        R, [(0.3, "a", "c"), (0.7, "b", "c")]
    )
    cpl_program.add_probabilistic_facts_from_tuples(S, [(0.4, "a", "c")])
    return cpl_program, T, R, S


def test_formula_outside_fo_existential_negation_is_declined():
    """The conversions to normal forms fail on a formula outside FO∃¬,
    such as a rule: the planner declines it."""
    cpl_program, T, R, S = _program_to_decline()
    ans, x, y = Symbol("ans"), Symbol("x"), Symbol("y")
    rule = Implication(
        ans(x),
        Conjunction(
            (
                T(x),
                UniversalPredicate(
                    y, Disjunction((Negation(R(x, y)), S(x, y)))
                ),
            )
        ),
    )
    symbol_table = generate_probabilistic_symbol_table_for_query(
        cpl_program, rule.antecedent
    )
    with pytest.raises(NonLiftableException) as error:
        dalvi_suciu_lift.dalvi_suciu_lift(rule, symbol_table)
    assert isinstance(error.value, UnsupportedSolverError)
    assert isinstance(error.value.__cause__, NotInFONegE)


@pytest.mark.parametrize("unate", ("on", "off"))
def test_union_with_a_negated_component_is_not_planned(request, unate):
    """∃y R(x, y) ∨ ¬T(x): the union of a negation is not planned, rather
    than planned without a negative operation."""
    if unate == "off":
        request.getfixturevalue("check_unate_off")
    cpl_program, T, R, _ = _program_to_decline()
    x, y = Symbol("x"), Symbol("y")
    formula = Disjunction((ExistentialPredicate(y, R(x, y)), Negation(T(x))))
    symbol_table = generate_probabilistic_symbol_table_for_query(
        cpl_program, formula
    )
    plan = dalvi_suciu_lift.dalvi_suciu_lift(formula, symbol_table)
    assert not dalvi_suciu_lift.is_pure_lifted_plan(plan)


def test_negated_component_without_the_unate_check(check_unate_off):
    """H(x) ← U(x) ∧ S(x, y) ∧ R(x, z) ∧ ¬U(y) reaches a union with a
    negated component, which the planner declined with a ValueError."""
    U, S, R, H, ans = (Symbol(n) for n in ("U", "S", "R", "H", "ans"))
    x, y, z = Symbol("x"), Symbol("y"), Symbol("z")
    probabilistic_facts = {
        U: [(0.3, "c"), (0.2, "a")],
        S: [(0.4, "a", "c"), (0.5, "c", "b")],
        R: [(0.3, "a", "c"), (0.7, "b", "c"), (0.4, "c", "a")],
    }
    rules = [
        Implication(
            H(x), Conjunction((U(x), S(x, y), R(x, z), Negation(U(y))))
        )
    ]

    def oracle(database):
        return {
            (a,)
            for (a,) in database[U]
            for (b, c) in database[S]
            if a == b
            and (c,) not in database[U]
            and any(d == a for d, _ in database[R])
        }

    check(probabilistic_facts, {}, rules, Implication(ans(x), H(x)), oracle)


def test_extremum_conjunct_of_a_subquery():
    """In S(x, y) ∧ V(z, w) ∧ y < w, the greatest w of ∃z V(z, w), whose
    events for different values of w have different tuples, implies the
    query; y is no candidate in R(x) ∧ S(x, y) ∧ y < w, ∃x R(x) ∧ S(x, y)
    sharing R(x) across the values of y, nor w with a comparison x < z of
    a variable of its subquery, or within a term."""
    R, S, V = (Symbol(n) for n in ("R", "S", "V"))
    x, y, z, w = (Symbol(n) for n in ("x", "y", "z", "w"))
    symbol_table = {
        s: ProbabilisticFactSet(Symbol(s.name.lower()), Constant(0))
        for s in (R, S, V)
    }
    variables = {x, y, z, w}
    extremum = dalvi_suciu_lift._extremum_conjunct(
        w, variables, (S(x, y), V(z, w), LT(y, w)), symbol_table
    )
    assert isinstance(extremum, Negation)
    assert extract_logic_free_variables(extremum) == {w}
    atoms = extract_logic_atoms(extremum)
    assert {atom.functor for atom in atoms} == {V, GT}
    assert next(a for a in atoms if a.functor == GT).args[1] == w
    assert dalvi_suciu_lift._extremum_conjunct(
        y, variables, (R(x), S(x, y), V(z, w), LT(y, w)), symbol_table
    ) is None
    assert dalvi_suciu_lift._extremum_conjunct(
        w, variables, (S(x, y), V(z, w), LT(y, w), LT(x, z)), symbol_table
    ) is None
    assert dalvi_suciu_lift._extremum_conjunct(
        w, variables, (S(x, y), V(z, w), LT(y, Constant(abs)(w))),
        symbol_table
    ) is None


def test_order_across_subqueries():
    """∃x ∃y ∃z R(x) ∧ S(x, y) ∧ T(z) ∧ y < z is projected on the greatest
    value m of T, ∃x R(x) ∧ ∃y (S(x, y) ∧ y < m) being lifted with m bound
    by the pairs of values of S and T in order."""
    R, S, T, Z, ans = (Symbol(n) for n in ("R", "S", "T", "Z", "ans"))
    x, y, z = Symbol("x"), Symbol("y"), Symbol("z")
    cpl_program = CPLogicProgram()
    cpl_program.add_probabilistic_facts_from_tuples(R, [(0.5, 1)])
    cpl_program.add_probabilistic_facts_from_tuples(
        S, [(0.6, 1, 1), (0.7, 1, 3)]
    )
    cpl_program.add_probabilistic_facts_from_tuples(T, [(0.8, 2), (0.4, 4)])
    cpl_program.walk(Union((
        Implication(Z(), Conjunction((R(x), S(x, y), T(z), LT(y, z)))),
    )))
    result = dalvi_suciu_lift.solve_succ_query(
        Implication(ans(), Z()), cpl_program
    )
    expected = 0.5 * (0.4 * (1 - 0.4 * 0.3) + 0.6 * 0.8 * 0.6)
    assert testing.eq_prov_relations(
        result, testing.make_prov_set([(expected,)], ("_p_",))
    )


@pytest.mark.parametrize("rows, sample, expected", [
    ([("a", 1), ("b", 2), ("a", 1)], 3, True),
    ([("a", 1), ("a", 2), ("b", 2)], 2, False),  # disproved by the sample
    # the first 3 rows disprove nothing: the distinct values count
    ([("a", 1), ("b", 2), ("c", 3), ("a", 4)], 3, False),
    # missing values are one value, as distinct values count them
    ([("a", float("nan")), ("a", float("nan")), ("b", 1.)], 3, True),
])
def test_a_column_is_a_function_of_others(
    rows, sample, expected, monkeypatch
):
    """Whether a column is a function of others: two of the first rows
    with one key and two values disprove it, without counting the
    distinct values of the relation; the counts decide otherwise."""
    from nl_expr.config import config

    from .. import dalvi_suciu_lift

    monkeypatch.setitem(
        config["PROBABILISTIC_SOLVER"], "function_sample_rows", str(sample)
    )
    relation = NamedRelationalAlgebraFrozenSet(("x", "y"), rows)
    assert dalvi_suciu_lift._is_function(relation, ("x",), "y") is expected
