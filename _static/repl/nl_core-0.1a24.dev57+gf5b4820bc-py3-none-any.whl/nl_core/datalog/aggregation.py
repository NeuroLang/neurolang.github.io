"""
Support for aggregations according to [1]_. For instance
the encoding of ``P(x, count<y>):-Q(x, y)`` in intermediate
representation ``Implication(P(x, AggregationApplication(count, y), Q(x, y))``
produces the set ``P(x, z)`` where ``z`` is the number of tuples ``(x, ...)``
in the set ``Q``.

.. [1] T. J. Green, S. S. Huang, B. T. Loo, W. Zhou,
   Datalog and Recursive Query Processing.
   FNT in Databases. 5, 105–195 (2012).
"""
import operator
import typing

import numpy

from nl_expr.exceptions import (
    ForbiddenExpressionError,
    ForbiddenUnstratifiedAggregation,
    NeuroLangException,
    NotConjunctiveExpressionNestedPredicates,
    SymbolNotFoundError,
)
from nl_expr.expression_walker import (
    FunctionApplicationToPythonLambda,
    PatternWalker,
    ReplaceSymbolsByConstants,
    add_match,
)
from nl_expr.expressions import (
    Constant,
    Expression,
    FunctionApplication,
    Symbol,
)
from nl_expr.type_system import get_generic_type
from ..utils.relational_algebra_set import (
    RelationalAlgebraStringExpression, count_distinct
)
from . import (
    Implication,
    Union,
    is_conjunctive_expression_with_nested_predicates,
)
from .basic_representation import UnionOfConjunctiveQueries
from .expression_processing import (
    extract_logic_atoms,
    is_aggregation_predicate,
    is_aggregation_rule,
)
from .expressions import AggregationApplication, TranslateToLogic
from .range_restriction import check_range_restriction

FA2L = FunctionApplicationToPythonLambda()

AGG_MAX = Symbol("max")
AGG_MEAN = Symbol("mean")
AGG_COUNT = Symbol("count")
AGG_SUM = Symbol("sum")
AGG_STD = Symbol("std")
AGG_MIN = Symbol("min")
AGG_AVG = Symbol("avg")


def is_builtin_aggregation_functor(functor):
    return functor in (
        AGG_MAX, AGG_MIN, AGG_MEAN, AGG_AVG, AGG_COUNT, AGG_SUM, AGG_STD
    )


class BuiltinAggregationMixin:
    constant_max = Constant(numpy.max)
    constant_min = Constant(numpy.min)
    constant_mean = Constant(numpy.mean)
    constant_avg = Constant(numpy.mean)
    constant_sum = Constant(sum)
    constant_std = Constant(numpy.std)

    constant_count = Constant(count_distinct)

    def function_percentile(
        self, values: typing.Iterable, q: float
    ) -> float:
        """
        Return the ``q``-th percentile of ``values``, ignoring NaNs.

        ``q`` is in ``[0, 100]`` and the percentile is linearly
        interpolated, as in :func:`numpy.nanpercentile`.  The rows in the
        top ``p``% of a column ``v`` are those with
        ``v >= percentile(v, 100 - p)``; with ties or interpolation, they
        can be slightly more than ``p``%.
        """
        return float(
            numpy.nanpercentile(numpy.asarray(values, dtype=float), q)
        )


# The operators of arithmetic, which compute a value of each row, not of
# a group: in the head of a rule they are no aggregation.
ARITHMETIC_OPERATORS = {
    operator.add: "+", operator.sub: "-", operator.mul: "*",
    operator.truediv: "/", operator.floordiv: "//", operator.mod: "%",
    operator.pow: "**", operator.neg: "-",
}


class TranslateToLogicWithAggregation(TranslateToLogic):
    @add_match(
        Implication(FunctionApplication(Symbol, ...), Expression),
        lambda rule: any(
            isinstance(arg, FunctionApplication)
            and get_generic_type(type(arg)) is FunctionApplication
            for arg in rule.consequent.args
        )
    )
    def transform_function_application_consequent_to_aggregation(self, rule):
        consequent_arguments = tuple()
        for arg in rule.consequent.args:
            if (
                isinstance(arg, FunctionApplication)
                and get_generic_type(type(arg)) is FunctionApplication
            ):
                if (
                    isinstance(arg.functor, Constant)
                    and arg.functor.value in ARITHMETIC_OPERATORS
                ):
                    raise ForbiddenExpressionError(
                        "An arithmetic operation in the head of a rule "
                        f"({ARITHMETIC_OPERATORS[arg.functor.value]} in "
                        f"{rule.consequent.functor.name}) is not an "
                        "aggregation: compute its value in the body, as "
                        "ans(x, v) :- r(x, n), (v == n / 2)"
                    )
                arg = AggregationApplication(*arg.unapply())
            consequent_arguments += (arg,)

        return self.walk(
            Implication(
                rule.consequent.functor(*consequent_arguments),
                rule.antecedent
            )
        )


class DatalogWithAggregationMixin(PatternWalker):
    @add_match(
        Implication(FunctionApplication(Symbol, ...), Expression),
        is_aggregation_rule
    )
    def statement_intensional_aggregation(self, expression):
        consequent = expression.consequent
        antecedent = expression.antecedent

        self._validate_aggregation_implication_syntax(consequent, antecedent)
        check_range_restriction(expression, self.symbol_table)

        if consequent.functor in self.symbol_table:
            eb = self._new_intensional_internal_representation(consequent)
        else:
            eb = tuple()

        eb = eb + (expression, )
        symbol = consequent.functor.cast(UnionOfConjunctiveQueries)
        self.symbol_table[symbol] = Union(eb)

        return expression

    def _validate_aggregation_implication_syntax(self, consequent, antecedent):
        if consequent.functor in self.protected_keywords:
            raise NeuroLangException(
                f'symbol {self.constant_set_name} is protected'
            )

        aggregation_functor_symbols = set()
        seen_aggregations = 0
        for arg in consequent.args:
            if isinstance(arg, AggregationApplication):
                seen_aggregations += 1
                aggregation_functor_symbols |= arg.functor._symbols
            elif not isinstance(arg, (Constant, Symbol)):
                raise NeuroLangException(
                    f'The consequent {consequent} can only be '
                    'constants, symbols'
                )

        consequent_symbols = (
            consequent._symbols - consequent.functor._symbols -
            aggregation_functor_symbols
        )

        if not consequent_symbols.issubset(antecedent._symbols):
            raise NeuroLangException(
                "All variables on the consequent need to be on the antecedent"
            )

        if not is_conjunctive_expression_with_nested_predicates(
            antecedent, allow_negation=True
        ):
            raise NotConjunctiveExpressionNestedPredicates(
                f'Expression {antecedent} is not conjunctive'
            )


class ChaseAggregationMixin:
    """Aggregation Chase Mixin to add support for aggregation to a Chase
    class. Can be used with StratifiedChase.
    """
    def check_constraints(self, instance_update):
        seen_in_stratum = set()
        aggregate_rules = []
        for rule in self.rules:
            seen_in_stratum.add(rule.consequent.functor)
            if is_aggregation_rule(rule):
                aggregate_rules.append(rule)

        self._stratum_is_aggregation_viable(
            seen_in_stratum, aggregate_rules
        )

        super().check_constraints(instance_update)

    def _stratum_is_aggregation_viable(self, seen_in_stratum, aggregate_rules):
        for rule in aggregate_rules:
            if any(
                atom.functor in seen_in_stratum
                for atom in extract_logic_atoms(rule.antecedent)
            ):
                raise ForbiddenUnstratifiedAggregation(
                    f"Unstratifiable aggregation {rule.consequent.functor}"
                )

    def compute_result_set(
        self, rule, substitutions, instance, restriction_instance=None
    ):
        if not is_aggregation_rule(rule):
            return super().compute_result_set(
                rule,
                substitutions,
                instance,
                restriction_instance=restriction_instance
            )
        if restriction_instance is None:
            restriction_instance = dict()

        group_vars, output_args = self._get_groups_and_aggregations(rule)
        new_tuples = (
            substitutions
            .aggregate(group_vars, output_args)
            .projection_to_unnamed(*(oa[0] for oa in output_args))
        )
        new_tuples = self.datalog_program.new_set(new_tuples)
        return self.compute_instance_update(
            rule, new_tuples, instance, restriction_instance
        )

    def _get_groups_and_aggregations(self, rule):
        output_args = []
        group_vars = []
        for arg in rule.consequent.args:
            if isinstance(arg, Symbol):
                group_vars.append(arg.name)
                aggregation_args = arg.name
                fun = RelationalAlgebraStringExpression('first')
            elif isinstance(arg, AggregationApplication):
                aggregation_args, fun = self._obtain_aggregations(arg)
            output_args.append(
                (
                    Symbol.fresh().name,
                    aggregation_args,
                    fun
                )
            )
        return group_vars, output_args

    def _obtain_aggregations(self, arg):
        if (
            len(arg.args) == 1 and
            isinstance(arg.args[0], Symbol)
        ):
            resolved_functor = self.datalog_program.walk(arg.functor)
            if not (
                isinstance(resolved_functor, Constant)
                and callable(resolved_functor.value)
            ):
                raise SymbolNotFoundError(f"Symbol not found {arg.functor}")
            fun = resolved_functor.value
            aggregation_args = arg.args[0].name
        else:
            aggregation_args = None
            fa = ReplaceSymbolsByConstants(
                self.datalog_program.symbol_table
            ).walk(FunctionApplication(*arg.unapply()))
            fun_, arg_names = FA2L.walk(fa)
            fun_str = (
                "lambda t: fun_(" +
                ", ".join(f't.{arg_}' for arg_ in arg_names) +
                ")"
            )
            # Globals of their own, so that the lambdas of several
            # aggregations of a head don't all call the last fun_.
            fun = eval(fun_str, dict(globals(), fun_=fun_))
            if (
                hasattr(fun_, "__annotations__")
                and "return" in fun_.__annotations__
            ):
                fun.__annotations__["return"] = fun_.__annotations__["return"]
        return aggregation_args, fun

    def eliminate_already_computed(self, consequent, instance, substitutions):
        if is_aggregation_predicate(consequent):
            return substitutions

        return super().eliminate_already_computed(
            consequent, instance, substitutions
        )
