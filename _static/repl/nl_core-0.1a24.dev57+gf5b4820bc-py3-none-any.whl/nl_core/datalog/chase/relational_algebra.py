import logging
import operator
from collections import ChainMap
from functools import wraps
from typing import AbstractSet, Callable


from nl_expr.exceptions import (
    ProjectionOverMissingColumnsError,
    UnboundVariablesError,
    WrongArgumentsInPredicateError,
)
from nl_expr.expressions import Constant, FunctionApplication, Symbol
from nl_expr.expression_walker import ExpressionWalker, ReplaceSymbolWalker
from nl_expr.logic.unification import apply_substitution_arguments
from ...relational_algebra import (ColumnInt, Product, Projection,
                                   RelationalAlgebraOptimiser,
                                   PushInSelections,
                                   RelationalAlgebraSolver, Selection, eq_,
                                   str2columnstr_constant)
from ...relational_algebra.optimisers.columns import _ra_columns
from nl_expr.type_system import Unknown, is_leq_informative
from ...utils.relational_algebra_set import NamedRelationalAlgebraFrozenSet
from ..expression_processing import extract_logic_free_variables
from ..expressions import Conjunction, Implication
from ..instance import MapInstance
from ..translate_to_named_ra import TranslateToNamedRA
from ..wrapped_collections import (WrappedNamedRelationalAlgebraFrozenSet,
                                   WrappedRelationalAlgebraSet)


LOG = logging.getLogger(__name__)


invert = Constant(operator.invert)
eq = Constant(operator.eq)


def _cached_in_chase(method, maxsize=1024):
    """
    Cache *method* in the chase it is called on, as ``lru_cache`` would,
    keeping at most *maxsize* results.

    ``lru_cache`` on a method is a cache of the class, whose keys hold the
    chase: it kept every chase that ran alive, with its program and the
    relations of its query (a forked REPL session kept 0.6 GB more after
    each query decoding an image on neurosynth). A key with the chase only
    ever matched that chase, so a cache of its own finds the same.
    """
    attribute = f"_cache_{method.__name__}"

    @wraps(method)
    def cached(self, *args, **kwargs):
        cache = self.__dict__.setdefault(attribute, {})
        key = (args, tuple(sorted(kwargs.items())))
        try:
            return cache[key]
        except KeyError:
            if len(cache) >= maxsize:
                cache.clear()
            value = cache[key] = method(self, *args, **kwargs)
            return value

    return cached


class ChaseRelationalAlgebraPlusCeriMixin:
    """
    Conjunctive query solving using Ceri et al [1]_ algorithm for unnamed
    positive relational algebra.

    .. [1] S. Ceri, G. Gottlob, L. Lavazza, in Proceedings of the 12th
       International Conference on Very Large Data Bases
       (Morgan Kaufmann Publishers Inc.,
       San Francisco, CA, USA, 1986;
       http://dl.acm.org/citation.cfm?id=645913.671468), VLDB ’86, pp. 395–402.
    """
    def obtain_substitutions(self, args_to_project, rule_predicates_iterator):
        ra_code, projected_var_names = self.translate_to_ra_plus(
            args_to_project,
            rule_predicates_iterator
        )
        ra_code_opt = RelationalAlgebraOptimiser().walk(ra_code)
        if not isinstance(ra_code_opt, Constant) or len(ra_code_opt.value) > 0:
            LOG.info('About to execute RA query %s', ra_code)
            result = RelationalAlgebraSolver().walk(ra_code_opt)
        else:
            return [{}]

        substitutions = self.compute_substitutions(result, projected_var_names)

        return substitutions

    def translate_to_ra_plus(
        self,
        args_to_project,
        rule_predicates_iterator
    ):
        self.seen_vars = dict()
        self.selections = []
        self.projections = tuple()
        self.projected_var_names = dict()
        column = 0
        new_ra_expressions = tuple()
        rule_predicates_iterator = list(rule_predicates_iterator)
        for pred_ra in rule_predicates_iterator:
            ra_expression_arity = pred_ra[1].arity
            new_ra_expression = self.translate_predicate(
                pred_ra, column, args_to_project
            )
            new_ra_expressions += (new_ra_expression,)
            column += ra_expression_arity
        if len(new_ra_expressions) > 0:
            if len(new_ra_expressions) == 1:
                relation = new_ra_expressions[0]
            else:
                relation = Product(new_ra_expressions)
            for s1, s2 in self.selections:
                relation = Selection(relation, eq_(s1, s2))
            relation = Projection(relation, self.projections)
        else:
            relation = Constant[AbstractSet](self.datalog_program.new_set())
        projected_var_names = self.projected_var_names
        del self.seen_vars
        del self.selections
        del self.projections
        del self.projected_var_names
        return relation, projected_var_names

    def translate_predicate(self, pred_ra, column, args_to_project):
        predicate, ra_expression = pred_ra
        local_selections = []
        for i, arg in enumerate(predicate.args):
            c = Constant[ColumnInt](ColumnInt(column + i))
            local_column = Constant[ColumnInt](ColumnInt(i))
            self.translate_predicate_process_argument(
                arg, local_selections, local_column, c, args_to_project
            )
        new_ra_expression = Constant[AbstractSet](ra_expression)
        for s1, s2 in local_selections:
            new_ra_expression = Selection(new_ra_expression, eq_(s1, s2))
        return new_ra_expression

    def translate_predicate_process_argument(
        self, arg, local_selections, local_column,
        global_column, args_to_project
    ):
        if isinstance(arg, Constant):
            local_selections.append((local_column, arg))
        elif isinstance(arg, Symbol):
            self.translate_predicate_process_argument_symbol(
                arg, global_column, args_to_project
            )

    def translate_predicate_process_argument_symbol(
        self, arg, global_column, args_to_project
    ):
        if arg in self.seen_vars:
            self.selections.append((self.seen_vars[arg], global_column))
        else:
            if arg in args_to_project:
                self.projected_var_names[arg] = len(self.projections)
                self.projections += (global_column,)
            self.seen_vars[arg] = global_column

    def compute_substitutions(self, result, projected_var_names):
        substitutions = []
        for tuple_ in result.value:
            subs = {
                var: tuple_.value[col]
                for var, col in projected_var_names.items()
            }
            substitutions.append(subs)
        return substitutions


class NamedRelationalAlgebraOptimiser(
    PushInSelections,
    ExpressionWalker
):
    pass


class _RelationsOrEmpty(ChainMap):
    """The relations of its mappings, the first holding them first, and
    an empty relation for a symbol of none."""

    def __missing__(self, symbol):
        return Constant[AbstractSet](
            WrappedRelationalAlgebraSet(), verify_type=False
        )


class ChaseNamedRelationalAlgebraMixin:
    """
    Conjunctive query solving using the algorithm 5.4.8 from Abiteboul et al
    [1]_ algorithm for named relational algebra.

    ..[1] S. Abiteboul, R. Hull, V. Vianu, Foundations of databases
      (Addison Wesley, 1995), Addison-Wesley.

    """
    def chase_step(self, instance, rule, restriction_instance=None):
        try:
            if restriction_instance is None:
                restriction_instance = MapInstance()

            rule = self.rewrite_constants_in_consequent(rule)
            rule = self.rewrite_antecedent_equalities(rule)

            consequent = rule.consequent

            if isinstance(rule.antecedent, Conjunction):
                predicates = rule.antecedent.formulas
            else:
                predicates = (rule.antecedent,)

            substitutions = self._rule_substitutions(
                rule, predicates, instance, restriction_instance
            )

            if consequent.functor in instance:
                substitutions = self.eliminate_already_computed(
                    consequent, instance, substitutions
                )
            if consequent.functor in restriction_instance:
                substitutions = self.eliminate_already_computed(
                    consequent, restriction_instance, substitutions
                )

            return self.compute_result_set(
                rule, substitutions, instance, restriction_instance
            )
        except ProjectionOverMissingColumnsError:
            raise WrongArgumentsInPredicateError(
                "There is a predicate in the query with the "
                "wrong number of arguments."
            )

    @_cached_in_chase
    def rewrite_constants_in_consequent(self, rule):
        new_equalities = []
        new_args = tuple()
        for arg in rule.consequent.args:
            if isinstance(arg, Constant):
                fresh = Symbol[arg.type].fresh()
                new_equalities.append(eq_(fresh, arg))
                arg = fresh
            new_args += (arg,)
        if len(new_equalities) > 0:
            rule = self.rewrite_rule_consequent_constants_to_equalities(
                rule, new_args, new_equalities
            )
        return rule

    @_cached_in_chase
    def rewrite_antecedent_equalities(self, rule):
        if not isinstance(rule.antecedent, Conjunction):
            return rule

        free_variables = (
            extract_logic_free_variables(rule.antecedent) |
            extract_logic_free_variables(rule.consequent)
        )
        cont = True
        while cont:
            cont = False
            for pos, predicate in enumerate(rule.antecedent.formulas):
                if (
                    isinstance(predicate, FunctionApplication) and
                    predicate.functor == eq and
                    predicate.args[0] in free_variables and
                    predicate.args[1] in free_variables
                ):
                    equality = predicate
                    new_antecedent_preds = (
                        rule.antecedent.formulas[:pos] +
                        rule.antecedent.formulas[pos + 1:]
                    )
                    cont = len(new_antecedent_preds) > 1
                    new_antecedent = Conjunction(new_antecedent_preds)
                    rule = Implication(rule.consequent, new_antecedent)
                    rule = ReplaceSymbolWalker(
                        {equality.args[0]: equality.args[1]}
                    ).walk(rule)
        return rule

    @staticmethod
    def rewrite_rule_consequent_constants_to_equalities(
        rule, new_args, new_equalities
    ):
        consequent = rule.consequent.functor(*new_args)
        if isinstance(rule.antecedent, Conjunction):
            antecedent_formulas = rule.antecedent.formulas
        else:
            antecedent_formulas = (rule.antecedent,)
        antecedent = Conjunction(
            antecedent_formulas + tuple(new_equalities)
        )
        rule = Implication(consequent, antecedent)
        return rule

    def eliminate_already_computed(self, consequent, instance, substitutions):
        substitutions_columns = set(substitutions.columns)
        if (
            substitutions.is_empty()
            or substitutions_columns.isdisjoint(consequent.args)
            or instance[consequent.functor].value.is_empty()
        ):
            return substitutions

        args = []
        args_to_project = []
        for i, arg in enumerate(consequent.args):
            if not isinstance(arg, Symbol) or arg.name in args:
                continue
            args.append(arg.name)
            args_to_project.append(i)

        already_computed = NamedRelationalAlgebraFrozenSet(
            args,
            (
                instance[consequent.functor]
                .value.unwrap()
                .projection(*args_to_project)
            )
        )
        if substitutions_columns.symmetric_difference(args):
            already_computed = (
                already_computed
                .naturaljoin(substitutions)
                .projection(*substitutions.columns)
            )
        substitutions_unwrapped = substitutions.unwrap()
        substitutions_unwrapped = substitutions_unwrapped - already_computed

        res = WrappedNamedRelationalAlgebraFrozenSet(
            substitutions_unwrapped.columns,
            substitutions_unwrapped,
            row_type=substitutions.row_type,
            verify_row_type=False
        )

        return res

    @staticmethod
    def ra_symbol_table(predicates, instance, restriction_instance):
        """
        Return the symbol table the RA plan of ``predicates`` runs on.

        Relations are taken from ``instance`` merged with
        ``restriction_instance``, except for the positive predicates
        found in ``restriction_instance``, which are bound to it alone.
        Those of ``instance`` are looked up when the plan reads them, not
        copied: copying them all, at every step of the chase, cost a
        quarter of an empty step.
        """
        symbol_table = _RelationsOrEmpty({}, instance)
        positive = {
            predicate.functor for predicate in predicates
            if isinstance(predicate, FunctionApplication)
        }
        used = set().union(*(predicate._symbols for predicate in predicates))
        # Differential evaluation: a positive body predicate is bound to the
        # delta alone, without merging it with the instance, which would
        # cost as much as the relation; the other predicates of the rule
        # (negated ones) are bound to both so that set-difference (RA
        # difference) computes correctly. A predicate the rule does not use
        # is left as it is, not even looked up: merging it would cost as
        # much as the relation, at every step of the chase, for nothing.
        for k in positive | used:
            try:
                v = restriction_instance[k]
            except KeyError:  # not a relation, or none of its tuples
                continue
            if k in positive or k not in symbol_table:
                symbol_table[k] = v
            else:
                symbol_table[k] = Constant[v.type](
                    symbol_table[k].value | v.value,
                    auto_infer_type=False, verify_type=False,
                )
        return symbol_table

    def _rule_substitutions(
        self, rule, predicates, instance, restriction_instance
    ):
        """
        Return the substitutions of the *predicates* of the body of
        *rule*, naming the rule in the error if a variable is unbound.
        """
        try:
            return self.obtain_substitutions(
                predicates, instance, restriction_instance,
                columns=self._head_columns(rule),
            )
        except UnboundVariablesError as error:
            functor = rule.consequent.functor
            if error.rule is not None or functor.is_fresh:
                raise
            raise error.located(functor.name) from None

    @staticmethod
    def _head_columns(rule):
        """
        Return the variables of the head of *rule*, which its substitutions
        need, or None for all those of its body.

        Projected on them, the substitutions are as many as the rows of the
        head, not as the combinations of the variables of the body; a head
        with other arguments (an aggregation's) keeps them all.
        """
        args = rule.consequent.args
        if not all(isinstance(arg, (Symbol, Constant)) for arg in args):
            return None
        return tuple(dict.fromkeys(
            arg.name for arg in args if isinstance(arg, Symbol)
        ))

    def obtain_substitutions(
        self, rule_predicates_iterator, instance, restriction_instance,
        columns=None,
    ):
        """
        Return the substitutions of the conjunction of the predicates, on
        *columns* only if given (see :meth:`_head_columns`).
        """
        predicates = tuple(rule_predicates_iterator)
        symbol_table = self.ra_symbol_table(
            predicates, instance, restriction_instance
        )

        if len(predicates) == 0:
            return [{}]

        ra_code = self.translate_conjunction_to_named_ra(
            Conjunction(predicates), columns
        )

        LOG.info('About to execute RA query %s', ra_code)
        result = RelationalAlgebraSolver(symbol_table).walk(ra_code)

        result_value = result.value
        substitutions = WrappedNamedRelationalAlgebraFrozenSet(
            result_value.columns,
            result_value
        )

        return substitutions

    @_cached_in_chase
    def translate_conjunction_to_named_ra(self, conjunction, columns=None):
        if not hasattr(self, "_builtins"):
            self._builtins = self.datalog_program.builtins()

        builtin_symbols = self._builtins
        rsw = ReplaceSymbolWalker(builtin_symbols)
        conjunction = rsw.walk(conjunction)
        traslator_to_named_ra = TranslateToNamedRA()
        LOG.info(f"Translating and optimising CQ {conjunction} to RA")
        ra_code = traslator_to_named_ra.walk(conjunction)
        ra_code = self._project_on(ra_code, columns)
        ra_code = NamedRelationalAlgebraOptimiser().walk(ra_code)
        ra_code = RelationalAlgebraOptimiser().walk(ra_code)
        return ra_code

    @staticmethod
    def _project_on(ra_code, columns):
        """
        Return *ra_code* projected on *columns*, for the optimisers to
        push the projection into its joins; as it is when *columns* is None,
        empty, all its columns, or not all among them.
        """
        if not columns:
            return ra_code
        available = _ra_columns(ra_code)
        kept = tuple(map(str2columnstr_constant, columns))
        # An operation may not tell all its columns (a region destroyed in
        # points): the projection is only made when it has all of the head's.
        if any(column not in available for column in kept) or \
                len(kept) == len(available):
            return ra_code
        return Projection(ra_code, kept)

    def compute_result_set(
        self, rule, substitutions, instance, restriction_instance=None
    ):
        if restriction_instance is None:
            restriction_instance = MapInstance

        if isinstance(substitutions, NamedRelationalAlgebraFrozenSet):
            new_tuples = substitutions.projection_to_unnamed(
                *(
                    arg.name for arg in rule.consequent.args
                    if arg in substitutions.columns
                )
            )
        else:
            tuples = [
                tuple(
                    a.value for a in
                    apply_substitution_arguments(
                        rule.consequent.args, substitution
                    )
                )
                for substitution in substitutions
                if len(substitutions) > 0
            ]
            new_tuples = self.datalog_program.new_set(tuples)

        return self.compute_instance_update(
            rule, new_tuples, instance, restriction_instance
        )
