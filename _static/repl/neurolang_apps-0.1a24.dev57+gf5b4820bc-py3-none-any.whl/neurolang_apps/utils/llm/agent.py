"""
Agents translating a question into a NeuroLang query with an LLM.

Two strategies are offered, following the text-to-SQL and text-to-SPARQL
literature:

* :class:`IclAgent`, in-context learning: the prompt holds the syntax of
  the language, the predicates of the engine and the examples closest to
  the question; the query the model writes is checked on the engine and,
  when it fails, the error is sent back for a correction (validation and
  reprompting).
* :class:`ReactAgent`, ReAct: the model reasons and calls tools to look
  at the predicates and their values, check and run its query, until it
  gives its final answer. The tools are called with the provider's
  native tool calls or with a Thought / Action / Observation text
  protocol that any chat model can follow.

With several ``samples``, either agent answers that many times and keeps
the answer whose result most of them give (self-consistency). Without a
majority, more than half of the answers giving the same rows, or when
none is valid, the ``fallback_provider`` of the configuration, if any,
answers once instead.
"""

import json
import re
import time
from collections import Counter
from dataclasses import dataclass, field, replace
from typing import Callable, Optional

from neurolang_apps.utils import engine_registry

from . import prompts
from .comments import comment_rules, commented_query
from .config import AssistantConfig, ProviderConfig
from .context import EngineContext
from .examples import load_examples, select_examples
from .providers import LLMError, make_client
from .validation import (
    QueryTimeout, QueryTooLarge, _in_child, check_query, run_preview,
)

MAX_OBSERVATION = 2000
EXAMPLE_QUERIES = {
    "squall": "obtain every Study.", "datalog": "ans(s) :- study(s)",
}
_FENCE = re.compile(r"```[ \t]*([A-Za-z]*)[ \t]*\n(.*?)```", re.DOTALL)
_ACTION = re.compile(
    r"^\s*Action\s*:\s*([A-Za-z_]+)", re.MULTILINE | re.IGNORECASE
)
_ACTION_INPUT = re.compile(
    r"^\s*Action[ _]Input\s*:", re.MULTILINE | re.IGNORECASE
)
_THOUGHT = re.compile(
    r"^\s*Thought\s*:\s*(.*?)(?=^\s*Action\s*:|\Z)",
    re.MULTILINE | re.DOTALL | re.IGNORECASE,
)
_FINAL = re.compile(r"^\s*Final\s+Answer\s*:", re.MULTILINE | re.IGNORECASE)
_OBSERVATION = re.compile(r"^\s*Observation\s*:", re.MULTILINE)
_VERDICT = re.compile(r"VERDICT\s*:\s*\**\s*(yes|no)\b", re.IGNORECASE)
# A keyword line as models write it, emphasis or tags included:
# **Action:** x, <Action: x>, <Action>x</Action>
_KEYWORD_LINE = re.compile(
    r"^[\s*_`#<>-]*(Thought|Action[ _]Input|Action|Final[ _]Answer)"
    r"[*_`\s]*[:>][*_`\s]*(.*?)\s*(?:</[\w ]+>|>)?\s*$",
    re.IGNORECASE,
)


def _normalise_keywords(text: str) -> str:
    """Return *text* with its keyword lines without markdown emphasis."""
    lines = []
    for line in text.splitlines():
        match = _KEYWORD_LINE.match(line)
        if match:
            keyword = match.group(1).replace("_", " ")
            value = match.group(2).strip().strip("`*_").strip()
            line = f"{keyword}: {value}"
        lines.append(line)
    return "\n".join(lines)


@dataclass
class AgentStep:
    """
    A step of an agent: a tool call or a query attempt.

    *action* is the tool called (``query`` for an ICL attempt) with its
    *arguments*, and *observation* what it returned.
    """

    thought: str = ""
    action: str = ""
    arguments: dict = field(default_factory=dict)
    observation: str = ""


@dataclass
class AgentResult:
    """
    The outcome of an agent: its query, if *valid*, or its *error*.

    *usage* counts the tokens sent (``input``, of which ``cached`` read
    from the cache of the provider) and received
    (``output``), *calls* the requests to the model and *seconds* the
    time it took. The ReAct agent translates its query back into English
    (*back_translation*) and sets *verified* to whether the model judged
    that to answer the question (None when unchecked), with the reason
    of its judgement (*verification*). The ReAct agent runs its final
    query to accept it, and keeps the whole result, as ``(title, frame)``
    for each relation, in *frames* (None when it is boolean, or too large
    to keep, see :data:`~.validation.MAX_KEPT_CELLS`), so that it need not
    be run again to be shown. *out_of_steps* is set when the ReAct agent
    ran out of steps before a final answer, and its query is only the
    last that gave rows.
    """

    query: str = ""
    language: str = "squall"
    explanation: str = ""
    valid: bool = False
    commented: str = ""
    error: str = ""
    steps: list = field(default_factory=list)
    usage: Counter = field(default_factory=Counter)
    calls: int = 0
    seconds: float = 0.0
    back_translation: str = ""
    verified: Optional[bool] = None
    verification: str = ""
    frames: Optional[list] = field(default=None, repr=False)
    out_of_steps: bool = False


@dataclass
class Previous:
    """
    What an agent starts from to refine an answer: the *question* that was
    asked ("" if not known), the *query* of that attempt, which may have
    failed, and its *outcome* ("" if not known): the error it gave, the
    rows it gave, or what was found against it.
    """

    question: str
    query: str
    outcome: str


def truncate(text: str, limit: int = MAX_OBSERVATION) -> str:
    """Return *text* cut to *limit* characters, telling that it was cut."""
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n… ({len(text) - limit} more characters)"


def extract_query(text: str, language: str) -> Optional[str]:
    """
    Return the query of the model's reply *text*, if any.

    It is the first fenced code block, preferring one labelled with
    *language*.
    """
    blocks = _FENCE.findall(text or "")
    for label, body in blocks:
        if label.lower() == language:
            return body.strip()
    for label, body in blocks:
        if label.lower() in ("", "text", "prolog", "sql", language):
            return body.strip()
    return None


def _json_object(text: str):
    """Return the first JSON object in *text*, or raise ValueError."""
    start = text.find("{")
    if start < 0:
        raise ValueError("no JSON object")
    value, _ = json.JSONDecoder(strict=False).raw_decode(text[start:])
    if not isinstance(value, dict):
        raise ValueError("not a JSON object")
    return value


@dataclass
class TextAction:
    """An action parsed from a reply of the text protocol."""

    thought: str
    name: str = ""
    arguments: dict = field(default_factory=dict)
    error: str = ""


def parse_text_action(text: str, language: str) -> TextAction:
    """
    Parse the Thought / Action / Action Input of a text protocol reply.

    A reply hallucinating its own ``Observation:`` is cut there (see
    :func:`_reply_end`). A ``Final Answer:`` or a lone fenced query is
    read as a call of ``final_answer``. On a malformed reply, *error*
    tells the model how to write its action.
    """
    text = _normalise_keywords(text)
    text = text[:_reply_end(text)]
    thought = _THOUGHT.search(text)
    thought = thought.group(1).strip() if thought else ""
    action = _ACTION.search(text)
    if action is None:
        final = _FINAL.search(text)
        rest = text[final.end():] if final else text
        try:
            arguments = _json_object(rest) if final else None
        except ValueError:
            arguments = None
        if arguments is None:
            query = extract_query(rest, language)
            if query is not None:
                arguments = {"query": query, "explanation": ""}
        if arguments is not None:
            return TextAction(thought, "final_answer", arguments)
        return TextAction(
            thought or text.strip(),
            error="Your reply has no action. Write `Action: <tool>` and "
            "`Action Input: <JSON object>`, e.g.\nAction: check_query\n"
            'Action Input: {"query": "..."}',
        )
    name = action.group(1)
    arguments_start = _ACTION_INPUT.search(text, action.end())
    if arguments_start is None:
        # Action: tool({...}) or Action: tool {...} on one line
        line_end = text.find("\n", action.end())
        rest = text[action.end():] if line_end < 0 else text[
            action.end():line_end
        ]
        if "{" in rest:
            try:
                return TextAction(thought, name, _json_object(rest))
            except ValueError:
                pass
        return TextAction(thought, name, {})
    rest = text[arguments_start.end():]
    try:
        arguments = _json_object(rest)
    except ValueError:
        # A lone JSON string is the argument of a tool taking one.
        required = next((
            tool["parameters"].get("required", [])
            for tool in prompts.TOOLS if tool["name"] == name
        ), [])
        try:
            value = json.loads(rest.strip().split("\n", 1)[0])
        except ValueError:
            value = None
        if isinstance(value, str) and len(required) == 1:
            return TextAction(thought, name, {required[0]: value})
        return TextAction(
            thought, name,
            error="The Action Input is not a JSON object, e.g. Action Input: "
            + json.dumps({"query": EXAMPLE_QUERIES[language]}),
        )
    return TextAction(thought, name, arguments)


def _reply_end(text: str) -> int:
    """
    Return where a text protocol reply, its keywords normalised, ends: at
    the ``Observation:`` it hallucinates after its action (or final
    answer), if any; one before it, the echo of the last observation, is
    kept.
    """
    starts = [
        m.start() for m in (
            _ACTION.search(text), _FINAL.search(text), _FENCE.search(text)
        ) if m
    ]
    observed = _OBSERVATION.search(text, min(starts, default=0))
    return observed.start() if observed else len(text)


def _atom_count(query: str) -> int:
    """Return the number of atoms of *query*, a measure of its detail."""
    return len(re.findall(r"[\w:]+\s*\(", query))


def _gave_rows(observation: str) -> bool:
    """Whether the observation of run_query shows rows."""
    return bool(re.match(r"(\w+: )?[1-9]\d* rows", observation))


class Toolbox:
    """
    The tools of the ReAct agent on an engine.

    :meth:`call` returns the observation of a tool call and, for an
    accepted ``final_answer``, the query and its explanation.
    """

    def __init__(
        self, context: EngineContext, language: str, preview_rows: int = 10,
        query_timeout: Optional[float] = None,
        query_memory_mb: Optional[float] = None,
        max_cells: Optional[int] = None,
    ):
        self.context = context
        self.language = language
        self.preview_rows = preview_rows
        self.query_timeout = query_timeout
        self.query_memory_mb = query_memory_mb
        # The most cells of a result kept whole (validation.Preview.frames),
        # MAX_KEPT_CELLS if None.
        self.max_cells = max_cells
        # Queries whose answer of no rows, or with notes on its
        # constants, has been confirmed.
        self.confirmed_empty = set()
        # The queries run with run_query that gave rows, in order.
        self.queries_with_rows = []
        # The first rows of the answer final_answer accepted last, its
        # whole result (see validation.Preview.frames), and its preview.
        self.answer_rows = ""
        self.answer_frames = None
        self.answer_preview = None
        # The observations of the calls, by tool and arguments.
        self.observations = {}
        # The facts search_values found, and its calls finding none new.
        self.values_found = set()
        self.searches_without_new_values = 0

    def call(self, name: str, arguments: dict):
        """
        Run the tool *name* with *arguments*: (observation, final). A call
        made already, but final_answer, is not run again: a model in a
        loop is told so, with the result it had, and after two searches
        finding no new value, to run a query with those it found.
        """
        key = (name, json.dumps(arguments, sort_keys=True, default=str))
        if key in self.observations and name != "final_answer":
            observation, final = (
                f"You already called {name} with these arguments, which "
                f"gave:\n{truncate(self.observations[key], 500)}\n"
                "Do not call it again: use that result and take the next "
                "step."
            ), None
        else:
            observation, final = self._call(name, arguments)
            self.observations[key] = observation
        if name == "search_values":
            values = set(self.observations[key].splitlines()[1:])
            stale = values <= self.values_found
            self.searches_without_new_values += stale
            self.values_found |= values
            if stale and self.searches_without_new_values >= 2:
                observation += (
                    "\nYour searches find no new values: write the query "
                    "with the values found so far and run it with run_query."
                )
        return observation, final

    def _call(self, name: str, arguments: dict):
        """Run the tool *name* with *arguments*: (observation, final)."""
        handler = getattr(self, f"tool_{name}", None)
        if handler is None:
            tools = ", ".join(tool["name"] for tool in prompts.TOOLS)
            return f"Unknown tool {name!r}. The tools are: {tools}.", None
        if "_invalid" in arguments:
            return "The arguments are not a JSON object.", None
        try:
            return handler(**arguments)
        except TypeError as exc:
            return f"Wrong arguments for {name}: {exc}", None
        except Exception as exc:
            return f"Error: {type(exc).__name__}: {exc}", None

    def tool_list_predicates(self):
        return self.context.schema_summary(), None

    def tool_describe_predicate(self, name: str):
        # Its sample rows run the rules: as long as any query may.
        try:
            return _in_child(
                lambda: self.context.describe(name),
                self.query_timeout, self.query_memory_mb,
            ), None
        except (QueryTimeout, QueryTooLarge):
            return (
                f"Computing the rows of {name} takes too long, they are "
                f"not listed.\n{self.context._bound_usage(name)}"
            ), None

    def tool_search_values(self, pattern: str, predicate=None, column=None):
        return self.context.search_values(pattern, predicate, column), None

    def tool_check_query(self, query: str):
        result = check_query(
            self.context.nl, query, self.language,
            self.context.engine_name if self.context.declared else "",
        )
        if not result.ok:
            return f"The query fails:\n{result.message}", None
        text = "The query is valid."
        if result.datalog:
            text += f" Its Datalog translation:\n{result.datalog}"
        if result.notes:
            text += f"\n{result.notes}"
        return text, None

    def tool_run_query(self, query: str):
        check = check_query(self.context.nl, query, self.language)
        if not check.ok:
            return f"The query fails:\n{check.message}", None
        preview = run_preview(
            self.context.nl, query, self.language, self.preview_rows,
            self.context.engine_name if self.context.declared else "",
            self.query_timeout, self.query_memory_mb, self.max_cells,
        )
        if preview.ok and preview.rows:
            self.queries_with_rows.append(query.strip())
        return preview.text, None

    def tool_final_answer(self, query: str, explanation: str = ""):
        result = check_query(
            self.context.nl, query, self.language,
            self.context.engine_name if self.context.declared else "",
        )
        if not result.ok:
            return (
                f"The answer is rejected: the query fails:\n{result.message}"
                "\nCorrect it and call final_answer again."
            ), None
        normalised = " ".join(query.split())
        preview = run_preview(
            self.context.nl, query, self.language, self.preview_rows,
            self.context.engine_name if self.context.declared else "",
            self.query_timeout, self.query_memory_mb, self.max_cells,
        )
        if not preview.ok:
            return (
                f"The answer is rejected: running the query fails:\n"
                f"{preview.text}\nCorrect it and call final_answer again."
            ), None
        if (
            (preview.rows == 0 or result.notes)
            and normalised not in self.confirmed_empty
        ):
            self.confirmed_empty.add(normalised)
            message = (
                "The query gives no rows. Check its constants with "
                "search_values and its joins with run_query; if no rows is "
                "the answer, call final_answer again with the same query."
            ) if preview.rows == 0 else (
                "Check the constants of the query; if it is right, call "
                "final_answer again with the same query."
            )
            if result.notes:
                message += f"\n{result.notes}"
            if self.queries_with_rows and preview.rows == 0:
                message += (
                    "\nYour query that gave rows was:\n"
                    + self.queries_with_rows[-1]
                )
            return message, None
        self.answer_rows = preview.text
        self.answer_frames = preview.frames
        self.answer_preview = preview
        return "Accepted.", (query.strip(), explanation.strip())


class Agent:
    """
    Base of the agents: the engine, the model and the prompt.

    *client* is the chat client of *provider* (by default made from its
    configuration), and *fallback_client* that of the configuration's
    ``fallback_provider``; *on_step* is called with each
    :class:`AgentStep` as it ends, and the examples whose question is
    *exclude_question* are left out of the prompt (to evaluate on the
    example bank).

    The examples of the prompt are chosen among *examples*, a list of
    :class:`~.examples.Example`, by default the engine's bank, and the
    engine is described by *description*, by default the description
    of its configuration, and *guidance* tells how to answer on it, by
    default its configuration's ``assistant_guidance``.
    """

    strategy = ""

    def __init__(
        self, nl, provider: ProviderConfig, config: AssistantConfig,
        language: str, engine_name: str = "", client=None, loaded=None,
        on_step: Optional[Callable] = None, exclude_question: str = "",
        examples: Optional[list] = None, description: Optional[str] = None,
        guidance: Optional[str] = None, fallback_client=None,
    ):
        self.nl = nl
        self.provider = provider
        self.config = config
        self.language = language
        self.engine_name = engine_name
        self.client = client or make_client(provider, config.timeout)
        self.fallback_client = fallback_client
        self.context = EngineContext(nl, engine_name, loaded)
        self.on_step = on_step or (lambda step: None)
        self.exclude_question = exclude_question
        self.examples = examples
        self.description = description
        self.guidance = guidance
        self.previous = None

    def system_prompt(
        self, question: str, text_tools: bool = False,
        schema: Optional[str] = None,
    ) -> str:
        """Return the system prompt for *question*, with the predicates of
        the engine, or *schema* in their place if given."""
        bank = self.examples
        if bank is None:
            bank = load_examples(self.engine_name)
        examples = select_examples(
            bank, question, self.language, self.config.few_shot_k,
            exclude=self.exclude_question,
        )
        return prompts.system_prompt(
            self.language,
            self.context.schema_summary() if schema is None else schema,
            examples,
            self.strategy, text_tools,
            self._engine_text(self.description, "description"),
            self._engine_text(self.guidance, "assistant_guidance"),
        )

    def _engine_text(self, given: Optional[str], key: str) -> str:
        """Return *given*, or else the engine configuration's *key*."""
        if given is not None:
            return given
        return self._engine_config().get(key, "")

    def _engine_config(self) -> dict:
        """Return the configuration of the engine, if it is registered."""
        if self.engine_name in engine_registry.list_engine_names():
            return engine_registry.get_engine_config(self.engine_name)
        return {}

    def _complete(self, result: AgentResult, messages, tools=None,
                  temperature=None):
        """
        Return the model's reply to *messages*, counting its usage. An
        empty reply (all the tokens spent on reasoning, or a glitch of
        the provider) is asked for again once.
        """
        for _ in range(2):
            reply = self.client.complete(
                messages, tools, self.config.temperature
                if temperature is None else temperature,
            )
            result.calls += 1
            result.usage.update(reply.usage)
            if reply.text.strip() or reply.tool_calls:
                break
        return reply

    def _step(self, result: AgentResult, step: AgentStep) -> None:
        """Record *step* in *result* and report it."""
        result.steps.append(step)
        self.on_step(step)

    def explain(self, query: str, rows: str = "") -> str:
        """
        Return *query* in English, as the check of an answer reads it back
        (see :func:`~.prompts.back_translation_request`); *rows* are the
        first rows of its answer, if given.
        """
        return self._complete(
            AgentResult(language=self.language),
            prompts.back_translation_request(
                query, self.language, self.context.schema_summary(), rows,
                self._engine_text(self.description, "description"),
            ),
        ).text.strip()

    def _user_message(self, question: str) -> str:
        """Return the message asking for *question*, or, if a previous
        attempt is to be refined, for the change of its query."""
        if self.previous is None:
            return question
        return prompts.refinement_request(
            question, self.previous, self.language
        )

    def run(self, question: str, previous=None) -> AgentResult:
        """
        Return the query answering *question*; the one of *previous*, a
        :class:`Previous`, is changed for it if it is given.

        With the setting ``comment_rules``, the accepted query is also
        written with a comment line explaining each rule, in
        ``commented`` (see :meth:`_comment`).
        """
        start = time.perf_counter()
        self.previous = previous
        result = self._run(question)
        if result.valid and result.query and self.config.comment_rules:
            self._comment(result, question)
        result.seconds = time.perf_counter() - start
        return result

    def _run(self, question: str) -> AgentResult:
        """
        Return the query answering *question*: the answer of the vote of
        the samples, or else of the fallback provider (see the module).
        """
        samples = max(1, self.config.samples)
        fallback = self.config.fallback_provider
        if samples == 1 and fallback is None:
            return self._attempt(question, self.config.temperature)
        temperature = self.config.temperature
        if samples > 1:
            temperature = max(temperature, 0.7)
        chosen, majority = self._vote([
            self._sample(question, temperature) for _ in range(samples)
        ])
        if majority or fallback is None:
            return chosen
        self._step(chosen, AgentStep(
            "", "fallback", {
                "provider": fallback.name,
                "voted": chosen.query if chosen.valid else "",
            },
            f"No majority of the {samples} answers: {fallback.name} answers.",
        ))
        answer = self._fallback(question, fallback)
        answer.steps[:0] = chosen.steps
        answer.usage.update(chosen.usage)
        answer.calls += chosen.calls
        return answer

    def _attempt(self, question: str, temperature: float) -> AgentResult:
        """Return an answer to *question*, as the strategy finds it."""
        raise NotImplementedError

    def _sample(self, question: str, temperature: float) -> AgentResult:
        """Return an answer to *question*, failed if the model failed."""
        try:
            return self._attempt(question, temperature)
        except LLMError as exc:
            return AgentResult(language=self.language, error=str(exc))

    def _fallback(self, question: str, fallback: ProviderConfig):
        """Return the answer of the provider *fallback* to *question*."""
        if self.fallback_client is None:
            self.fallback_client = make_client(fallback, self.config.timeout)
        state = self.provider, self.client, self.config
        self.provider, self.client = fallback, self.fallback_client
        self.config = replace(self.config, samples=1, fallback_provider=None)
        try:
            return self._sample(question, self.config.temperature)
        finally:
            self.provider, self.client, self.config = state

    def _fingerprint(self, candidate: AgentResult):
        """Return what identifies the result of *candidate*, for the vote."""
        frame = candidate.frames[0][1] if candidate.frames else None
        if frame is None:
            preview = run_preview(
                self.nl, candidate.query, self.language, 0,
                timeout=self.config.query_timeout,
                memory_mb=self.config.query_memory_mb,
            )
            frame = preview.frame if preview.ok else None
        if frame is not None:
            rows = frame.astype(str).itertuples(index=False)
            return ("rows", frozenset(map(tuple, rows)))
        return ("text", " ".join(candidate.query.split()))

    def _vote(self, candidates: list):
        """
        Return the valid candidate whose result most candidates give, or
        the first, with the usage of all, and whether more than half of
        the candidates give that result.
        """
        valid = [c for c in candidates if c.valid]
        chosen, votes = candidates[0], 0
        if valid:
            fingerprints = [self._fingerprint(c) for c in valid]
            counts = Counter(fingerprints)
            chosen, fingerprint = max(
                zip(valid, fingerprints), key=lambda pair: counts[pair[1]]
            )
            votes = counts[fingerprint]
        for candidate in candidates:
            if candidate is not chosen:
                chosen.usage.update(candidate.usage)
                chosen.calls += candidate.calls
        return chosen, votes > len(candidates) / 2

    def _comment(self, result: AgentResult, question: str) -> None:
        """
        Ask the model for a comment line on each rule of the query of
        *result* and write it commented in ``result.commented``.

        The query itself is unchanged; a request that fails, or a reply
        without a comment per rule, leaves ``commented`` empty and is
        reported as a step.
        """
        try:
            rules, notes = comment_rules(
                lambda messages: self._complete(result, messages, None, 0.0),
                question, result.query, result.language,
            )
        except (LLMError, ValueError) as exc:
            self._step(result, AgentStep(
                "", "comment_rules", {}, f"No comments: {exc}"
            ))
            return
        result.commented = commented_query(rules, notes)
        self._step(result, AgentStep(
            "", "comment_rules", {}, result.commented
        ))


class IclAgent(Agent):
    """In-context learning, then validation and repair of the query."""

    strategy = "icl"

    def _attempt(self, question: str, temperature: float) -> AgentResult:
        """Ask for a query and correct it until it passes the checks."""
        result = AgentResult(language=self.language)
        messages = [
            {"role": "system", "content": self.system_prompt(question)},
            {"role": "user", "content": self._user_message(question)},
        ]
        for _ in range(self.config.max_repairs + 1):
            reply = self._complete(result, messages, temperature=temperature)
            query = extract_query(reply.text, self.language)
            if query is None:
                result.error = (
                    reply.text.strip() or "The model wrote no query."
                )
                self._step(result, AgentStep(reply.text.strip(), "answer"))
                return result
            check = check_query(self.nl, query, self.language)
            self._step(result, AgentStep(
                "", "query", {"query": query},
                "valid" if check.ok else check.message,
            ))
            result.query = query
            result.explanation = _FENCE.sub("", reply.text).strip()
            if check.ok:
                result.valid = True
                result.error = ""
                return result
            result.error = check.message
            messages += [
                {"role": "assistant", "content": reply.text},
                {"role": "user", "content": prompts.repair_prompt(
                    query, check.message, self.language
                )},
            ]
        return result


def parse_verdict(text: str):
    """
    Return the verdict of a verification reply, True or False, and its
    reason; the verdict is None when the reply gives none.

    The last ``VERDICT:`` counts. The reason is the text after it, or
    else the reasoning before it.
    """
    matches = list(_VERDICT.finditer(text))
    match = matches[-1] if matches else None
    if match is None:
        first = text.strip().split(None, 1)
        word = first[0].strip(".,:*").lower() if first else ""
        if word not in ("yes", "no"):
            return None, text.strip()
        return word == "yes", (first[1] if len(first) > 1 else "").strip()
    reason = text[match.end():].lstrip("*.,:-— \n").strip()
    if not reason:
        reason = " ".join(text[:match.start()].split()).strip("* ")
    return match.group(1).lower() == "yes", truncate(reason, 600)


class ReactAgent(Agent):
    """
    ReAct: reasoning and tool calls until a checked final answer.

    A final answer is then verified, as long as *verify_rounds* of the
    configuration allow it to be rejected: the model translates the query
    back into English without seeing the question, then judges whether
    that answers the question. A rejection goes back to the agent as the
    observation of its final answer, with the reason.
    """

    strategy = "react"

    @property
    def native(self) -> bool:
        """Whether the provider's native tool calls are used."""
        return self.provider.tool_calling == "native"

    def _attempt(self, question: str, temperature: float) -> AgentResult:
        result = AgentResult(language=self.language)
        toolbox = Toolbox(
            self.context, self.language, self.config.preview_rows,
            self.config.query_timeout, self.config.query_memory_mb,
        )
        messages = [
            {"role": "system", "content": self.system_prompt(
                question, text_tools=not self.native
            )},
            {"role": "user", "content": self._user_message(question)},
        ]
        turn = self._native_turn if self.native else self._text_turn
        rejections = 0
        for _ in range(self.config.max_steps):
            final = turn(result, messages, toolbox, temperature)
            if final is None:
                continue
            rejection = None
            if self.config.verify_rounds > 0:
                rejection = self._verify(
                    result, question, final[0], toolbox.answer_rows
                )
            if rejection is None or rejections >= self.config.verify_rounds:
                result.query, result.explanation = final
                result.frames = toolbox.answer_frames
                result.valid = True
                return result
            rejections += 1
            messages.append(
                {"role": "user", "content": prompts.observation(rejection)}
            )
        # Out of steps: the verdict of a rejected answer is not that of
        # the answer given instead.
        result.verified, result.back_translation = None, ""
        result.verification = ""
        ran = max(
            (
                s for s in reversed(result.steps)
                if s.action == "run_query" and _gave_rows(s.observation)
            ),
            key=lambda s: _atom_count(s.arguments.get("query", "")),
            default=None,
        )
        if ran is not None:
            # Out of steps, the last query that gave rows is the answer.
            result.query = ran.arguments["query"]
            result.valid = result.out_of_steps = True
            result.explanation = (
                f"Out of steps: no final answer after "
                f"{self.config.max_steps} steps. This is the last query "
                "that gave rows, which may not answer the question."
            )
            return result
        last = next(
            (s for s in reversed(result.steps) if "query" in s.arguments), None
        )
        if last is not None:
            result.query = last.arguments["query"]
        result.error = (
            f"No valid query after {self.config.max_steps} steps."
        )
        return result

    def _verify(self, result, question: str, query: str, rows: str):
        """
        Translate *query* back into English and judge whether it answers
        *question*. Record the step and return the observation rejecting
        the answer, or None when it is judged to answer the question, or
        cannot be judged (an error of the model).
        """
        from .providers import LLMError

        try:
            description = self._engine_text(self.description, "description")
            guidance = self._engine_text(self.guidance, "assistant_guidance")
            schema = self.context.schema_summary()
            english = self._complete(
                result, prompts.back_translation_request(
                    query, self.language, schema, rows, description,
                ),
            ).text.strip()
            verdict, reason = parse_verdict(self._complete(
                result, prompts.verification_request(
                    question, english, rows, schema, description, guidance,
                ),
            ).text)
        except LLMError as exc:
            self._step(result, AgentStep(
                "", "verify", {"query": query},
                f"The verification failed: {exc}",
            ))
            return None
        result.back_translation = english
        result.verified = verdict
        result.verification = reason
        answers = {True: "yes", False: "no", None: "unclear"}[verdict]
        self._step(result, AgentStep(
            "", "verify", {"query": query},
            f"Reads back as: {english}\nAnswers the question: {answers}"
            + (f" — {reason}" if reason else ""),
        ))
        if verdict is False:
            return prompts.verification_rejection(english, reason)
        return None

    def _call(self, result, toolbox, thought, name, arguments):
        """Call a tool, record the step and return (observation, final)."""
        observation, final = toolbox.call(name, arguments)
        observation = truncate(observation)
        self._step(result, AgentStep(thought, name, arguments, observation))
        return observation, final

    def _native_turn(self, result, messages, toolbox, temperature):
        """Run one turn with the provider's tool calls."""
        reply = self._complete(result, messages, prompts.TOOLS, temperature)
        if not reply.tool_calls:
            query = extract_query(reply.text, self.language)
            messages.append({"role": "assistant", "content": reply.text})
            if query is not None:
                observation, final = self._call(
                    result, toolbox, reply.text, "final_answer",
                    {"query": query, "explanation": ""},
                )
                if final is not None:
                    return final
                messages.append({"role": "user", "content": observation})
                return None
            messages.append({
                "role": "user",
                "content": "Call a tool, or final_answer with your query.",
            })
            self._step(result, AgentStep(reply.text.strip(), "answer"))
            return None
        messages.append({
            "role": "assistant", "content": reply.text,
            "tool_calls": reply.tool_calls, "blocks": reply.blocks,
        })
        accepted = None
        for call in reply.tool_calls:
            observation, final = self._call(
                result, toolbox, reply.text.strip(), call.name, call.arguments
            )
            messages.append({
                "role": "tool", "tool_call_id": call.id, "name": call.name,
                "content": observation,
            })
            accepted = accepted or final
        return accepted

    def _text_turn(self, result, messages, toolbox, temperature):
        """Run one turn of the Thought / Action / Observation protocol."""
        reply = self._complete(result, messages, temperature=temperature)
        action = parse_text_action(reply.text, self.language)
        content = _normalise_keywords(reply.text)
        content = content[:_reply_end(content)]
        error = action.error
        if error and reply.usage.get("output", 0) >= self.provider.max_tokens:
            # A reply cut at the token limit, often a loop the model
            # would copy: keep only its thought in the conversation.
            content = action.thought
            error = (f"Your reply was cut at {self.provider.max_tokens} "
                     f"tokens: write a shorter one. {error}")
        messages.append({"role": "assistant", "content": content.strip()})
        if error:
            self._step(result, AgentStep(action.thought, "", {}, error))
            messages.append(
                {"role": "user", "content": prompts.observation(error)}
            )
            return None
        observation, final = self._call(
            result, toolbox, action.thought, action.name, action.arguments
        )
        if final is None:
            messages.append(
                {"role": "user", "content": prompts.observation(observation)}
            )
        return final


AGENTS = {"icl": IclAgent, "react": ReactAgent}


def make_agent(
    nl, provider: ProviderConfig, config: AssistantConfig, language: str,
    strategy: Optional[str] = None, **options,
) -> Agent:
    """Return the agent of *strategy* (default: the configuration's)."""
    return AGENTS[strategy or config.strategy](
        nl, provider, config, language, **options
    )
