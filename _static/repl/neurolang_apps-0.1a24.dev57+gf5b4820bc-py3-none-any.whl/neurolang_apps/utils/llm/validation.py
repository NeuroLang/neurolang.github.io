"""
Deterministic checks of the queries an LLM writes.

A query is parsed and dry-run on the engine, without running the chase
(:func:`check_query`): the errors, formatted as for the user, are sent
back to the model so that it can correct its query. A query can also be
run to show the model a few rows of its result (:func:`run_preview`).
Both work in a scope of the engine that is discarded afterwards: the
rules of the query never stay in the session.
"""

import contextlib
import ctypes
import io
import os
import pickle
import re
import signal
import subprocess
import sys
import threading
import time
import warnings
from dataclasses import dataclass
from typing import Optional

from neurolang.frontend.error_formatting import format_error
from neurolang_apps.utils.cli import (
    _known_symbol_names,
    _show_squall_datalog,
    left_out_symbol,
    not_available,
    result_to_dataframe,
    squall_column_names,
    warning_note,
)
from neurolang_apps.utils.predicate_catalog import predicate_catalog

LANGUAGE_NAMES = {"squall": "SQUALL", "datalog": "Datalog"}
CHILD_POLL_SECONDS = 0.25
_DATALOG_QUERY = re.compile(r"(^|[\s.])ans\s*(\[\s*\w+\s*\]\s*)?\(")
_CALL = re.compile(
    r"(?<![\w.:'\"])([A-Za-z_][A-Za-z0-9_]*(?::[A-Za-z_][A-Za-z0-9_-]*)?)"
    r"\s*\("
)
# String literals and IRIs, whose characters are not syntax.
_OPAQUE = re.compile(
    r"'[^'\n]*'|\"[^\"\n]*\"|<[A-Za-z][A-Za-z0-9+.-]*:[^<>\s]*>"
)


class QueryCheckError(Exception):
    """A query that parses but cannot be run as it is."""


@dataclass
class CheckResult:
    """
    The outcome of checking a query.

    *message* is the formatted error when the query is not *ok*.
    *datalog* is the Datalog translation of a SQUALL query. *notes* tell
    of its constants that match nothing (see
    :func:`~neurolang_apps.utils.tui.constant_notes.constant_notes`).
    """

    ok: bool
    message: str = ""
    datalog: str = ""
    notes: str = ""


def _parse(text: str, language: str):
    """Parse *text* in *language*, returning the parsed program."""
    if language == "squall":
        from neurolang.frontend.datalog.squall_syntax_lark import (
            SquallProgram,
            parser,
        )
        parsed = parser(text)
        if not isinstance(parsed, SquallProgram) or not parsed.queries:
            raise QueryCheckError(
                "The program has no query: end it with a sentence "
                "starting with 'obtain'."
            )
        return parsed
    from neurolang.frontend.datalog.standard_syntax import parser
    parsed = parser(text)
    if not _DATALOG_QUERY.search(text):
        raise QueryCheckError(
            "The program has no query: add a rule whose head is ans(...)."
        )
    return parsed


def _execute(nl, text: str, language: str, dry_run: bool):
    """Execute *text* in a discarded scope, its output being captured."""
    execute = (
        nl.execute_squall_program if language == "squall"
        else nl.execute_datalog_program
    )
    with contextlib.redirect_stdout(io.StringIO()):
        with nl.scope:
            return execute(text, dry_run=dry_run)


class QueryTimeout(Exception):
    """Raised in a query that ran longer than its time limit."""


def _with_timeout(function, timeout):
    """
    Return ``function()``, interrupting it after *timeout* seconds.

    It runs in a worker thread in which :class:`QueryTimeout` is raised
    when the time is up; the query stops as soon as it runs Python code
    again. Without *timeout*, or where threads cannot be started, as in
    WebAssembly, *function* runs as it is.
    """
    if not timeout or sys.platform == "emscripten":
        return function()
    outcome = {}
    done = threading.Event()

    def target():
        try:
            outcome["value"] = function()
        except BaseException as exc:
            outcome["error"] = exc
        finally:
            done.set()

    worker = threading.Thread(target=target, daemon=True)
    worker.start()
    if not done.wait(timeout):
        ctypes.pythonapi.PyThreadState_SetAsyncExc(
            ctypes.c_ulong(worker.ident), ctypes.py_object(QueryTimeout)
        )
        done.wait()
    if "error" in outcome:
        raise outcome["error"]
    return outcome.get("value")


_UNDEFINED = re.compile(r"Symbol (\S+) used in rule body has no entry")


def _undefined_predicates(caught, known, text: str, nl=None) -> list:
    """
    Return the notes of the *caught* warnings on undefined predicates,
    those the engine *nl* leaves out being not available.

    Only the predicates written in the query *text* are reported: those
    the engine generates while rewriting it (the magic sets'
    ``magic_p^bf_0``, the rules SQUALL numbers) are defined when it runs.
    """
    written = {word.lower() for word in re.findall(r"[\w:]+", text)}
    notes = []
    for warning in caught:
        message = str(warning.message)
        match = _UNDEFINED.match(message)
        if match and match.group(1).lower() not in written:
            continue
        left_out = left_out_symbol(nl, message)
        note = not_available(left_out) if left_out else warning_note(
            message, known
        )
        if left_out or "has no facts or rules" in note:
            notes.append(note.removeprefix("note: "))
    return list(dict.fromkeys(notes))


def _argument_count(text: str, start: int) -> int:
    """Return the number of arguments of the call opened at *start*."""
    depth, count, empty, quote = 0, 1, True, None
    for char in text[start:]:
        if quote:
            quote = None if char == quote else quote
            empty = False
            continue
        if char in "'\"":
            quote = char
        elif char in "([{":
            depth += 1
            if depth == 1:
                continue
        elif char in ")]}":
            depth -= 1
            if depth == 0:
                return 0 if empty else count
        elif char == "," and depth == 1:
            count += 1
        if not char.isspace():
            empty = False
    return count


def arity_errors(nl, datalog: str) -> list:
    """
    Return the predicates of the Datalog text with a wrong arity.

    Each is described as ``name has N columns (cols), not M``, from the
    predicates the engine *nl* defines with a known arity.
    """
    catalog = predicate_catalog(nl)
    datalog = _OPAQUE.sub(lambda m: "_" * len(m.group(0)), datalog)
    errors = []
    for match in _CALL.finditer(datalog):
        info = catalog.get(match.group(1))
        if info is None or info.kind == "function" or info.arity is None:
            continue
        used = _argument_count(datalog, match.end() - 1)
        if used != info.arity:
            errors.append(
                f"{info.name} has {info.arity} columns, not {used}: "
                f"use it as {info.signature()}"
            )
    return list(dict.fromkeys(errors))


_AGGREGATE = re.compile(r"AGGREGATE\s*\[([^\]]*)\]\s*\(")


def aggregation_errors(text: str) -> list:
    """
    Return the misuses of AGGREGATE in the Datalog program *text*.

    The aggregated relation must be a single atom (a rule of its own
    otherwise), and the variable aggregated must not be a group key.
    """
    masked = _OPAQUE.sub(lambda m: "_" * len(m.group(0)), text)
    errors = []
    for match in _AGGREGATE.finditer(masked):
        groups = {g.strip() for g in match.group(1).split(",") if g.strip()}
        depth, start = 1, match.end()
        for end in range(start, len(masked)):
            depth += {"(": 1, ")": -1}.get(masked[end], 0)
            if depth == 0:
                break
        body, _, function = masked[start:end].rpartition("@")
        atoms = [a for a in re.split(r",(?![^()]*\))", body) if a.strip()]
        if len(atoms) > 1:
            errors.append(
                "AGGREGATE[...](... @ f(x)) takes a single atom: define the "
                "conjunction in a rule of its own, e.g. "
                "item(g, x) :- p(g, y), q(y, x), and aggregate it: "
                "AGGREGATE[g](item(g, x) @ count(x)) = n"
            )
        arguments = function.split("(", 1)[-1]
        aggregated = set(re.findall(r"[A-Za-z_]\w*", arguments))
        if groups & aggregated:
            errors.append(
                f"AGGREGATE groups by {', '.join(sorted(groups & aggregated))}"
                ", the variable it aggregates: group by the other variables "
                "of the atom, e.g. AGGREGATE[g](item(g, x) @ count(x)) = n"
            )
    return list(dict.fromkeys(errors))


def error_message(nl, exc: BaseException, text: str, language: str) -> str:
    """Return the error *exc* of the query *text* formatted as for users."""
    if isinstance(exc, QueryCheckError):
        return str(exc)
    missing = left_out_symbol(nl, str(exc))
    if missing:
        return not_available(missing)
    return format_error(
        exc, text, language=LANGUAGE_NAMES[language],
        known_symbols=_known_symbol_names(nl), color=False,
    ).strip()


def squall_datalog(text: str) -> str:
    """Return the Datalog translation of the SQUALL program *text*."""
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        _show_squall_datalog(text)
    return output.getvalue().strip()


def check_query(
    nl, text: str, language: str, engine_name: str = ""
) -> CheckResult:
    """
    Check that the query *text* in *language* can run on the engine *nl*.

    It is parsed, then dry-run: the program is rewritten for the
    engine, which finds the predicates that do not exist or are used
    with the wrong number of arguments, but the chase is not run. The
    constants matching no value of the sorts the engine *engine_name*
    declares are noted.
    """
    text = text.strip()
    if not text:
        return CheckResult(False, "The query is empty.")
    try:
        _parse(text, language)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            _execute(nl, text, language, dry_run=True)
    except Exception as exc:
        return CheckResult(False, error_message(nl, exc, text, language))
    problems = _undefined_predicates(
        caught, _known_symbol_names(nl), text, nl
    )
    datalog = ""
    if language == "squall":
        try:
            datalog = squall_datalog(text)
        except Exception:
            datalog = ""
    problems += arity_errors(nl, datalog or text)
    if language == "datalog":
        problems += aggregation_errors(text)
    if problems:
        return CheckResult(False, "\n".join(problems), datalog)
    return CheckResult(
        True, datalog=datalog, notes=_notes(nl, engine_name, text, language)
    )


# The most cells (rows times columns) of a result kept whole, to show it
# without running its query again: a larger one is run again.
MAX_KEPT_CELLS = 5_000_000


@dataclass
class Preview:
    """
    The rows of a query's result: their number and the first ones.

    *frame* is the first relation of the result, and *frames* all of them,
    ``(title, frame)``, when the result is not larger than
    :data:`MAX_KEPT_CELLS` (None for a boolean, or too large).
    """

    ok: bool
    text: str
    rows: int = 0
    frame: object = None
    frames: object = None


def _frames(result, column_names: dict) -> list:
    """Return ``(name, frame)`` for each relation of a query *result*."""
    if isinstance(result, dict):
        return [
            (key, result_to_dataframe(value, column_names.get(key)))
            for key, value in result.items()
        ]
    names = next(iter(column_names.values()), None)
    return [("", result_to_dataframe(result, names))]


class QueryTooLarge(Exception):
    """Raised for a query using more memory than its limit."""


class QueryCrashed(Exception):
    """Raised for a query whose process died of a signal, e.g. SIGSEGV."""


class QueryStopped(Exception):
    """Raised for a query whose process :func:`stop_queries` stopped."""


# The processes running queries (see _in_child), and those stopped.
_RUNNING = set()
_STOPPED = set()
_RUNNING_LOCK = threading.Lock()


def stop_queries() -> int:
    """
    Stop the processes running queries now, as when the call that runs
    them is cancelled: each query raises :class:`QueryStopped`. Return
    how many were stopped.
    """
    with _RUNNING_LOCK:
        running = list(_RUNNING)
        _STOPPED.update(running)
    for pid in running:
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    return len(running)


def _memory_mb(pid: int) -> float:
    """
    Return the memory of the process *pid*, in MB: that private to it
    where the system tells (Linux, macOS), as a forked child shares the
    pages of its parent it only reads, else its resident memory.
    """
    try:
        if sys.platform == "darwin":
            # proc_pid_rusage(RUSAGE_INFO_V2): ri_phys_footprint is the
            # 10th 64-bit field, after the 16 bytes of ri_uuid.
            info = (ctypes.c_uint64 * 64)()
            libproc = ctypes.CDLL("/usr/lib/libproc.dylib")
            if libproc.proc_pid_rusage(pid, 2, info) == 0:
                return info[9] / 2 ** 20
        with open(f"/proc/{pid}/smaps_rollup") as smaps:
            return sum(
                int(line.split()[1]) for line in smaps
                if line.startswith(("Private_Clean:", "Private_Dirty:"))
            ) / 1024
    except (OSError, ValueError, AttributeError):
        pass
    try:
        out = subprocess.run(
            ["ps", "-o", "rss=", "-p", str(pid)],
            capture_output=True, text=True, timeout=5,
        ).stdout.strip()
        return int(out) / 1024 if out else 0.0
    except (OSError, ValueError, subprocess.SubprocessError):
        return 0.0


def _in_child(function, timeout, memory_mb):
    """
    Return ``function()``, run in a forked child process.

    The child shares the engine's memory with the parent until it
    writes, so forking is cheap. It is killed when it runs longer than
    *timeout* seconds (QueryTimeout) or uses more than *memory_mb* MB
    (QueryTooLarge), so that a runaway query cannot bring the parent
    down. Without fork, or when the system refuses it (a parent too
    large to copy where the memory is not overcommitted), *function* runs
    in a thread with *timeout* only.
    """
    if sys.platform == "emscripten" or not hasattr(os, "fork"):
        return _with_timeout(function, timeout)
    import neurolang_apps

    if not neurolang_apps.BLAS_FORK_SAFE and _accelerate():
        # numpy loaded before neurolang_apps could keep Accelerate to one
        # thread: a matrix product would crash the child.
        return _with_timeout(function, timeout)
    embeddings = sys.modules.get("neurolang_apps.utils.text_embeddings")
    if embeddings is not None:
        # Load the text encoders here: a child process may not (macOS).
        embeddings.prepare_for_fork()
    read, write = os.pipe()
    try:
        with warnings.catch_warnings():
            # A child deadlocked by a lock of another thread is killed at
            # the timeout like any other stuck query.
            warnings.filterwarnings(
                "ignore", message=".*multi-threaded, use of fork",
                category=DeprecationWarning,
            )
            pid = os.fork()
    except OSError:
        os.close(read)
        os.close(write)
        return _with_timeout(function, timeout)
    if pid == 0:  # the child
        os.close(read)
        try:
            payload = ("value", function())
        except BaseException as exc:
            payload = ("error", exc)
        try:
            data = pickle.dumps(payload)
        except Exception:
            data = pickle.dumps(("error", RuntimeError(repr(payload[1]))))
        with os.fdopen(write, "wb") as stream:
            stream.write(data)
        os._exit(0)
    os.close(write)
    with _RUNNING_LOCK:
        _RUNNING.add(pid)
    received = {}
    reader = threading.Thread(
        target=lambda: received.setdefault(
            "data", os.fdopen(read, "rb").read()
        ),
        daemon=True,
    )
    reader.start()
    start, stop = time.monotonic(), None
    while reader.is_alive():
        reader.join(CHILD_POLL_SECONDS)
        if not reader.is_alive():
            break
        if timeout and time.monotonic() - start > timeout:
            stop = QueryTimeout
        elif memory_mb and _memory_mb(pid) > memory_mb:
            stop = QueryTooLarge
        if stop is not None:
            os.kill(pid, signal.SIGKILL)
            reader.join()
            break
    _, status = os.waitpid(pid, 0)
    with _RUNNING_LOCK:
        _RUNNING.discard(pid)
        stopped = pid in _STOPPED
        _STOPPED.discard(pid)
    if stopped:
        raise QueryStopped()
    if stop is not None:
        raise stop()
    if not received.get("data"):
        # Killed by the system (out of memory), or crashed: say which.
        if os.WIFSIGNALED(status) and os.WTERMSIG(status) != signal.SIGKILL:
            raise QueryCrashed(signal.Signals(os.WTERMSIG(status)).name)
        raise QueryTooLarge()
    kind, value = pickle.loads(received["data"])
    if kind == "error":
        raise value
    return value


def _accelerate() -> bool:
    """Whether numpy's BLAS is Apple's Accelerate, which a forked child
    cannot run after its parent ran it with several threads."""
    numpy = sys.modules.get("numpy")
    try:
        config = numpy.show_config(mode="dicts")
        return config["Build Dependencies"]["blas"]["name"] == "accelerate"
    except Exception:  # an older numpy, or none loaded
        return False


def run_preview(
    nl, text: str, language: str, rows: int = 10, engine_name: str = "",
    timeout: Optional[float] = None, memory_mb: Optional[float] = None,
    max_cells: Optional[int] = None,
) -> Preview:
    """
    Run the query *text* and return the first *rows* rows of its result,
    and all of them if they are no more than *max_cells* cells
    (:data:`MAX_KEPT_CELLS` if None).

    The rules it defines are discarded with the scope it runs in. With a
    *timeout* (seconds) or a *memory_mb* limit, the query runs in a child
    process stopped when it exceeds them.
    """
    def preview():
        return _preview(nl, text, language, rows, engine_name, max_cells)

    if not (timeout or memory_mb):
        return preview()
    try:
        return _in_child(preview, timeout, memory_mb)
    except QueryTimeout:
        return Preview(
            False,
            f"The query ran for more than {timeout:.0f} s and was stopped: "
            "restrict it with constants or joins before running it again.",
        )
    except QueryTooLarge:
        return Preview(
            False,
            "The query was stopped: it used too much memory, e.g. joining "
            "large relations without a shared variable. Restrict it, e.g. "
            "with the class of its entities, before running it again.",
        )
    except QueryStopped:
        return Preview(
            False, "The query was stopped: the call running it was cancelled."
        )
    except QueryCrashed as exc:
        return Preview(
            False,
            f"The process running the query crashed ({exc}), not because of "
            "the query: it is valid as far as it ran. Give it as the final "
            "answer if it is the right one.",
        )


def _notes(nl, engine_name, text, language) -> str:
    """Return the notes on the constants of the query *text*, one a line."""
    try:
        from neurolang_apps.utils.tui.constant_notes import constant_notes
    except ImportError:  # without the tui dependencies
        return ""
    return "\n".join(
        f"Note: {note}" for note in constant_notes(
            nl, engine_name, text, language == "squall"
        )
    )


def _preview(nl, text, language, rows, engine_name, max_cells=None) -> Preview:
    """
    Run the query *text* and return its preview (see run_preview), after
    the notes on its constants.
    """
    try:
        result = _execute(nl, text.strip(), language, dry_run=False)
    except Exception as exc:
        return Preview(False, error_message(nl, exc, text, language))
    if result is None:
        return Preview(True, "(no result)")
    if isinstance(result, bool):
        return Preview(True, "true" if result else "false", int(result))
    names = (
        squall_column_names(engine_name, text) if language == "squall"
        else {}
    )
    parts, total, first = [], 0, None
    frames = _frames(result, names)
    for key, frame in frames:
        total += len(frame)
        first = frame if first is None else first
        title = f"{key}: " if key else ""
        if frame.empty:
            parts.append(f"{title}0 rows")
        else:
            parts.append(
                f"{title}{len(frame)} rows; columns "
                f"{', '.join(map(str, frame.columns))}\n"
                + frame.head(rows).to_string(index=False)
            )
    if max_cells is None:
        max_cells = MAX_KEPT_CELLS
    kept = frames if sum(f.size for _, f in frames) <= max_cells else None
    notes = _notes(nl, engine_name, text, language)
    shown = "\n".join(filter(None, [notes, *parts]))
    return Preview(True, shown, total, first, kept)
