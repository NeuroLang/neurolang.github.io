"""NeuroSynth engine initialization."""
