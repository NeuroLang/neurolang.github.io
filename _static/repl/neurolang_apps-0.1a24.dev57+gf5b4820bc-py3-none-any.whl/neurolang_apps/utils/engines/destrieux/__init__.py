"""Destrieux atlas engine initialization."""
