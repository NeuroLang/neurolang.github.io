"""Tests for engine initialization modules."""

import numbers
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from unittest.mock import MagicMock, patch

from neurolang.frontend.neurosynth_utils import StudyID

# Where the engines keep their cache: a directory of the run, not the working one.
DATA_DIR = Path(tempfile.mkdtemp(prefix="neurolang-test-data-"))

NS_INIT = "neurolang_apps.utils.engines.neurosynth.init"

# The NeuroSynth metadata of the mock studies, for study_title: the tests
# never download the real one.
FAKE_METADATA = pd.DataFrame({
    "id": [1, 2, 3, 1001, 1002],
    "title": ["Study one", "Study two", "Study three", "Memory", "Language"],
    "year": [2001, 2002, 2003, 2010, 2011],
    "journal": ["Brain", "Brain", "Neuron", "NeuroImage", "Neuron"],
    "doi": ["10.1/1", "10.1/2", "10.1/3", "10.1/1001", "10.1/1002"],
})


def _fake_abstracts(pmids, cache_path=None):
    """PubMed's titles and abstracts of the studies 1001 and 1002."""
    return {
        str(p): ("", f"The abstract of {p}.") if p in (1001, 1002, "1001", "1002")
        else ("", "")
        for p in pmids
    }


@pytest.fixture(autouse=True)
def _fake_study_metadata():
    """Serve FAKE_METADATA to the tests that call init_engine themselves."""
    with patch(f"{NS_INIT}.fetch_study_metadata", return_value=FAKE_METADATA):
        yield


class TestNeurosynthEngineStudyIdConsistency:
    """
    Regression test: study_id dtype must be consistent across all tuple sets.

    Currently ``init_engine`` loads ``peak_data`` study IDs as ``int64``
    (via ``fetch_neurosynth_peak_data`` without ``convert_study_ids``) while
    ``term_in_study_tfidf`` study IDs are ``StudyID``/``str`` (via
    ``get_ns_term_study_associations`` with ``convert_study_ids=True``).

    This test asserts that all ``study_id`` columns share the same integer
    dtype.  It is expected to **fail** until the inconsistency is fixed.
    """

    @patch("neurolang_apps.utils.engines.neurosynth.init.fetch_cognitive_atlas_tasks")
    @patch("neurolang_apps.utils.engines.neurosynth.init.fetch_cortical_atlas")
    @patch("neurolang_apps.utils.engines.neurosynth.init.fetch_neurosynth_peak_data")
    @patch("neurolang_apps.utils.engines.neurosynth.init.get_ns_term_study_associations")
    def test_study_id_consistency(
        self, mock_get_term, mock_get_peaks, mock_atlas, mock_tasks,
        tmp_path
    ):
        """All study_id columns should share the same integer dtype."""
        from neurolang_apps.utils.engines.neurosynth.init import init_engine

        # ---- Mock peak data: study_id is int64 -------------------------------
        mock_peaks_df = pd.DataFrame({
            "id": [1, 2, 3],
            "x": [0.0, 10.0, 20.0],
            "y": [0.0, 10.0, 20.0],
            "z": [0.0, 10.0, 20.0],
            "space": ["MNI", "MNI", "MNI"],
        })
        mock_get_peaks.return_value = mock_peaks_df

        # ---- Mock term data: study_id is StudyID (integer alias) -----------
        mock_term_df = pd.DataFrame({
            "id": [StudyID(1), StudyID(2), StudyID(3)],
            "term": ["memory", "memory", "language"],
            "tfidf": [0.5, 0.3, 0.7],
        })
        mock_get_term.return_value = mock_term_df

        # ---- Minimal nibabel mask (identity affine) --------------------------
        import nibabel as nib

        mask = nib.Nifti1Image(
            np.ones((10, 10, 10), dtype=np.uint8),
            np.eye(4),
        )
        mock_atlas.return_value = nib.Nifti1Image(
            np.zeros((10, 10, 10), dtype=np.int16), np.eye(4)
        )

        # ---- Mock NeurolangPDL to capture add_tuple_set calls ---------------
        nl = MagicMock(engine_cache_dir=None)  # no cache: a mock would be a path
        init_engine(nl, mask, data_dir=str(tmp_path / "fake"))

        # Collect the DataFrames that were passed to add_tuple_set
        captured_dfs: dict[str, pd.DataFrame] = {}
        for call in nl.add_tuple_set.call_args_list:
            args, kwargs = call
            df = args[0] if args else kwargs["iterable"]
            name = kwargs.get("name")
            if name is not None:
                captured_dfs[name] = df

        # ---- Assertions -----------------------------------------------------
        study_id_dtypes: dict[str, np.dtype] = {}
        for name in ("peak_reported", "study", "term_in_study_tfidf"):
            df = captured_dfs[name]
            study_id_dtypes[name] = df["study_id"].dtype

        # All three must be the same dtype
        dtypes_set = set(study_id_dtypes.values())
        assert len(dtypes_set) == 1, (
            f"study_id dtypes differ: {study_id_dtypes}"
        )

        # And that dtype must be a numpy integer subtype
        for name, dtype in study_id_dtypes.items():
            assert np.issubdtype(dtype, np.integer), (
                f"{name}.study_id has non-integer dtype: {dtype}"
            )


@patch("neurolang_apps.utils.engines.neurosynth.init.fetch_cognitive_atlas_tasks")
@patch("neurolang_apps.utils.engines.neurosynth.init.fetch_cortical_atlas")
@patch("neurolang_apps.utils.engines.neurosynth.init.fetch_neurosynth_peak_data")
@patch("neurolang_apps.utils.engines.neurosynth.init.get_ns_term_study_associations")
def test_neurosynth_cortical_mask(
    mock_get_term, mock_get_peaks, mock_atlas, mock_tasks
):
    """``cortical_mask(i, j, k)`` holds the voxels of the engine's grid
    labelled by the cortical atlas, resampled to that grid: here an atlas
    shifted by two voxels along i, and larger than the grid."""
    import nibabel as nib

    from neurolang_apps.utils.engines.neurosynth.init import init_engine

    mock_get_peaks.return_value = pd.DataFrame({
        "id": [1], "x": [0.0], "y": [0.0], "z": [0.0], "space": ["MNI"],
    })
    mock_get_term.return_value = pd.DataFrame({
        "id": [StudyID(1)], "term": ["memory"], "tfidf": [0.5],
    })
    labels = np.zeros((14, 10, 10), dtype=np.int16)
    labels[3, 4, 5] = 7
    labels[5, 0, 9] = 2
    labels[13, 0, 0] = 1  # outside the grid of the engine
    affine = np.eye(4)
    affine[0, 3] = -2
    mock_atlas.return_value = nib.Nifti1Image(labels, affine)
    mask = nib.Nifti1Image(np.ones((10, 10, 10), dtype=np.uint8), np.eye(4))

    nl = MagicMock(engine_cache_dir=None)  # no cache: a mock would be a path
    init_engine(nl, mask, data_dir=Path("unused"))

    sets = {
        call.kwargs["name"]: call.args[0]
        for call in nl.add_tuple_set.call_args_list
    }
    assert {tuple(v) for v in sets["cortical_mask"]} == {(1, 4, 5), (3, 0, 9)}


_COGNITIVE_ATLAS_TASKS = pd.DataFrame({
    "task_id": ["tsk_1", "trm_2"],
    "name": ["stop signal task", "n-back task"],
    "description": ["Stop when a signal appears.", ""],
})


@patch("neurolang_apps.utils.engines.neurosynth.init.fetch_cognitive_atlas_tasks")
@patch("neurolang_apps.utils.engines.neurosynth.init.fetch_cortical_atlas")
@patch("neurolang_apps.utils.engines.neurosynth.init.fetch_neurosynth_peak_data")
@patch("neurolang_apps.utils.engines.neurosynth.init.get_ns_term_study_associations")
def test_neurosynth_cognitive_atlas_tasks(
    mock_get_term, mock_get_peaks, mock_atlas, mock_tasks
):
    """``cognitive_task(task_id, name, description)`` holds the tasks of
    the Cognitive Atlas."""
    import nibabel as nib

    from neurolang_apps.utils.engines.neurosynth.init import init_engine

    mock_get_peaks.return_value = pd.DataFrame({
        "id": [1], "x": [0.0], "y": [0.0], "z": [0.0], "space": ["MNI"],
    })
    mock_get_term.return_value = pd.DataFrame({
        "id": [StudyID(1)], "term": ["memory"], "tfidf": [0.5],
    })
    mask = nib.Nifti1Image(np.ones((4, 4, 4), dtype=np.uint8), np.eye(4))
    mock_atlas.return_value = nib.Nifti1Image(
        np.zeros((4, 4, 4), dtype=np.int16), np.eye(4)
    )
    mock_tasks.return_value = _COGNITIVE_ATLAS_TASKS

    nl = MagicMock(engine_cache_dir=None)  # no cache: a mock would be a path
    init_engine(nl, mask, data_dir=Path("unused"))

    sets = {
        call.kwargs["name"]: call.args[0]
        for call in nl.add_tuple_set.call_args_list
    }
    pd.testing.assert_frame_equal(
        sets["cognitive_task"], _COGNITIVE_ATLAS_TASKS
    )


def test_fetch_cognitive_atlas_tasks(tmp_path):
    """The tasks of the Cognitive Atlas API, with their names and
    descriptions stripped, a missing description empty, and the tasks
    without a name left out."""
    import json

    from neurolang_apps.utils.engines.neurosynth import init

    tasks = tmp_path / "tasks.json"
    tasks.write_text(json.dumps([
        {"id": "tsk_1", "name": " stop signal task ",
         "definition_text": "Stop when a signal appears.\n"},
        {"id": "trm_2", "name": "n-back task", "definition_text": None},
        {"id": "trm_3", "name": "", "definition_text": "None"},
    ]))
    with patch.object(init, "fetch_files", return_value=[str(tasks)]) as fetch:
        result = init.fetch_cognitive_atlas_tasks(tmp_path)

    (directory, files), _ = fetch.call_args
    assert directory == str(tmp_path / "cognitive_atlas")
    assert files[0][1] == init.COGNITIVE_ATLAS_TASKS_URL
    pd.testing.assert_frame_equal(result, _COGNITIVE_ATLAS_TASKS)


GRAPH = """
@prefix ex: <http://example.org/> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
ex:Dog a owl:Class ; rdfs:subClassOf ex:Animal .
ex:Animal a owl:Class .
ex:rex a ex:Dog ; ex:name "Rex" .
"""


def test_ontologies_load_local_files_with_options(tmp_path):
    """``ontologies`` loads local files together, with their options."""
    from neurolang_apps.utils import engine_registry

    (tmp_path / "data").mkdir()
    (tmp_path / "data" / "vocab.ttl").write_text(GRAPH)
    (tmp_path / "data" / "more.nt").write_text(
        '<http://example.org/rex> <http://example.org/age> "3" .\n'
    )
    config = tmp_path / "engines.yaml"
    config.write_text(
        "engines:\n"
        "  pets:\n"
        "    ontologies:\n"
        "      - urls: [data/vocab.ttl, data/more.nt]\n"
        "        individuals: true\n"
        "        names: prefixed\n"
    )
    nl = engine_registry.build_engine(
        "pets", tmp_path / "cache", yaml_path=config
    )
    animals = nl.execute_datalog_program(
        "ans(n, a) :- ex:Animal(x), ex:name(x, n), ex:age(x, a)"
    )
    assert set(animals) == {("Rex", "3")}


def test_ontologies_declare_prefixes(tmp_path):
    """``prefixes`` names the classes of a namespace the file declares no
    prefix for."""
    from neurolang_apps.utils import engine_registry

    (tmp_path / "vocab.ttl").write_text(
        "@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .\n"
        "@prefix owl: <http://www.w3.org/2002/07/owl#> .\n"
        "<http://example.org/Dog> a owl:Class ;\n"
        "    rdfs:subClassOf <http://example.org/Animal> .\n"
        "<http://example.org/Animal> a owl:Class .\n"
        "<http://example.org/rex> a <http://example.org/Dog> ;\n"
        '    <http://example.org/name> "Rex" .\n'
    )
    config = tmp_path / "engines.yaml"
    config.write_text(
        "engines:\n"
        "  pets:\n"
        "    ontologies:\n"
        "      - url: vocab.ttl\n"
        "        individuals: true\n"
        "        names: prefixed\n"
        "        prefixes:\n"
        "          ex: http://example.org/\n"
    )
    nl = engine_registry.build_engine(
        "pets", tmp_path / "cache", yaml_path=config
    )
    assert set(nl.execute_datalog_program(
        "ans(n) :- ex:Animal(x), ex:name(x, n)"
    )) == {("Rex",)}


def test_sparql_builtins(tmp_path):
    """The SPARQL-like builtins apply to strings and numbers."""
    from neurolang_apps.utils import engine_registry

    config = tmp_path / "engines.yaml"
    config.write_text(
        "engines:\n"
        "  words:\n"
        "    builtins: [lcase, strlen, str_contains, regex, round, int,"
        " strstarts]\n"
    )
    nl = engine_registry.build_engine(
        "words", tmp_path / "cache", yaml_path=config
    )
    nl.add_tuple_set(
        [("a", "Russia", "12", 2.5), ("b", "France", "7", -2.5)],
        name="country",
    )
    result = nl.execute_datalog_program(
        "ans(x, l, n, q, r) :- country(x, c, s, v), (l == lcase(c)), "
        "(n == strlen(c)), (q == int(s)), (r == round(v))"
    )
    assert set(result) == {
        ("a", "russia", 6, 12, 3.0), ("b", "france", 6, 7, -3.0)
    }
    matched = nl.execute_datalog_program(
        "ans(x) :- country(x, c, s, v), str_contains(lcase(c), 'russ'), "
        "regex(c, '(?i)^RU'), strstarts(c, 'R')"
    )
    assert set(matched) == {("a",)}


def test_t_pvalue_builtin(tmp_path):
    """t_pvalue(t, df) is the two-sided p-value of Student's t, as scipy's
    Student test gives it, in a rule."""
    import numpy as np
    from scipy import stats

    from neurolang_apps.utils import engine_registry

    config = tmp_path / "engines.yaml"
    config.write_text("engines:\n  stats:\n    builtins: [t_pvalue]\n")
    nl = engine_registry.build_engine(
        "stats", tmp_path / "cache", yaml_path=config
    )
    a, b = [0.3, 0.5, 0.4, 0.6], [0.1, 0.2, 0.0, 0.15, 0.25]
    student = stats.ttest_ind(a, b)
    nl.add_tuple_set([(student.statistic, len(a) + len(b) - 2)], name="test")
    (p,), = nl.execute_datalog_program(
        "ans(p) :- test(t, df), (p == t_pvalue(t, df))")
    assert np.isclose(p, student.pvalue)
    assert engine_registry._builtin_t_pvalue(-2.0, 10) == \
        engine_registry._builtin_t_pvalue(2.0, 10)


def test_fdr_threshold_aggregation(tmp_path):
    """fdr_threshold(p, alpha), in the head of a rule, is the cut-off of
    Benjamini and Hochberg: the tests under it are those whose q-values
    are at most alpha."""
    import numpy as np

    from neurolang_apps.utils import engine_registry

    config = tmp_path / "engines.yaml"
    config.write_text("engines:\n  stats:\n    builtins: [fdr_threshold]\n")
    nl = engine_registry.build_engine(
        "stats", tmp_path / "cache", yaml_path=config
    )
    p = [0.001, 0.008, 0.039, 0.041, 0.042, 0.06, 0.074, 0.205, 0.212, 0.216]
    nl.add_tuple_set([(f"test{i}", v) for i, v in enumerate(p)],
                     name="p_value")
    significant = nl.execute_datalog_program(
        "cutoff(fdr_threshold(p, 0.05)) :- p_value(x, p)\n"
        "ans(x) :- p_value(x, p), cutoff(c), (p <= c)")
    m = len(p)
    q = np.minimum.accumulate(
        (np.array(p) * m / np.arange(1, m + 1))[::-1])[::-1]
    assert {x for x, in significant} == {
        f"test{i}" for i in range(m) if q[i] <= 0.05}
    assert engine_registry._builtin_fdr_threshold([0.5, 0.9], 0.05) == 0.0


class TestNeurosynthEngineVocabulary:
    """Check the vocabulary predicates the neurosynth engine defines."""

    @patch("neurolang_apps.utils.engines.neurosynth.init.fetch_cognitive_atlas_tasks")
    @patch("neurolang_apps.utils.engines.neurosynth.init.fetch_cortical_atlas")
    @patch("neurolang_apps.utils.engines.neurosynth.init.fetch_neurosynth_peak_data")
    @patch("neurolang_apps.utils.engines.neurosynth.init.get_ns_term_study_associations")
    def test_term_relation_holds_distinct_terms(
        self, mock_get_term, mock_get_peaks, mock_atlas, mock_tasks
    ):
        """Check that ``term`` lists every TF-IDF term once."""
        import nibabel as nib

        from neurolang_apps.utils.engines.neurosynth.init import init_engine

        mock_get_peaks.return_value = pd.DataFrame({
            "id": [1, 2], "x": [0.0, 1.0], "y": [0.0, 1.0],
            "z": [0.0, 1.0], "space": ["MNI", "MNI"],
        })
        mock_get_term.return_value = pd.DataFrame({
            "id": [StudyID(1), StudyID(2), StudyID(2)],
            "term": ["memory", "memory", "language"],
            "tfidf": [0.5, 0.3, 0.7],
        })
        mask = nib.Nifti1Image(np.ones((4, 4, 4), dtype=np.uint8), np.eye(4))
        mock_atlas.return_value = nib.Nifti1Image(
            np.zeros((4, 4, 4), dtype=np.int16), np.eye(4)
        )
        nl = MagicMock(engine_cache_dir=None)  # no cache: a mock would be a path

        init_engine(nl, mask, data_dir="unused")

        added = {
            call.kwargs["name"]: (call.args[0] if call.args else None)
            for call in nl.add_tuple_set.call_args_list
        }
        assert list(added["term"].columns) == ["term"]
        assert sorted(added["term"]["term"]) == ["language", "memory"]

    def test_vocabulary_predicates_are_declared(self):
        """Check the YAML declares the vocabulary predicates' columns."""
        from neurolang_apps.utils import engine_registry

        predicates = engine_registry.get_predicates("neurosynth")
        expected = {
            "term": ["term"],
            "study": ["study_id"],
            "voxel": ["i", "j", "k"],
            "mentions": ["study_id", "term"],
            "reports": ["study_id", "i", "j", "k"],
        }
        for name, columns in expected.items():
            assert predicates[name]["columns"] == columns
            assert predicates[name]["arity"] == len(columns)
            assert predicates[name]["description"]

    def test_mentions_and_reports_match_their_declared_order(self):
        """Check the datalog_init rules agree with the declared columns."""
        from neurolang_apps.utils import engine_registry

        datalog_init = engine_registry.get_engine_config("neurosynth")[
            "datalog_init"
        ]
        assert (
            "mentions(s, t) :- term_in_study_tfidf(s, t, v)" in datalog_init
        )
        assert "reports(s, i, j, k) :- peak_reported(i, j, k, s)" in datalog_init

    def test_weighted_mention_is_declared(self):
        """Check ``weighted_mention`` has the columns of the TF-IDF."""
        from neurolang_apps.utils import engine_registry

        config = engine_registry.get_engine_config("neurosynth")
        info = engine_registry.get_predicates("neurosynth")["weighted_mention"]
        assert info["columns"] == ["study_id", "term", "tfidf"]
        assert info["arity"] == 3
        assert "Weighted_mention" in info["description"]
        assert (
            "weighted_mention(s, t, w) :- term_in_study_tfidf(s, t, w)"
            in config["datalog_init"]
        )
        assert "term_in_study_tfidf" in engine_registry.get_predicates(
            "neurosynth"
        )

    @pytest.mark.squall
    def test_weighted_mention_reads_in_squall(self):
        """Check a SQUALL sentence on ``weighted_mention`` gets its rows."""
        from neurolang.frontend import NeurolangPDL
        from neurolang_apps.utils import engine_registry

        datalog_init = engine_registry.get_engine_config("neurosynth")[
            "datalog_init"
        ]
        rule = next(
            line.strip() for line in datalog_init.splitlines()
            if line.strip().startswith("weighted_mention(")
        )
        nl = NeurolangPDL()
        nl.add_tuple_set(
            [(10, "pain", 0.5), (11, "pain", 0.05), (11, "fear", 0.4)],
            name="term_in_study_tfidf",
        )
        nl.execute_datalog_program(rule)
        result = nl.execute_squall_program(
            "obtain every Weighted_mention (?s; ?t; ?w) "
            "such that ?t is 'pain' and ?w is greater than 0.1."
        )
        rows = {
            tuple(row)
            for row in result.as_pandas_dataframe()[["s", "t", "w"]].values
        }
        assert rows == {(10, "pain", 0.5)}


_FAKE_ATLASES = {
    "schaefer": "17Networks LH DefaultA PCC 1",
    "destrieux": "L G temporal middle",
    "tian": "lAMY lh",
    # the finer Schaefer atlas of the connectivity engines
    "schaefer400": "17Networks LH DefaultA PFCd 1",
}


def _fake_schaefer(nl, cfg, data_dir, name, use_cache=True):
    """
    Register one-region ``schaefer``, ``destrieux`` and ``tian`` atlases
    with the studies activating and covering them and the points *cfg*
    asks for, as ``_phase_atlases``.
    """
    import nibabel as nib

    from neurolang.atlases import Atlas
    from neurolang_apps.utils import engine_registry

    voxels = np.array([[1, 1, 1], [1, 2, 1]])
    data = np.zeros((4, 4, 4), dtype=np.int16)
    data[tuple(voxels.T)] = 1
    image = nib.Nifti1Image(data, np.eye(4))
    for name, label in _FAKE_ATLASES.items():
        atlas = Atlas.from_labels(name, image, {1: label}, "MNI152")
        nl.add_atlas_set(name, atlas)
        engine_registry._register_atlas_activation(
            nl, {1: label}, image, {"radius_mm": 3}, name
        )
        engine_registry._register_atlas_coverage(
            nl, {1: label}, image, {}, name
        )
        points = cfg["atlases"][name].get("points")
        if points:
            engine_registry._register_atlas_points(nl, atlas, points)


def _fake_relations(nl, cfg, engine_name, data_dir, rel_base_dir):
    """
    Register one row of each relation of *cfg* (the connectivity's, which
    the engines download), as ``_phase_relations``, its values of the
    declared sorts: a label of a sort of an atlas that of the fake atlas
    (``_FAKE_ATLASES``), so that it is one of the atlas's.
    """
    import pandas as pd

    from neurolang_apps.utils import engine_registry

    sorts = cfg.get("sorts", {})
    signatures = engine_registry.get_signatures(engine_name)
    for name in cfg.get("relations", {}):
        row = []
        for argument in signatures[name]:
            atlas = sorts.get(argument.sort, {}).get("atlas")
            if atlas:
                first = atlas if isinstance(atlas, str) else atlas[0]
                row.append(_FAKE_ATLASES[first])
            else:
                row.append({"int": 1, "float": 0.5}.get(argument.type, "L"))
        nl.add_tuple_set(pd.DataFrame([row]), name=name)


# The predicates of a free-text query: computed for the text a query gives
# as a constant, not for every text (``solve_all`` cannot).
FREE_TEXT_PREDICATES = frozenset({
    "study_similarity", "similar_study", "lift_llm", "relative_risk_llm",
    "uniformity_llm", "ratios_llm",
})


def _without_free_text_rules(config):
    """Return the engine *config* without the rules of a free-text query."""
    names = FREE_TEXT_PREDICATES | {
        "p_similar", "p_a_given_similar",
        "p_any_voxel_given_similar",
    }
    rules = [
        line for line in config["datalog_init"].splitlines()
        if line.split("(")[0] not in names
    ]
    return {**config, "datalog_init": "\n".join(rules)}


@pytest.fixture(scope="module")
def small_neurosynth():
    """Build the neurosynth engine of the registry on tiny mock data."""
    return _build_small_neurosynth()


# The sparse views of the coordinate meta-analysis engines, those of the
# comment of ``engines.yaml``.
COORDINATE_VIEWS = {
    "activated": ["voxel", "study"],
    "schaefer_activated": ["label", "study"],
    "schaefer400_activated": ["schaefer400_label", "study"],
    "destrieux_activated": ["destrieux_label", "study"],
    "tian_activated": ["tian_label", "study"],
}


@pytest.fixture(scope="module")
def small_neurosynth_views():
    """Build the neurosynth engine on tiny mock data, with the sparse
    views of :data:`COORDINATE_VIEWS`."""
    return _build_small_neurosynth(sparse_views=COORDINATE_VIEWS)


def _build_small_neurosynth(free_text=True, sparse_views=None):
    """Build the neurosynth engine on tiny data, with the free-text rules
    of its configuration or without, and the *sparse_views*, if any."""
    import nibabel as nib

    from neurolang_apps.utils import engine_registry

    peaks = pd.DataFrame({
        "id": [1001, 1001, 1002], "x": [1.0, 2.0, 3.0],
        "y": [1.0, 2.0, 3.0], "z": [1.0, 2.0, 3.0],
        "space": ["MNI", "MNI", "MNI"],
    })
    terms = pd.DataFrame({
        "id": [StudyID(1001), StudyID(1002), StudyID(1002)],
        "term": ["memory", "memory", "language"],
        "tfidf": [0.5, 0.3, 0.02],
    })
    mask = nib.Nifti1Image(np.ones((4, 4, 4), dtype=np.uint8), np.eye(4))
    cortex = np.zeros((4, 4, 4), dtype=np.int16)
    cortex[1, 2, 3] = 1
    init = "neurolang_apps.utils.engines.neurosynth.init"
    with patch(f"{init}.fetch_neurosynth_peak_data", return_value=peaks), \
            patch(f"{init}.get_ns_term_study_associations",
                  return_value=terms), \
            patch(f"{init}.fetch_cortical_atlas",
                  return_value=nib.Nifti1Image(cortex, np.eye(4))), \
            patch(f"{init}.fetch_cognitive_atlas_tasks",
                  return_value=_COGNITIVE_ATLAS_TASKS), \
            patch(f"{init}.fetch_study_metadata",
                  return_value=FAKE_METADATA), \
            patch.object(engine_registry, "_resolve_mask",
                         return_value=mask), \
            patch.object(engine_registry, "_phase_atlases", _fake_schaefer), \
            patch.object(engine_registry, "_phase_relations",
                         _fake_relations), \
            patch(f"{init}.fetch_pubmed_abstracts", _fake_abstracts):
        if free_text and not sparse_views:
            return engine_registry.build_engine("neurosynth", DATA_DIR)
        config = engine_registry.get_engine_config

        def get_config(name, yaml_path=None):
            cfg = config(name, yaml_path)
            if not free_text:
                cfg = _without_free_text_rules(cfg)
            return {**cfg, "sparse_views": sparse_views or {}}

        with patch.object(engine_registry, "get_engine_config", get_config):
            return engine_registry.build_engine("neurosynth", DATA_DIR)


_TYPES = {
    "int": numbers.Integral, "float": float, "str": str,
}


def _relation(nl, solution, name):
    """
    Return the rows of the relation *name* of *nl*, as a DataFrame.

    A stored relation is read from the engine, which keeps its regions;
    a derived one from the *solution*.
    """
    from nl_expr.expressions import Symbol

    stored = getattr(nl.program_ir.symbol_table[Symbol(name)], "value", None)
    if hasattr(stored, "unwrap"):
        return stored.unwrap().as_pandas_dataframe()
    return solution[name].as_pandas_dataframe()


def _column_type(nl, name, column):
    """Return the type of the *column* of the stored relation *name*."""
    from nl_expr.expressions import Symbol

    row_type = nl.program_ir.symbol_table[Symbol(name)].type.__args__[0]
    return row_type.__args__[column]


def _column_values(frame, start, width):
    """Return the set of rows of *width* columns of *frame* from *start*."""
    columns = frame.iloc[:, start:start + width]
    return set(columns.itertuples(index=False, name=None))


# The relation holding every entity of a sort.
_NOUNS = {
    "study": "study", "term": "term", "voxel": "voxel",
    "label": "schaefer_label",
}


def _check_argument(nl, solution, name, argument, start):
    """
    Check the *argument* of *name* from its column *start*.

    Its values have the declared type and, for a sort of which a
    relation holds every entity, are entities of that relation.
    """
    from neurolang.regions import ExplicitVBR

    width = len(argument.columns)
    values = _column_values(_relation(nl, solution, name), start, width)
    if argument.type in _TYPES:
        assert all(
            isinstance(value, _TYPES[argument.type])
            for row in values for value in row
        ), (name, argument)
    else:
        assert _column_type(nl, name, start) is ExplicitVBR, name
    noun = _NOUNS.get(argument.sort, name)
    if noun != name:
        known = _column_values(_relation(nl, solution, noun), 0, width)
        assert values <= known, (name, argument)


class TestNeurosynthDeclarations:
    """Check the declared arguments against the symbols of the engine."""

    def test_every_declaration_matches_its_symbol(self):
        """Check the column count, order and types of each predicate."""
        from neurolang_apps.utils import engine_registry

        small_neurosynth = _build_small_neurosynth(free_text=False)
        predicates = engine_registry.get_predicates("neurosynth")
        signatures = engine_registry.get_signatures("neurosynth")
        with small_neurosynth.scope:
            solution = small_neurosynth.solve_all()
        assert set(signatures) == set(predicates)
        for name, arguments in signatures.items():
            if name in FREE_TEXT_PREDICATES:
                continue
            frame = _relation(small_neurosynth, solution, name)
            probability = int(bool(predicates[name].get("probability")))
            assert frame.shape[1] == predicates[name]["arity"] + probability
            assert len(frame) > 0, name
            start = probability
            for argument in arguments:
                _check_argument(
                    small_neurosynth, solution, name, argument, start
                )
                start += len(argument.columns)

    def test_hidden_predicates_are_declared(self):
        """Check the hidden predicates are declared predicates."""
        from neurolang_apps.utils import engine_registry

        hidden = engine_registry.get_hidden_predicates("neurosynth")
        assert hidden == {"peak_reported", "schaefer_voxels"}
        assert hidden <= set(engine_registry.get_predicates("neurosynth"))

    def test_probability_declared_for_the_choice(self):
        """Check the choices over the studies and the voxels, and the
        coverage of the atlases' regions, are the probabilistic predicates."""
        from neurolang_apps.utils import engine_registry

        assert engine_registry.get_probabilistic_predicates(
            "neurosynth"
        ) == {
            "selected_study", "selected_voxel", "schaefer_covered",
            "schaefer400_covered", "destrieux_covered", "tian_covered",
        }


class TestPredicateArguments:
    """Check the parsing and validation of the declared arguments."""

    def test_columns_and_arity_come_from_the_arguments(self):
        """Check a voxel is one entity of three columns."""
        from neurolang_apps.utils import engine_registry

        info = engine_registry.get_predicates("neurosynth")["reports"]
        assert info["columns"] == ["study_id", "i", "j", "k"]
        assert info["arity"] == 4
        assert info["entities"] == 2
        reports = engine_registry.get_signatures("neurosynth")["reports"]
        assert [argument.sort for argument in reports] == ["study", "voxel"]
        assert reports[1].columns == ("i", "j", "k")
        assert reports[1].type == "int"

    def test_declared_columns_must_agree(self, tmp_path):
        """Check columns contradicting the arguments are rejected."""
        from neurolang_apps.utils import engine_registry

        path = _engine_yaml(tmp_path, "columns: [a, b]")
        with pytest.raises(ValueError, match="columns"):
            engine_registry.get_predicates("e", path)
        path = _engine_yaml(tmp_path, "arity: 3")
        with pytest.raises(ValueError, match="arity"):
            engine_registry.get_predicates("e", path)
        path = _engine_yaml(tmp_path, "columns: [s, i, j, k]")
        assert engine_registry.get_predicates("e", path)["p"]["arity"] == 4

    def test_a_sort_spans_the_same_columns_everywhere(self, tmp_path):
        """Check a sort of different widths is rejected."""
        from neurolang_apps.utils import engine_registry

        path = _engine_yaml(
            tmp_path, "",
            "      q:\n        arguments:\n"
            "          - {sort: voxel, columns: [x, y], type: int}\n",
        )
        with pytest.raises(ValueError, match="voxel"):
            engine_registry.get_signatures("e", path)

    def test_destrieux_regions(self):
        """Check the destrieux predicates relate a label and a region."""
        from neurolang_apps.utils import engine_registry

        signatures = engine_registry.get_signatures("destrieux")
        for name in ("destrieux", "left_region", "right_region"):
            assert [a.sort for a in signatures[name]] == ["label", "region"]
        assert engine_registry.get_predicates("destrieux")["destrieux"][
            "columns"
        ] == ["name", "region"]


_SORTED_ENGINE = (
    "engines:\n  e:\n"
    "    sorts:\n"
    "      study: {columns: [study_id], type: int, description: a study}\n"
    "      voxel:\n"
    "        columns: [i, j, k]\n"
    "        type: int\n"
    "        description: a voxel of the MNI template grid, in 3D\n"
    "    predicates:\n"
    "      reports:\n"
    "        arguments: [study, {sort: voxel}]\n"
    "      peak:\n"
    "        arguments:\n"
    "          - {sort: voxel, columns: [x, y, z]}\n"
    "          - {sort: study, columns: [s], type: int}\n"
)


class TestDeclaredSorts:
    """Check the sorts an engine declares once, by name."""

    def test_sorts_are_read(self, tmp_path):
        """Check each sort keeps its columns, type and description."""
        from neurolang_apps.utils import engine_registry

        path = tmp_path / "engines.yaml"
        path.write_text(_SORTED_ENGINE)
        sorts = engine_registry.get_sorts("e", path)
        assert sorts["voxel"] == engine_registry.Sort(
            "voxel", ("i", "j", "k"), "int",
            "a voxel of the MNI template grid, in 3D",
        )
        assert sorts["study"].columns == ("study_id",)

    def test_an_argument_names_its_sort(self, tmp_path):
        """Check a reference to a sort takes its columns and type."""
        from neurolang_apps.utils import engine_registry

        path = tmp_path / "engines.yaml"
        path.write_text(_SORTED_ENGINE)
        info = engine_registry.get_predicates("e", path)["reports"]
        assert info["columns"] == ["study_id", "i", "j", "k"]
        assert info["arity"] == 4 and info["entities"] == 2
        reports = engine_registry.get_signatures("e", path)["reports"]
        assert reports == (
            engine_registry.Argument("study", ("study_id",), "int"),
            engine_registry.Argument("voxel", ("i", "j", "k"), "int"),
        )

    def test_an_argument_may_rename_the_columns(self, tmp_path):
        """Check a predicate may name the columns of a sort its own way."""
        from neurolang_apps.utils import engine_registry

        path = tmp_path / "engines.yaml"
        path.write_text(_SORTED_ENGINE)
        peak = engine_registry.get_signatures("e", path)["peak"]
        assert peak[0] == engine_registry.Argument(
            "voxel", ("x", "y", "z"), "int"
        )
        assert peak[1].columns == ("s",)

    def test_a_reference_names_a_declared_sort(self, tmp_path):
        """Check a reference to an undeclared sort is rejected."""
        from neurolang_apps.utils import engine_registry

        path = tmp_path / "engines.yaml"
        path.write_text(
            _SORTED_ENGINE.replace("[study, {sort: voxel}]", "[study, place]")
        )
        with pytest.raises(ValueError, match="place"):
            engine_registry.get_predicates("e", path)

    def test_renamed_columns_keep_the_width_of_the_sort(self, tmp_path):
        """Check renamed columns must span as many columns as the sort."""
        from neurolang_apps.utils import engine_registry

        path = tmp_path / "engines.yaml"
        path.write_text(_SORTED_ENGINE.replace("[x, y, z]", "[x, y]"))
        with pytest.raises(ValueError, match="voxel"):
            engine_registry.get_signatures("e", path)

    @pytest.mark.parametrize("engine", ["neurosynth", "destrieux"])
    def test_the_engines_reference_their_sorts(self, engine):
        """Check the shipped engines declare their arguments by sort."""
        from neurolang_apps.utils import engine_registry

        config = engine_registry.get_engine_config(engine)
        sorts = engine_registry.get_sorts(engine)
        for name, info in config["predicates"].items():
            for argument in info["arguments"]:
                assert isinstance(argument, str), (name, argument)
                assert argument in sorts, (name, argument)

    def test_neurosynth_sorts(self):
        """Check the voxel grids of neurosynth are 3D sorts."""
        from neurolang_apps.utils import engine_registry

        sorts = engine_registry.get_sorts("neurosynth")
        assert sorts["voxel"].columns == ("i", "j", "k")
        assert sorts["atlas_voxel"].columns == ("i", "j", "k")
        assert "3D" in sorts["voxel"].description
        assert sorts["study"] == engine_registry.Sort(
            "study", ("study_id",), "int", sorts["study"].description
        )

    def test_cognitive_task_is_declared(self):
        """Check ``cognitive_task`` relates a task, its name and its
        description."""
        from neurolang_apps.utils import engine_registry

        predicates = engine_registry.get_predicates("neurosynth")
        assert predicates["cognitive_task"]["columns"] == [
            "task_id", "name", "description"
        ]


def _engine_yaml(tmp_path, extra: str, more: str = "") -> Path:
    """Write an engine ``e`` declaring ``p(s, i, j, k)`` with *extra*."""
    path = tmp_path / "engines.yaml"
    path.write_text(
        "engines:\n  e:\n    predicates:\n      p:\n"
        + (f"        {extra}\n" if extra else "")
        + "        arguments:\n"
        "          - {sort: study, columns: [s], type: int}\n"
        "          - {sort: voxel, columns: [i, j, k], type: int}\n"
        + more
    )
    return path


class TestSortSpaces:
    """Check the sorts declaring the space of their coordinates."""

    def test_space_is_read(self, tmp_path):
        """Check a sort keeps its declared space, empty by default."""
        from neurolang_apps.utils import engine_registry

        path = tmp_path / "engines.yaml"
        path.write_text(
            "engines:\n  e:\n    sorts:\n"
            "      voxel: {columns: [i, j, k], type: int, space: voxel}\n"
            "      mni: {columns: [x, y, z], type: float, space: mm}\n"
            "      study: {columns: [s], type: int}\n"
        )
        sorts = engine_registry.get_sorts("e", path)
        assert sorts["voxel"].space == "voxel"
        assert sorts["mni"].space == "mm"
        assert sorts["study"].space == ""

    def test_unknown_space_is_rejected(self, tmp_path):
        """Check a space is ``voxel`` or ``mm``."""
        from neurolang_apps.utils import engine_registry

        path = tmp_path / "engines.yaml"
        path.write_text(
            "engines:\n  e:\n    sorts:\n"
            "      voxel: {columns: [i, j, k], type: int, space: grid}\n"
        )
        with pytest.raises(ValueError, match="grid"):
            engine_registry.get_sorts("e", path)

    def test_neurosynth_spaces(self):
        """Check neurosynth declares its template grid and MNI millimetres."""
        from neurolang_apps.utils import engine_registry

        sorts = engine_registry.get_sorts("neurosynth")
        assert sorts["voxel"].space == "voxel"
        assert sorts["mni"] == engine_registry.Sort(
            "mni", ("x", "y", "z"), "float", sorts["mni"].description, "mm"
        )
        assert sorts["voxel"].grid == ""
        # The Schaefer atlas indexes its own grid, not the template's.
        assert sorts["atlas_voxel"].space == "voxel"
        assert sorts["atlas_voxel"].grid == "schaefer"

    @pytest.mark.parametrize("grid", ["template", "schaefer"])
    def test_grid_is_read(self, tmp_path, grid):
        """Check a sort of voxels names the grid it indexes."""
        from neurolang_apps.utils import engine_registry

        path = tmp_path / "engines.yaml"
        path.write_text(
            "engines:\n  e:\n    atlases:\n      schaefer: {n_rois: 100}\n"
            "    sorts:\n"
            "      v: {columns: [i, j, k], type: int, space: voxel, "
            f"grid: {grid}}}\n"
        )
        assert engine_registry.get_sorts("e", path)["v"].grid == grid

    def test_unknown_grid_is_rejected(self, tmp_path):
        """Check a grid is the template's or one of the engine's atlases."""
        from neurolang_apps.utils import engine_registry

        path = tmp_path / "engines.yaml"
        path.write_text(
            "engines:\n  e:\n    atlases:\n      schaefer: {n_rois: 100}\n"
            "    sorts:\n"
            "      v: {columns: [i, j, k], type: int, space: voxel, "
            "grid: nowhere}\n"
        )
        with pytest.raises(ValueError, match="nowhere") as info:
            engine_registry.get_sorts("e", path)
        assert "template, schaefer" in str(info.value)
        with pytest.raises(ValueError, match="nowhere"):
            engine_registry.get_predicates("e", path)

    def test_grid_of_a_sort_not_of_voxels_is_rejected(self, tmp_path):
        """Check only a sort of ``space: voxel`` names a grid."""
        from neurolang_apps.utils import engine_registry

        path = tmp_path / "engines.yaml"
        path.write_text(
            "engines:\n  e:\n    sorts:\n"
            "      p: {columns: [x, y, z], type: float, space: mm, "
            "grid: template}\n"
        )
        with pytest.raises(ValueError, match="space: voxel"):
            engine_registry.get_sorts("e", path)


class TestEngineTemplate:
    """Check an engine keeps the template its voxel indices refer to."""

    def test_the_template_is_the_mask(self, small_neurosynth):
        """Check the voxel grid of neurosynth is the MNI mask's."""
        template = small_neurosynth.template
        assert template.shape == (4, 4, 4)
        assert np.array_equal(template.affine, np.eye(4))

    def test_no_template_without_a_mask(self, tmp_path):
        """Check an engine not requiring the MNI mask has no template."""
        from neurolang_apps.utils import engine_registry

        path = tmp_path / "engines.yaml"
        path.write_text("engines:\n  e:\n    description: bare\n")
        nl = engine_registry.build_engine("e", tmp_path, yaml_path=path)
        assert nl.template is None
        assert nl.grids == {}

    def test_the_template_is_a_grid(self, small_neurosynth):
        """Check the template is the engine's ``template`` grid."""
        assert small_neurosynth.grids["template"] is (
            small_neurosynth.template
        )

    def test_an_atlas_is_a_grid(self, tmp_path, monkeypatch):
        """Check loading an atlas registers its image as a grid."""
        import nibabel as nib

        from neurolang_apps.utils import engine_registry

        data = np.zeros((3, 5, 2), dtype=np.int16)
        data[2, 4, 1], data[0, 0, 0] = 1, 2
        affine = np.diag([3.0, 3.0, 3.0, 1.0])
        nib.save(nib.Nifti1Image(data, affine), tmp_path / "atlas.nii")
        monkeypatch.setitem(
            engine_registry._ATLAS_REGISTRY, "schaefer", {
                "fetch": lambda **kw: {
                    "maps": str(tmp_path / "atlas.nii"),
                    "labels": ["Background", "A", "B"],
                },
                "probabilistic": False,
            },
        )
        path = tmp_path / "engines.yaml"
        path.write_text(
            "engines:\n  e:\n    atlases:\n"
            "      schaefer: {predicate_name: parcels}\n"
        )
        nl = engine_registry.build_engine("e", tmp_path, yaml_path=path)
        grid = nl.grids["schaefer"]
        assert grid.shape == (3, 5, 2)
        assert np.array_equal(grid.affine, affine)


# GH-1075: the template of the engines below, a 2 mm grid whose voxel
# (i, j, k) is at (2 i - 6, 2 j, 2 k) mm, and two atlases of the same
# regions, L (x < 0) and R (x >= 0), on other grids: one with its x axis
# flipped, as FSL's, and one with another shape and origin.
TEMPLATE_1075 = np.diag([2.0, 2.0, 2.0, 1.0])
TEMPLATE_1075[0, 3] = -6
FLIPPED_1075 = np.array([
    [-1.0, 0, 0, 5], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]
])
SHIFTED_1075 = np.array([
    [1.0, 0, 0, -9], [0, 1, 0, -2], [0, 0, 1, -1], [0, 0, 0, 1]
])


def _hemisphere_atlas(affine, shape):
    """A label image on the grid *affine*, *shape*: 1 (L) where x < 0,
    2 (R) elsewhere, in millimetres."""
    import nibabel as nib

    ijk = np.indices(shape).reshape(3, -1).T
    x = nib.affines.apply_affine(affine, ijk)[:, 0]
    return nib.Nifti1Image(
        np.where(x < 0, 1, 2).astype(np.int16).reshape(shape), affine
    )


@pytest.fixture
def engine_1075(tmp_path, monkeypatch):
    """An engine with the template above and Schaefer and Tian on their
    own grids, with ``at_<atlas>(l, i, j, k)`` the label of each of their
    voxels (i, j, k), as ``labels`` of the engines."""
    import nibabel as nib

    from neurolang_apps.utils import engine_registry

    template = nib.Nifti1Image(np.ones((6, 4, 4), np.float32), TEMPLATE_1075)
    monkeypatch.setattr(
        engine_registry, "_get_mni_mask", lambda data_dir: template
    )
    for kind, affine, shape in (
        ("schaefer", FLIPPED_1075, (12, 8, 8)),
        ("tian", SHIFTED_1075, (16, 10, 9)),
    ):
        nib.save(_hemisphere_atlas(affine, shape), tmp_path / f"{kind}.nii")
        monkeypatch.setitem(engine_registry._ATLAS_REGISTRY, kind, {
            "fetch": lambda kind=kind, **kw: {
                "maps": str(tmp_path / f"{kind}.nii"),
                "labels": ["Background", "L", "R"],
            },
            "probabilistic": False,
        })
    path = tmp_path / "engines.yaml"
    path.write_text(
        "engines:\n  e:\n    requires_mni_mask: true\n    atlases:\n"
        "      schaefer: {predicate_name: schaefer}\n"
        "      tian: {predicate_name: tian}\n"
        "    datalog_init: |\n"
        "      at_schaefer(l, i, j, k) :- schaefer(l, r), "
        "contains(r, (i, j, k)).\n"
        "      at_tian(l, i, j, k) :- tian(l, r), contains(r, (i, j, k)).\n"
    )
    return engine_registry.build_engine(
        "e", tmp_path / "data", yaml_path=path
    )


def _labelled_voxels(nl, name):
    return {
        (i, j, k): label for label, i, j, k
        in nl.execute_datalog_program(f"ans(l, i, j, k) :- {name}(l, i, j, k)")
    }


@pytest.mark.parametrize("atlas", ["schaefer", "tian"])
def test_an_atlas_labels_the_voxels_of_the_template(engine_1075, atlas):
    """GH-1075: the voxel (i, j, k) of an atlas is that of the template, as
    those of ``voxel`` and the peaks: its label is the one of the atlas at
    the same point in millimetres."""
    import nibabel as nib

    labelled = _labelled_voxels(engine_1075, f"at_{atlas}")
    grid = engine_1075.grids[atlas]
    assert grid.shape == (6, 4, 4)
    assert np.array_equal(grid.affine, TEMPLATE_1075)
    assert set(labelled) == set(np.ndindex(6, 4, 4))
    for ijk, label in labelled.items():
        x = nib.affines.apply_affine(TEMPLATE_1075, ijk)[0]
        assert label == ("L" if x < 0 else "R"), ijk


def test_the_atlases_label_a_template_voxel_alike(engine_1075):
    """GH-1075: the atlases of the same regions on different grids give a
    voxel of the template the same region."""
    assert _labelled_voxels(engine_1075, "at_schaefer") == (
        _labelled_voxels(engine_1075, "at_tian")
    )


def test_resamplings_of_a_choice(tmp_path):
    """Check ``resamplings`` adds replicates of a choice, for RESAMPLE."""
    from neurolang_apps.utils import engine_registry

    (tmp_path / "study.tsv").write_text("study_id\n1\n2\n3\n4\n")
    (tmp_path / "mentions.tsv").write_text(
        "study_id\tterm\n1\tpain\n2\tpain\n"
    )
    path = tmp_path / "engines.yaml"
    path.write_text(
        """
engines:
  e:
    relations:
      study: study.tsv
      mentions: mentions.tsv
    probabilistic_choice:
      selected_study: {source: study}
    resamplings:
      boot_studies:
        choice: selected_study
        n: 20
        description: "Replicates of the studies"
"""
    )
    nl = engine_registry.build_engine("e", tmp_path, yaml_path=path)
    res = nl.execute_datalog_program(
        "p(PROB) :- mentions(s, 'pain') & selected_study(s)\n"
        "rep(b, x) :- RESAMPLE[boot_studies](p(x)) = b\n"
        "ans(count(b), percentile(x, 2.5), percentile(x, 97.5)) :- rep(b, x)"
    )
    (n, lo, hi), = res
    assert n == 20
    assert 0 < lo < .5 < hi < 1
    predicates = engine_registry.get_predicates("e", path)
    assert "boot_studies" in predicates


@pytest.mark.parametrize(
    "unknown_space, expected_studies",
    [("mni", [1, 2, 3]), ("tal", [1, 2, 3]), ("drop", [1, 2])],
)
def test_process_peaks_converts_only_talairach(
    unknown_space, expected_studies
):
    """GH-1071: the peaks of UNKNOWN space are not taken as Talairach by
    default."""
    import nibabel as nib

    from neurolang_apps.utils.engines.neurosynth.init import process_peaks

    activations = pd.DataFrame({
        "id": [1, 2, 3], "x": [40.0] * 3, "y": [-60.0] * 3, "z": [30.0] * 3,
        "space": ["MNI", "TAL", "UNKNOWN"],
    })
    mask = nib.Nifti1Image(np.ones((2, 2, 2), dtype=np.uint8), np.eye(4))
    peaks = process_peaks(
        activations, mask, unknown_space=unknown_space
    ).set_index("study_id")
    assert sorted(peaks.index) == expected_studies
    mni, tal = (tuple(peaks.loc[s, ["i", "j", "k"]]) for s in (1, 2))
    assert mni == (40, -60, 30)
    assert tal != mni
    if unknown_space != "drop":
        unknown = tuple(peaks.loc[3, ["i", "j", "k"]])
        assert unknown == (mni if unknown_space == "mni" else tal)


def test_process_peaks_rejects_an_unknown_option():
    import nibabel as nib

    from neurolang_apps.utils.engines.neurosynth.init import process_peaks

    mask = nib.Nifti1Image(np.ones((2, 2, 2), dtype=np.uint8), np.eye(4))
    with pytest.raises(ValueError, match="unknown_space"):
        process_peaks(
            pd.DataFrame(columns=["id", "x", "y", "z", "space"]), mask,
            unknown_space="MNI",
        )


@pytest.mark.parametrize("engine", ["neurosynth", "neurostore"])
def test_unknown_space_peaks_are_taken_as_mni(engine):
    from neurolang_apps.utils import engine_registry

    config = engine_registry.get_engine_config(engine)
    assert config["python_init_options"]["unknown_space"] == "mni"


def test_python_init_is_given_the_python_init_options():
    from neurolang_apps.utils import engine_registry

    cfg = {
        "python_init": NS_INIT,
        "python_init_options": {"unknown_space": "drop"},
    }
    with patch(f"{NS_INIT}.init_engine") as init_engine:
        engine_registry._phase_python_init("nl", cfg, "mask", DATA_DIR)
    init_engine.assert_called_once_with(
        "nl", "mask", DATA_DIR, unknown_space="drop"
    )


def test_engines_change_the_settings_of_the_euclidean_join(tmp_path):
    """
    The ``euclidean_join`` mapping of an engine is merged with those of the
    engines it extends, and changes the settings of the Euclidean join when
    the engine is built.
    """
    import dataclasses

    from neurolang.utils.euclidean_join_settings import SETTINGS, profile
    from neurolang_apps.utils import engine_registry

    path = tmp_path / "engines.yaml"
    path.write_text(
        "engines:\n"
        "  base:\n"
        "    abstract: true\n"
        "    euclidean_join: {kdtree_chunk_pairs: 11, block_pairs: 12}\n"
        "  small:\n"
        "    extends: base\n"
        "    euclidean_join: {block_pairs: 13}\n"
        "  plain: {}\n"
    )
    assert engine_registry.get_euclidean_join_settings("small", path) == {
        "kdtree_chunk_pairs": 11, "block_pairs": 13,
    }
    assert engine_registry.get_euclidean_join_settings("plain", path) == {}
    with profile("default"):
        before = dataclasses.replace(SETTINGS)
        engine_registry.build_engine("plain", tmp_path, yaml_path=path)
        assert SETTINGS == before
        engine_registry.build_engine("small", tmp_path, yaml_path=path)
        assert SETTINGS.kdtree_chunk_pairs == 11
        assert SETTINGS.block_pairs == 13


def test_datalog_init_reads_files_relative_to_the_data_directory(
    tmp_path, monkeypatch
):
    """The commands of ``datalog_init`` find the files ``downloads`` put in
    the engine's data directory, wherever the program runs from, and the
    working directory is left as it was."""
    from neurolang.frontend import NeurolangPDL
    from neurolang_apps.utils import engine_registry

    data_dir = tmp_path / "data"
    (data_dir / "e").mkdir(parents=True)
    (data_dir / "e" / "pairs.csv").write_text("x,y\n1,a\n")
    elsewhere = tmp_path / "elsewhere"
    elsewhere.mkdir()
    monkeypatch.chdir(elsewhere)
    nl = NeurolangPDL()
    engine_registry._phase_datalog_init(
        nl, {"datalog_init": '.load_csv(pair, "e/pairs.csv")\n'}, data_dir
    )
    assert "pair" in nl.symbol_table
    import os

    assert os.getcwd() == str(elsewhere)


def _activated_mm(voxel_mm, data_dir):
    """
    Return the MNI points, in millimetres, of the voxels ``activated``
    (its rule in the neurosynth engine) by a peak at the origin, on a grid
    of *voxel_mm* millimetres spanning 12 mm around it.
    """
    import nibabel as nib

    from neurolang.frontend import NeurolangPDL
    from neurolang_apps.utils import engine_registry

    cfg = engine_registry.get_engine_config("neurosynth")
    rule = next(
        line for line in cfg["datalog_init"].splitlines()
        if line.startswith("activated(")
    )
    side = 24 // voxel_mm + 1
    affine = np.diag([voxel_mm] * 3 + [1]).astype(float)
    affine[:3, 3] = -12
    mask = nib.Nifti1Image(np.ones((side,) * 3, dtype=np.uint8), affine)
    nl = NeurolangPDL()
    nl.add_tuple_set(np.argwhere(mask.get_fdata() > 0), name="brain_mask")
    peak = 12 // voxel_mm
    nl.add_tuple_set([(peak, peak, peak, 1)], name="peak_reported")
    engine_registry._phase_datalog_init(
        nl, {**cfg, "datalog_init": rule}, data_dir, mask
    )
    voxels = nl.solve_all()["activated"].as_pandas_dataframe()
    return {
        tuple(int(c) for c in nib.affines.apply_affine(affine, voxel))
        for voxel in voxels.iloc[:, :3].to_numpy()
    }


def test_activated_is_within_the_kernel_radius_in_mm_at_every_resolution(
    tmp_path,
):
    """
    ``activated`` holds the voxels within ``kernel_radius_mm`` millimetres
    of a peak whatever the size of the voxels: the same MNI neighbourhood
    on the 1 mm and the 2 mm grids, the 2 mm voxels being the 1 mm ones
    on its lattice (about 8 times fewer).
    """
    from neurolang_apps.utils import engine_registry

    radius = engine_registry.get_engine_config("neurosynth")[
        "kernel_radius_mm"
    ]
    one, two = (_activated_mm(size, tmp_path) for size in (1, 2))
    offsets = np.argwhere(np.ones((25, 25, 25))) - 12
    ball = {
        tuple(int(c) for c in point) for point in offsets
        if np.linalg.norm(point) <= radius
    }
    assert one == ball
    assert two == {point for point in ball if not np.any(np.mod(point, 2))}


def test_the_kernel_radius_is_written_in_the_atlases_and_the_guidance():
    """
    The ``kernel_radius_mm`` of an engine is the ``radius_mm`` of the
    activations of its atlases and the radius its texts give, those of the
    assistant, also when an engine extending it sets its own.
    """
    from neurolang_apps.utils import engine_registry

    engines = engine_registry._load_yaml_config()["engines"]
    engines["wide"] = {"extends": "neurosynth", "kernel_radius_mm": 10}
    for name, radius in (("neurosynth", 6), ("wide", 10)):
        cfg = engine_registry.resolve_engine_config(engines, name)
        assert cfg["kernel_radius_mm"] == radius
        assert {
            atlas["activated"]["radius_mm"]
            for atlas in cfg["atlases"].values() if "activated" in atlas
        } == {radius}
        assert f"<= {radius})" in cfg["assistant_guidance"]
        assert "{kernel_radius_mm}" not in str(cfg)


class TestSparseViews:
    """Check the engine builds the sparse views it declares."""

    def test_activated_is_a_voxel_by_study_view(
        self, small_neurosynth_views
    ):
        """Check the view of ``activated`` holds its tuples, its voxels
        and studies numbered by the view's entity indices, and is indexed
        by its studies (``sparse_view_indexes``)."""
        nl = small_neurosynth_views
        view = nl.sparse_views["activated"]
        with nl.scope as e:
            rows = nl.query(
                (e.i, e.j, e.k, e.s), nl.symbols.activated(e.i, e.j, e.k, e.s)
            ).as_pandas_dataframe()
        assert view.matrix.shape == (
            len(view.row_index), len(view.column_index)
        )
        assert view.matrix.nnz == len(rows) > 0
        tuples = view.to_frame()
        expected = {tuple(row) for row in rows.itertuples(index=False)}
        assert {
            tuple(row) for row in tuples[list(view.rows) + list(
                view.columns
            )].itertuples(index=False)
        } == expected
        studies = np.arange(len(view.column_index))
        np.testing.assert_array_equal(
            view.by_columns.matrix(studies).toarray(),
            view.weighted().T.toarray(),
        )

    def test_the_atlases_share_the_studies_of_activated(
        self, small_neurosynth_views
    ):
        """Check the region x study views of the atlases number the
        studies as ``activated`` does, and hold their relation's tuples."""
        from nl_expr.expressions import Symbol

        small_neurosynth = small_neurosynth_views
        views = small_neurosynth.sparse_views
        for name in (
            "schaefer_activated", "schaefer400_activated",
            "destrieux_activated", "tian_activated",
        ):
            view = views[name]
            assert view.column_index is views["activated"].column_index
            rows = small_neurosynth.program_ir.symbol_table[
                Symbol(name)
            ].value.as_pandas_dataframe()
            assert view.matrix.nnz == len(rows) > 0
            assert {
                tuple(row) for row in view.to_frame().itertuples(index=False)
            } == {tuple(row) for row in rows.itertuples(index=False)}

    @staticmethod
    def _engine(tmp_path, views, body="p(x, y, w) :- q(x, y, w)"):
        from neurolang_apps.utils import engine_registry

        (tmp_path / "q.csv").write_text("x,y,w\nu,1,.5\nv,2,.25\nu,2,0\n")
        path = tmp_path / "engines.yaml"
        path.write_text(
            "engines:\n  e:\n"
            "    sorts:\n"
            "      a: {columns: [x], type: str}\n"
            "      b: {columns: [y], type: int}\n"
            "      w: {columns: [w], type: float}\n"
            "    predicates:\n"
            "      p: {arguments: [a, b, w]}\n"
            "    relations: {q: q.csv}\n"
            f"    datalog_init: '{body}'\n"
            f"    sparse_views: {views}\n"
        )
        return engine_registry.build_engine("e", tmp_path, yaml_path=path)

    def test_a_view_with_a_value(self, tmp_path):
        """Check a third sort is the value of the entries, of a rule
        renaming a stored relation."""
        nl = self._engine(tmp_path, "{p: [b, a, w]}")
        view = nl.sparse_views["p"]
        np.testing.assert_array_equal(
            view.matrix.toarray(), [[0.5, 0], [0, 0.25]]
        )
        assert view.matrix.nnz == 3  # the explicit zero of ('u', 2)

    def test_the_engines_declare_the_views_contractions_read(
        self, small_neurosynth
    ):
        """Check the coordinate-based engines build the voxel x study view
        of ``activated``, which the probabilistic solver reads when it
        computes sums of products as contractions; the views of atlases
        the engine did not load are left out."""
        views = small_neurosynth.sparse_views
        assert "activated" in views
        assert set(views) <= {
            "activated", "schaefer_activated", "schaefer400_activated",
            "destrieux_activated", "tian_activated",
        }

    def test_no_view_of_a_predicate_the_engine_lacks(self, tmp_path):
        """Check the view of a predicate the engine does not define (left
        out of a lightweight engine, of an atlas not loaded) is not built,
        and the others are."""
        nl = self._engine(tmp_path, "{p: [b, a, w], absent: [a, b]}")
        assert set(nl.sparse_views) == {"p"}

    def test_views_are_kept_and_read_mapped(self, tmp_path):
        """Check the views of a build are kept with its tables and read
        back, memory-mapped, by the next build, with the same entries."""
        first = self._engine(tmp_path, "{p: [b, a, w]}").sparse_views["p"]
        kept = [
            p for p in (tmp_path / "derived_tables").glob("sparse_views-*")
            if p.is_dir()
        ]
        assert len(kept) == 1
        again = self._engine(tmp_path, "{p: [b, a, w]}").sparse_views["p"]
        assert (again.matrix != first.matrix).nnz == 0
        np.testing.assert_array_equal(
            again.weighted().toarray(), [[0.5, 0], [0, 0.25]]
        )
        assert not again.weighted().data.flags.writeable  # mapped
        assert again.row_index.decode([0, 1])[0].tolist() == [1, 2]
        assert again.column_index.decode([0, 1])[0].tolist() == ["u", "v"]

    def test_no_views_without_contractions(self, tmp_path):
        """Check no view is built when the probabilistic solver does not
        compute contractions, the only reader of the views."""
        from nl_expr.config import config

        previous = config.get("PROBABILISTIC_SOLVER", "contractions")
        config.set("PROBABILISTIC_SOLVER", "contractions", "False")
        try:
            nl = self._engine(tmp_path, "{p: [b, a, w]}")
        finally:
            config.set("PROBABILISTIC_SOLVER", "contractions", previous)
        assert nl.sparse_views == {}

    def test_no_views_declared(self, tmp_path):
        """Check an engine without ``sparse_views`` has none."""
        from neurolang_apps.utils import engine_registry

        path = tmp_path / "engines.yaml"
        path.write_text("engines:\n  e:\n    description: bare\n")
        nl = engine_registry.build_engine("e", tmp_path, yaml_path=path)
        assert nl.sparse_views == {}

    @pytest.mark.parametrize("views, body, match", [
        ("{p: [a]}", "p(x, y, w) :- q(x, y, w)", "rows, of its columns"),
        ("{p: [a, c]}", "p(x, y, w) :- q(x, y, w)", "sort 'c'"),
        ("{p: [a, b]}", "p(x, y, w) :- q(x, y, w)", "spans each column"),
        ("{p: [a, w]}", "p(x, y, w) :- q(x, y, w) & (w > 0)",
         "not a stored relation"),
    ])
    def test_a_bad_declaration_is_a_clear_error(
        self, tmp_path, views, body, match
    ):
        """Check a view of too few sorts, of a sort the predicate lacks,
        leaving out a column or of a derived relation is refused."""
        with pytest.raises(ValueError, match=match):
            self._engine(tmp_path, views, body)
