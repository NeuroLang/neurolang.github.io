import json
import os
import shutil
import time
from pathlib import Path
from unittest.mock import patch

import nibabel as nib
import numpy as np
import pandas as pd
import pytest

from neurolang.frontend import NeurolangPDL
from neurolang_apps.utils import engine_registry
from neurolang_apps.utils.engines.neurostore import init as neurostore_init

NS_INIT = "neurolang_apps.utils.engines.neurosynth.init"


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    def offline():
        raise OSError("offline")

    monkeypatch.setattr(neurostore_init, "_fetch_releases", offline)
    monkeypatch.setattr(neurostore_init, "MIN_TERM_STUDIES", 1)
    monkeypatch.setattr(neurostore_init, "NGRAM_RANGE", (1, 1))
    release = tmp_path / "neurostore" / "2026-10"
    release.mkdir(parents=True)
    pd.DataFrame(
        {
            "study_id": ["s1", "s1", "s2", "s3"],
            "x": [0.0, 10.0, -20.0, 0.0],
            "y": [0.0, 10.0, -20.0, 0.0],
            "z": [0.0, 10.0, -20.0, 0.0],
            "space": ["MNI", "MNI", "TAL", "UNKNOWN"],
        }
    ).to_parquet(release / "coordinates.parquet")
    pd.DataFrame(
        {
            "study_id": ["s1", "s1", "s2", "s3"],
            "TaskExtractor.fMRITasks[0].Concepts": [
                json.dumps(["memory", "attention"]),
                json.dumps(["memory"]),
                None,
                json.dumps(["ignored"]),
            ],
            "TaskExtractor.fMRITasks[0].Domain": [
                json.dumps(["Learning"]), None, json.dumps(["Emotion"]), None
            ],
        }
    ).to_parquet(release / "annotations.parquet")
    pd.DataFrame(
        {
            "study_id": ["s1", "s2", "s3"],
            "name": ["Memory paper", "Emotion paper", "Other"],
            "description": [
                "Memory and attention network",
                "Emotion network",
                "Ignored study",
            ],
        }
    ).to_parquet(release / "studies.parquet")
    return tmp_path


def _build(data_dir, **options):
    mask = nib.Nifti1Image(
        np.ones((4, 4, 4), dtype="uint8"), np.diag([2.0, 2.0, 2.0, 1.0])
    )
    nl = NeurolangPDL()
    with patch(
        f"{NS_INIT}.fetch_cortical_atlas",
        return_value=nib.Nifti1Image(
            np.ones((4, 4, 4), dtype="int16"), np.diag([2.0, 2.0, 2.0, 1.0])
        ),
    ), patch(
        f"{NS_INIT}.fetch_cognitive_atlas_tasks",
        return_value=pd.DataFrame(
            {"task_id": ["t1"], "name": ["n-back"], "description": ["d"]}
        ),
    ):
        neurostore_init.init_engine(nl, mask, Path(data_dir), **options)
    return nl


def test_init_engine(data_dir):
    nl = _build(data_dir, unknown_space="drop")
    rel = lambda name: set(nl.symbols[name].value)  # noqa: E731

    assert {s for (s,) in rel("study")} == {"s1", "s2"}
    assert len(nl.symbols["peak_reported"].value) == 3
    assert len(nl.symbols["selected_study"].value) == 2
    assert rel("study_concept") == {("s1", "memory"), ("s1", "attention")}
    assert rel("study_domain") == {("s1", "Learning"), ("s2", "Emotion")}
    assert rel("study_abstract") == {
        ("s1", "Memory and attention network"), ("s2", "Emotion network"),
    }
    assert rel("study_title") == {
        ("s1", "Memory paper"), ("s2", "Emotion paper"),
    }
    tfidf = nl.symbols["term_in_study_tfidf"].value
    assert {(s, t) for s, t, _ in tfidf} == {
        ("s1", "memory"), ("s1", "attention"), ("s1", "network"),
        ("s2", "emotion"), ("s2", "network"),
    }
    assert all(0 < v <= 1 for _, _, v in tfidf)
    assert {t for (t,) in rel("term")} == {
        "memory", "attention", "network", "emotion"
    }
    assert rel("cognitive_task") == {("t1", "n-back", "d")}


def test_the_tables_of_a_release_are_read_mapped_by_the_next_build(
    data_dir, tmp_path, monkeypatch
):
    """While an engine is built (``derived_tables``), the peaks, the TF-IDF
    and the labels of the studies are read from the Arrow files the first
    build kept, by the files of the release, not found again."""
    from neurolang_apps.utils import engine_cache

    def build():
        with patch.object(
            NeurolangPDL, "__init__", keeping(NeurolangPDL.__init__)
        ):
            nl = _build(data_dir)
        return {
            name: sorted(nl.symbols[name].value)
            for name in ("peak_reported", "term_in_study_tfidf",
                         "study_concept", "study_domain", "study")
        }

    def keeping(init):
        def keeping_init(self, *args, **kwargs):
            init(self, *args, **kwargs)
            self.program_ir.derived_tables = engine_cache.DerivedTables(
                tmp_path / "tables"
            )
        return keeping_init

    first = build()
    for name in ("process_peaks", "_tfidf_table", "_extract_labels"):
        monkeypatch.setattr(
            neurostore_init, name, lambda *a, **k: pytest.fail("found again")
        )
    assert build() == first and first["study_concept"]
    kinds = sorted(
        path.name.split("-")[0] for path in (tmp_path / "tables").iterdir()
    )
    assert kinds == ["neurostore_labels", "neurostore_labels",
                     "neurostore_peaks", "neurostore_tfidf"]


def test_unknown_space_studies_are_kept_as_mni(data_dir):
    nl = _build(data_dir)

    assert {s for (s,) in nl.symbols["study"].value} == {"s1", "s2", "s3"}
    assert len(nl.symbols["peak_reported"].value) == 4


def test_engine_declarations_match_neurosynth_names():
    ns = engine_registry.get_predicates("neurosynth")
    nstore = engine_registry.get_predicates("neurostore")
    assert set(ns) <= set(nstore)
    assert nstore["term_in_study_tfidf"]["columns"] == ns[
        "term_in_study_tfidf"
    ]["columns"]
    assert nstore["study_abstract"]["columns"] == ["study_id", "text"]


def test_embeddings_read_the_engine_texts(data_dir):
    nl = _build(data_dir)
    cfg = engine_registry.get_engine_config("neurostore")
    source = cfg["text_embeddings"]["study_abstracts"]["source"]
    assert engine_registry._predicate_texts(nl, source) == {
        "s1": ("Memory paper", "Memory and attention network"),
        "s2": ("Emotion paper", "Emotion network"),
        "s3": ("Other", "Ignored study"),
    }
    # Same function and models as the neurosynth engine.
    entry = cfg["text_embeddings"]["study_abstracts"]
    assert entry["function"] == "query_similarity"
    assert entry["model"] == "allenai/specter2_base"


def test_select_release():
    releases = [
        {"version": "nightly", "release_type": "nightly", "built_at": "3"},
        {"version": "2026-09", "release_type": "monthly", "built_at": "1"},
        {"version": "2026-10", "release_type": "monthly", "built_at": "2"},
    ]
    select = neurostore_init._select_release
    assert select(releases, "latest")["version"] == "2026-10"
    assert select(releases, "nightly")["version"] == "nightly"
    with pytest.raises(ValueError, match="Unknown NeuroStore release"):
        select(releases, "1999-01")


def test_terms_include_word_sequences():
    abstracts = pd.Series(
        ["working memory task", "working memory network"], index=["a", "b"]
    )
    with patch.object(neurostore_init, "MIN_TERM_STUDIES", 1):
        terms = neurostore_init._tfidf_terms(abstracts)
    assert {"working memory", "memory task", "working memory network"} <= set(
        terms["term"]
    )


def test_the_tfidf_is_kept_for_the_same_release(tmp_path, monkeypatch):
    abstracts = pd.Series(
        ["working memory task", "working memory network", "emotion network"],
        index=["a", "b", "c"],
    )
    monkeypatch.setattr(neurostore_init, "MIN_TERM_STUDIES", 1)
    monkeypatch.setattr(neurostore_init, "NGRAM_RANGE", (1, 2))
    first = neurostore_init._kept_tfidf_terms(abstracts, "2026-10", tmp_path)
    assert list(tmp_path.glob("tfidf-*.npz"))
    expected = neurostore_init._tfidf_terms(abstracts)
    key = ["study_id", "term"]
    pd.testing.assert_frame_equal(
        first.sort_values(key).reset_index(drop=True),
        expected.sort_values(key).reset_index(drop=True),
        check_exact=False, atol=1e-6, check_dtype=False,
    )

    def not_again(abstracts):
        raise AssertionError("computed again")

    monkeypatch.setattr(neurostore_init, "_tfidf_arrays", not_again)
    again = neurostore_init._kept_tfidf_terms(abstracts, "2026-10", tmp_path)
    pd.testing.assert_frame_equal(again, first)
    with pytest.raises(AssertionError):  # another release: computed anew
        neurostore_init._kept_tfidf_terms(abstracts, "2026-11", tmp_path)


def test_the_tfidf_without_a_cache_directory_is_computed(monkeypatch):
    abstracts = pd.Series(["a memory task", "a memory test"], index=["a", "b"])
    monkeypatch.setattr(neurostore_init, "MIN_TERM_STUDIES", 1)
    table = neurostore_init._kept_tfidf_terms(abstracts, "2026-10", None)
    assert {"memory", "task", "test"} <= set(table["term"])


def test_only_the_columns_the_engine_reads_are_taken_from_the_annotations(
    tmp_path
):
    path = tmp_path / "annotations.parquet"
    pd.DataFrame(
        {
            "study_id": ["s1"], "contrast_id": ["c1"],
            "TaskExtractor.fMRITasks[0].Concepts": ['["memory"]'],
            "TaskExtractor.fMRITasks[0].Domain": ['["Learning"]'],
            "TaskExtractor.fMRITasks[0].TaskName": ["n-back"],
            "ParticipantDemographicsExtractor.groups": [None],
        }
    ).to_parquet(path)
    assert neurostore_init._annotation_columns(path) == [
        "study_id",
        "TaskExtractor.fMRITasks[0].Concepts",
        "TaskExtractor.fMRITasks[0].Domain",
    ]


def test_an_init_takes_the_cache_directory_only_if_it_asks_for_it(
    tmp_path, monkeypatch
):
    import sys
    import types

    from neurolang_apps.utils import engine_registry

    calls = {}
    plain = types.ModuleType("fake_engines.plain.init")
    plain.init_engine = lambda nl, mask, data_dir: calls.setdefault(
        "plain", True
    )
    cached = types.ModuleType("fake_engines.cached.init")
    cached.init_engine = lambda nl, mask, data_dir, cache_dir=None: (
        calls.setdefault("cache_dir", cache_dir)
    )
    monkeypatch.setitem(sys.modules, "fake_engines.plain.init", plain)
    monkeypatch.setitem(sys.modules, "fake_engines.cached.init", cached)
    kept = tmp_path / "kept"
    nl = types.SimpleNamespace(engine_cache_dir=kept)
    engine_registry._phase_python_init(
        nl, {"python_init": "fake_engines.plain.init"}, None, tmp_path
    )
    engine_registry._phase_python_init(
        nl, {"python_init": "fake_engines.cached.init"}, None, tmp_path
    )
    assert calls["plain"] and calls["cache_dir"] == kept
    calls.clear()
    nl.engine_cache_dir = None
    engine_registry._phase_python_init(
        nl, {"python_init": "fake_engines.cached.init"}, None, tmp_path
    )
    assert calls["cache_dir"] is None


def test_in_a_browser_the_release_of_the_page_is_used_without_the_network(
    tmp_path, monkeypatch
):
    release = tmp_path / "neurostore" / "2026-10"
    release.mkdir(parents=True)
    (release / "coordinates.parquet").write_bytes(b"")

    def no_network():
        raise AssertionError("the network was asked")

    monkeypatch.setattr(neurostore_init, "_fetch_releases", no_network)
    monkeypatch.setattr(neurostore_init.sys, "platform", "emscripten")
    assert neurostore_init.fetch_neurostore_dir(tmp_path) == release


def test_the_tfidf_table_is_that_of_the_vectorizer(tmp_path, monkeypatch):
    """The arrays kept (offsets by study, terms by index) give back the
    rows of scikit-learn's matrix."""
    from sklearn.feature_extraction.text import TfidfVectorizer

    abstracts = pd.Series(
        ["working memory task", "working memory network", "emotion network",
         "an emotion task with working memory"],
        index=["a", "b", "c", "d"],
    )
    monkeypatch.setattr(neurostore_init, "MIN_TERM_STUDIES", 1)
    monkeypatch.setattr(neurostore_init, "NGRAM_RANGE", (1, 2))
    vectorizer = TfidfVectorizer(
        stop_words="english", strip_accents="unicode", min_df=1,
        ngram_range=(1, 2),
    )
    dense = pd.DataFrame(
        vectorizer.fit_transform(abstracts).toarray(),
        index=abstracts.index, columns=vectorizer.get_feature_names_out(),
    )
    expected = {
        (study, term): value
        for study, row in dense.iterrows() for term, value in row.items()
        if value > neurostore_init.TFIDF_THRESHOLD
    }
    kept = neurostore_init._kept_tfidf_terms(abstracts, "r", tmp_path)
    got = {
        (row.study_id, row.term): row.tfidf for row in kept.itertuples()
    }
    assert got.keys() == expected.keys()
    for key, value in expected.items():
        assert got[key] == pytest.approx(value, abs=1e-6)


def _releases(built_at="2026-11-01"):
    return [
        {"version": "2026-10", "release_type": "monthly",
         "built_at": "2026-10-01", "download_path": "/m"},
        {"version": "nightly", "release_type": "nightly",
         "built_at": built_at, "download_path": "/n"},
    ]


@pytest.fixture
def network(monkeypatch):
    """A mocked network: the calls of the listing and of the downloads."""
    calls = {"listing": 0, "download": [], "releases": _releases(),
             "offline": False}

    def listing():
        calls["listing"] += 1
        if calls["offline"]:
            raise OSError("offline")
        return calls["releases"]

    def download(release, target):
        if calls["offline"]:
            raise OSError("offline")
        calls["download"].append(release["version"])
        shutil.rmtree(target, ignore_errors=True)
        target.mkdir(parents=True)
        (target / "coordinates.parquet").write_bytes(b"")

    monkeypatch.setattr(neurostore_init, "_fetch_releases", listing)
    monkeypatch.setattr(neurostore_init, "_download_release", download)
    monkeypatch.delenv(neurostore_init.RELEASE_ENV_VAR, raising=False)
    monkeypatch.delenv(neurostore_init.UPDATE_ENV_VAR, raising=False)
    return calls


def test_a_fresh_listing_and_a_downloaded_release_need_no_network(
    tmp_path, network
):
    first = neurostore_init.fetch_neurostore_dir(tmp_path, 24)
    second = neurostore_init.fetch_neurostore_dir(tmp_path, 24)
    assert first == second == tmp_path / "neurostore" / "2026-10"
    assert network["listing"] == 1
    assert network["download"] == ["2026-10"]


def test_an_expired_listing_is_fetched_again(tmp_path, network):
    neurostore_init.fetch_neurostore_dir(tmp_path, 24)
    old = time.time() - 25 * 3600
    os.utime(tmp_path / "neurostore" / neurostore_init.LISTING_FILE, (old, old))
    neurostore_init.fetch_neurostore_dir(tmp_path, 24)
    assert network["listing"] == 2
    assert network["download"] == ["2026-10"]


def test_without_a_ttl_the_listing_is_always_fetched(tmp_path, network):
    neurostore_init.fetch_neurostore_dir(tmp_path)
    neurostore_init.fetch_neurostore_dir(tmp_path)
    assert network["listing"] == 2


def test_the_update_variable_ignores_the_kept_listing(
    tmp_path, network, monkeypatch
):
    neurostore_init.fetch_neurostore_dir(tmp_path, 24)
    monkeypatch.setenv(neurostore_init.UPDATE_ENV_VAR, "1")
    neurostore_init.fetch_neurostore_dir(tmp_path, 24)
    assert network["listing"] == 2


def test_offline_the_downloaded_release_is_used_with_a_message(
    tmp_path, network, caplog
):
    release = neurostore_init.fetch_neurostore_dir(tmp_path, 0)
    network["offline"] = True
    with caplog.at_level("WARNING"):
        assert neurostore_init.fetch_neurostore_dir(tmp_path, 0) == release
    assert "could not be reached" in caplog.text


def test_offline_without_a_downloaded_release_the_error_is_raised(
    tmp_path, network
):
    network["offline"] = True
    with pytest.raises(OSError):
        neurostore_init.fetch_neurostore_dir(tmp_path, 24)


def test_a_nightly_is_downloaded_again_only_when_rebuilt(
    tmp_path, network, monkeypatch
):
    monkeypatch.setenv(neurostore_init.RELEASE_ENV_VAR, "nightly")
    neurostore_init.fetch_neurostore_dir(tmp_path, 0)
    neurostore_init.fetch_neurostore_dir(tmp_path, 0)
    assert network["download"] == ["nightly"]
    network["releases"] = _releases(built_at="2026-11-02")
    neurostore_init.fetch_neurostore_dir(tmp_path, 0)
    assert network["download"] == ["nightly", "nightly"]


def test_a_failed_nightly_download_keeps_the_old_copy(
    tmp_path, network, monkeypatch
):
    monkeypatch.setenv(neurostore_init.RELEASE_ENV_VAR, "nightly")
    nightly = neurostore_init.fetch_neurostore_dir(tmp_path, 0)
    network["releases"] = _releases(built_at="2026-11-02")
    network["offline"] = False

    def failing(release, target):
        raise OSError("connection reset")

    monkeypatch.setattr(neurostore_init, "_download_release", failing)
    assert neurostore_init.fetch_neurostore_dir(tmp_path, 0) == nightly
    assert (nightly / "coordinates.parquet").exists()


def test_an_unreadable_kept_listing_is_fetched_again(tmp_path, network):
    root = tmp_path / "neurostore"
    root.mkdir()
    (root / neurostore_init.LISTING_FILE).write_text("{trunc")
    release = neurostore_init.fetch_neurostore_dir(tmp_path, 24)
    assert release == root / "2026-10"
    assert network["listing"] == 1
    assert json.loads((root / neurostore_init.LISTING_FILE).read_text())


def test_a_pinned_release_missing_from_the_kept_listing_lists_again(
    tmp_path, network, monkeypatch
):
    neurostore_init.fetch_neurostore_dir(tmp_path, 24)
    network["releases"] = _releases() + [
        {"version": "2026-11", "release_type": "monthly",
         "built_at": "2026-11-01", "download_path": "/m2"},
    ]
    monkeypatch.setenv(neurostore_init.RELEASE_ENV_VAR, "2026-11")
    release = neurostore_init.fetch_neurostore_dir(tmp_path, 24)
    assert release == tmp_path / "neurostore" / "2026-11"
    assert network["listing"] == 2


def test_an_unknown_release_is_an_error_after_one_new_listing(
    tmp_path, network, monkeypatch
):
    monkeypatch.setenv(neurostore_init.RELEASE_ENV_VAR, "2099-01")
    with pytest.raises(ValueError, match="Unknown NeuroStore release"):
        neurostore_init.fetch_neurostore_dir(tmp_path, 24)
    assert network["listing"] == 1
