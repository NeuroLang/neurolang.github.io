"""
An interactive viewer of brain images, as a self-contained HTML page.

:func:`viewer_html` writes a page showing NIfTI images on one grid, its
overlays, over a background, the MNI152 T1 of nilearn
(:func:`mni_background`), with NiiVue [niivue]_: three orthogonal slices
with a crosshair, drawn with WebGL2, which a click or a drag moves and
the mouse wheel scrolls. Its controls change live, in the browser, the
threshold (a value or a percentile), the colormap, whether the colormap
is symmetric, the opacity and the visibility of each overlay, the one
they apply to being chosen in a list, and the order the overlays are
drawn in, the later ones over the earlier ones. Other controls set
NiiVue's display: the view (an axial, coronal or sagittal slice, the
three slices, in a row, a column or a grid, with or without the 3D
render, or the 3D render alone), what a drag with the right button does
(contrast, pan and zoom, measure, angle, 3D slicer), the colour, width
and 3D drawing of the crosshair, the gamma of the background, NiiVue's
colour bars, labels, orientation cube and ruler, the radiological
convention, the interpolation of the voxels and a clip plane of the 3D
render; NiiVue's hot keys, V and C on the views, cycle the views and the
clip planes. The page shows the MNI coordinates of the voxel under the
cursor, the value of each overlay there, and a colour bar per overlay.
It also draws a network (:func:`connectome_state`) or streamlines
(:func:`streamlines_state`), in the 3D render and on the slices near
them.

The page needs no network: NiiVue (``static/niivue/niivue.umd.js``, a
copy of its release :data:`NIIVUE_VERSION`), the script of the page
(``static/brain_viewer.js``), its data and NeuroLang's favicon
(``static/favicon.svg``) are inlined. The data is a JSON
document holding the overlays and the background as gzipped NIfTI
images, base64-encoded, and the colormaps as 256 RGB colours, deflated
with zlib then base64-encoded, which the page inflates with the browser's
``DecompressionStream``; streamlines are a TrackVis ``.trk`` file,
encoded as the colormaps. NiiVue reorients the images itself, and draws
them as nilearn does: neurological, the left hemisphere on the left.

.. [niivue] https://github.com/niivue/niivue, BSD 2-Clause License.
"""

import base64
import gzip
import html
import io
import itertools
import json
import re
import zlib
from pathlib import Path

import nibabel as nib
import numpy as np
import yaml

# The release of NiiVue the page inlines.
NIIVUE_VERSION = "0.69.0"

# The defaults of the viewer, the one place they are written.
DEFAULTS_FILE = Path(__file__).with_name("viewer.yaml")
DEFAULTS = yaml.safe_load(DEFAULTS_FILE.read_text(encoding="utf-8"))

# The colormap used when none is asked for.
DEFAULT_CMAP = DEFAULTS["colormap"]

# The colormaps of the overlays after the first, in turn: the first has
# the colormap asked for, :data:`DEFAULT_CMAP` by default.
OVERLAY_CMAPS = tuple(DEFAULTS["overlay_colormaps"])
# Those of the masks among several overlays, in turn.
MASK_CMAPS = tuple(DEFAULTS["mask_colormaps"])

# The colormaps the page offers, from matplotlib and nilearn.
COLORMAPS = tuple(DEFAULTS["colormaps"])

# The largest background embedded, in voxels: the 1 mm MNI grid fits.
BACKGROUND_MAX_VOXELS = DEFAULTS["background_max_voxels"]

_STATIC = Path(__file__).parent / "static"


def frame_hooks() -> str:
    """Return the script that lets a page in a frame of the REPL take its
    theme and say how tall it is, to inline in the page."""
    return (_STATIC / "frame_hooks.js").read_text(encoding="utf-8")


def encode_array(array: np.ndarray) -> str:
    """Return the bytes of *array*, deflated then base64-encoded."""
    raw = np.ascontiguousarray(array).tobytes()
    return base64.b64encode(zlib.compress(raw, 9)).decode("ascii")


def encode_nifti(data: np.ndarray, affine: np.ndarray) -> str:
    """Return the NIfTI image of *data* and *affine*, gzipped then
    base64-encoded, as NiiVue reads it."""
    image = nib.Nifti1Image(np.asarray(data), affine)
    return base64.b64encode(
        gzip.compress(image.to_bytes(), compresslevel=9)
    ).decode("ascii")


def overlay_values(data: np.ndarray) -> np.ndarray:
    """
    Return the values of the volume *data* the page draws, as float32.

    NaN stands for no value, as 0; an infinite value is drawn at the end
    of the colour scale, as the largest finite one of its sign.
    """
    data = np.asarray(data, dtype=np.float32)
    data = data.reshape(data.shape[:3] + (-1,))[..., 0]
    finite = data[np.isfinite(data)]
    return np.nan_to_num(
        data, nan=0.0,
        posinf=max(finite.max(), 0.0) if finite.size else 0.0,
        neginf=min(finite.min(), 0.0) if finite.size else 0.0,
    )


def _colormap(name: str):
    """Return the matplotlib or nilearn colormap *name*, or None."""
    import matplotlib

    if name in matplotlib.colormaps:
        return matplotlib.colormaps[name]
    try:
        from nilearn.plotting import cm
    except ImportError:
        return None
    return getattr(cm, "_cmap_d", {}).get(name)


def colormap_luts(extra=()) -> dict:
    """
    Return the colours of the colormaps, 256 RGB uint8 each, by name.

    They are those of :data:`COLORMAPS` and the *extra* ones that
    matplotlib or nilearn know, encoded as :func:`encode_array` does.
    """
    luts = {}
    for name in dict.fromkeys((*COLORMAPS, *extra)):
        cmap = _colormap(name)
        if cmap is not None:
            rgb = cmap(np.linspace(0, 1, 256))[:, :3]
            luts[name] = encode_array(np.rint(rgb * 255).astype(np.uint8))
    return luts


def mni_background():
    """
    Return the MNI152 T1 template packaged with nilearn, or None.

    It ships with nilearn: nothing is downloaded.
    """
    try:
        from nilearn.datasets import load_mni152_template
    except ImportError:
        return None
    return load_mni152_template(resolution=1)


def _background_factor(shape, max_voxels: int) -> int:
    """Return the smallest subsampling of *shape* within *max_voxels*."""
    factor = 1
    while np.prod([-(-n // factor) for n in shape]) > max_voxels:
        factor += 1
    return factor


def _to_uint8(volume: np.ndarray) -> np.ndarray:
    """Return *volume* scaled from 0 to its maximum into 0 to 255."""
    volume = np.clip(np.nan_to_num(volume), 0, None)
    top = volume.max() if volume.size else 0
    if top <= 0:
        return np.zeros(volume.shape, dtype=np.uint8)
    return np.rint(volume / top * 255).astype(np.uint8)


def resample_background(
    background, shape, affine: np.ndarray,
    max_voxels: int = BACKGROUND_MAX_VOXELS,
) -> tuple:
    """
    Return the image *background* on the grid (*shape*, *affine*).

    The grid is subsampled by the smallest integer factor that keeps it
    within *max_voxels*, a background voxel covering factor³ voxels of
    the grid. Return the volume, as uint8 from 0 to its maximum, and the
    factor.
    """
    from scipy import ndimage

    factor = _background_factor(shape[:3], max_voxels)
    target_shape = tuple(-(-n // factor) for n in shape[:3])
    subsample = np.diag([factor] * 3 + [1.0])
    subsample[:3, 3] = (factor - 1) / 2
    mapping = np.linalg.inv(background.affine) @ affine @ subsample
    source = np.asarray(background.dataobj, dtype=np.float32)
    volume = ndimage.affine_transform(
        source.reshape(source.shape[:3] + (-1,))[..., 0],
        mapping[:3, :3], mapping[:3, 3], output_shape=target_shape,
        order=1, mode="constant", cval=0.0,
    )
    return _to_uint8(volume), factor


def initial_cursor(data: np.ndarray) -> list:
    """
    Return the voxel the cursor starts at: a peak of ``|data|``.

    Of the voxels of largest absolute value, it is the closest to their
    centre; the centre of the grid when *data* is empty.
    """
    magnitude = np.abs(np.nan_to_num(data))
    if not magnitude.any():
        return [int(n // 2) for n in data.shape]
    peaks = np.argwhere(magnitude == magnitude.max())
    distances = ((peaks - peaks.mean(axis=0)) ** 2).sum(axis=1)
    return [int(v) for v in peaks[np.argmin(distances)]]


def _threshold_state(threshold) -> dict:
    """Return the threshold of the page: a value, or ``P%`` a percentile."""
    if isinstance(threshold, str) and threshold.endswith("%"):
        return {"threshold": float(threshold[:-1]),
                "thresholdMode": "percentile"}
    return {"threshold": float(threshold), "thresholdMode": "value"}


def _background_state(background, shape, affine) -> dict:
    """
    Return the *background* on the grid (*shape*, *affine*) of the
    overlays, subsampled to stay within :data:`BACKGROUND_MAX_VOXELS`, as
    the page reads it, zeros without one: NiiVue draws the overlays
    over a background.
    """
    if background is None:
        volume, factor = np.zeros(shape[:3], dtype=np.uint8), 1
    else:
        volume, factor = resample_background(background, shape, affine)
    subsample = np.diag([factor] * 3 + [1.0])
    subsample[:3, 3] = (factor - 1) / 2
    return {
        "nifti": encode_nifti(volume, affine @ subsample),
        "factor": factor,
    }


def _layers(img) -> list:
    """
    Return the overlays *img* stands for, as (name, image) pairs on one
    grid.

    *img* is an image, an overlay without a name, or a sequence of
    (name, image) pairs. Those on several grids, such as the regions of
    an answer on the grid of their atlas and the streamlines of another
    on that of the background, are drawn on the finest of them (the first
    of the finest): the others are resampled to it, each voxel taking the
    value of the nearest one, so that a mask stays a mask and a count
    keeps its values.
    """
    if isinstance(img, nib.spatialimages.SpatialImage):
        return [("", img)]
    layers = list(img)
    grid = min(
        (image for _, image in layers),
        key=lambda image: abs(np.linalg.det(image.affine[:3, :3])),
    )
    return [(name, _on_grid(image, grid)) for name, image in layers]


def _on_grid(image, grid):
    """Return *image* on the grid of the image *grid*, by the nearest
    voxel."""
    if image.shape[:3] == grid.shape[:3] and np.allclose(
        image.affine, grid.affine
    ):
        return image
    from nibabel.processing import resample_from_to

    return resample_from_to(
        image, (grid.shape[:3], grid.affine), order=0, cval=0.0
    )


def _overlay_cmaps(cmap, names) -> list:
    """
    Return the colormaps of the overlays *names*: *cmap* for the first,
    then those of :data:`OVERLAY_CMAPS` other than it, in turn; but the
    masks among several (``mask`` or ``answer: mask``) take those of
    :data:`MASK_CMAPS` in turn, which keep them apart.
    """
    first = cmap or DEFAULT_CMAP
    others = [name for name in OVERLAY_CMAPS if name != first]
    values = itertools.chain([first], itertools.cycle(others))
    masks = itertools.cycle(MASK_CMAPS)
    several = len(names) > 1
    return [
        next(masks) if several and (name == "mask" or name.endswith(": mask"))
        else next(values)
        for name in names
    ]


def viewer_state(
    img, background, *, title, threshold, cmap, symmetric
) -> dict:
    """
    Return the data of the viewer page of *img*, as a JSON-able dict.

    See :func:`viewer_html`. The ``affine`` maps the voxels of the
    images, in which the ``cursor`` is, to millimetres.
    """
    layers = _layers(img)
    first = layers[0][1]
    volumes = [overlay_values(image.dataobj) for _, image in layers]
    affine = first.affine
    cmaps = _overlay_cmaps(cmap, [name for name, _ in layers])
    if isinstance(symmetric, (bool, np.bool_)):
        symmetric = [symmetric] * len(layers)
    return {
        "title": title, "shape": list(volumes[0].shape),
        "affine": affine.tolist(),
        "overlays": [
            {"name": name, "nifti": encode_nifti(volume, affine)}
            for (name, _), volume in zip(layers, volumes)
        ],
        "background": _background_state(
            background, volumes[0].shape, affine
        ),
        "colormaps": colormap_luts(cmaps),
        # What the script of the page takes from viewer.yaml.
        "settings": DEFAULTS["page"],
        "initial": {
            "cursor": initial_cursor(volumes[0]), "active": 0,
            "layers": [
                {
                    **_threshold_state(threshold), "cmap": layer_cmap,
                    "symmetric": bool(layer_symmetric), "opacity": 1.0,
                    "visible": True,
                }
                for layer_cmap, layer_symmetric in zip(cmaps, symmetric)
            ],
        },
    }


# The radius, in millimetres, of the largest node and of the thickest edge
# of a network.
NODE_RADIUS = DEFAULTS["network"]["node_radius"]
EDGE_RADIUS = DEFAULTS["network"]["edge_radius"]

# The opacity the overlays of a network or of streamlines start with, for
# its edges or them to show on the slices.
NETWORK_OVERLAY_OPACITY = DEFAULTS["network"]["overlay_opacity"]

# The number of edges a percentile threshold shows at least, all of them
# when there are fewer.
MIN_SHOWN_EDGES = DEFAULTS["network"]["min_shown_edges"]

# The number of edges, the largest, given to the page to threshold there.
MAX_EDGES = DEFAULTS["network"]["max_edges"]


def edge_threshold(values, threshold, at_least: int = 0) -> float:
    """
    Return the smallest |value| of the edges shown: *threshold*, a value,
    or the percentile ``"P%"`` of the |*values*|, lowered to show the
    *at_least* largest.
    """
    magnitudes = np.sort(np.abs(np.asarray(values, dtype=float)))[::-1]
    if not (isinstance(threshold, str) and threshold.endswith("%")):
        return float(threshold)
    if not magnitudes.size:
        return 0.0
    minimum = float(np.percentile(magnitudes, float(threshold[:-1])))
    if at_least:
        minimum = min(minimum, magnitudes[:at_least][-1])
    return float(minimum)


def connectome_state(names, coordinates, edges, threshold) -> dict:
    """
    Return the network of *edges* for the page to draw, a JSON-able dict.

    The nodes have *names* and the millimetre *coordinates* of their
    centre; an edge ``(first, second, value)`` joins two of them, by
    index. The page draws the edges of |value| at least its edge
    threshold, which starts at *threshold* (:func:`edge_threshold`; a
    percentile shows the :data:`MIN_SHOWN_EDGES` largest at least) and
    can be changed there, and the nodes they join: the colour and the
    size of a node is its strength, the sum of the values of its edges
    drawn, and the colour and the thickness of an edge its value, from
    the threshold to the largest. The :data:`MAX_EDGES` largest edges
    are given to the page.
    """
    edges = sorted(
        (e for e in edges if e[2] != 0 and not np.isnan(e[2])),
        key=lambda e: -abs(e[2]),
    )[:MAX_EDGES]
    return {
        "name": "network",
        "threshold": edge_threshold(
            [w for _, _, w in edges], threshold, MIN_SHOWN_EDGES
        ),
        "nodeRadius": NODE_RADIUS, "edgeRadius": EDGE_RADIUS,
        "nodes": [
            {
                "name": str(name), "x": float(x), "y": float(y),
                "z": float(z),
            }
            for name, (x, y, z) in zip(names, coordinates)
        ],
        "edges": [
            {"first": int(a), "second": int(b), "value": float(w)}
            for a, b, w in edges
        ],
    }


def shown_edges(connectome: dict) -> list:
    """Return the edges of *connectome* the page draws at first."""
    return [
        e for e in connectome["edges"]
        if abs(e["value"]) >= connectome["threshold"]
    ]


# The number of streamlines drawn at most, evenly subsampled.
MAX_STREAMLINES = DEFAULTS["streamlines"]["max_shown"]
#: The most bundles the streamlines are coloured by, one colour each.
MAX_BUNDLES = DEFAULTS["streamlines"]["max_bundles"]


def shown_streamlines(ids, cap=None) -> list:
    """Return the *ids* drawn: all of them, or *cap* evenly spaced,
    :data:`MAX_STREAMLINES` by default."""
    ids = list(ids)
    cap = MAX_STREAMLINES if cap is None else cap
    if len(ids) <= cap:
        return ids
    return [ids[n] for n in np.linspace(0, len(ids) - 1, cap).round()
            .astype(int)]


def streamline_ranks(n: int) -> np.ndarray:
    """
    Return the ranks, *n* down to 1, of *n* streamlines, as float32, such
    that the *k* highest are an even sample of them: the order of the ranks
    is that of the indices with their bits reversed (0, n/2, n/4, 3n/4...).
    The page shows the streamlines whose rank is at least ``n - k + 1``: *k*
    streamlines spread over all, not the first *k* of the file.
    """
    bits = max(1, (n - 1).bit_length())
    order = [
        i for i in (int(format(j, f"0{bits}b")[::-1], 2)
                    for j in range(1 << bits)) if i < n
    ]
    ranks = np.empty(n, dtype=np.float32)
    ranks[order] = n - np.arange(n)
    return ranks


def trk_bytes(lines) -> bytes:
    """
    Return the TrackVis ``.trk`` file of the streamlines *lines*, (n, 3)
    arrays of points in millimetres (RAS+), each with its ``rank``
    (:func:`streamline_ranks`), which NiiVue reads as its ``dps``.

    NiiVue 0.69.0 reads a ``.tck`` without its first streamline (its
    ``readTCK`` misses the offset 0), a ``.trk`` whole.
    """
    tractogram = nib.streamlines.Tractogram(
        [np.asarray(line, dtype=np.float32) for line in lines],
        affine_to_rasmm=np.eye(4),
        data_per_streamline={"rank": streamline_ranks(len(lines))[:, None]},
    )
    file = io.BytesIO()
    nib.streamlines.TrkFile(tractogram).save(file)
    return file.getvalue()


def streamlines_state(lines, total: int, bundles=None) -> dict:
    """
    Return the streamlines *lines* for the page to draw, a JSON-able dict.

    *lines* are (n, 3) arrays of points in millimetres, those drawn of
    the *total* of the result; they go in the page as a ``.trk`` file
    (:func:`trk_bytes`), encoded as :func:`encode_array` does. With
    *bundles*, a tuple (names, colours, the number of the name of each
    line), the page can colour each line by its bundle, a colour
    ``#rrggbb`` per name, rather than by its direction.
    """
    state = {
        "trk": encode_array(np.frombuffer(trk_bytes(lines), np.uint8)),
        "shown": len(lines), "total": int(total),
    }
    if bundles is not None:
        names, colours, numbers = bundles
        state["bundles"] = {
            "names": [str(name) for name in names],
            "colours": list(colours),
            "of": encode_array(np.asarray(numbers, dtype=np.uint16)),
        }
    return state


def regions_state(regions) -> dict:
    """
    Return the regions of a result (a :class:`~.nifti.RegionLayer`) as the
    page reads them: the image of their numbers, which names the one under
    the cursor, and that of their colours, RGBA, transparent elsewhere,
    which the page draws.
    """
    numbers = np.asanyarray(regions.image.dataobj)
    table = np.zeros(len(regions.names) + 1, dtype=RGBA)
    for n, colour in enumerate(regions.colours, 1):
        table[n] = (*bytes.fromhex(colour[1:7]), 255)
    return {
        "nifti": encode_nifti(numbers, regions.image.affine),
        "colours": encode_nifti(table[numbers], regions.image.affine),
        "names": [str(name) for name in regions.names],
        "coloured": bool(regions.coloured),
    }


# The voxels of an RGBA image, as NIfTI stores them (its datatype 2304).
RGBA = np.dtype([("R", "u1"), ("G", "u1"), ("B", "u1"), ("A", "u1")])


def _script_json(state: dict) -> str:
    """Return *state* as JSON that cannot end the script element it is in."""
    return json.dumps(state, separators=(",", ":")).replace("<", "\\u003c")


def viewer_html(
    img, background, *, title: str, threshold, cmap, symmetric: bool,
    connectome=None, streamlines=None, space: str = "MNI", regions=None,
) -> str:
    """
    Return the HTML page of an interactive viewer of the image *img*.

    *img* is an image, or a sequence of (name, image) pairs on one grid,
    each an overlay. *background* is drawn under them (e.g.
    :func:`mni_background`), or nothing if None. Each overlay starts with
    the *threshold*, a value or a percentile such as ``"95%"`` of its
    nonzero (absolute, when symmetric) values; the first with the
    colormap *cmap*, :data:`DEFAULT_CMAP` if None, the others with those
    of :data:`OVERLAY_CMAPS`; and with a colormap symmetric around 0 or
    not, as *symmetric*, a bool or one per overlay, tells. Its controls
    change them. A *connectome*, a network of :func:`connectome_state`,
    is drawn in the 3D render, which the page then starts with, beside
    the slices, and its strongest edges are listed. *streamlines*, of
    :func:`streamlines_state`, are drawn so too, coloured by their
    direction or, if they have bundles, by their bundle, as a control
    chooses, with controls of their visibility and number, on
    slices cut in millimetres, as they are drawn. *space* names the
    millimetres of the cursor: ``MNI``, or ``RAS`` over the background of
    a subject. *regions*, a :class:`~.nifti.RegionLayer`, are the regions
    of a result: the readout names the one under the cursor, and a
    control shows them in their colours, those of their atlas.
    """
    state = viewer_state(
        img, background, title=title, threshold=threshold, cmap=cmap,
        symmetric=symmetric,
    )
    state["space"] = space
    if streamlines is not None:
        state["streamlines"] = streamlines
    if connectome is not None:
        state["connectome"] = connectome
    if regions is not None:
        state["regions"] = regions_state(regions)
    if connectome is not None or streamlines is not None:
        state["initial"]["display"] = {"renderTile": True, "layout": "grid"}
        for layer in state["initial"]["layers"]:
            layer["opacity"] = NETWORK_OVERLAY_OPACITY
    parts = {
        "TITLE": html.escape(title),
        "DATA": _script_json(state),
        "NIIVUE": (_STATIC / "niivue" / "niivue.umd.js").read_text(
            encoding="utf-8"
        ),
        "SCRIPT": (_STATIC / "brain_viewer.js").read_text(encoding="utf-8"),
        "FRAME_HOOKS": frame_hooks(),
        "FAVICON": base64.b64encode(
            (_STATIC / "favicon.svg").read_bytes()
        ).decode("ascii"),
    }
    page = (_STATIC / "brain_viewer.html").read_text(encoding="utf-8")
    return re.sub(
        r"__(TITLE|DATA|NIIVUE|SCRIPT|FRAME_HOOKS|FAVICON)__",
        lambda m: parts[m.group(1)], page,
    )
