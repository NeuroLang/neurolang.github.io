"""
The REPL of the browser's page, run by this machine's Python.

The page (``doc/_static/repl``) runs NeuroLang in its worker, on Pyodide,
within the memory a tab is given. When its ``bundle.json`` says
``"backend": "local"``, as ``neurolang-repl-serve --local`` writes it, the
page starts ``local_worker.js`` instead, which sends what the page asks to
the server, and so to a :class:`LocalBackend`: the engine is built by this
machine's Python from its data directory, with all of its analyses, and the
REPL is the page's own, :class:`~.web.WebRepl`, whose replies the page
shows as it does those of Pyodide.

What the REPL tells while it works (the steps of a build, of the AI
assistant) goes to every page listening (:meth:`LocalBackend.listen`), the
server sending it as events.
"""

import json
import os
import queue
import sys
import tempfile
import threading
from pathlib import Path
from typing import Callable, Optional

from neurolang.confine import lifted
from neurolang_apps.utils import engine_registry
from neurolang_apps.utils.tui import constant_notes, session, web
from neurolang_apps.utils.tui.interrupt import _raise_in_thread


def reply_payload(reply: web.Reply) -> dict:
    """Return *reply* as the page takes it, as ``worker.js`` gives it."""
    return {
        "html": reply.html, "viewers": reply.viewers,
        "failed": reply.failed, "tables": reply.tables,
        "prompt": reply.prompt, "mode": reply.mode,
        "predicates": reply.predicates,
        "ratable": getattr(reply, "ratable", False),
        "graph": getattr(reply, "graph", ""),
        "tokens": getattr(reply, "tokens", {}),
        "uploads": getattr(reply, "uploads", {}),
    }


# The variables of a session's process (neurolang-repl-serve --users) telling
# its user's assistant, as JSON (provider, model, base_url, key), and, "0",
# that they may not give their own key (tools/serve_repl has them too).
ASSISTANT_ENV = "NEUROLANG_REPL_LLM"
OWN_KEY_ENV = "NEUROLANG_REPL_OWN_KEY"
# "1": the user brings their own key (a guest): the server's is not theirs.
BRING_KEY_ENV = "NEUROLANG_REPL_BRING_KEY"
OWN_KEY_REFUSED = ("Your assistant's key is the one your admin set: you "
                   "cannot give your own.")

# What the page says of a rating stored on this server.
RATING_NOTE = (
    "A rating stores the query with its first rows or its error, and for an "
    "answer of the assistant the question and its steps, on this server, "
    "with your user name and groups."
)


def _is_initialize(body: bytes) -> bool:
    """Whether the JSON-RPC *body* of an MCP client starts a session."""
    try:
        message = json.loads(body)
    except ValueError:
        return False
    return isinstance(message, dict) and message.get("method") == "initialize"


def apply_env(env: dict) -> None:
    """Put the variables *env* in this process's environment; one whose
    value is None is taken out (a key of the server, from a guest's)."""
    for name, value in env.items():
        if value is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = value


class LocalBackend:
    """
    The engine and the REPL of the page, in this process.

    The engines are built from *data_dir* at *resolution*, with all their
    analyses unless *light* (those a tab can hold, as in the browser).
    *feedback*, ``(url, doc)``, is where a rated answer goes (see
    :meth:`~.web.WebRepl.set_feedback`), or ``{"path": ..., "user": ...,
    "groups": ...}`` the database of this machine where it is stored,
    signed (see :meth:`~.web.WebRepl.set_feedback_store`). *build*,
    ``build(name, say)``, builds an engine, telling its steps with ``say``:
    by default
    :func:`~neurolang_apps.utils.engine_registry.build_engine`. With
    *preload_embeddings*, an engine built has its text embeddings loaded
    too (see :meth:`build`). With *memory_mb*, a request that takes this
    process more than that much memory of its own (on Linux; see
    :func:`~.sessions.process_usage`) is interrupted as a stop does, and
    its reply says so.
    """

    def __init__(
        self, data_dir, resolution: float = 2.0, light: bool = False,
        feedback: Optional[tuple] = None, build: Optional[Callable] = None,
        preload_embeddings: bool = False, uploads: Optional[dict] = None,
        memory_mb: float = 0, memory_seconds: float = 0.5,
    ):
        self.data_dir = Path(data_dir).resolve()
        # Where the page's uploads go and how large they may be
        # (session.Uploads), in memory without a directory.
        self.uploads = uploads or {}
        self.resolution = resolution
        self.light = light
        self.feedback = feedback
        self._build = build or self._build_engine
        self.preload_embeddings = preload_embeddings
        self.repl: Optional[web.WebRepl] = None
        self._engine = ""
        # The MCP server on the REPL, once a client asked (see mcp).
        self._mcp = None
        self._page_key = False  # whether the page gave the assistant's key
        # The values the variables of the user's identity had before it
        # (see use_identity).
        self._before_identity = {}
        # One request at a time works on the REPL; the thread of the one
        # that does, for a stop to interrupt it.
        self._lock = threading.Lock()
        self._worker: Optional[threading.Thread] = None
        self.memory_mb = memory_mb
        self.memory_seconds = memory_seconds
        self._over: Optional[float] = None  # MB, when the cap stopped a request
        self._listeners = []
        self._listeners_lock = threading.Lock()

    # -- What the REPL tells while it works -------------------------------

    def listen(self) -> queue.Queue:
        """Return a queue of the messages to come, as JSON texts."""
        listener = queue.Queue()
        with self._listeners_lock:
            self._listeners.append(listener)
        return listener

    def forget(self, listener: queue.Queue) -> None:
        """Stop sending messages to *listener*."""
        with self._listeners_lock:
            if listener in self._listeners:
                self._listeners.remove(listener)

    def emit(self, message: dict) -> None:
        """Send *message* to every page listening."""
        text = json.dumps(message)
        with self._listeners_lock:
            for listener in self._listeners:
                listener.put(text)

    def say(self, message: str) -> None:
        """Tell the pages a step of the work, as their status."""
        self.emit({"type": "status", "message": message + "…"})

    # -- The requests of the page -----------------------------------------

    def build(self, name: str, say: Callable):
        """Build the engine *name*, telling its steps with *say*; with
        ``preload_embeddings``, load its text embeddings (the documents',
        from their cache or computed into it, and the query model), so
        that its first query of them does not, nor do the sessions forked
        from this process (see
        :func:`~neurolang_apps.utils.text_embeddings.preload`); and find the
        values of its string sorts, which the notes of a query look up
        (:func:`~neurolang_apps.utils.tui.constant_notes.prepare`)."""
        nl = self._build(name, say)
        if self.preload_embeddings and \
                getattr(nl, "text_embedding_indexes", None):
            from neurolang_apps.utils import text_embeddings

            say("Loading the text embeddings")
            text_embeddings.preload(nl)
        say("Finding the names of the engine")
        constant_notes.prepare(nl, name)
        return nl

    def _build_engine(self, name: str, say: Callable):
        yaml_path = None
        if self.light:
            yaml_path = web.lightweight_engines_yaml(tempfile.mkdtemp())
        # The files an engine reads by a relative path (the atlas of
        # tractography) are in its data directory, which its downloads make
        # on a first start.
        self.data_dir.mkdir(parents=True, exist_ok=True)
        os.chdir(self.data_dir)
        return engine_registry.build_engine(
            name, self.data_dir, self.resolution, yaml_path=yaml_path,
            progress=say,
        )

    def _working(self, work: Callable, watched: bool = False):
        """Return *work()*, one request at a time, which a stop interrupts,
        and so does the memory cap if the request is *watched*."""
        with self._lock:
            self._worker = threading.current_thread()
            self._over = None
            done = threading.Event()
            if watched and self.memory_mb:
                threading.Thread(target=self._watch, args=(done,),
                                 daemon=True).start()
            try:
                return work()
            finally:
                done.set()
                self._worker = None

    def _watch(self, done: threading.Event) -> None:
        """Stop the request at work, until *done*, if this process takes
        more than *memory_mb* of memory of its own (nothing off Linux)."""
        from neurolang_apps.utils.tui.sessions import process_usage

        while not done.wait(self.memory_seconds):
            usage = process_usage(os.getpid())
            if usage is None:
                return
            if usage["private"] > self.memory_mb and not done.is_set():
                self._over = usage["private"]
                self.stop()
                return

    def stop(self) -> bool:
        """Interrupt the request at work, if any; return whether there was
        one."""
        worker = self._worker
        if worker is None:
            return False
        _raise_in_thread(worker, KeyboardInterrupt)
        return True

    def start(self, engine: str, text: bool = False) -> dict:
        """
        Build the engine *engine* and a REPL on it, and return what the page
        is told when it is ready. Each start builds them anew, as the page
        does when it restarts: the rules of a session are not kept. With
        *text*, the REPL answers in plain text, not in HTML (that of an MCP
        client, see :meth:`mcp`).
        """
        return self._working(lambda: self._start(engine, text))

    def _start(self, engine: str, text: bool = False) -> dict:
        with lifted():  # the engine's commands are the server's
            nl = self.build(engine, self.say)
        self.say("Starting the REPL")
        options = {}
        # The metadata of the studies of Neurosynth, whose ids are
        # PubMed's, let the page link the studies of a result.
        if engine.startswith("neurosynth"):
            try:
                from neurolang.frontend.neurosynth_utils import (
                    fetch_study_metadata,
                )
                options["study_metadata"] = fetch_study_metadata(
                    self.data_dir, verbose=0
                )
            except Exception:
                pass
        self._page_key = False
        repl = web.WebRepl(
            nl, engine, self.resolution, html=not text, **options
        )
        repl.app.uploads = session.Uploads(**self.uploads)
        repl.set_event_sink(lambda text: self.emit(json.loads(text)))
        self._use_machine_llm(repl)
        can_rate = False
        if isinstance(self.feedback, dict):  # this machine's database
            repl.set_feedback_store(**self.feedback)
            can_rate = repl.can_rate()
        elif self.feedback:
            repl.set_feedback(*self.feedback)
            can_rate = repl.can_rate()
        self.repl = repl
        self._engine = engine
        from neurolang_apps.utils.llm.browser import providers_for_form
        import neurolang
        return {
            "banner": repl.banner(),
            "source": f"the Python of this machine ({sys.executable}), "
            f"NeuroLang from {Path(neurolang.__file__).parent.parent}",
            "providers": providers_for_form(),
            "examples": repl.examples(),
            "questions": repl.questions(),
            "moreQuestions": repl.more_questions(),
            "questionQueries": repl.question_queries(),
            "questionTopics": repl.question_topics(),
            "predicates": repl.predicates(),
            "commands": repl.commands(),
            "canRate": can_rate,
            # whether the page may give a key of its own
            "ownKey": os.environ.get(OWN_KEY_ENV) != "0",
            # where a rating goes, when it stays on this server
            **({"ratingNote": RATING_NOTE}
               if isinstance(self.feedback, dict) else {}),
            # whether the assistant of this machine can answer, for the
            # page to suggest a question (a version of the page that
            # predates it leaves it out)
            "assistant": getattr(repl, "assistant_ready", lambda: False)(),
        }

    def mcp(self, verb: str, path: str, headers: dict, body: bytes,
            base_url: str, results_dir: str) -> tuple:
        """
        Answer the HTTP request of an MCP client, (status, headers, body),
        with the MCP server on the REPL (see
        :mod:`~neurolang_apps.utils.mcp_server`), made at the first: the
        files of its answers in a folder of *results_dir*, linked under
        *base_url*. A client's ``initialize`` starts a conversation.
        """
        from neurolang_apps.utils import mcp_server

        repl = self._repl()
        if self._mcp is None or self._mcp[0] is not repl:
            session = mcp_server.McpSession(
                self._engine, repl=repl, results_dir=Path(results_dir),
                token_bytes=16,
            )
            session.about = {"Grid": f"{self.resolution} mm"}
            bridge = mcp_server.HttpBridge(mcp_server.http_app(session))
            self._mcp = (repl, session, bridge)
        _, session, bridge = self._mcp
        session.store.base_url = base_url
        if _is_initialize(body):
            session.new_conversation()
        return bridge.call(verb, path, headers, body)

    def _repl(self) -> web.WebRepl:
        if self.repl is None:
            raise RuntimeError("The engine is not started")
        return self.repl

    def submit(self, text: str) -> dict:
        """Run *text* in the REPL and return its reply for the page."""
        def work():
            try:
                payload = reply_payload(self._repl().submit(text))
                if payload["tokens"]:  # whose key: the page's, or the server's
                    payload["tokens"]["key"] = \
                        "page" if self._page_key else "server"
                if not (self._over and payload["failed"]):
                    return payload
            except KeyboardInterrupt:
                pass
            # Stopped, by the page or by the memory cap (the REPL tells
            # "Query interrupted" only).
            message = "Stopped."
            if self._over:
                message = (
                    f"Stopped: the query took {self._over:.0f} MB of "
                    f"memory, over the {self.memory_mb:g} MB a session "
                    "may take (session_memory_mb). Narrow it (a smaller "
                    "region, fewer terms, a restriction before a join) "
                    "and run it again; the rules of the session stay.")
            return {
                "html": f"<pre>{message}</pre>", "failed": True,
                "viewers": [], "tables": [],
            }
        return self._working(work, watched=True)

    def set_llm(
        self, provider: str = "", key: str = "", model: str = "",
        baseUrl: str = "",
    ) -> None:
        """Use the AI assistant of *provider* with *key*, or that of this
        machine without a key; a user who may not give their own key
        cannot."""
        repl = self._repl()
        if not key:
            self._page_key = False
            self._use_machine_llm(repl)
        elif os.environ.get(OWN_KEY_ENV) == "0":
            raise ValueError(OWN_KEY_REFUSED)
        else:
            repl.set_llm(provider, key, model, baseUrl)
            self._page_key = True
        self._tell_assistant()

    def use_identity(self, env: dict, groups=None) -> dict:
        """
        Take the variables *env* of the user as they are now (their
        assistant, whether they may give their own key, the keys of the
        server's configuration), which an admin or the user changed while
        the session runs, and their *groups*, which sign their ratings, if
        given. A variable of the identity before that *env* lacks is as it
        was before it (a key revoked is taken out). If they changed, the
        assistant is theirs at once, unless the page gives a key that they
        may still give. Return what the page is told.
        """
        before = dict(os.environ)
        apply_env(self._before_identity)
        self._before_identity = {name: os.environ.get(name) for name in env}
        apply_env(env)
        if groups is not None and isinstance(self.feedback, dict) and \
                groups != self.feedback.get("groups"):
            self.feedback = {**self.feedback, "groups": groups}
            if self.repl is not None:
                self.repl.set_feedback_store(**self.feedback)
        if self.repl is not None and dict(os.environ) != before and (
            not self._page_key or os.environ.get(OWN_KEY_ENV) == "0"
        ):
            self._page_key = False
            self._use_machine_llm(self.repl)
        return self._tell_assistant()

    def _tell_assistant(self) -> dict:
        """Tell the pages whether the assistant can answer and whether the
        user may give their own key; return it."""
        state = {
            "type": "assistant",
            "ready": bool(self.repl and self.repl.assistant_ready()),
            "ownKey": os.environ.get(OWN_KEY_ENV) != "0",
        }
        self.emit(state)
        return state

    @staticmethod
    def _use_machine_llm(repl: web.WebRepl) -> None:
        """
        Have the assistant of *repl* use the configuration of this machine,
        as ``neurolang-query`` does (its file, and the keys of the
        environment), until the page gives a key; without one, the
        assistant asks the page for a key, as in the browser.
        """
        if os.environ.get(BRING_KEY_ENV) == "1":  # theirs, from the page
            repl.set_llm("anthropic", "")
            return
        assistant = os.environ.get(ASSISTANT_ENV)
        if assistant:  # that of the user, or of their group
            settings = json.loads(assistant)
            repl.set_llm(settings["provider"], settings.get("key", ""),
                         settings.get("model", ""),
                         settings.get("base_url", ""))
            return
        state = repl.app.assistant
        state.provider = None
        try:
            state.reload()
        except Exception:
            repl.set_llm("anthropic", "")

    def rate(self, verdict: str, comment: str = "") -> dict:
        """Share the last answer of the assistant with its rating."""
        return self._repl().rate_answer(verdict, comment)

    def upload(self, name: str, data: bytes) -> dict:
        """Keep the file the page uploaded (WebRepl.upload)."""
        return self._working(lambda: self._repl().upload(name, data))

    def download(self, block: int, kind: str, value: str = "") -> web.Download:
        """Return the file of a result for the page to save."""
        return self._working(
            lambda: self._repl().download(block, kind, value)
        )
