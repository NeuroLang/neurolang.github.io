"""
Session commands of the interactive REPL.

The rules defined during a session, and the relations loaded with
``.load``, go to a scope of the engine's program opened when the REPL
starts (:func:`open_session_scope`), so that ``.idb`` lists the rules,
``.drop`` removes a rule, a predicate or a relation, and ``.clear``
removes them all. Each submission runs in a scope of its own, committed
to the session's only if the whole submission succeeds (see
:mod:`.submission`). The columns of the loaded relations, named by the
header of their file, are kept in the application's ``loaded_relations``
to name the columns of the results and of ``.sets``. The other commands
list the engines and the engine's sets and predicates, and show how the
last query is rewritten (``.rewritten``) or translated from SQUALL to
Datalog, and the Datalog rules of a predicate (``.datalog``).
"""

import re
import shlex
import shutil
import time
import traceback
import warnings
from contextlib import contextmanager
from pathlib import Path
from typing import Optional

import pandas as pd
from neurolang.confine import ConfinedError, check_read, confined_roots
from rich import box
from rich.table import Table

from nl_core.datalog import Union as DatalogUnion
from nl_core.datalog.basic_representation import UnionOfConjunctiveQueries
from nl_core.datalog.expressions import AdornedSymbol
from nl_core.datalog.wrapped_collections import WrappedRelationalAlgebraSet
from nl_expr.expressions import Command, Query, Symbol
from nl_core.datalog.pretty_printer import DatalogPrettyPrinter
from neurolang.frontend.datalog.squall_syntax_lark import (
    SquallProgram,
    parser as squall_parser,
)
from neurolang.frontend.datalog.standard_syntax import (
    DOCUMENT_COMMAND,
    documentation_command,
)
from nl_expr.logic import Implication
from neurolang_apps.utils import engine_registry
from neurolang_apps.utils.cli import (
    _execute_program,
    _declared_columns,
    _execute_squall_program,
    _list_sets,
    _show_squall_datalog,
)

from .commands import _switch, command
from neurolang_apps.utils.predicate_catalog import (
    is_user_symbol,
    listed,
    predicate_catalog,
    program_documentation,
)
from .submission import predicate_extent

def open_session_scope(nl) -> None:
    """Open the scope of the program of *nl* holding the session's rules."""
    nl.program_ir.push_scope()


def session_idb_symbols(nl) -> set:
    """
    Return the symbols of the predicates defined in the session.

    The helpers NeuroLang compiles a conditional probability into, such
    as ``P^cond_num`` and ``P^cond_den`` for ``P``, are left out: they
    are named ``P`` too.
    """
    symbol_table = nl.program_ir.symbol_table
    return {
        symbol
        for symbol in nl.program_ir.intensional_database()
        if symbol in symbol_table._symbols
        and not isinstance(symbol, AdornedSymbol)
    }


def _drop_helpers(app, name: str) -> None:
    """Remove the session's helper predicates of the predicate *name*."""
    symbol_table = app._nl.program_ir.symbol_table
    helpers = [
        symbol for symbol in symbol_table._symbols
        if isinstance(symbol, AdornedSymbol) and symbol.name == name
    ]
    for symbol in helpers:
        del symbol_table[symbol]


def _warn(app, message: str) -> None:
    """Print *message*, which tells why a command did nothing."""
    app.console.print(message, style="yellow", markup=False)


def _plural(count: int, noun: str) -> str:
    """Return *count* and *noun*, e.g. ``1 rule`` or ``2 rules``."""
    return f"{count} {noun}" if count == 1 else f"{count} {noun}s"


def rule_text(rule) -> str:
    """Return the Datalog text of *rule* on one line."""
    return re.sub(r"\s*\n\s*", " ", DatalogPrettyPrinter().walk(rule))


def _print_idb_table(app) -> None:
    """Print the session's predicates with their number of rules."""
    symbols = session_idb_symbols(app._nl)
    if not symbols:
        app.console.print("  [dim](no session-defined IDB predicates)[/dim]")
        return
    idb = app._nl.program_ir.intensional_database()
    table = Table(
        title="Session IDB predicates", box=box.ROUNDED,
        header_style="bold cyan",
    )
    for column in ("Predicate", "Rules", "Arity"):
        table.add_column(column)
    for symbol in sorted(symbols, key=lambda s: s.name):
        rules = idb[symbol].formulas
        arity = len(rules[0].consequent.args)
        table.add_row(symbol.name, str(len(rules)), str(arity))
    app.console.print(table)
    app.console.print(
        f"\n[dim]Total session IDB predicates: {len(symbols)}[/dim]"
    )


def _print_rules(app, name: str) -> None:
    """Print the rules of the IDB predicate *name*, numbered from 1."""
    symbol_table = app._nl.program_ir.symbol_table
    symbol = Symbol(name)
    value = symbol_table[symbol] if symbol in symbol_table else None
    if not isinstance(value, DatalogUnion):
        _warn(app, f"{name!r} is not an IDB predicate.")
        return
    width = len(str(len(value.formulas)))
    for number, rule in enumerate(value.formulas, 1):
        app.console.print(
            f"{number:>{width}}  {rule_text(rule)}", markup=False,
            highlight=False,
        )


@command(
    ".idb", "List the predicates defined in this session, or the rules "
    "of one", ".idb [PREDICATE]",
)
def cmd_idb(app, arg: str) -> None:
    """Print the session's predicates, or the rules of the one in *arg*."""
    name = arg.strip()
    if name:
        _print_rules(app, name)
    else:
        _print_idb_table(app)


def _session_value(app, name: str):
    """
    Return the value of *name* in the session's scope.

    If *name* is not defined in this session, print why and return None.
    """
    symbol = Symbol(name)
    symbol_table = app._nl.program_ir.symbol_table
    if symbol in symbol_table._symbols:
        return symbol_table[symbol]
    if symbol in symbol_table:
        _warn(
            app, f"Predicate {name!r} is part of the engine; only the "
            "session's predicates and relations can be removed.",
        )
    else:
        _warn(app, f"Predicate {name!r} is not defined.")
    return None


def _engine_rules(app, name: str) -> tuple:
    """Return the rules of *name* defined outside the session's scope."""
    enclosing = app._nl.program_ir.symbol_table.enclosing_scope
    if enclosing is None or Symbol(name) not in enclosing:
        return ()
    value = enclosing[Symbol(name)]
    return value.formulas if isinstance(value, DatalogUnion) else ()


def _removal_message(name: str, unit: str, size: int, kept: int) -> str:
    """
    Return the message telling that the predicate *name* was removed.

    It had *size* rules or facts, as *unit* names them, *kept* of which
    are the engine's and remain.
    """
    message = f"removed {name} ({_plural(size - kept, unit)})"
    if kept:
        message += f"; its {_plural(kept, f'engine {unit}')} remain"
    return message


def _drop_all_rules(app, name: str, rules: tuple) -> None:
    """Remove the session's rules of the predicate *name*."""
    del app._nl.program_ir.symbol_table[Symbol(name)]
    _drop_helpers(app, name)
    app.squall_rules.pop(name, None)
    kept = len(_engine_rules(app, name))
    app.console.print(
        _removal_message(name, "rule", len(rules), kept), style="green",
        markup=False,
    )


def _drop_rule(app, name: str, rules: tuple, number: int) -> None:
    """Remove the rule *number*, counted from 1, of the predicate *name*."""
    if not 1 <= number <= len(rules):
        _warn(
            app, f"{name} has {_plural(len(rules), 'rule')}; there is no "
            f"rule {number}. See .idb {name}.",
        )
        return
    if rules[number - 1] in _engine_rules(app, name):
        _warn(app, f"Rule {number} of {name} is part of the engine.")
        return
    remaining = rules[:number - 1] + rules[number:]
    # its rules as compiled are not numbered as those SQUALL translated
    app.squall_rules.pop(name, None)
    symbol_table = app._nl.program_ir.symbol_table
    if remaining:
        symbol = Symbol(name).cast(UnionOfConjunctiveQueries)
        symbol_table[symbol] = DatalogUnion(remaining)
        left = f"{_plural(len(remaining), 'rule')} left"
    else:
        del symbol_table[Symbol(name)]
        _drop_helpers(app, name)
        left = f"no rules left: {name} removed"
    app.console.print(
        f"removed rule {number} of {name} ({left})", style="green",
        markup=False,
    )


def drop(app, name: str, number=None) -> None:
    """
    Remove the session predicate or relation *name*.

    With a rule *number*, counted from 1 as ``.idb NAME`` shows them,
    remove only that rule of the predicate *name*.
    """
    value = _session_value(app, name)
    if value is None:
        return
    if isinstance(value, DatalogUnion):
        if number is None:
            _drop_all_rules(app, name, value.formulas)
        else:
            _drop_rule(app, name, value.formulas, number)
    elif not isinstance(
        getattr(value, "value", None), WrappedRelationalAlgebraSet
    ):
        _warn(app, f"{name!r} is neither an IDB predicate nor a relation.")
    elif number is not None:
        _warn(app, f"{name!r} is a relation, it has no rules.")
    else:
        del app._nl.program_ir.symbol_table[Symbol(name)]
        app.loaded_relations.pop(name, None)
        app.console.print(
            f"removed relation {name}", style="green", markup=False
        )


def _rule_number(text: str):
    """Return the rule number *text*, or None if it is not one."""
    return int(text) if text.isdigit() and int(text) > 0 else None


@command(
    ".drop", "Remove rule N of a session predicate, all its rules, or a "
    "loaded relation", ".drop PREDICATE [N]",
)
def cmd_drop(app, arg: str) -> None:
    """Remove the session predicate, rule or relation named in *arg*."""
    words = arg.split()
    if not 1 <= len(words) <= 2:
        _warn(app, "Usage: .drop PREDICATE [N]")
        return
    if len(words) == 1:
        drop(app, words[0])
        return
    number = _rule_number(words[1])
    if number is None:
        _warn(
            app, f"The rule number must be a positive integer, "
            f"not {words[1]!r}.",
        )
        return
    drop(app, words[0], number)


def _cleared_line(app, symbol, value):
    """
    Return the line telling that ``.clear`` removes *symbol*, or None.

    *value* is its value in the session's scope. None is returned for
    the symbols NeuroLang generates and those that are not predicates.
    """
    extent = predicate_extent(value)
    if extent is None or not is_user_symbol(symbol):
        return None
    if symbol.name in app.loaded_relations:
        return f"removed relation {symbol.name}"
    enclosing = app._nl.program_ir.symbol_table.enclosing_scope
    engine = predicate_extent(enclosing.get(symbol)) if enclosing else None
    kept = engine[1] if engine else 0
    return _removal_message(symbol.name, extent[2], extent[1], kept)


def _cleared_lines(app) -> list:
    """Return the lines telling what ``.clear`` removes, by name."""
    session = app._nl.program_ir.symbol_table._symbols
    lines = {
        symbol.name: _cleared_line(app, symbol, value)
        for symbol, value in session.items()
    }
    return [line for _, line in sorted(lines.items()) if line]


@command(
    ".clear", "Clear the predicates and relations of this session, or one",
    ".clear [PREDICATE]",
)
def cmd_clear(app, arg: str) -> None:
    """Remove the session's predicates and relations, or the one in *arg*."""
    name = arg.strip()
    if name:
        drop(app, name)
        return
    lines = _cleared_lines(app)
    app._nl.program_ir.pop_scope()
    open_session_scope(app._nl)
    app.loaded_relations.clear()
    app.squall_rules.clear()
    for line in lines or ["nothing to clear"]:
        app.console.print(line, style="green", markup=False)


def default_relation_name(path) -> str:
    """
    Return the default name of the relation loaded from *path*.

    It is the file name without its ``.csv``/``.tsv``/``.nii``/``.trk``/
    ``.tck`` and ``.gz`` extensions, in lower case, with the characters
    other than letters and digits replaced by ``_`` and ``rel_`` prepended
    if it would start with a digit.
    """
    stem = re.sub(r"(\.(csv|tsv|nii|trk|tck))?(\.gz)?$", "",
                  Path(path).name.lower())
    name = re.sub(r"[^a-z0-9]", "_", stem)
    return f"rel_{name}" if not name or name[0].isdigit() else name


_IDENTIFIER = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\Z")


def _name_problem(app, name: str, explicit: bool):
    """
    Return why *name* cannot name a loaded relation, or None.

    Only a relation loaded in this session can be replaced, and only
    when its name is given *explicit*-ly.
    """
    if not _IDENTIFIER.match(name):
        return (
            f"Invalid relation name {name!r}: use letters, digits and "
            "'_', not starting with a digit."
        )
    if Symbol(name) not in app._nl.program_ir.symbol_table:
        return None
    if name not in app.loaded_relations:
        return (
            f"{name!r} is already defined; give another name: "
            ".load PATH NAME"
        )
    if not explicit:
        return (
            f"Relation {name!r} is already loaded; to replace it, give "
            f"its name: .load PATH {name}"
        )
    return None


def _read_rows(path: Path, data: bytes = None) -> pd.DataFrame:
    """Return the rows of the relation file *path* (or of the bytes *data*
    it names), which must have some."""
    df = engine_registry.read_relation_file(path, data)
    if df.empty:
        raise pd.errors.EmptyDataError("no rows")
    return df


def _load_error_message(path: Path, exc: Exception) -> str:
    """Return the one-line message of the error *exc* loading *path*."""
    if isinstance(exc, FileNotFoundError):
        return f"No such file: {path}"
    if isinstance(exc, engine_registry.UnsupportedRelationFile):
        return str(exc)
    if isinstance(exc, pd.errors.EmptyDataError):
        return f"Cannot load {path}: the file is empty (no rows)."
    lines = str(exc).strip().splitlines() or [type(exc).__name__]
    return f"Cannot load {path}: {lines[0]}"


def _load_failed(app, message: str, exc=None) -> None:
    """Report that ``.load`` failed with *message* and the error *exc*."""
    app.failed = True
    if exc is not None and app.settings.debug:
        traceback.print_exception(
            type(exc), exc, exc.__traceback__, file=app.err_console.file
        )
    app.err_console.print(message, style="red", markup=False)


def _add_relation(app, name: str, df: pd.DataFrame, path: Path) -> None:
    """Add the rows *df* read from *path* as the session relation *name*."""
    replaced = name in app.loaded_relations
    if replaced:
        del app._nl.program_ir.symbol_table[Symbol(name)]
    app._nl.add_tuple_set(df, name=name)
    columns = [str(column) for column in df.columns]
    app.loaded_relations[name] = columns
    message = (
        f"loaded {name}({', '.join(columns)}): "
        f"{_plural(len(df), 'row')} from {path}"
    )
    if replaced:
        message += f" (replaces the previous {name})"
    app.console.print(message, style="green", markup=False)


def _load_arguments(arg: str):
    """Return the words ``PATH [NAME]`` of *arg*, or None if malformed."""
    try:
        words = shlex.split(arg)
    except ValueError:
        return None
    return words if 1 <= len(words) <= 2 else None


# The files a page uploads (WebRepl.upload): their names, and by default
# the bytes of one and of all those of a session (a server sets its own:
# neurolang-repl-serve --max-upload-mb, --max-uploads-mb).
UPLOAD_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._ -]{0,99}\Z")
MOST_UPLOAD_BYTES = 50 << 20
MOST_UPLOADS_BYTES = 200 << 20
# Those of an image or a tractogram, which .image loads (nifti.py), not
# .load: a tractogram as the voxels near the ends of its streamlines.
TRACTOGRAM_SUFFIXES = (".trk", ".tck")
IMAGE_SUFFIXES = (".nii", ".nii.gz") + TRACTOGRAM_SUFFIXES


def is_image(name: str) -> bool:
    """Whether the file *name* is a NIfTI image or a tractogram, which
    ``.image`` loads."""
    return name.lower().endswith(IMAGE_SUFFIXES)


def is_tractogram(name: str) -> bool:
    """Whether the file *name* is a tractogram (``.trk``, ``.tck``)."""
    return name.lower().endswith(TRACTOGRAM_SUFFIXES)


class Uploads:
    """
    The files the page of a session uploaded, by name, for ``.load NAME``
    and ``.image NAME``: in the memory of the session, or, on a server that
    gives one (neurolang-repl-serve --uploads-dir), as the files of the
    session's *directory*, which the server removes when the session ends
    and its admins may erase (what the folder holds is the session's). A
    file is at most *most_file* bytes, and all those of the session
    *most_all*: a ValueError tells which is exceeded. A new store of a
    directory empties it, as the page forgets its files on a restart.
    """

    def __init__(self, directory=None, most_file: int = MOST_UPLOAD_BYTES,
                 most_all: int = MOST_UPLOADS_BYTES):
        self.directory = Path(directory) if directory else None
        self.most_file = int(most_file)
        self.most_all = int(most_all)
        self._memory = {}  # name -> data, without a directory
        self._times = {}  # name -> when it was uploaded, without one
        self._loaded = {}  # name -> the relations loaded from it
        # The last file removed, for an undo (restore): its name, its
        # bytes (without a directory) and the relations loaded from it.
        self._removed = None
        if self.directory is not None and self.directory.exists():
            shutil.rmtree(self.directory, ignore_errors=True)

    def _sizes(self) -> dict:
        """Return the sizes of the files kept, by name."""
        if self.directory is None:
            return {name: len(data) for name, data in self._memory.items()}
        if not self.directory.is_dir():
            return {}
        return {path.name: path.stat().st_size
                for path in self.directory.iterdir() if path.is_file()}

    def get(self, name: str) -> Optional[bytes]:
        """Return the bytes of the file *name*, or None."""
        if self.directory is None:
            return self._memory.get(name)
        try:
            return (self.directory / name).read_bytes()
        except OSError:  # never uploaded, or erased
            return None

    def put(self, name: str, data: bytes) -> None:
        """Keep the bytes *data* as the file *name*, replacing one of that
        name; *name* is that of a file of the directory (store_upload
        checks it)."""
        if len(data) > self.most_file:
            raise ValueError(f"{name} is over {self.most_file >> 20} MB")
        kept = sum(size for n, size in self._sizes().items() if n != name)
        if kept + len(data) > self.most_all:
            raise ValueError(f"The uploads of a session hold at most "
                             f"{self.most_all >> 20} MB")
        self._forget_removed()  # another change: no undo of a removal
        if self.directory is None:
            self._memory[name] = bytes(data)
            self._times[name] = time.time()
        else:
            self.directory.mkdir(parents=True, exist_ok=True)
            (self.directory / name).write_bytes(data)
        self._loaded.pop(name, None)  # new bytes, nothing loaded of them

    __setitem__ = put

    def __contains__(self, name) -> bool:
        return name in self._sizes()

    def remove(self, name: str) -> bool:
        """Remove the file *name*, from the memory of the session or from
        its folder; return whether there was one. It is kept aside, for
        :meth:`restore`, until the next change of the uploads."""
        if name not in self:
            return False
        self._forget_removed()
        loaded = self._loaded.pop(name, set())
        self._times.pop(name, None)
        if self.directory is None:
            self._removed = (name, self._memory.pop(name), loaded)
        else:
            aside = self.directory / self.REMOVED
            aside.mkdir(exist_ok=True)
            (self.directory / name).replace(aside / name)
            self._removed = (name, None, loaded)
        return True

    #: The folder, in that of a session, of the file removed last.
    REMOVED = ".removed"

    def restore(self, name: str) -> bool:
        """Bring back the file *name*, if it was the last removed and
        nothing changed since; return whether it was."""
        if self._removed is None or self._removed[0] != name:
            return False
        _, data, loaded = self._removed
        self._removed = None
        if self.directory is None:
            self._memory[name] = data
            self._times[name] = time.time()
        else:
            (self.directory / self.REMOVED / name).replace(
                self.directory / name)
        if loaded:
            self._loaded[name] = loaded
        return True

    def _forget_removed(self) -> None:
        """Forget the file removed last: it can no longer be restored."""
        self._removed = None
        if self.directory is not None:
            shutil.rmtree(self.directory / self.REMOVED, ignore_errors=True)

    def loaded(self, name: str, relation: str) -> None:
        """Tell that the relation *relation* was loaded from the file
        *name* (.load NAME, .image NAME)."""
        self._loaded.setdefault(name, set()).add(relation)

    def used(self) -> int:
        """Return the bytes the files take."""
        return sum(self._sizes().values())

    def listing(self) -> list:
        """Return the files, by name: each one's ``name``, ``size``, ``age``
        in seconds since it was uploaded, and the relations ``loaded`` from
        it, by name."""
        now = time.time()
        listing = []
        for name, size in sorted(self._sizes().items()):
            when = self._times.get(name) if self.directory is None else None
            if when is None and self.directory is not None:
                try:
                    when = (self.directory / name).stat().st_mtime
                except OSError:  # erased meanwhile
                    continue
            listing.append({
                "name": name, "size": size,
                "age": max(0, round(now - (when or now))),
                "loaded": sorted(self._loaded.get(name, ())),
            })
        return listing


def store_upload(app, name: str, data: bytes) -> None:
    """
    Keep the file *name*, of the bytes *data*, that the page uploaded, for
    ``.load NAME`` (``.image NAME`` for a NIfTI image or a tractogram), in
    the uploads of
    the session (:class:`Uploads`), gone with it. A ValueError tells why it
    is refused (its name, its format, its size).
    """
    if not isinstance(name, str) or not UPLOAD_NAME.match(name) \
            or ".." in name:
        raise ValueError(f"{name!r} is not the name of a file: letters, "
                         "digits, '.', '_', '-' and spaces")
    if not is_image(name):
        engine_registry.relation_file_separator(name)  # .csv, .tsv(.gz)
    app.uploads.put(name, data)


def _confined_may_read(path: str) -> bool:
    """Whether the confined statements may read the file *path*: one of
    the directories they may read (neurolang.confine)."""
    try:
        check_read(Path(path).expanduser(), "file")
    except ConfinedError:
        return False
    return True


@command(
    ".load", "Load a CSV or TSV file (optionally gzipped), or one the page "
    "uploaded, as a relation",
    ".load PATH|UPLOADED [NAME]",
)
def cmd_load(app, arg: str) -> None:
    """Load the file named in *arg* as a relation of the session: one the
    page uploaded (store_upload) by its name, or a path; on a server, which
    reads none of its files for a statement (neurolang.confine), an
    uploaded one only."""
    words = _load_arguments(arg)
    if words is None:
        _load_failed(app, "Usage: .load PATH|UPLOADED [NAME]")
        return
    data = app.uploads.get(words[0])
    if data is None and confined_roots() is not None and \
            not _confined_may_read(words[0]):
        _load_failed(app, f"No file {words[0]} was uploaded: here the "
                     "statements load the files uploaded (the page's Upload "
                     "button) by their name, and those of the folders they "
                     "may read (neurolang-query --mcp --allow-dir), not the "
                     "machine's other files")
        return
    path = Path(words[0]) if data is not None else \
        Path(words[0]).expanduser()
    name = words[1] if len(words) == 2 else default_relation_name(path)
    try:
        df = _read_rows(path, data)
    except Exception as exc:
        _load_failed(app, _load_error_message(path, exc), exc)
        return
    problem = _name_problem(app, name, explicit=len(words) == 2)
    if problem:
        _load_failed(app, problem)
        return
    try:
        _add_relation(app, name, df, path)
    except Exception as exc:
        _load_failed(app, _load_error_message(path, exc), exc)
        return
    if data is not None:
        app.uploads.loaded(words[0], name)


UPLOADS_USAGE = ".uploads [remove NAME | restore NAME]"


@command(
    ".uploads", "List the files the page uploaded in this session (Upload "
    "data): their kind, size, age and the relations loaded from them; "
    "remove NAME deletes one, restore NAME brings back the one removed last",
    UPLOADS_USAGE,
)
def cmd_uploads(app, arg: str) -> None:
    """Print the files of the session's uploads (session.Uploads), or
    remove one."""
    try:
        words = shlex.split(arg)
    except ValueError:
        words = None
    if words and len(words) == 2 and words[0] == "remove":
        _remove_upload(app, words[1])
        return
    if words and len(words) == 2 and words[0] == "restore":
        if app.uploads.restore(words[1]):
            app.console.print(f"restored {words[1]}", style="green",
                              markup=False)
        else:
            _warn(app, f"{words[1]} cannot be restored: only the file "
                       "removed last can, before another is uploaded or "
                       "removed.")
        return
    if words != []:
        _warn(app, f"Usage: {UPLOADS_USAGE}")
        return
    listing = app.uploads.listing()
    if not listing:
        app.console.print(
            "No file was uploaded in this session: Upload data, on the "
            "page, uploads one; .load NAME or .image NAME loads it.",
            markup=False,
        )
        return
    table = Table(box=box.ROUNDED, header_style="bold cyan")
    for column in ("File", "Kind", "Size", "Uploaded", "Loaded as"):
        table.add_column(column, justify="right" if column == "Size"
                         else "left")
    for upload in listing:
        table.add_row(
            upload["name"],
            "tractogram" if is_tractogram(upload["name"])
            else "image" if is_image(upload["name"]) else "table",
            _megabytes(upload["size"]), _ago(upload["age"]),
            ", ".join(upload["loaded"]) or "not loaded",
        )
    app.console.print(table)
    app.console.print(
        f"{_megabytes(app.uploads.used())} of "
        f"{app.uploads.most_all >> 20} MB used; a file takes at most "
        f"{app.uploads.most_file >> 20} MB.", markup=False,
    )


def _remove_upload(app, name: str) -> None:
    """Delete the uploaded file *name* from the session, telling which
    relations loaded from it stay."""
    listing = {upload["name"]: upload for upload in app.uploads.listing()}
    if not app.uploads.remove(name):
        _warn(app, f"No file {name} was uploaded in this session: "
                   ".uploads lists them.")
        return
    loaded = listing.get(name, {}).get("loaded", [])
    message = f"removed {name}"
    if loaded:
        relations = ", ".join(loaded)
        message += (f"; {relations}, loaded from it, "
                    f"{'stays' if len(loaded) == 1 else 'stay'} in this "
                    f"session (.drop {loaded[0]} removes it)")
    app.console.print(message, style="green", markup=False)


def _megabytes(size: int) -> str:
    """Return the *size* in bytes as a text: bytes below a kilobyte, kB
    below a megabyte."""
    if size < 1024:
        return f"{size} B"
    if size < 1 << 20:
        return f"{size / 1024:.1f} kB"
    return f"{size / (1 << 20):.1f} MB"


def _ago(seconds: int) -> str:
    """Return how long ago *seconds* was, as a text."""
    if seconds < 120:
        return f"{seconds} s ago"
    if seconds < 7200:
        return f"{seconds // 60} min ago"
    return f"{seconds // 3600} h ago"


@command(".sets", "List the engine's sets (EDB relations) and the loaded ones")
def cmd_sets(app, arg: str) -> None:
    """Print the relational algebra sets of the engine."""
    _list_sets(app._nl, app.loaded_relations)


def _print_predicates_table(app, infos) -> None:
    """
    Print the predicates *infos* as a table, with the description of
    those documented in the program, if any is.
    """
    described = any(info.description for info in infos)
    table = Table(box=box.ROUNDED, header_style="bold cyan")
    for column in _PREDICATE_COLUMNS + ("Description",) * described:
        table.add_column(column)
    for info in infos:
        row = (info.name, info.kind, info.signature())
        table.add_row(*row, *(_one_line(info.description),) * described)
    app.console.print(table)


def _one_line(text: str) -> str:
    """Return *text* on one line."""
    return " ".join(text.split())


def _print_predicates_text(app, infos) -> None:
    """
    Print the predicates *infos* as plain aligned text, each documented
    in the program followed by its description.
    """
    rows = [_PREDICATE_COLUMNS + ("",)] + [
        (info.name, info.kind, info.signature(), info.description)
        for info in infos
    ]
    widths = [max(len(row[i]) for row in rows) for i in range(2)]
    for name, kind, signature, description in rows:
        line = f"{name:<{widths[0]}}  {kind:<{widths[1]}}  {signature}"
        if description:
            line += f" — {_one_line(description)}"
        app.console.print(
            line, markup=False, highlight=False, soft_wrap=True,
        )


_PREDICATE_COLUMNS = ("Predicate", "Kind", "Columns")


@command(
    ".predicates", "List the predicates of the engine and of the session, "
    "with their kind and columns",
)
def cmd_predicates(app, arg: str) -> None:
    """
    Print the predicates of the engine, by kind and name.

    A predicate the engine declares the arguments of shows its
    entities.
    """
    engine = app.settings.engine_name
    signatures = engine_registry.get_signatures(engine) if engine else {}
    infos = listed(predicate_catalog(
        app._nl, _declared_columns(engine), app.loaded_relations,
        signatures,
    ))
    if app.console.is_terminal:
        _print_predicates_table(app, infos)
    else:
        _print_predicates_text(app, infos)


@command(".engines", "List the available engines")
def cmd_engines(app, arg: str) -> None:
    """Print the engines of the registry."""
    engine_registry.show_engines()


@command(".credits", "Show the sources of the engine's data, and how to "
         "acknowledge them")
def cmd_credits(app, arg: str) -> None:
    """Print the acknowledgements of the data of the session's engine."""
    name = app.settings.engine_name
    texts = engine_registry.get_acknowledgements(name) if name else []
    if not texts:
        app.console.print("This engine names no source of its data.",
                          markup=False)
        return
    app.console.print(f"The data of {name}, and how to acknowledge them:",
                      markup=False)
    for text in texts:
        app.console.print(f"- {text}", markup=False, soft_wrap=True)


def _no_last_query(app) -> bool:
    """Print a message and return True if no query has been run yet."""
    if app.last_query is None:
        app.console.print("[yellow]No query has been run yet.[/yellow]")
        return True
    return False


def _replace(symbol_table, symbol, value) -> None:
    """Set *symbol* to *value* in *symbol_table*, or remove it if None."""
    if symbol in symbol_table._symbols:
        del symbol_table[symbol]
    if value is not None:
        symbol_table[symbol] = value


@contextmanager
def last_query_scope(app):
    """
    Open a scope of the program where the last query can run again.

    The rules that its submission added are taken out of the session
    while the block runs: running the query again adds them again, and
    SQUALL gives them new variables, so that they would be there twice.
    """
    session = app._nl.program_ir.symbol_table
    saved = {}
    for symbol, added in app.last_added_rules.items():
        value = session._symbols.get(symbol)
        if isinstance(value, DatalogUnion):
            saved[symbol] = value
            rules = tuple(r for r in value.formulas if r not in added)
            _replace(session, symbol, DatalogUnion(rules) if rules else None)
    try:
        with app._nl.scope:
            yield
    finally:
        for symbol, value in saved.items():
            _replace(session, symbol, value)


def rerun_last_query(app, **flags) -> None:
    """
    Run the last query again, in a scope, with the execution *flags*.

    The flags are those of :func:`~neurolang_apps.utils.cli._execute_program`,
    such as ``dry_run``; errors and warnings are reported as when it
    first ran.
    """
    if _no_last_query(app):
        return
    program, squall = app.last_query
    execute = _execute_squall_program if squall else _execute_program
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            try:
                with last_query_scope(app):
                    execute(app._nl, program, **flags)
            finally:
                app._print_notes(caught)
    except Exception as exc:
        app._report_error(exc, program)


@command(
    ".rewritten",
    "Show the rewritten program of the last query, or of every query",
    ".rewritten [on|off]",
)
def cmd_rewritten(app, arg: str) -> None:
    """Print the magic-sets rewriting of the last query, or toggle it."""
    if arg.strip():
        _switch(app, arg, "show_rewritten", "Rewritten program")
        return
    rerun_last_query(app, dry_run=True)


@command(
    ".scope",
    "Keep the rules of a query local to it (on, the default), or in the "
    "session (off)",
    ".scope [on|off]",
)
def cmd_scope(app, arg: str) -> None:
    """
    Show, or set, whether the rules defined with a query are local to it.

    On, a submission with a query (``ans`` in Datalog, ``obtain`` in
    SQUALL) runs in a scope discarded after it: its rules do not stay in
    the session, so that the next query can define rules of the same
    names. A submission without a query keeps its rules in any case.
    """
    _switch(app, arg, "scope_queries", "Rules of a query local to it")


@command(
    ".ra", "Print the relational algebra plans of the last query, or of "
    "every query instead of running it", ".ra [on|off]",
)
def cmd_ra(app, arg: str) -> None:
    """Print the plans of the last query, or toggle printing them."""
    if arg.strip():
        _switch(app, arg, "show_ra", "RA plans")
        return
    rerun_last_query(app, show_ra=app.settings.ra_options)


def _parsed_rules(parsed) -> tuple:
    """Return the rules of the parsed SQUALL program *parsed*."""
    if isinstance(parsed, SquallProgram):
        formulas = parsed.rules
    else:
        formulas = getattr(parsed, "formulas", None) or (parsed,)
    return tuple(f for f in formulas if isinstance(f, Implication))


def record_squall_rules(app, program: str) -> None:
    """
    Keep the Datalog rules of the SQUALL *program*, which just ran.

    They are kept by predicate name in the application's
    ``squall_rules``, as SQUALL translated them, for ``.datalog
    PREDICATE``: NeuroLang compiles some of them further, for instance a
    conditional probability into the predicate and two helpers.
    """
    if "define" not in program.lower():
        return
    for rule in _parsed_rules(squall_parser(program)):
        name = rule.consequent.functor.name
        app.squall_rules.setdefault(name, []).append(rule)


def _print_datalog_of(app, name: str) -> None:
    """
    Print the Datalog rules of the predicate *name*.

    A predicate defined in SQUALL during the session has its rules as
    SQUALL translated them; any other has its rules as the engine holds
    them.
    """
    rules = app.squall_rules.get(name)
    if rules is None:
        symbol_table = app._nl.program_ir.symbol_table
        value = symbol_table.get(Symbol(name))
        if not isinstance(value, DatalogUnion):
            _warn(app, f"{name!r} is not an IDB predicate.")
            return
        rules = value.formulas
    printer = DatalogPrettyPrinter()
    documentation = program_documentation(app._nl.program_ir).get(name)
    doc = () if documentation is None else (printer.walk(
        documentation_command(name, *documentation)
    ),)
    app.console.print(
        "\n\n".join((*doc, *(printer.walk(rule) for rule in rules))),
        markup=False, highlight=False, soft_wrap=True,
    )


def _print_datalog_program(app, program: str) -> None:
    """Print the rules and the query of the Datalog *program*."""
    printer = DatalogPrettyPrinter()
    parsed = app._nl.datalog_parser(program)
    for formula in getattr(parsed, "formulas", (parsed,)):
        label = (
            "query" if isinstance(formula, Query)
            else "rule" if not isinstance(formula, Command)
            else "documentation" if formula.name == DOCUMENT_COMMAND
            else "command"
        )
        app.console.print(
            f"── {label} ──\n{printer.walk(formula)}\n", markup=False,
            highlight=False, soft_wrap=True,
        )


@command(
    ".datalog", "Show the Datalog program of the last query, translated "
    "from SQUALL, or the Datalog rules of a predicate",
    ".datalog [PREDICATE]",
)
def cmd_datalog(app, arg: str) -> None:
    """
    Print the Datalog rules of the predicate in *arg*.

    Without a predicate, print the Datalog program of the last query,
    as the SQUALL of a SQUALL query translates to.
    """
    if arg.strip():
        _print_datalog_of(app, arg.strip())
        return
    if _no_last_query(app):
        return
    program, squall = app.last_query
    try:
        if squall:
            _show_squall_datalog(program)
        else:
            _print_datalog_program(app, program)
    except Exception as exc:
        app._report_error(exc, program)
