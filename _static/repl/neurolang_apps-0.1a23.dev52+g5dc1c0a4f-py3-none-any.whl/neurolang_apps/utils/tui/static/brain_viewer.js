/*
 * Interactive viewer of brain images, inlined in the page that
 * neurolang/utils/tui/brain_viewer.py writes (see its docstring for the
 * data), after NiiVue, which draws the slices.
 *
 * The background is NiiVue's volume 0 and the overlays its next volumes,
 * drawn in turn, each over the previous ones. Each overlay has its own
 * threshold, colormap, symmetry, opacity and visibility, which the
 * controls set for the active one, and the order the overlays are drawn
 * in can be changed. NiiVue's display is set by controls of its own:
 * the view, the layout of the slices and the 3D render, the drag mode,
 * the crosshair, the gamma, NiiVue's colour bar, labels, orientation
 * cube and ruler, the radiological convention, the interpolation and
 * the clip plane; its hot keys V and C, on the views, change the view
 * and the clip plane. A network, or streamlines, are NiiVue meshes,
 * drawn in the 3D render and on the slices near them. The colormaps of the page are given to NiiVue so
 * that it colours a value as the colour bars do:
 *
 * - one-sided, the colormap spans the threshold to the high threshold
 *   (the maximum by default), and the values out of that range are
 *   transparent;
 * - symmetric, it spans -h to h, h the high threshold of |v| (max|v| by
 *   default), its upper half for the positive values and its lower half
 *   for the negative ones, and the values of |v| out of the range are
 *   transparent.
 *
 * NiiVue draws the values above its range with the colour of its top: the
 * voxels above the high threshold are hidden by drawing a copy of the
 * image with them set below the range (the image itself is kept, for the
 * value under the cursor). A histogram of the values shows the range.
 */
(function () {
  'use strict';

  var data = JSON.parse(document.getElementById('viewer-data').textContent);
  // NiiVue's colormap types: from the minimum to the maximum, or from 0,
  // transparent below the minimum.
  var MIN_TO_MAX = 0, ZERO_TO_MAX_TRANSPARENT = 2;

  // The display of NiiVue the page starts with, and Reset restores: the 3
  // slices in a row, or in a column on a screen as narrow as a phone's.
  var NARROW = window.matchMedia && matchMedia('(max-width: 30rem)').matches;
  var DISPLAY = {
    sliceType: 'multiplanar', layout: NARROW ? 'column' : 'row', renderTile: false,
    dragMode: 'contrast', crosshairColor: '#4fa1ff', crosshairWidth: 1,
    crosshair3D: false, gamma: 1, colorbar: false, orientationText: true,
    orientCube: false, ruler: false, radiological: false, smooth: true,
    clipPlane: false
  };
  var SLICE_TYPES = ['axial', 'coronal', 'sagittal', 'multiplanar', 'render'];

  // Each layer holds the NiiVue volume of an overlay and the summary of
  // its values; the state holds the cursor, the active layer, the order
  // the layers are drawn in and the settings of each layer.
  var viewer = {layers: [], luts: {}, state: null, nv: null};

  /* The theme: that the page showing this one sends (see frame_hooks.js),
   * else the system's. The image is drawn on white in the light theme and
   * on black in the dark one; the other colours are those of the page. */
  function isLight() {
    var chosen = document.documentElement.dataset.theme;
    return chosen ? chosen === 'light' :
      matchMedia('(prefers-color-scheme: light)').matches;
  }

  function backColor() {
    var c = isLight() ? 1 : 0;
    return [c, c, c, 1];
  }

  /* The empty voxels of the template are black: transparent on the white
   * of the light theme. */
  function setBackdrop(nv) {
    nv.opts.backColor = backColor();
    nv.opts.isAlphaClipDark = isLight();
  }

  function themeColour(name) {
    return getComputedStyle(document.documentElement)
      .getPropertyValue(name).trim();
  }

  function $(id) { return document.getElementById(id); }

  /* ---------------------------------------------------------------
   * Decoding of the embedded colormaps: base64 of zlib-deflated bytes.
   */

  function base64Bytes(text) {
    var binary = atob(text);
    var bytes = new Uint8Array(binary.length);
    for (var i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  function inflate(text) {
    var stream = new Blob([base64Bytes(text)]).stream()
      .pipeThrough(new DecompressionStream('deflate'));
    return new Response(stream).arrayBuffer();
  }

  /* ---------------------------------------------------------------
   * The colormaps of NiiVue: for a colormap of the page, the whole of
   * it, its upper half and its lower half reversed, each transparent at
   * its first colour, which NiiVue gives the values below the minimum.
   */

  function niivueColormap(lut, index) {
    var map = {R: [], G: [], B: [], A: [], I: []};
    for (var i = 0; i < 256; i++) {
      var c = 3 * index(i);
      map.R.push(lut[c]); map.G.push(lut[c + 1]); map.B.push(lut[c + 2]);
      map.A.push(i === 0 ? 0 : 255); map.I.push(i);
    }
    return map;
  }

  function colormapKey(name, part) {
    return 'neurolang_' + name.toLowerCase() + (part ? '_' + part : '');
  }

  function addColormaps(nv) {
    Object.keys(viewer.luts).forEach(function (name) {
      var lut = viewer.luts[name];
      nv.addColormap(colormapKey(name), niivueColormap(lut, function (i) {
        return i;
      }));
      nv.addColormap(colormapKey(name, 'positive'), niivueColormap(
        lut, function (i) { return 128 + Math.round(i * 127 / 255); }
      ));
      nv.addColormap(colormapKey(name, 'negative'), niivueColormap(
        lut, function (i) { return 127 - Math.round(i * 127 / 255); }
      ));
    });
  }

  /* ---------------------------------------------------------------
   * Loading of the volumes.
   */

  function loadVolume(item, name) {
    return niivue.NVImage.loadFromBase64({base64: item.nifti, name: name});
  }

  // The layer of the NiiVue volume: the range of its nonzero values, and
  // their sorted lists for the percentiles, of |v| (symmetric colormap)
  // and of v (one-sided).
  function summarise(name, volume) {
    var img = volume.img, values = [];
    for (var i = 0; i < img.length; i++) {
      if (img[i] !== 0 && !isNaN(img[i])) values.push(img[i]);
    }
    var layer = {name: name, volume: volume};
    layer.sortedValues = Float32Array.from(values).sort();
    layer.sortedAbs = Float32Array.from(values, Math.abs).sort();
    var n = values.length;
    layer.min = n ? layer.sortedValues[0] : 0;
    layer.max = n ? layer.sortedValues[n - 1] : 0;
    layer.maxAbs = n ? layer.sortedAbs[n - 1] : 0;
    return layer;
  }

  // Size NiiVue's canvas to the pixels of the screen again when the browser
  // zoom changes them: NiiVue does so only when the canvas changes size,
  // which in a frame of a fixed width the zoom does not change.
  function followZoom(nv) {
    if (!window.matchMedia) return;
    matchMedia('(resolution: ' + devicePixelRatio + 'dppx)').addEventListener(
      'change', function () { nv.resizeListener(); followZoom(nv); },
      { once: true });
  }

  async function load() {
    for (var name in data.colormaps) {
      viewer.luts[name] = new Uint8Array(await inflate(data.colormaps[name]));
    }
    var nv = new niivue.Niivue({
      isAlphaClipDark: isLight(), backColor: backColor(), crosshairColor: [0.31, 0.63, 1, 0.85],
      crosshairWidth: 1, isColorbar: false, isRadiologicalConvention: false,
      multiplanarShowRender: niivue.SHOW_RENDER.NEVER,
      multiplanarLayout: niivue.MULTIPLANAR_TYPE.ROW,
      show3Dcrosshair: false, dragAndDropEnabled: false
    });
    await nv.attachTo('gl');
    followZoom(nv);
    // On a phone the options of the display start folded, the views close to the main controls.
    if (NARROW) $('display-options').open = false;
    addColormaps(nv);
    var background = await loadVolume(data.background, 'background.nii.gz');
    background.colormap = 'gray';
    nv.addVolume(background);
    for (var l = 0; l < data.overlays.length; l++) {
      var volume = await loadVolume(data.overlays[l], 'overlay' + l + '.nii.gz');
      volume.neurolangName = data.overlays[l].name;
      nv.addVolume(volume);
      viewer.layers.push(summarise(data.overlays[l].name, volume));
    }
    background.colorbarVisible = false;
    if (data.regions) await loadRegions(nv, data.regions);
    if (data.connectome) {
      // The network shows through the 3D render, and on a slice only
      // within a few millimetres of it.
      nv.opts.meshXRay = NETWORK_XRAY;
      nv.setMeshThicknessOn2D(NETWORK_SLAB_MM);
      viewer.network = data.connectome;
      setUpEdgeThreshold(nv, data.connectome);
    }
    $('space').textContent = data.space || 'MNI';
    if (data.streamlines) {
      // Slices cut in mm, as the streamlines are: NiiVue otherwise
      // straightens an oblique background (a subject's) under them.
      nv.setSliceMM(true);
      nv.opts.meshXRay = NETWORK_XRAY;
      nv.setMeshThicknessOn2D(NETWORK_SLAB_MM);
      await loadStreamlines(nv, data.streamlines);
    }
    if (data.regions || data.connectome) followMouse(nv);
    nv.setSliceType(nv.sliceTypeMultiplanar);
    nv.onLocationChange = function () { updateReadout(); };
    viewer.nv = nv;
  }

  // The regions of a result: the one under the cursor is named, from the
  // image of their numbers (n + 1 at the voxels of the n-th region), and
  // the control "atlas colours" draws them in the colours of their atlas,
  // an RGBA image transparent elsewhere.
  async function loadRegions(nv, regions) {
    var numbers = await loadVolume(regions, 'regions.nii.gz');
    var colours = await loadVolume({nifti: regions.colours}, 'regions-colours.nii.gz');
    numbers.opacity = 0;
    colours.opacity = regions.coloured ? 1 : 0;
    nv.addVolume(numbers);
    nv.addVolume(colours);
    viewer.regions = {volume: numbers, names: regions.names};
    var box = $('atlas-colours');
    box.checked = regions.coloured;
    $('atlas-colours-control').hidden = false;
    $('region-readout').hidden = false;
    box.addEventListener('change', function () {
      colours.opacity = box.checked ? 1 : 0;
      nv.updateGLVolume();
    });
  }

  // The node or the edge of the network, else the region of the result,
  // under the mouse on a slice, named beside it.
  function followMouse(nv) {
    var canvas = $('gl'), tip = $('region-tip');
    canvas.addEventListener('mousemove', function (event) {
      var rect = canvas.getBoundingClientRect();
      var ratio = canvas.width / rect.width;
      var frac = nv.canvasPos2frac([
        (event.clientX - rect.left) * ratio, (event.clientY - rect.top) * ratio]);
      var mm = Array.from(nv.frac2mm(frac)).slice(0, 3);
      var name = frac[0] < 0 ? '–' : networkAt(mm) || (viewer.regions ? regionAt(mm) : '–');
      tip.hidden = name === '–';
      tip.textContent = name;
      tip.style.left = event.clientX + 14 + 'px';
      tip.style.top = event.clientY + 14 + 'px';
    });
    canvas.addEventListener('mouseleave', function () { tip.hidden = true; });
  }

  // The name of the region of the result under the cursor, at *mm*.
  function regionAt(mm) {
    var regions = viewer.regions, vox = regions.volume.mm2vox(mm);
    var n = Math.round(regions.volume.getValue(vox[0], vox[1], vox[2]));
    return n > 0 ? regions.names[n - 1] : '–';
  }

  // The name of the node of the network drawn at *mm*, else 'first —
  // second: value' of its edge there, the nearest within HOVER_MM of its
  // surface; '' when none is.
  function networkAt(mm) {
    var state = viewer.networkState, network = viewer.network;
    if (!state) return '';
    var best = '', nearest = Infinity;
    var near = function (distance, radius, name) {
      if (distance - radius <= HOVER_MM && distance - radius < nearest) {
        nearest = distance - radius;
        best = name;
      }
    };
    state.nodes.forEach(function (n) {
      near(Math.hypot(n.x - mm[0], n.y - mm[1], n.z - mm[2]),
           n.sizeValue * network.nodeRadius, n.name);
    });
    if (best) return best;
    state.edges.forEach(function (e) {
      var a = state.nodes[e.first], b = state.nodes[e.second];
      near(segmentDistance(mm, [a.x, a.y, a.z], [b.x, b.y, b.z]),
           Math.abs(e.colorValue) * state.edgeScale,
           a.name + ' — ' + b.name + ': ' + format(e.value));
    });
    return best;
  }

  // The distance from the point p to the segment from a to b.
  function segmentDistance(p, a, b) {
    var ab = [0, 1, 2].map(function (i) { return b[i] - a[i]; });
    var length2 = ab[0] * ab[0] + ab[1] * ab[1] + ab[2] * ab[2];
    var t = length2 > 0 ? ((p[0] - a[0]) * ab[0] + (p[1] - a[1]) * ab[1] +
      (p[2] - a[2]) * ab[2]) / length2 : 0;
    t = Math.min(1, Math.max(0, t));
    return Math.hypot(a[0] + t * ab[0] - p[0], a[1] + t * ab[1] - p[1],
                      a[2] + t * ab[2] - p[2]);
  }

  // The strongest edges of the network, listed under the views, how
  // much the network shows through the 3D render, the thickness of the
  // slab of a slice it is drawn in, in millimetres, and the thickness of
  // the edge at the threshold, a share of that of the largest edge.
  var pageSettings = data.settings;  // of viewer.yaml
  var LISTED_EDGES = pageSettings.listed_edges,
    NETWORK_XRAY = pageSettings.network_xray,
    NETWORK_SLAB_MM = pageSettings.network_slab_mm,
    THINNEST_EDGE = pageSettings.thinnest_edge,
    HOVER_MM = pageSettings.hover_mm;

  // The network as NiiVue draws it, of the edges of |value| at least
  // *threshold* and the nodes they join. The colour and the size of a
  // node is its strength, the sum of the values of its edges; the colour
  // and the thickness of an edge its value, from the threshold (the
  // thinnest, THINNEST_EDGE of the thickest) to the largest value. NiiVue
  // makes an edge as thick as its value: the values it is given are
  // those above the threshold, plus that of the thinnest edge.
  function networkState(network, threshold) {
    var edges = network.edges.filter(function (e) {
      return e.value !== 0 && Math.abs(e.value) >= threshold;
    });
    var top = 0, strength = {}, kept = [];
    edges.forEach(function (e) {
      top = Math.max(top, Math.abs(e.value));
      [e.first, e.second].forEach(function (n) {
        if (!(n in strength)) { strength[n] = 0; kept.push(n); }
        strength[n] += e.value;
      });
    });
    kept.sort(function (a, b) { return a - b; });
    var position = {}, topNode = 0;
    kept.forEach(function (n, p) {
      position[n] = p;
      topNode = Math.max(topNode, Math.abs(strength[n]));
    });
    topNode = topNode || 1;
    var low = Math.min(threshold, top), span = top - low;
    var base = span > 0 ? span * THINNEST_EDGE / (1 - THINNEST_EDGE) : (top || 1);
    return {
      name: 'network',
      nodeColormap: 'winter', nodeColormapNegative: 'cool',
      nodeMinColor: 0, nodeMaxColor: topNode, nodeScale: network.nodeRadius,
      edgeColormap: 'warm', edgeColormapNegative: 'cool',
      edgeMin: base, edgeMax: span + base,
      edgeScale: network.edgeRadius / (span + base),
      legendLineThickness: 0, showLegend: false,
      nodes: kept.map(function (n) {
        var node = network.nodes[n];
        return {
          name: node.name, x: node.x, y: node.y, z: node.z,
          colorValue: strength[n],
          sizeValue: Math.max(Math.abs(strength[n]) / topNode, 0.4)
        };
      }),
      edges: edges.map(function (e) {
        var magnitude = Math.abs(e.value) - low + base;
        return {
          first: position[e.first], second: position[e.second],
          colorValue: e.value < 0 ? -magnitude : magnitude, value: e.value
        };
      })
    };
  }

  // Draw the edges of the network of |value| at least *threshold*, and
  // list the strongest.
  function drawNetwork(nv, threshold) {
    var state = viewer.networkState = networkState(viewer.network, threshold);
    nv.meshes.slice().forEach(function (mesh) { nv.removeMesh(mesh); });
    if (state.edges.length) nv.addMesh(nv.loadConnectomeAsMesh(state));
    nv.drawScene();
    listEdges(state);
  }

  // The edge threshold, a value and a slider from the smallest |value|
  // of the edges to the largest, which draws the network again; and, when
  // the result has several value columns, the one the edges are of.
  var edgeRange = {lo: 0, hi: 0};
  function toSlider(v) {
    var r = edgeRange;
    return r.hi > r.lo ? Math.round(1000 * (v - r.lo) / (r.hi - r.lo)) : 0;
  }

  // Show the network of one value column: its range, threshold and edges.
  function showNetwork(nv, network) {
    viewer.network = network;
    var values = network.edges.map(function (e) { return Math.abs(e.value); });
    edgeRange.lo = values.length ? Math.min.apply(null, values) : 0;
    edgeRange.hi = values.length ? Math.max.apply(null, values) : 0;
    $('edge-threshold').value = format(network.threshold);
    $('edge-slider').value = toSlider(network.threshold);
    drawNetwork(nv, network.threshold);
  }

  function setUpEdgeThreshold(nv, network) {
    var input = $('edge-threshold'), slider = $('edge-slider');
    input.addEventListener('input', function () {
      var v = parseFloat(input.value);
      if (!isFinite(v)) return;
      slider.value = toSlider(v);
      drawNetwork(nv, v);
    });
    slider.addEventListener('input', function () {
      var v = edgeRange.lo + (edgeRange.hi - edgeRange.lo) * slider.value / 1000;
      input.value = format(v);
      drawNetwork(nv, v);
    });
    var choices = network.values || [];
    if (choices.length > 1) {
      var select = $('edge-value');
      choices.forEach(function (choice, i) { select.add(new Option(choice.value, String(i))); });
      $('edge-value-control').hidden = false;
      select.addEventListener('change', function () {
        showNetwork(nv, choices[parseInt(select.value, 10)]);
      });
    }
    showNetwork(nv, network);
  }

  function listEdges(state) {
    var edges = state.edges.slice().sort(function (a, b) {
      return Math.abs(b.value) - Math.abs(a.value);
    }).slice(0, LISTED_EDGES);
    var list = $('edges');
    list.replaceChildren();
    $('network').style.display = '';
    $('network-count').textContent = state.nodes.length + ' nodes, ' +
      state.edges.length + ' edges shown' +
      (state.edges.length > edges.length ? ', the strongest ' + edges.length : '');
    edges.forEach(function (e) {
      var item = document.createElement('li');
      item.textContent = state.nodes[e.first].name + ' — ' +
        state.nodes[e.second].name + ': ' + format(e.value);
      list.appendChild(item);
    });
  }

  // The streamlines, a .trk file NiiVue reads as a mesh of fibres,
  // coloured by the direction of each segment, and the controls of their
  // visibility and opacity.
  async function loadStreamlines(nv, streamlines) {
    var mesh = await niivue.NVMesh.loadFromUrl({
      url: 'streamlines.trk', buffer: await inflate(streamlines.trk),
      gl: nv.gl
    });
    nv.addMesh(mesh);
    nv.setMeshProperty(mesh.id, 'fiberColor', 'Local');
    viewer.streamlines = mesh;
    $('streamlines').style.display = '';
    $('streamline-count').textContent = streamlines.shown + ' of ' +
      streamlines.total + ' streamlines shown';
    $('streamlines-visible').addEventListener('change', function (e) {
      nv.setMeshProperty(mesh.id, 'visible', e.target.checked);
    });
    $('streamline-opacity').addEventListener('input', function (e) {
      nv.setMeshProperty(mesh.id, 'opacity', parseFloat(e.target.value));
    });
  }

  /* ---------------------------------------------------------------
   * NiiVue's display: the display of the state, set by its controls.
   */

  // The colour of the crosshair, as NiiVue takes it, from #rrggbb.
  function hexColour(hex) {
    return [1, 3, 5].map(function (i) {
      return parseInt(hex.substr(i, 2), 16) / 255;
    }).concat([0.85]);
  }

  function isRow(d) {
    return d.sliceType === 'multiplanar' && d.layout === 'row';
  }

  // Set NiiVue's views: the slice type, the layout and the 3D tile, the
  // views being taller unless they are the 3 slices in a row.
  function applyViews(d) {
    var nv = viewer.nv;
    $('views').classList.toggle('tall', !isRow(d));
    nv.opts.multiplanarShowRender =
      niivue.SHOW_RENDER[d.renderTile ? 'ALWAYS' : 'NEVER'];
    nv.setMultiplanarLayout(niivue.MULTIPLANAR_TYPE[d.layout.toUpperCase()]);
    nv.setSliceType(SLICE_TYPES.indexOf(d.sliceType));
    if (nv.resizeListener) nv.resizeListener();
  }

  function applyDisplay() {
    var nv = viewer.nv, d = viewer.state.display;
    nv.opts.dragMode = nv.dragModes[d.dragMode];
    nv.opts.show3Dcrosshair = d.crosshair3D;
    nv.opts.isColorbar = d.colorbar;
    nv.opts.isOrientCube = d.orientCube;
    nv.opts.isRuler = d.ruler;
    nv.setCrosshairColor(hexColour(d.crosshairColor));
    nv.setCrosshairWidth(d.crosshairWidth);
    nv.setGamma(d.gamma);
    nv.setIsOrientationTextVisible(d.orientationText);
    nv.setRadiologicalConvention(d.radiological);
    nv.setInterpolation(!d.smooth);
    nv.setClipPlane(d.clipPlane ? [0, 270, 0] : [2, 0, 0]);
    applyViews(d);
  }

  // The controls of the display, by id, and the setting each holds.
  var DISPLAY_CONTROLS = {
    'slice-type': 'sliceType', 'layout': 'layout',
    'render-tile': 'renderTile', 'drag-mode': 'dragMode',
    'crosshair-color': 'crosshairColor',
    'crosshair-width': 'crosshairWidth', 'crosshair-3d': 'crosshair3D',
    'gamma': 'gamma', 'nv-colorbar': 'colorbar',
    'orientation-text': 'orientationText', 'orient-cube': 'orientCube',
    'ruler': 'ruler', 'radiological': 'radiological', 'smooth': 'smooth',
    'clip-plane': 'clipPlane'
  };

  function controlValue(el) {
    if (el.type === 'checkbox') return el.checked;
    if (el.type === 'number' || el.type === 'range') {
      return parseFloat(el.value);
    }
    return el.value;
  }

  function syncDisplayControls() {
    var d = viewer.state.display;
    Object.keys(DISPLAY_CONTROLS).forEach(function (id) {
      var el = $(id), value = d[DISPLAY_CONTROLS[id]];
      if (el.type === 'checkbox') el.checked = value; else el.value = value;
    });
  }

  // Keep the state in step with what NiiVue's hot keys changed.
  function followHotKeys() {
    var nv = viewer.nv, d = viewer.state.display;
    d.sliceType = SLICE_TYPES[nv.opts.sliceType];
    d.clipPlane = nv.scene.clipPlaneDepthAziElevs[0][0] < 2;
    $('views').classList.toggle('tall', !isRow(d));
    if (nv.resizeListener) nv.resizeListener();
    syncDisplayControls();
  }

  function setUpDisplay() {
    Object.keys(DISPLAY_CONTROLS).forEach(function (id) {
      var el = $(id);
      var kind = el.type === 'range' || el.type === 'color' ? 'input' : 'change';
      el.addEventListener(kind, function () {
        var value = controlValue(el);
        if (typeof value === 'number' && isNaN(value)) return;
        viewer.state.display[DISPLAY_CONTROLS[id]] = value;
        applyDisplay();
      });
    });
    $('gl').addEventListener('keyup', followHotKeys);
  }

  // The settings of the layer l, of the active one by default.
  function settings(l) {
    var s = viewer.state;
    return s.layers[l === undefined ? s.active : l];
  }

  /* ---------------------------------------------------------------
   * Threshold and colour scale.
   */

  // The percentile p (0 to 100) of sorted, interpolated as numpy does.
  function percentile(sorted, p) {
    if (!sorted.length) return 0;
    var position = (sorted.length - 1) * p / 100;
    var below = Math.floor(position);
    var above = Math.min(below + 1, sorted.length - 1);
    return sorted[below] + (sorted[above] - sorted[below]) * (position - below);
  }

  // The fraction (0 to 100) of sorted below value: percentile's inverse.
  function rank(sorted, value) {
    if (sorted.length < 2) return 0;
    var lo = 0, hi = sorted.length;
    while (lo < hi) {
      var mid = (lo + hi) >> 1;
      if (sorted[mid] < value) lo = mid + 1; else hi = mid;
    }
    return Math.min(100, 100 * lo / (sorted.length - 1));
  }

  function percentileSource(l) {
    var layer = viewer.layers[l];
    return settings(l).symmetric ? layer.sortedAbs : layer.sortedValues;
  }

  function thresholdValue(l) {
    var s = settings(l);
    if (s.thresholdMode === 'percentile') {
      return percentile(percentileSource(l), s.threshold);
    }
    return s.threshold;
  }

  // The largest value of the layer l the threshold applies to: of |v|
  // when symmetric.
  function topValue(l) {
    var layer = viewer.layers[l];
    return settings(l).symmetric ? layer.maxAbs : layer.max;
  }

  // The high threshold of the layer l, a value: its maximum when none is set.
  function upperValue(l) {
    var s = settings(l);
    if (s.upper === null || s.upper === undefined) return topValue(l);
    if (s.thresholdMode === 'percentile') {
      return percentile(percentileSource(l), s.upper);
    }
    return s.upper;
  }

  // The colour scale of the layer l: values from lo to hi span its
  // colormap, and only the voxels shown(v) are drawn.
  function scale(l) {
    var t = thresholdValue(l), u = upperValue(l), layer = viewer.layers[l];
    if (settings(l).symmetric) {
      var top = Math.max(u, t);
      return {lo: -top, hi: top, threshold: t, upper: u,
              shown: function (v) { return Math.abs(v) >= t && Math.abs(v) <= u; }};
    }
    var lo = t > 0 ? t : Math.min(0, layer.min);
    return {lo: lo, hi: Math.max(u, lo), threshold: t, upper: u,
            shown: function (v) { return v >= t && v <= u; }};
  }

  // The index (0 to 255) of the colour of v in the scale.
  function colourIndex(v, s) {
    var span = s.hi - s.lo;
    var t = span > 0 ? (v - s.lo) / span : 1;
    return Math.round(255 * Math.min(1, Math.max(0, t)));
  }

  // Set the NiiVue volume of the layer l as its settings and scale s
  // tell.
  function applyLayer(l, s) {
    var settingsOf = settings(l), volume = viewer.layers[l].volume;
    if (settingsOf.symmetric) {
      volume.colormap = colormapKey(settingsOf.cmap, 'positive');
      volume.colormapNegative = colormapKey(settingsOf.cmap, 'negative');
      volume.colormapType = ZERO_TO_MAX_TRANSPARENT;
      volume.cal_min = s.threshold;
      volume.cal_max = Math.max(s.hi, s.threshold);
    } else {
      volume.colormap = colormapKey(settingsOf.cmap);
      volume.colormapNegative = '';
      volume.colormapType = MIN_TO_MAX;
      volume.cal_min = s.lo;
      volume.cal_max = s.hi;
    }
    volume.cal_minNeg = NaN;
    volume.cal_maxNeg = NaN;
    volume.opacity = settingsOf.visible ? settingsOf.opacity : 0;
    hideAbove(l, s);
  }

  // Draw the voxels of the layer l above the high threshold of its scale s
  // out of the range, so transparent; the image is kept in layer.original.
  function hideAbove(l, s) {
    var layer = viewer.layers[l], symmetric = settings(l).symmetric;
    var key = s.upper < topValue(l) ? [symmetric, s.upper, s.lo].join() : '';
    if (key === (layer.hidden || '')) return;
    layer.hidden = key;
    var img = layer.volume.img;
    if (!layer.original) layer.original = img.slice();
    var original = layer.original, out = symmetric ? 0 : s.lo - 1;
    for (var i = 0; i < img.length; i++) {
      var v = original[i];
      img[i] = key && (symmetric ? Math.abs(v) : v) > s.upper ? out : v;
    }
  }

  // The value of the layer at the voxel vox, of its image, not of what is drawn.
  function valueAt(layer, vox) {
    var drawn = layer.volume.img;
    if (layer.original) layer.volume.img = layer.original;
    var value = layer.volume.getValue(vox[0], vox[1], vox[2]);
    layer.volume.img = drawn;
    return value;
  }

  // The histogram of the nonzero values of the layer l (|v| when
  // symmetric), from 0 to the top of the sliders, log-scaled, the bins of
  // the range shown in the colours they are drawn with.
  var BINS = pageSettings.histogram_bins;
  function drawHistogram(l, s) {
    var canvas = $('threshold-histogram'), context = canvas.getContext('2d');
    var layer = viewer.layers[l], symmetric = settings(l).symmetric;
    var source = percentileSource(l), top = Math.max(layer.maxAbs, layer.max, 1e-12);
    layer.histograms = layer.histograms || {};
    var key = symmetric ? 'abs' : 'values', counts = layer.histograms[key];
    if (!counts) {
      counts = layer.histograms[key] = new Array(BINS).fill(0);
      for (var i = 0; i < source.length; i++) {
        if (source[i] < 0) continue;
        counts[Math.min(BINS - 1, Math.floor(source[i] / top * BINS))] += 1;
      }
    }
    var width = canvas.width, height = canvas.height, bar = width / BINS;
    var most = Math.log1p(Math.max.apply(null, counts)) || 1;
    var lut = viewer.luts[settings(l).cmap];
    context.clearRect(0, 0, width, height);
    counts.forEach(function (count, bin) {
      if (!count) return;
      var v = (bin + 0.5) / BINS * top, h = Math.max(1, Math.log1p(count) / most * (height - 4));
      if (s.shown(v) || s.shown(-v)) {
        var c = 3 * colourIndex(v, s);
        context.fillStyle = 'rgb(' + lut[c] + ',' + lut[c + 1] + ',' + lut[c + 2] + ')';
      } else {
        context.fillStyle = themeColour('--line');
      }
      context.fillRect(bin * bar + 0.5, height - h, Math.max(1, bar - 1), h);
    });
    context.fillStyle = themeColour('--soft');
    [s.threshold, s.upper].forEach(function (v) {
      context.fillRect(Math.round(Math.min(width - 1, v / top * width)), 0, 1, height);
    });
    canvas.dataset.bins = counts.join(' ');
    canvas.dataset.range = format(s.threshold) + ' ' + format(s.upper);
  }

  /* ---------------------------------------------------------------
   * Colour bars, read-out and controls.
   */

  function format(v) {
    if (v === 0 || !isFinite(v)) return String(v);
    if (Math.abs(v) < 1e-3 || Math.abs(v) >= 1e5) return v.toExponential(2);
    return String(Number(v.toPrecision(3)));
  }

  function round(v) { return String(Math.round(v * 100) / 100); }

  function ticksOf(s, l) {
    var ticks = settings(l).symmetric
      ? [s.lo, -s.threshold, 0, s.threshold, s.hi]
      : [s.lo, s.threshold, s.hi];
    return ticks.filter(function (t, i) {
      return t >= s.lo && t <= s.hi && ticks.indexOf(t) === i;
    });
  }

  // The colour bar of the layer l, on its canvas.
  function drawColourBar(s, l) {
    var canvas = viewer.layers[l].colorbar, context = canvas.getContext('2d');
    var lut = viewer.luts[settings(l).cmap];
    var left = 12, width = canvas.width - 2 * left, span = s.hi - s.lo;
    var xOf = function (v) { return left + (span > 0 ? (v - s.lo) / span : 1) * width; };
    context.clearRect(0, 0, canvas.width, canvas.height);
    for (var x = 0; x < width; x++) {
      var v = s.lo + span * x / Math.max(1, width - 1);
      var c = 3 * colourIndex(v, s);
      context.fillStyle = 'rgb(' + lut[c] + ',' + lut[c + 1] + ',' + lut[c + 2] + ')';
      context.fillRect(left + x, 2, 1, 16);
      if (!s.shown(v)) {  // hidden values are greyed out
        context.globalAlpha = 0.75;
        context.fillStyle = themeColour('--bg');
        context.fillRect(left + x, 2, 1, 16);
        context.globalAlpha = 1;
      }
    }
    var ticks = ticksOf(s, l).map(format);
    context.fillStyle = themeColour('--soft');
    context.font = '12px system-ui, sans-serif';
    context.textAlign = 'center';
    context.textBaseline = 'top';
    ticksOf(s, l).forEach(function (t, i) {
      var x = xOf(t), half = context.measureText(ticks[i]).width / 2 + 1;
      context.fillRect(Math.round(x), 18, 1, 5);
      // Keep the labels at the ends of the bar inside the canvas.
      var at = Math.min(Math.max(x, half), canvas.width - half);
      context.fillText(ticks[i], at, 26);
    });
    canvas.dataset.ticks = ticks.join(' ');
    canvas.style.opacity = settings(l).visible ? 1 : 0.4;
  }

  // The millimetres of the voxel ijk of the images, and its inverse.
  function toMm(ijk) {
    var a = data.affine;
    return [0, 1, 2].map(function (r) {
      return a[r][0] * ijk[0] + a[r][1] * ijk[1] + a[r][2] * ijk[2] + a[r][3];
    });
  }

  function toVoxel(mm) {
    var a = data.affine;
    var m = [[a[0][0], a[0][1], a[0][2]], [a[1][0], a[1][1], a[1][2]],
             [a[2][0], a[2][1], a[2][2]]];
    var d = [mm[0] - a[0][3], mm[1] - a[1][3], mm[2] - a[2][3]];
    var det = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) -
      m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
      m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
    // Cramer's rule, column by column.
    return [0, 1, 2].map(function (c) {
      var mc = m.map(function (row, r) {
        return row.map(function (v, k) { return k === c ? d[r] : v; });
      });
      var dc = mc[0][0] * (mc[1][1] * mc[2][2] - mc[1][2] * mc[2][1]) -
        mc[0][1] * (mc[1][0] * mc[2][2] - mc[1][2] * mc[2][0]) +
        mc[0][2] * (mc[1][0] * mc[2][1] - mc[1][1] * mc[2][0]);
      return Math.round(dc / det);
    });
  }

  function cursorMm() {
    var mm = viewer.nv.frac2mm(viewer.nv.scene.crosshairPos, 0, true);
    return [mm[0], mm[1], mm[2]];
  }

  function updateReadout() {
    if (!viewer.state) return;
    var mm = cursorMm();
    var several = viewer.layers.length > 1;
    $('mm').textContent = '(' + mm.map(round).join(', ') + ')';
    $('voxel').textContent = '(' + toVoxel(mm).join(', ') + ')';
    $('value').textContent = viewer.layers.map(function (layer) {
      var value = valueAt(layer, layer.volume.mm2vox(mm));
      value = String(Number(Number(value).toPrecision(6)));
      return several ? layer.name + ' ' + value : value;
    }).join(' · ');
    if (viewer.regions) $('region').textContent = regionAt(mm);
  }

  // The theme changed: the background of the image and the colour bars.
  function applyTheme() {
    if (!viewer.nv || !viewer.state) return;
    setBackdrop(viewer.nv);
    viewer.nv.updateGLVolume();
    viewer.layers.forEach(function (layer, l) { drawColourBar(scale(l), l); });
  }
  window.addEventListener('neurolang-theme', applyTheme);
  matchMedia('(prefers-color-scheme: light)').addEventListener(
    'change', applyTheme);

  function redraw() {
    var scales = viewer.layers.map(function (layer, l) { return scale(l); });
    scales.forEach(function (s, l) { applyLayer(l, s); });
    viewer.nv.updateGLVolume();
    scales.forEach(drawColourBar);
    drawHistogram(viewer.state.active, scales[viewer.state.active]);
    updateReadout();
    var mode = settings().thresholdMode;
    $('threshold-value').textContent =
      mode === 'percentile' ? '= ' + format(scales[viewer.state.active].threshold) +
        ' to ' + format(scales[viewer.state.active].upper) : '';
  }

  // The sliders lie over the histogram, so a position (0 to 1000) is a
  // value on its axis, from 0 to its top, in either mode.
  function sliderTop() {
    var layer = viewer.layers[viewer.state.active];
    return Math.max(layer.maxAbs, layer.max, 1e-12);
  }

  function positionOf(v) { return Math.round(1000 * v / sliderTop()); }

  // The threshold, in the unit of the mode, at the slider position p.
  function thresholdAt(p) {
    var v = sliderTop() * p / 1000;
    return settings().thresholdMode === 'percentile'
      ? rank(percentileSource(viewer.state.active), v) : v;
  }

  function syncControls() {
    var s = settings();
    $('layer').value = String(viewer.state.active);
    $('visible').checked = s.visible;
    $('threshold').value = Number(s.threshold.toPrecision(6));
    $('threshold').max = s.thresholdMode === 'percentile' ? 100 : '';
    $('threshold-slider').value = positionOf(thresholdValue(viewer.state.active));
    var upper = upperInMode();
    $('threshold-high').value = Number(upper.toPrecision(6));
    $('threshold-high').max = s.thresholdMode === 'percentile' ? 100 : '';
    $('threshold-high-slider').value = positionOf(upperValue(viewer.state.active));
    $('threshold-mode').value = s.thresholdMode;
    $('cmap').value = s.cmap;
    $('symmetric').checked = s.symmetric;
    $('opacity').value = s.opacity;
    var position = viewer.state.order.indexOf(viewer.state.active);
    $('layer-up').disabled = position === viewer.state.order.length - 1;
    $('layer-down').disabled = position === 0;
  }

  // The high threshold in the unit of the mode: the top when none is set.
  function upperInMode() {
    var s = settings();
    if (s.upper !== null && s.upper !== undefined) return s.upper;
    return s.thresholdMode === 'percentile' ? 100 : topValue(viewer.state.active);
  }

  function setThreshold(value) {
    if (isNaN(value)) return;
    var top = settings().thresholdMode === 'percentile' ? 100 : Infinity;
    settings().threshold = Math.min(Math.max(value, 0), top, upperInMode());
    syncControls();
    redraw();
  }

  // The high threshold: none (the maximum) at the top or above it.
  function setUpper(value) {
    if (isNaN(value)) return;
    var s = settings(), percent = s.thresholdMode === 'percentile';
    var top = percent ? 100 : topValue(viewer.state.active);
    s.upper = value >= top ? null : Math.max(value, s.threshold);
    syncControls();
    redraw();
  }

  // Switch between a value and a percentile, keeping the threshold.
  function setThresholdMode(mode) {
    var s = settings(), active = viewer.state.active;
    if (mode === s.thresholdMode) return;
    var value = thresholdValue(active), upper = upperValue(active);
    var hasUpper = s.upper !== null && s.upper !== undefined;
    s.thresholdMode = mode;
    s.threshold = mode === 'percentile'
      ? rank(percentileSource(active), value) : Math.max(0, value);
    if (hasUpper) {
      s.upper = mode === 'percentile' ? rank(percentileSource(active), upper) : upper;
    }
    syncControls();
    redraw();
  }

  function setOption(name, value) {
    settings()[name] = value;
    syncControls();
    redraw();
  }

  /* ---------------------------------------------------------------
   * The order the overlays are drawn in, shown from the top in the list
   * of the layers and in the colour bars.
   */

  function drawInOrder() {
    viewer.state.order.forEach(function (l, position) {
      viewer.nv.setVolume(viewer.layers[l].volume, position + 1);
    });
  }

  function listLayers() {
    var list = $('layer'), bars = $('colorbars');
    var several = viewer.layers.length > 1;
    list.innerHTML = '';
    viewer.state.order.slice().reverse().forEach(function (l) {
      var layer = viewer.layers[l];
      list.add(new Option(layer.name || 'overlay', String(l)));
      if (several) bars.appendChild(layer.label);
      bars.appendChild(layer.colorbar);
    });
  }

  // Draw the active layer over the next one (step 1) or under the
  // previous one (step -1).
  function moveLayer(step) {
    var order = viewer.state.order;
    var position = order.indexOf(viewer.state.active);
    var to = position + step;
    if (to < 0 || to >= order.length) return;
    order[position] = order[to];
    order[to] = viewer.state.active;
    drawInOrder();
    listLayers();
    syncControls();
    redraw();
  }

  function reset() {
    viewer.state = JSON.parse(JSON.stringify(data.initial));
    viewer.state.order = viewer.layers.map(function (layer, l) { return l; });
    viewer.state.display = Object.assign({}, DISPLAY, data.initial.display || {});
    drawInOrder();
    listLayers();
    syncControls();
    syncDisplayControls();
    applyDisplay();
    redraw();
  }

  // A colour bar per layer, labelled with its name when there are
  // several, and the list of the layers, shown with several.
  function setUpLayers() {
    var several = viewer.layers.length > 1;
    $('layer-control').style.display = several ? '' : 'none';
    viewer.layers.forEach(function (layer, l) {
      var canvas = l === 0 ? $('colorbar') : document.createElement('canvas');
      if (l > 0) {
        canvas.id = 'colorbar-' + l;
        canvas.width = $('colorbar').width;
        canvas.height = $('colorbar').height;
      }
      layer.colorbar = canvas;
      layer.label = document.createElement('div');
      layer.label.className = 'colorbar-name';
      layer.label.textContent = layer.name;
    });
  }

  function setUpControls() {
    var cmaps = $('cmap');
    Object.keys(viewer.luts).forEach(function (name) {
      cmaps.add(new Option(name, name));
    });
    $('layer').addEventListener('change', function (e) {
      viewer.state.active = parseInt(e.target.value, 10);
      syncControls();
      redraw();
    });
    $('layer-up').addEventListener('click', function () { moveLayer(1); });
    $('layer-down').addEventListener('click', function () { moveLayer(-1); });
    $('visible').addEventListener('change', function (e) {
      setOption('visible', e.target.checked);
    });
    var onThreshold = function (e) { setThreshold(parseFloat(e.target.value)); };
    $('threshold').addEventListener('change', onThreshold);
    $('threshold').addEventListener('input', onThreshold);
    $('threshold-slider').addEventListener('input', function (e) {
      setThreshold(thresholdAt(e.target.value));
    });
    var onUpper = function (e) { setUpper(parseFloat(e.target.value)); };
    $('threshold-high').addEventListener('change', onUpper);
    $('threshold-high').addEventListener('input', onUpper);
    $('threshold-high-slider').addEventListener('input', function (e) {
      setUpper(thresholdAt(e.target.value));
    });
    $('threshold-mode').addEventListener('change', function (e) {
      setThresholdMode(e.target.value);
    });
    $('cmap').addEventListener('change', function (e) { setOption('cmap', e.target.value); });
    $('symmetric').addEventListener('change', function (e) {
      setOption('symmetric', e.target.checked);
    });
    $('opacity').addEventListener('input', function (e) {
      setOption('opacity', parseFloat(e.target.value));
    });
    $('reset').addEventListener('click', function () {
      reset();
      moveCursor(data.initial.cursor);
    });
  }

  // Move the cursor to the voxel ijk of the images.
  function moveCursor(ijk) {
    var nv = viewer.nv;
    nv.scene.crosshairPos = nv.mm2frac(toMm(ijk), 0, true);
    nv.drawScene();
    updateReadout();
  }

  async function start() {
    if (typeof DecompressionStream === 'undefined') {
      throw new Error('This browser cannot read the page\'s data ' +
                      '(no DecompressionStream): use a recent browser.');
    }
    await load();
    setUpLayers();
    setUpControls();
    setUpDisplay();
    reset();
    moveCursor(data.initial.cursor);
  }

  window.brainViewer = {
    viewer: viewer,
    get nv() { return viewer.nv; },
    moveCursor: moveCursor,
    ready: start().catch(function (error) {
      $('message').textContent = 'The viewer failed: ' + error.message;
      throw error;
    })
  };
})();
