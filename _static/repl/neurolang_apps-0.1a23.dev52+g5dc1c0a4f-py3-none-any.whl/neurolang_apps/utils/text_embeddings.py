"""
Semantic similarity between documents and free-text queries.

Documents (for instance scientific articles identified by their PubMed
id) are embedded once with a SPECTER2 document adapter and cached on
disk.  A free-text query is embedded with the SPECTER2 ad-hoc query
adapter and compared to every document by cosine similarity.

The similarities are exposed to NeuroLang as a function built by
:func:`make_similarity_function`, ``query_similarity(query, doc)``, which
returns the similarity of a document to a query text and is used in a
rule as ``study(d) & (sim == query_similarity("visual word form", d))``.

Nothing in this module is specific to a dataset.  Texts come from PubMed
(:func:`fetch_pubmed_abstracts`) or from a CSV/TSV table
(:func:`load_text_table`).  ``torch``, ``transformers`` and ``adapters``
are only imported when the first document or query is embedded; install
them with ``pip install "neurolang[embeddings]"``. Queries are embedded
by the numpy encoder of :mod:`.specter2_numpy` when its weights are
exported next to the model (:attr:`Specter2Encoder.numpy_path`), or
without torch, as in a browser, the documents having been embedded
beforehand; :data:`fetch_missing` can fetch both when first needed.

Engines declared in ``engines.yaml`` can opt in through a
``text_embeddings`` section.  Embeddings are computed on the first query
that needs them, or ahead of time with::

    python -m neurolang.utils.text_embeddings -e neurosynth -d neurolang_data
"""

import argparse
import hashlib
import json
import logging
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import weakref
import xml.etree.ElementTree as ET
from functools import lru_cache
from pathlib import Path
from types import MappingProxyType

import numpy as np

LOG = logging.getLogger(__name__)

EFETCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
EMAIL_ENV = "NEUROLANG_ENTREZ_EMAIL"
API_KEY_ENV = "NCBI_API_KEY"
INSTALL_HINT = 'pip install "neurolang[embeddings]"'

# The files of a model or adapter repository the encoder loads: its
# configuration, tokenizer and PyTorch weights.
MODEL_FILES = ("*.json", "*.txt", "*.bin")

# Written in a local copy of a repository once it is complete.
COMPLETE_MARKER = ".complete"

# Called with the path of a file the embeddings need and that is missing,
# to fetch it: in a browser, from the site of the page. None: no fetching.
fetch_missing = None


def _ensure(path):
    """Fetch the file *path* with :data:`fetch_missing` if it is missing."""
    if fetch_missing is not None and not Path(path).exists():
        fetch_missing(Path(path))


# Where torch cannot be installed, the missing query model is that of the
# page the REPL runs in.
_MISSING_MODEL = {
    "emscripten": (
        "query_similarity needs the text embeddings, and this page was "
        "built without them: its bundle has them when built with torch, or "
        "from a directory of embeddings (see neurolang-repl-serve --help)."
    ),
}


def _torch_available():
    """Whether torch can be imported."""
    try:
        import torch  # noqa: F401
    except ImportError:
        return False
    return True


def _cause(error):
    """The import error *error* as ``" (ImportError: ...)"``, for a message."""
    return f" ({type(error).__name__}: {error})"


# ---------------------------------------------------------------------------
# Text sources
# ---------------------------------------------------------------------------


def fetch_pubmed_abstracts(
    pmids, cache_path=None, email=None, api_key=None, batch_size=200
):
    """
    Return the title and abstract of PubMed articles.

    Records are downloaded with the NCBI E-utilities ``efetch`` endpoint
    and stored in a JSON cache, so that only the ids missing from the
    cache are requested.  Requests are rate limited to 3 per second, or
    10 per second when an NCBI API key is given.

    Parameters
    ----------
    pmids : iterable
        PubMed ids; each is converted with ``str``.
    cache_path : str or Path, optional
        JSON file holding the records already downloaded.
    email : str, optional
        Contact e-mail sent to NCBI, defaults to the
        ``NEUROLANG_ENTREZ_EMAIL`` environment variable.  NCBI asks for
        it but does not require it.
    api_key : str, optional
        NCBI API key, defaults to the ``NCBI_API_KEY`` environment
        variable.
    batch_size : int, optional
        Number of ids per request.

    Returns
    -------
    dict
        Maps each id, as a string, to a ``(title, abstract)`` pair.  Both
        are empty strings when PubMed has no record for the id, and the
        abstract is empty when the article has none.

    """
    pmids = list(dict.fromkeys(str(p) for p in pmids))
    records = _read_json(cache_path)
    missing = [p for p in pmids if p not in records]
    email = email or os.environ.get(EMAIL_ENV)
    api_key = api_key or os.environ.get(API_KEY_ENV)
    interval = 0.1 if api_key else 0.34
    for start in range(0, len(missing), batch_size):
        batch = missing[start:start + batch_size]
        LOG.info("PubMed: fetching %d/%d", start + len(batch), len(missing))
        fetched = _efetch(batch, email, api_key)
        records.update({p: fetched.get(p, ("", "")) for p in batch})
        _write_json(cache_path, records)
        time.sleep(interval)
    return {p: tuple(records[p]) for p in pmids}


def _efetch(pmids, email, api_key):
    params = {
        "db": "pubmed",
        "retmode": "xml",
        "tool": "neurolang",
        "id": ",".join(pmids),
    }
    if email:
        params["email"] = email
    if api_key:
        params["api_key"] = api_key
    data = urllib.parse.urlencode(params).encode()
    return parse_pubmed_xml(_post(EFETCH_URL, data))


def _post(url, data, retries=3):
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(url, data=data, timeout=120) as res:
                return res.read()
        except (urllib.error.URLError, TimeoutError):
            if attempt == retries - 1:
                raise
            time.sleep(2 ** attempt)


def parse_pubmed_xml(xml):
    """
    Extract titles and abstracts from a PubMed ``efetch`` XML answer.

    Parameters
    ----------
    xml : bytes or str
        ``PubmedArticleSet`` document.

    Returns
    -------
    dict
        Maps each PMID to a ``(title, abstract)`` pair.  Structured
        abstracts have their sections joined with spaces.

    """
    records = {}
    for article in ET.fromstring(xml).iter("PubmedArticle"):
        citation = article.find("MedlineCitation")
        title = citation.find("Article/ArticleTitle")
        sections = citation.findall("Article/Abstract/AbstractText")
        records[citation.findtext("PMID")] = (
            _text(title),
            " ".join(_text(s) for s in sections),
        )
    return records


def _text(element):
    if element is None:
        return ""
    return "".join(element.itertext()).strip()


def _read_json(path):
    if path is None or not Path(path).exists():
        return {}
    with open(path) as f:
        return json.load(f)


def _write_json(path, records):
    if path is None:
        return
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w") as f:
        json.dump(records, f)
    os.replace(tmp, path)


def load_text_table(path, id_column="id", text_columns=("title", "abstract")):
    """
    Read document texts from a CSV or TSV file.

    Parameters
    ----------
    path : str or Path
        Table with one row per document; ``.tsv`` and ``.tsv.gz`` files
        are tab separated, any other file comma separated.
    id_column : str, optional
        Column holding the document ids.
    text_columns : sequence of str, optional
        The first column is used as the title, the others are joined into
        the body text.

    Returns
    -------
    dict
        Maps each id, as a string, to a ``(title, text)`` pair.

    """
    import pandas as pd

    sep = "\t" if ".tsv" in Path(path).name.lower() else ","
    columns = [id_column, *text_columns]
    df = pd.read_csv(path, sep=sep, usecols=columns, dtype=str)
    df = df.fillna("")
    title, *body = text_columns
    return {
        row[id_column]: (row[title], " ".join(row[c] for c in body).strip())
        for _, row in df.iterrows()
    }


# ---------------------------------------------------------------------------
# Encoder
# ---------------------------------------------------------------------------


class Specter2Encoder:

    """
    Embed documents and queries with SPECTER2.

    The base model and both adapters are loaded on the first call to
    :meth:`encode_documents` or :meth:`encode_query` (which embeds with
    numpy instead when its weights are there, see :meth:`_uses_numpy`).  With a *model_dir*
    they are downloaded once into it (see :meth:`download`) and then
    loaded from there without network; otherwise they come from the
    Hugging Face hub and its cache.  A document is encoded as
    ``title [SEP] abstract`` with the document adapter, a query with the
    query adapter; the embedding is the first ([CLS]) token of the last
    hidden layer.

    Parameters
    ----------
    model : str, optional
        Base model name.
    document_adapter : str, optional
        Adapter used for documents.
    query_adapter : str, optional
        Adapter used for short free-text queries.
    batch_size : int, optional
        Number of documents per forward pass.
    device : str, optional
        Torch device; by default CUDA, then MPS, then CPU.
    model_dir : str or Path, optional
        Directory holding local copies of the model and the adapters.

    """

    def __init__(
        self,
        model="allenai/specter2_base",
        document_adapter="allenai/specter2",
        query_adapter="allenai/specter2_adhoc_query",
        batch_size=16,
        device=None,
        model_dir=None,
    ):
        """Store the configuration; the model is loaded on first use."""
        self.model_name = model
        self.document_adapter = document_adapter
        self.query_adapter = query_adapter
        self.batch_size = batch_size
        self.device = device
        self.model_dir = None if model_dir is None else Path(model_dir)
        self._model = None
        self._numpy = None
        _ENCODERS.add(self)

    @property
    def cache_key(self):
        """Identify the document embeddings this encoder produces."""
        return json.dumps(
            [self.model_name, self.document_adapter, self.query_adapter]
        )

    @property
    def numpy_path(self):
        """
        The model with the query adapter for :mod:`.specter2_numpy`, which
        embeds queries without torch: next to the local copies of the
        model, None without them.
        """
        if self.model_dir is None:
            return None
        names = (self.model_name, self.query_adapter)
        return self.model_dir / (
            "+".join(n.replace("/", "--") for n in names) + ".npz"
        )

    def download(self):
        """
        Download the model and the adapters into ``model_dir``, once.

        Returns
        -------
        tuple
            Paths of the local copies of the model, the document adapter
            and the query adapter; their names on the hub without a
            ``model_dir``.

        """
        repos = (self.model_name, self.document_adapter, self.query_adapter)
        if self.model_dir is None:
            return repos
        return tuple(local_model(repo, self.model_dir) for repo in repos)

    def _load(self):
        if self._model is not None:
            return
        if self.cache_key in _MODELS:  # an engine built again
            loaded = _MODELS[self.cache_key]
            self._torch, self._tokenizer, self._model = loaded
            self.device = self._model.device.type
            return
        try:
            import torch
            from adapters import AutoAdapterModel
            from transformers import AutoTokenizer
        except ImportError as e:
            raise ImportError(
                f"Text embeddings need torch, transformers and adapters: "
                f"{INSTALL_HINT}{_cause(e)}"
            ) from e
        self._torch = torch
        self.device = self.device or _default_device(torch)
        base, document, query = self.download()
        # Local copies are directories: no hub source, no network.
        source = None if self.model_dir is not None else "hf"
        self._tokenizer = AutoTokenizer.from_pretrained(base)
        model = AutoAdapterModel.from_pretrained(base)
        model.load_adapter(str(document), source=source, load_as="document")
        model.load_adapter(str(query), source=source, load_as="query")
        self._model = model.to(self.device).eval()
        _MODELS[self.cache_key] = (torch, self._tokenizer, self._model)
        LOG.info("Loaded %s on %s", self.model_name, self.device)

    def _has_local_copies(self):
        """Whether the model and adapters are complete in ``model_dir``."""
        repos = (self.model_name, self.document_adapter, self.query_adapter)
        return self.model_dir is not None and all(
            (self.model_dir / repo.replace("/", "--") / COMPLETE_MARKER).exists()
            for repo in repos
        )

    def _fork_safe(self):
        """
        Load the model, on the CPU, ahead of a fork: the numpy query
        encoder if it embeds the queries (see :meth:`_uses_numpy`).

        On macOS a forked child, as the query assistant checks queries in,
        is aborted when it loads a model with transformers or uses MPS
        (nor can one use CUDA anywhere); it can run a model its parent
        loaded on the CPU.
        """
        if self._uses_numpy():
            if self._numpy is None:
                self._numpy_query("brain")  # loads its weights
            return
        if self._model is None and not self._has_local_copies():
            return      # loading would download: leave it to the child
        self._load()
        if self.device != "cpu":
            self._model = self._model.to("cpu")
            self.device = "cpu"

    def encode_documents(self, titles, texts):
        """
        Embed documents given their titles and body texts.

        Returns
        -------
        numpy.ndarray
            One row per document.

        """
        self._load()
        sep = self._tokenizer.sep_token
        docs = [t + sep + (a or "") for t, a in zip(titles, texts)]
        return self._encode(docs, "document")

    def _uses_numpy(self):
        """Whether queries are embedded with numpy: when its weights are
        at :attr:`numpy_path` (it loads faster and takes less memory than
        torch, and starts no thread), or torch is not installed."""
        path = self.numpy_path
        return self._numpy is not None or (
            path is not None and path.exists()) or not _torch_available()

    def encode_query(self, text):
        """
        Embed a free-text query as a vector, with numpy if
        :meth:`_uses_numpy`, otherwise with torch.
        """
        if self._uses_numpy():
            return self._numpy_query(text)
        self._load()
        return self._encode([text], "query")[0]

    def _numpy_query(self, text):
        if self._numpy is None:
            path = self.numpy_path
            if path is not None:
                _ensure(path)
            if path is None or not path.exists():
                try:
                    import torch  # noqa: F401
                    cause = ""
                except ImportError as e:
                    cause = _cause(e)
                raise ImportError(_MISSING_MODEL.get(
                    sys.platform,
                    "Text embeddings need torch, transformers and adapters: "
                    f"{INSTALL_HINT}{cause}",
                ))
            from .specter2_numpy import load
            self._numpy = load(path)
        tokenizer, encoder = self._numpy
        return np.asarray(encoder(tokenizer.ids(text)), dtype=float)

    def _encode(self, texts, adapter):
        self._model.set_active_adapters(adapter)
        # Batching texts of similar length reduces padding.
        order = np.argsort([len(t) for t in texts], kind="stable")
        out = np.empty((len(texts), self._model.config.hidden_size))
        with self._torch.inference_mode():
            for start in range(0, len(texts), self.batch_size):
                rows = order[start:start + self.batch_size]
                out[rows] = self._embed_batch([texts[i] for i in rows])
                if len(texts) > self.batch_size:
                    LOG.info("Embedded %d/%d", start + len(rows), len(texts))
        return out

    def _embed_batch(self, texts):
        inputs = self._tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=512,
            return_tensors="pt",
            return_token_type_ids=False,
        ).to(self._model.device)  # moved by another encoder sharing it
        hidden = self._model(**inputs).last_hidden_state
        return hidden[:, 0, :].float().cpu().numpy()


# The SPECTER2 encoders of the process (see prepare_for_fork).
_ENCODERS = weakref.WeakSet()

# The models loaded, by cache_key: the encoders of an engine built again
# share them.
_MODELS = {}


def prepare_for_fork():
    """
    Make the encoders usable in a child process forked next.

    On macOS a forked child cannot load a model nor use MPS: load them,
    on the CPU, beforehand (see ``Specter2Encoder._fork_safe``). Called
    by the query assistant before it forks to check a query; elsewhere
    the child loads the model itself.
    """
    if sys.platform != "darwin":
        return
    for encoder in list(_ENCODERS):
        try:
            encoder._fork_safe()
        except Exception:  # noqa: BLE001 -- a fork must not fail for it
            LOG.debug("Encoder not prepared for fork", exc_info=True)


def preload(nl):
    """
    Load the document embeddings and the query model of the engine *nl*
    (the numpy one if there, else torch's on the CPU), for the processes forked from this one to share them,
    rather than each load them on its first query (the REPL server's
    sessions). What cannot be loaded (torch is missing, the model is not
    in ``model_dir``) is left to the first query, and logged.
    """
    for name, index in getattr(nl, "text_embedding_indexes", {}).items():
        try:
            index.build()
            if not index.encoder._uses_numpy():
                index.encoder.download()  # the copies _fork_safe loads
            index.encoder._fork_safe()
        except Exception as error:  # noqa: BLE001 -- loaded on first use
            LOG.warning("The text embeddings %s are not preloaded: %s: %s",
                        name, type(error).__name__, error)


def _after_fork_in_child():
    """
    Run torch on one thread in a forked child: the OpenMP pool of its
    intra-op parallelism does not survive a fork, and a child using it
    hangs.
    """
    torch = sys.modules.get("torch")
    if torch is not None:
        torch.set_num_threads(1)


if hasattr(os, "register_at_fork"):
    os.register_at_fork(after_in_child=_after_fork_in_child)


def local_model(repo_id, model_dir):
    """
    Return a local copy of the Hugging Face repository *repo_id*.

    The copy is ``model_dir/<owner>--<name>``.  It is downloaded on the
    first call, then marked complete; later calls return it without
    contacting the hub, so the model works offline.  An interrupted
    download is resumed on the next call.
    """
    path = Path(model_dir) / repo_id.replace("/", "--")
    if (path / COMPLETE_MARKER).exists():
        return path
    try:
        from huggingface_hub import snapshot_download
    except ImportError as e:
        raise ImportError(
            f"Downloading {repo_id} needs huggingface_hub: {INSTALL_HINT}"
        ) from e
    LOG.info("Downloading %s to %s", repo_id, path)
    snapshot_download(
        repo_id, local_dir=path, allow_patterns=list(MODEL_FILES)
    )
    (path / COMPLETE_MARKER).touch()
    return path


def _default_device(torch):
    if torch.cuda.is_available():
        return "cuda"
    if torch.backends.mps.is_available():
        return "mps"
    return "cpu"


# ---------------------------------------------------------------------------
# Index
# ---------------------------------------------------------------------------


class EmbeddingIndex:

    """
    Cached document embeddings with cosine similarity to queries.

    The embedding matrix is computed on first use (or by :meth:`build`)
    and saved as ``.npz``.  The cache is reused only if it was built with
    the same encoder and the same document ids, in any order: the ids are
    kept sorted.

    Parameters
    ----------
    ids : iterable
        Document ids, as stored in the NeuroLang relation.
    load_texts : callable
        ``load_texts(keys)`` returns a mapping from ``str(id)`` to a
        ``(title, text)`` pair; documents missing from it, or with an
        empty title and text, get a zero embedding (similarity 0).
    encoder : object
        Has ``encode_documents(titles, texts)``, ``encode_query(text)``
        and a ``cache_key`` string, e.g. :class:`Specter2Encoder`.
    cache_path : str or Path, optional
        ``.npz`` file holding the embeddings.

    """

    def __init__(self, ids, load_texts, encoder, cache_path=None):
        """Store the ids; embeddings are computed on first use."""
        self.ids = sorted(set(ids))
        self._load_texts = load_texts
        self.encoder = encoder
        self.cache_path = None if cache_path is None else Path(cache_path)
        self._matrix = None
        self._positions = None
        # Per-index caches, which live and die with the index: the
        # similarities to the 16 most recent queries, and the embeddings
        # of the 4096 most recent query texts (3 kB each), so that a rule
        # over many texts, whose rows come in any order, embeds each once.
        self.similarities = lru_cache(maxsize=16)(self._similarities)
        self.query_vector = lru_cache(maxsize=4096)(self._query_vector)

    @property
    def cache_key(self):
        """Hash of the encoder and of the document ids."""
        digest = hashlib.sha256(self.encoder.cache_key.encode())
        for d in self.ids:
            digest.update(str(d).encode() + b"\0")
        return digest.hexdigest()

    @property
    def matrix(self):
        """L2-normalised embeddings, one row per document id."""
        if self._matrix is None:
            self._matrix = self._read_cache()
        if self._matrix is None:
            self._matrix = self._embed()
            self._write_cache()
        return self._matrix

    def build(self):
        """Compute, or load from the cache, the document embeddings."""
        return self.matrix

    def _embed(self):
        keys = [str(d) for d in self.ids]
        start = time.perf_counter()
        texts = self._load_texts(keys)
        pairs = [texts.get(k, ("", "")) for k in keys]
        has_text = np.array([bool(t or a) for t, a in pairs])
        LOG.info(
            "Loaded texts in %.1fs: %d documents, %d without abstract, "
            "%d without any text",
            time.perf_counter() - start,
            len(keys),
            sum(not a for _, a in pairs),
            int((~has_text).sum()),
        )
        if not has_text.any():
            raise ValueError("None of the documents has a title or text")
        start = time.perf_counter()
        titles, bodies = zip(*(p for p, h in zip(pairs, has_text) if h))
        embedded = _normalise(self.encoder.encode_documents(titles, bodies))
        matrix = np.zeros((len(keys), embedded.shape[1]), dtype=np.float32)
        matrix[has_text] = embedded
        LOG.info("Embedded documents in %.1fs", time.perf_counter() - start)
        return matrix

    def _read_cache(self):
        if self.cache_path is not None:
            _ensure(self.cache_path)
        if self.cache_path is None or not self.cache_path.exists():
            return None
        if cached_key(self.cache_path) != self.cache_key:
            LOG.info("Embedding cache %s is stale", self.cache_path)
            return None
        with np.load(self.cache_path) as data:
            return data["matrix"]

    def _write_cache(self):
        if self.cache_path is None:
            return
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.cache_path.with_suffix(".tmp.npz")
        np.savez(tmp, key=np.array(self.cache_key), matrix=self._matrix)
        os.replace(tmp, self.cache_path)

    def _query_vector(self, query):
        return _normalise(self.encoder.encode_query(query)[None])[0]

    def scores(self, query):
        """Cosine similarity of each document, in ``ids`` order, to a query."""
        return self.matrix @ self.query_vector(query)

    def similarity(self, query, doc):
        """Cosine similarity of the document *doc* to a query, ``nan`` if
        *doc* is not in the index."""
        if self._positions is None:
            self._positions = {d: i for i, d in enumerate(self.ids)}
        i = self._positions.get(doc)
        if i is None:
            return float("nan")
        return float(self.matrix[i] @ self.query_vector(query))

    def _similarities(self, query):
        # Read-only mapping from document id to similarity, so that the
        # cached value cannot be modified by a caller.
        scores = self.scores(query).tolist()
        return MappingProxyType(dict(zip(self.ids, scores)))


def cached_key(path):
    """The :attr:`EmbeddingIndex.cache_key` of the embeddings in *path*."""
    with np.load(path) as data:
        return str(data["key"])


def _normalise(matrix):
    matrix = np.asarray(matrix, dtype=np.float32)
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    return matrix / np.where(norms == 0, 1, norms)


# ---------------------------------------------------------------------------
# NeuroLang integration
# ---------------------------------------------------------------------------


def make_similarity_function(index, id_type=None):
    """
    Build a NeuroLang function ``f(query, doc) -> similarity``.

    The embedding of a query text is computed once and cached by
    :meth:`EmbeddingIndex.query_vector`, so each call is a dot product.

    Parameters
    ----------
    index : EmbeddingIndex
        Index holding the documents.
    id_type : type, optional
        Type of the document ids, by default the type of the first id.

    Returns
    -------
    callable
        ``f(query: str, doc: id_type) -> float``, the cosine similarity
        between the query text and the document, or ``nan`` if ``doc``
        is not in the index.  Use it in a rule as
        ``study(d) & (sim == f("query text", d))``; the query can also be
        a variable bound by a calling rule.

    """
    if id_type is None:
        id_type = type(index.ids[0]) if index.ids else str

    def query_similarity(query, doc):
        if not isinstance(query, str):
            raise TypeError(
                f"query_similarity(query, doc) takes the query text first: "
                f"got {query!r} as the query"
            )
        return index.similarity(query, doc)

    query_similarity.__annotations__ = {
        "query": str, "doc": id_type, "return": float
    }
    return query_similarity


def main(argv=None):
    """
    Download the models and compute the text embeddings of an engine.

    Afterwards, queries embed their texts without network.
    """
    from neurolang_apps.utils.engine_registry import build_engine

    parser = argparse.ArgumentParser(
        prog="python -m neurolang.utils.text_embeddings",
        description=main.__doc__,
    )
    parser.add_argument("--engine", "-e", default="neurosynth")
    parser.add_argument("--data-dir", "-d", default="neurolang_data")
    parser.add_argument("--yaml", default=None, help="Engine YAML file.")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    nl = build_engine(
        args.engine,
        Path(args.data_dir),
        yaml_path=None if args.yaml is None else Path(args.yaml),
    )
    for name, index in getattr(nl, "text_embedding_indexes", {}).items():
        # The model is needed by every new query text, even when the
        # document embeddings are already cached.
        index.encoder.download()
        start = time.perf_counter()
        matrix = index.build()
        print(
            f"{name}: {matrix.shape[0]} documents, dimension "
            f"{matrix.shape[1]}, {time.perf_counter() - start:.1f}s, "
            f"cache {index.cache_path}"
        )


if __name__ == "__main__":
    main()
