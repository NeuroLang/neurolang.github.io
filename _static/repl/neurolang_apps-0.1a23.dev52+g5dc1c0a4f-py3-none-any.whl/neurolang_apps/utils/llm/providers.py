"""
Chat clients of the LLM providers.

A client speaks either the OpenAI chat completions API or the Anthropic
messages API with httpx, or runs a local command (e.g. ``claude -p``)
that reads the conversation on its standard input. The conversation is
kept in a provider-neutral form, a list of messages::

    {"role": "system" | "user" | "assistant", "content": str}
    {"role": "assistant", "content": str, "tool_calls": [ToolCall, ...]}
    {"role": "tool", "tool_call_id": str, "name": str, "content": str}

and tools are described as ``{"name", "description", "parameters"}``,
*parameters* being a JSON schema. Each client translates both into the
format of its API.
"""

import json
import subprocess
import sys
import time
from dataclasses import dataclass, field
from typing import Optional

import httpx

from .config import ProviderConfig

ANTHROPIC_VERSION = "2023-06-01"


class LLMError(Exception):
    """Raised when a provider cannot be reached or gives a bad reply."""


@dataclass
class ToolCall:
    """A call of the tool *name* with *arguments*, identified by *id*."""

    id: str
    name: str
    arguments: dict


@dataclass
class Reply:
    """The reply of a model: its text, tool calls and token usage."""

    text: str = ""
    tool_calls: list = field(default_factory=list)
    usage: dict = field(default_factory=dict)
    # The content blocks of an Anthropic reply, sent back as they are:
    # its thinking blocks must stay with its tool calls.
    blocks: list = field(default_factory=list)


def _parse_arguments(arguments) -> dict:
    """Return the tool call *arguments*, a JSON string or a mapping."""
    if isinstance(arguments, dict):
        return arguments
    try:
        parsed = json.loads(arguments or "{}")
    except json.JSONDecodeError:
        return {"_invalid": arguments}
    return parsed if isinstance(parsed, dict) else {"_invalid": arguments}


# Rate limits and transient server errors are retried, waiting as the
# server asks (Retry-After) or longer and longer.
RETRY_STATUSES = frozenset({429, 500, 502, 503, 504})
HTTP_ATTEMPTS = 6
MAX_RETRY_SECONDS = 60.0


def _retry_delay(response, attempt: int) -> float:
    """Return the seconds to wait before retrying after *response*."""
    try:
        delay = float(response.headers.get("retry-after", ""))
    except ValueError:
        delay = 2.0 * 2 ** attempt
    return min(max(delay, 1.0), MAX_RETRY_SECONDS)


class ChatClient:
    """
    Base of the chat clients: HTTP session, errors and request loop.

    Subclasses define the path of the API, its payload and the parsing
    of its replies. *transport* replaces the network, e.g. by an
    ``httpx.MockTransport`` in tests.
    """

    path = ""

    def __init__(
        self, provider: ProviderConfig, timeout: float = 60.0,
        transport: Optional[httpx.BaseTransport] = None,
    ):
        self.provider = provider
        self._last_request = None
        self._http = httpx.Client(
            base_url=provider.base_url,
            headers={**self._auth_headers(), **provider.headers},
            timeout=timeout,
            transport=transport,
        )

    def _auth_headers(self) -> dict:
        """Return the headers authenticating the requests."""
        raise NotImplementedError

    def _payload(self, messages, tools, temperature) -> dict:
        """Return the JSON body of a request."""
        raise NotImplementedError

    def _reply(self, data: dict) -> Reply:
        """Return the reply in the JSON body *data* of a response."""
        raise NotImplementedError

    def complete(
        self, messages: list, tools: Optional[list] = None,
        temperature: float = 0.0,
    ) -> Reply:
        """Return the model's reply to the conversation *messages*."""
        name = self.provider.name
        payload = self._payload(messages, tools, temperature)
        for attempt in range(HTTP_ATTEMPTS):
            self._pace()
            try:
                response = self._http.post(self.path, json=payload)
            except httpx.TimeoutException as exc:
                raise LLMError(f"{name}: the request timed out.") from exc
            except httpx.HTTPError as exc:
                raise LLMError(
                    f"{name}: cannot reach the API ({exc})."
                ) from exc
            if (
                response.status_code not in RETRY_STATUSES
                or attempt == HTTP_ATTEMPTS - 1
            ):
                break
            time.sleep(_retry_delay(response, attempt))
        if response.status_code >= 400:
            raise LLMError(
                f"{name}: HTTP {response.status_code}: "
                f"{response.text.strip()[:300]}"
            )
        try:
            return self._reply(response.json())
        except (ValueError, KeyError, IndexError, TypeError) as exc:
            raise LLMError(
                f"{name}: unexpected reply: {response.text.strip()[:300]}"
            ) from exc

    def _pace(self) -> None:
        """Wait so as to keep to the provider's requests per minute."""
        rate = self.provider.requests_per_minute
        if rate and self._last_request is not None:
            wait = 60.0 / rate - (time.monotonic() - self._last_request)
            if wait > 0:
                time.sleep(wait)
        self._last_request = time.monotonic()

    def close(self) -> None:
        """Close the HTTP session."""
        self._http.close()


class OpenAIChatClient(ChatClient):
    """Client of the OpenAI chat completions API and its look-alikes."""

    path = "chat/completions"

    def _auth_headers(self) -> dict:
        key = self.provider.api_key()
        return {"Authorization": f"Bearer {key}"} if key else {}

    @staticmethod
    def _message(message: dict) -> dict:
        """Return *message* in the format of the API."""
        if message["role"] == "tool":
            return {
                "role": "tool",
                "tool_call_id": message["tool_call_id"],
                "content": message["content"],
            }
        if message.get("tool_calls"):
            return {
                "role": "assistant",
                "content": message.get("content") or None,
                "tool_calls": [
                    {
                        "id": call.id, "type": "function",
                        "function": {
                            "name": call.name,
                            "arguments": json.dumps(call.arguments),
                        },
                    }
                    for call in message["tool_calls"]
                ],
            }
        return {"role": message["role"], "content": message["content"]}

    def _payload(self, messages, tools, temperature) -> dict:
        payload = {
            "model": self.provider.model,
            "messages": [self._message(m) for m in messages],
            "temperature": temperature,
            "max_tokens": self.provider.max_tokens,
        }
        if tools:
            payload["tools"] = [
                {"type": "function", "function": tool} for tool in tools
            ]
        # OpenRouter caches the prompts of Claude only when asked to (it
        # caches those of OpenAI, DeepSeek and others by itself); other
        # look-alikes of the API may reject the field.
        if self.provider.model.startswith("anthropic/"):
            payload["cache_control"] = CACHED
        return payload

    def _reply(self, data: dict) -> Reply:
        message = data["choices"][0]["message"]
        calls = [
            ToolCall(
                call.get("id") or f"call_{i}",
                call["function"]["name"],
                _parse_arguments(call["function"].get("arguments")),
            )
            for i, call in enumerate(message.get("tool_calls") or [])
        ]
        usage = data.get("usage") or {}
        return Reply(
            message.get("content") or "", calls,
            {
                "input": usage.get("prompt_tokens", 0),
                "output": usage.get("completion_tokens", 0),
                # Of the input, the tokens read from the cache.
                "cached": (usage.get("prompt_tokens_details") or {}).get(
                    "cached_tokens"
                ) or 0,
            },
        )


# Prompt caching of the Anthropic API: each request marks the end of
# the system prompt and of the conversation, so that the next request
# of the assistant, which repeats them, reads them from the cache (at a
# tenth of the price of input tokens, or less) instead of sending them
# again. The cache lasts five minutes from its last use.
CACHED = {"type": "ephemeral"}


def _cached(messages: list) -> list:
    """
    Return *messages* with a cache mark on the last block of the last,
    a user message (the blocks of a reply, thinking blocks among them,
    go back unchanged).
    """
    if not messages or messages[-1]["role"] != "user":
        return messages
    last = messages[-1]
    content = last["content"]
    if isinstance(content, str):
        content = [{"type": "text", "text": content}]
    if not content:
        return messages
    content = [*content[:-1], {**content[-1], "cache_control": CACHED}]
    return [*messages[:-1], {**last, "content": content}]


class AnthropicChatClient(ChatClient):
    """Client of the Anthropic messages API."""

    path = "messages"

    def _auth_headers(self) -> dict:
        headers = {"anthropic-version": ANTHROPIC_VERSION}
        key = self.provider.api_key()
        if key:
            headers["x-api-key"] = key
        return headers

    @staticmethod
    def _messages(messages) -> list:
        """
        Return the non-system *messages* in the format of the API.

        Tool results are sent in a user message, those of consecutive
        tool messages in the same one.
        """
        converted = []
        for message in messages:
            role = message["role"]
            if role == "system":
                continue
            if role == "tool":
                block = {
                    "type": "tool_result",
                    "tool_use_id": message["tool_call_id"],
                    "content": message["content"],
                }
                previous = converted[-1] if converted else None
                if previous and previous.get("_tool_results"):
                    previous["content"].append(block)
                else:
                    converted.append(
                        {"role": "user", "content": [block],
                         "_tool_results": True}
                    )
                continue
            if role == "assistant" and message.get("blocks"):
                converted.append(
                    {"role": "assistant", "content": message["blocks"]}
                )
                continue
            if role == "assistant" and message.get("tool_calls"):
                content = []
                if message.get("content"):
                    content.append(
                        {"type": "text", "text": message["content"]}
                    )
                content.extend(
                    {
                        "type": "tool_use", "id": call.id,
                        "name": call.name, "input": call.arguments,
                    }
                    for call in message["tool_calls"]
                )
                converted.append({"role": "assistant", "content": content})
                continue
            converted.append({"role": role, "content": message["content"]})
        for message in converted:
            message.pop("_tool_results", None)
        return converted

    def _payload(self, messages, tools, temperature) -> dict:
        system = "\n\n".join(
            m["content"] for m in messages if m["role"] == "system"
        )
        # No temperature: current Claude models reject sampling parameters.
        payload = {
            "model": self.provider.model,
            "messages": _cached(self._messages(messages)),
            "max_tokens": self.provider.max_tokens,
        }
        if system:
            payload["system"] = [
                {"type": "text", "text": system, "cache_control": CACHED}
            ]
        if tools:
            payload["tools"] = [
                {
                    "name": tool["name"],
                    "description": tool["description"],
                    "input_schema": tool["parameters"],
                }
                for tool in tools
            ]
        return payload

    def _reply(self, data: dict) -> Reply:
        text, calls = [], []
        for block in data["content"]:
            if block["type"] == "text":
                text.append(block["text"])
            elif block["type"] == "tool_use":
                calls.append(
                    ToolCall(
                        block["id"], block["name"],
                        _parse_arguments(block.get("input")),
                    )
                )
        usage = data.get("usage") or {}
        return Reply(
            "".join(text), calls,
            {
                # Tokens read from or written to the cache are sent too.
                "input": usage.get("input_tokens", 0)
                + (usage.get("cache_read_input_tokens") or 0)
                + (usage.get("cache_creation_input_tokens") or 0),
                "output": usage.get("output_tokens", 0),
                # Of the input, the tokens read from the cache.
                "cached": usage.get("cache_read_input_tokens") or 0,
            },
            data["content"],
        )


SYSTEM_PLACEHOLDER = "{system}"
COMMAND_ATTEMPTS = 3
COMMAND_RETRY_SECONDS = 5


def render_conversation(messages, with_system: bool) -> str:
    """
    Return the conversation *messages* as plain text, for a command.

    The system prompt comes first when *with_system* is set; the turns
    follow, headed ``USER:`` and ``ASSISTANT:``, and the text ends by
    asking for the next assistant turn.
    """
    parts = []
    turns = [m for m in messages if m["role"] != "system"]
    if with_system:
        parts.extend(m["content"] for m in messages if m["role"] == "system")
    if len(turns) == 1:
        parts.append(turns[0]["content"])
        return "\n\n".join(parts)
    for message in turns:
        role = "ASSISTANT" if message["role"] == "assistant" else "USER"
        parts.append(f"{role}:\n{message['content']}")
    parts.append(
        "Write only the next ASSISTANT message, without the ASSISTANT: "
        "header."
    )
    return "\n\n".join(parts)


class CommandChatClient:
    """
    Client running a local command for each request.

    The conversation is written as text on the standard input of the
    provider's *command* (see :func:`render_conversation`) and its
    standard output is the reply. ``{system}`` in the arguments of the
    command is replaced by the system prompt, which is otherwise written
    first on its input. Only the text tool calling protocol is possible.
    """

    def __init__(self, provider: ProviderConfig, timeout: float = 60.0,
                 transport=None):
        self.provider = provider
        self.timeout = timeout

    def complete(
        self, messages: list, tools: Optional[list] = None,
        temperature: float = 0.0,
    ) -> Reply:
        """Return the command's reply to the conversation *messages*."""
        system = "\n\n".join(
            m["content"] for m in messages if m["role"] == "system"
        )
        command = self.provider.command
        placeholder = any(SYSTEM_PLACEHOLDER in arg for arg in command)
        args = [
            arg.replace(SYSTEM_PLACEHOLDER, system)
            for arg in self.provider.command
        ]
        name = self.provider.name
        text = render_conversation(messages, not placeholder)
        for attempt in range(COMMAND_ATTEMPTS):
            try:
                completed = subprocess.run(
                    args, input=text, capture_output=True, text=True,
                    timeout=self.timeout,
                )
                break
            except FileNotFoundError as exc:
                raise LLMError(
                    f"{name}: command not found: {args[0]}"
                ) from exc
            except subprocess.TimeoutExpired as exc:
                raise LLMError(f"{name}: the command timed out.") from exc
            except OSError as exc:
                # e.g. the command's file being replaced by an update
                if attempt == COMMAND_ATTEMPTS - 1:
                    raise LLMError(
                        f"{name}: cannot run the command: {exc}"
                    ) from exc
                time.sleep(COMMAND_RETRY_SECONDS)
        if completed.returncode != 0:
            raise LLMError(
                f"{name}: the command failed with status "
                f"{completed.returncode}: "
                f"{(completed.stderr or completed.stdout).strip()[:300]}"
            )
        return Reply(completed.stdout.strip())

    def close(self) -> None:
        """Nothing to close."""


CLIENTS = {
    "openai": OpenAIChatClient,
    "anthropic": AnthropicChatClient,
    "command": CommandChatClient,
}


def make_client(
    provider: ProviderConfig, timeout: float = 60.0, transport=None
):
    """
    Return the chat client of *provider*.

    In a browser (Pyodide) the requests are sent by the browser itself.
    """
    if transport is None and sys.platform == "emscripten":
        from .browser import BrowserTransport

        transport = BrowserTransport()
    return CLIENTS[provider.api](provider, timeout, transport)
