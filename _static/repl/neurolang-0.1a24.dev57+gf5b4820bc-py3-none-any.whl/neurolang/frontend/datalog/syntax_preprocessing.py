from nl_core.datalog.expression_processing import extract_logic_free_variables
from nl_core.datalog.negation import is_conjunctive_negation
from nl_expr.expression_walker import (
    ExpressionWalker, PatternWalker, add_match,
)
from nl_expr.expressions import ExpressionBlock, NeuroLangException, Symbol
from nl_expr.logic import Implication, ExistentialPredicate
from nl_core.datalog.horn_clauses import (
    Fol2DatalogTranslationException,
    fol_query_to_datalog_program,
)
from nl_core.probabilistic.expressions import Condition


class ProbFol2DatalogMixin(PatternWalker):
    """Mixin to translate first order logic expressions
    to datalog expressions, including MARG queries
    """

    @add_match(
        Implication(..., ExistentialPredicate(..., Condition)),
    )
    def strip_ep_over_condition(self, imp):
        """Strip ``ExistentialPredicate`` that wraps a ``Condition`` in the
        antecedent of an ``Implication``.

        The ``AnaphoraResolutionWalker`` lifts the existential quantifier
        (from ``a/an/every``) to wrap the ``Condition`` after cross-boundary
        resolution.  Datalog semantics already treat free variables in the
        body as existentially quantified, so the quantifier wrapper is
        unnecessary and can be removed.  The inner ``Condition`` is then
        handled naturally by downstream mixins such as
        ``rewrite_conditional_query`` or
        ``decompose_non_conjunctive_condition``.
        """
        return self.walk(Implication(
            imp.consequent, imp.antecedent.body
        ))

    @add_match(
        Implication(..., Condition),
        lambda imp: any(
            not is_conjunctive_negation(arg)
            for arg in imp.antecedent.unapply()
        ),
    )
    def decompose_non_conjunctive_condition(self, imp):
        condition = imp.antecedent
        results = []
        new_args = []
        for arg in (condition.conditioned, condition.conditioning):
            if is_conjunctive_negation(arg):
                new_args.append(arg)
            else:
                fv = extract_logic_free_variables(arg)
                fresh_head = Symbol.fresh()(*tuple(fv))
                aux = fol_query_to_datalog_program(
                    fresh_head, arg, self.symbol_table
                )
                results.append(aux)
                new_args.append(fresh_head)
        new_condition = Condition(new_args[0], new_args[1])
        main_impl = self.walk(Implication(imp.consequent, new_condition))
        if results:
            return ExpressionBlock([main_impl] + results)
        return main_impl

    @add_match(
        Implication,
        lambda imp: not isinstance(imp.antecedent, Condition)
        and not is_conjunctive_negation(imp.antecedent),
    )
    def translate_implication(self, imp):
        try:
            program = fol_query_to_datalog_program(
                imp.consequent, imp.antecedent, self.symbol_table
            )
        except NeuroLangException as e:
            raise Fol2DatalogTranslationException(str(e)) from e
        return self.walk(program)


class TranslateRuleToDatalog(ProbFol2DatalogMixin, ExpressionWalker):
    """``ProbFol2DatalogMixin`` on its own, outside a program."""

    def __init__(self, symbol_table):
        self.symbol_table = symbol_table


def rule_to_datalog(rule, symbol_table):
    """
    Translate *rule*, ``head :- body`` of first order logic, to Datalog, as
    a program translates its rules: return the rule of its head and the
    rules it needs.  ``exists(...)`` and ``~exists(...)`` become rules, a
    Datalog rule is left as it is.
    """
    def rules(expression):
        if isinstance(expression, ExpressionBlock):
            return [r for e in expression.expressions for r in rules(e)]
        return [expression]

    translated = rules(TranslateRuleToDatalog(symbol_table).walk(rule))
    head = next(r for r in translated if r.consequent == rule.consequent)
    return head, [r for r in translated if r is not head]
