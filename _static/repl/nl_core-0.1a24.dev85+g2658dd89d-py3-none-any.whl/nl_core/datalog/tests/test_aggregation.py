from typing import AbstractSet

import pytest
import numpy as np

from nl_expr.exceptions import (
    ForbiddenUnstratifiedAggregation,
    UnboundVariablesError,
)

from nl_expr.expression_walker import ExpressionBasicEvaluator
from nl_expr.expressions import (
    Constant,
    ExpressionBlock,
    NeuroLangException,
    Symbol,
)
from nl_expr.type_system import Unknown
from .. import DatalogProgram, Fact, Implication
from ..aggregation import (
    AGG_COUNT,
    AGG_MAX,
    AGG_MEAN,
    AggregationApplication,
    BuiltinAggregationMixin,
    DatalogWithAggregationMixin,
    TranslateToLogicWithAggregation,
)
from ..chase import Chase, ChaseAggregationSN
from ..negation import DatalogProgramNegationMixin
from ..expressions import Union

S_ = Symbol
C_ = Constant
Imp_ = Implication
Fa_ = AggregationApplication
Eb_ = ExpressionBlock
U_ = Union
F_ = Fact


class Datalog(
    TranslateToLogicWithAggregation,
    DatalogWithAggregationMixin, DatalogProgram,
    ExpressionBasicEvaluator
):
    def function_sum(self, x: AbstractSet) -> Unknown:
        return sum(v for v in x)

    def function_sum2(self, x: AbstractSet, y: AbstractSet) -> Unknown:
        return sum(v + w for v, w in zip(x, y))

    def function_set_create(self, x: AbstractSet) -> np.object_:
        return frozenset(x)


def test_aggregation_parsing():
    dl = Datalog()

    P = S_('P')  # noqa: N806
    Q = S_('Q')  # noqa: N806
    x = S_('x')
    y = S_('y')

    edb = [
        F_(P(C_(i), C_(j)))
        for i in range(3)
        for j in range(3)
    ]

    code = U_(edb + [
        Imp_(Q(x, S_('sum')(y,)), P(x, y)),
    ])

    dl.walk(code)

    assert Q in dl.intensional_database()
    assert P in dl.extensional_database()

    with pytest.raises(NeuroLangException):
        dl.walk(U_([
            Imp_(Q(x, Fa_(C_(sum), (y,)), Fa_(C_(sum), (y,))), P(x, y)),
        ]))


def test_aggregation_non_stratified():
    P = S_('P')  # noqa: N806
    Q = S_('Q')  # noqa: N806
    x = S_('x')

    edb = [
        F_(P(C_(i)))
        for i in range(3)
    ]

    code = Eb_(edb + [
        Imp_(Q(Fa_(S_('sum'), (x,))), Q(x)),
    ])

    dl = Datalog()
    dl.walk(code)

    chase = ChaseAggregationSN(dl)

    with pytest.raises(ForbiddenUnstratifiedAggregation):
        chase.build_chase_solution()


def test_aggregation_chase_no_grouping():

    P = S_('P')  # noqa: N806
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    x = S_('x')

    edb = [
        F_(P(C_(i)))
        for i in range(3)
    ]

    code = Eb_(edb + [
        Imp_(Q(Fa_(S_('sum'), (x,))), P(x)),
    ])

    dl = Datalog()
    dl.walk(code)

    chase = Chase(dl)

    solution = chase.build_chase_solution()

    dl.add_extensional_predicate_from_tuples(R, {(3,)})

    res = dl.extensional_database()['R']

    assert solution[Q] == res


def test_aggregation_chase_no_grouping_2args():

    P = S_('P')  # noqa: N806
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    x = S_('x')
    y = S_('y')

    edb = [
        F_(P(C_(i), C_(2 * i)))
        for i in range(3)
    ]

    code = U_(edb + [
        Imp_(Q(Fa_(S_('sum2'), (x, y))), P(x, y)),
    ])

    dl = Datalog()
    dl.walk(code)

    chase = Chase(dl)

    solution = chase.build_chase_solution()

    dl.add_extensional_predicate_from_tuples(R, {(9,)})

    res = dl.extensional_database()['R']

    assert solution[Q] == res


def test_aggregation_chase_single_grouping():
    dl = Datalog()

    P = S_('P')  # noqa: N806
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    x = S_('x')
    y = S_('y')

    edb = [
        F_(P(C_(i), C_(i * j)))
        for i in range(3)
        for j in range(3)
    ]

    code = Eb_(edb + [
        Imp_(Q(x, Fa_(S_('sum'), (y,))), P(x, y)),
    ])

    dl.walk(code)

    chase = Chase(dl)

    solution = chase.build_chase_solution()

    dl.add_extensional_predicate_from_tuples(
        R,
        {
            (0, 0),
            (1, 3),
            (2, 6)
        }
    )
    res = dl.extensional_database()['R']

    assert solution[Q] == res


def test_aggregation_chase_single_grouping_muliple_columns():
    dl = Datalog()

    P = S_('P')  # noqa: N806
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    x = S_('x')
    y = S_('y')
    z = S_('z')

    edb = [
        F_(P(C_(i), C_(i * j), C_(0)))
        for i in range(3)
        for j in range(3)
    ]

    code = Eb_(edb + [
        Imp_(Q(x, Fa_(S_('sum2'), (y, z))), P(x, y, z)),
    ])

    dl.walk(code)

    chase = Chase(dl)

    solution = chase.build_chase_solution()

    dl.add_extensional_predicate_from_tuples(
        R,
        {
            (0, 0),
            (1, 3),
            (2, 6)
        }
    )
    res = dl.extensional_database()['R']

    assert solution[Q] == res


def test_aggregation_set_creation():
    dl = Datalog()
    P = S_('P')
    Q = S_('Q')
    x = S_('x')
    y = S_('y')

    edb = tuple(
        F_(P(C_(0), C_(i)))
        for i in range(3)
    )

    code = Eb_(edb + (
        Imp_(
            Q(x, Fa_(S_('set_create'), (y,))),
            P(x, y)
        ),
    ))

    dl.walk(code)
    chase = Chase(dl)
    solution = chase.build_chase_solution()

    assert Q in solution
    assert set(solution[Q].value.unwrapped_iter()) == {
        (0, frozenset(i for i in range(3)))
    }


class DatalogNegation(
    TranslateToLogicWithAggregation,
    DatalogWithAggregationMixin, DatalogProgramNegationMixin, DatalogProgram,
    ExpressionBasicEvaluator
):
    pass


@pytest.mark.parametrize(
    "aggregation, expected", [("sum", 5), ("count", 2), ("max", 3)]
)
def test_aggregation_over_negated_body(aggregation, expected):
    """``Q(agg(x)) :- P(x), ~R(x)`` aggregates the ``x`` of ``P`` not in
    ``R``, as the two-rule ``S(x) :- P(x), ~R(x); Q(agg(x)) :- S(x)``."""
    P = S_('P')  # noqa: N806
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    x = S_('x')

    dl = DatalogNegation()
    dl.walk(Eb_(
        [F_(P(C_(i))) for i in range(4)] + [F_(R(C_(0))), F_(R(C_(1)))] +
        [Imp_(Q(Fa_(S_(aggregation), (x,))), P(x) & ~R(x))]
    ))
    dl.symbol_table[S_(aggregation)] = C_(
        {"sum": sum, "count": len, "max": max}[aggregation]
    )

    solution = Chase(dl).build_chase_solution()

    assert solution[Q] == C_[AbstractSet]({(expected,)})


def test_aggregation_over_negated_body_non_stratified():
    P = S_('P')  # noqa: N806
    Q = S_('Q')  # noqa: N806
    x = S_('x')

    dl = DatalogNegation()
    dl.walk(Eb_(
        [F_(P(C_(i))) for i in range(3)] +
        [Imp_(Q(Fa_(S_('sum'), (x,))), P(x) & ~Q(x))]
    ))

    with pytest.raises(ForbiddenUnstratifiedAggregation):
        ChaseAggregationSN(dl).build_chase_solution()


def test_aggregation_emptyset():
    dl = Datalog()

    P = S_('P')  # noqa: N806
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    x = S_('x')
    y = S_('y')

    edb = [
        F_(P(C_(i), C_(i * j)))
        for i in range(3)
        for j in range(3)
    ] + [F_(R(C_(10)))]

    code = Eb_(edb + [
        Imp_(Q(x, Fa_(S_('sum'), (y,))), R(x) & P(x, y)),
    ])

    dl.walk(code)

    chase = Chase(dl)

    solution = chase.build_chase_solution()

    assert Q not in solution or solution[Q] == set()


def test_builtin_aggregations():
    class DatalogWithBuiltinAggregation(
        BuiltinAggregationMixin,
        DatalogWithAggregationMixin,
        DatalogProgram,
        ExpressionBasicEvaluator,
    ):
        pass

    dl = DatalogWithBuiltinAggregation()
    assert AGG_MAX in dl.symbol_table
    assert AGG_MEAN in dl.symbol_table
    assert AGG_COUNT in dl.symbol_table

    P = S_('P')
    Q = S_('Q')
    x = S_('x')
    edb = Eb_(tuple(F_(P(C_(i))) for i in range(10)))
    dl.walk(edb)
    agg_rule = Imp_(Q(Fa_(S_('count'), (x,))), P(x))
    dl.walk(agg_rule)
    chase = Chase(dl)
    solution = chase.build_chase_solution()
    assert Q in solution
    result = solution[Q]
    expected = Constant[AbstractSet]({(10,)})
    assert result == expected


def test_count_counts_distinct_values():
    """``count(s)`` counts the values of ``s``, not the rows of the body
    (#1090), and ``sum`` sums the rows."""
    class DatalogWithBuiltinAggregation(
        BuiltinAggregationMixin,
        DatalogWithAggregationMixin,
        DatalogProgram,
        ExpressionBasicEvaluator,
    ):
        pass

    dl = DatalogWithBuiltinAggregation()
    P, Q, R, T = S_('P'), S_('Q'), S_('R'), S_('T')
    l, s, w = S_('l'), S_('s'), S_('w')
    dl.walk(Eb_(tuple(
        F_(P(C_(a), C_(b), C_(1.0)))
        for a, b in (("x", 1), ("y", 1), ("x", 2))
    )))
    dl.walk(Imp_(Q(Fa_(S_('count'), (s,))), P(l, s, w)))
    dl.walk(Imp_(R(l, Fa_(S_('count'), (s,))), P(l, s, w)))
    dl.walk(Imp_(T(Fa_(S_('count'), (l, s)), Fa_(S_('sum'), (w,))), P(l, s, w)))
    solution = Chase(dl).build_chase_solution()
    assert solution[Q] == Constant[AbstractSet]({(2,)})
    assert solution[R] == Constant[AbstractSet]({("x", 2), ("y", 1)})
    assert set(solution[T].value) == {(3, 3.0)}


def test_multiple_aggregations():
    class DatalogWithBuiltinAggregation(
        BuiltinAggregationMixin,
        DatalogWithAggregationMixin,
        DatalogProgram,
        ExpressionBasicEvaluator,
    ):
        pass

    dl = DatalogWithBuiltinAggregation()

    P = S_('P')
    Q = S_('Q')
    x = S_('x')
    edb = Eb_(tuple(F_(P(C_(i))) for i in range(10)))
    dl.walk(edb)
    agg_rule = Imp_(
        Q(Fa_(AGG_COUNT, (x,)), Fa_(AGG_MAX, (x,))),
        P(x)
    )
    dl.walk(agg_rule)
    chase = Chase(dl)
    solution = chase.build_chase_solution()
    assert Q in solution
    result = solution[Q]
    expected = Constant[AbstractSet]({(10, 9)})
    assert result == expected


def test_percentile_aggregation_ignores_nan():
    class DatalogWithBuiltinAggregation(
        BuiltinAggregationMixin,
        DatalogWithAggregationMixin,
        DatalogProgram,
        ExpressionBasicEvaluator,
    ):
        pass

    dl = DatalogWithBuiltinAggregation()

    P = S_('P')
    Q = S_('Q')
    x = S_('x')
    values = [float(i) for i in range(11)] + [float('nan')]
    dl.walk(Eb_(tuple(F_(P(C_(v))) for v in values)))
    dl.walk(Imp_(
        Q(Fa_(S_('percentile'), (x, C_(90.)))),
        P(x)
    ))
    solution = Chase(dl).build_chase_solution()
    (result,), = solution[Q].value.unwrap()
    assert result == pytest.approx(9.)


def test_head_variable_missing_from_body_named():
    dl = Datalog()
    x, y, z, P, Q = S_('x'), S_('y'), S_('z'), S_('P'), S_('Q')
    with pytest.raises(UnboundVariablesError) as exc_info:
        dl.walk(Imp_(P(z, Fa_(S_('count'), (y,))), Q(x, y)))
    assert exc_info.value.rule == 'P'
    assert exc_info.value.variables == ('z',)
