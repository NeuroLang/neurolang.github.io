import operator as op
import random
from itertools import product
from typing import AbstractSet, Callable, Tuple

from pytest import fixture, mark, raises, skip

from nl_expr import expression_walker as ew
from nl_expr import expressions
from nl_expr.exceptions import WrongArgumentsInPredicateError
from ..basic_representation import DatalogProgram
from ..chase import (ChaseGeneral, ChaseMGUMixin, ChaseNaive,
                     ChaseNamedRelationalAlgebraMixin, ChaseNode,
                     ChaseNonRecursive, ChaseRelationalAlgebraPlusCeriMixin,
                     ChaseSemiNaive, NeuroLangNonLinearProgramException,
                     NeuroLangProgramHasLoopsException)
from ..expressions import (Conjunction, Fact, Implication, TranslateToLogic,
                           Union)
from ..instance import MapInstance
from ..expression_processing import EQ

try:
    from contextlib import nullcontext
except ImportError:
    from contextlib import suppress as nullcontext


C_ = expressions.Constant
S_ = expressions.Symbol
Imp_ = Implication
F_ = Fact
Eb_ = expressions.ExpressionBlock
Disj_ = Union


class DatalogTranslator(TranslateToLogic, ew.IdentityWalker):
    pass


DT = DatalogTranslator()


Q = S_('Q')
T = S_('T')
S = S_('S')
v = S_('v')
w = S_('w')
x = S_('x')
y = S_('y')
z = S_('z')
a = C_('a')
b = C_('b')
c = C_('c')
eq = C_[Callable[[expressions.Unknown, expressions.Unknown], bool]](op.eq)
gt = C_[Callable[[expressions.Unknown, expressions.Unknown], bool]](op.gt)
contains = C_[Callable[[expressions.Unknown, expressions.Unknown], bool]](
    op.contains
)


class Datalog(TranslateToLogic, DatalogProgram, ew.ExpressionBasicEvaluator):
    def function_gt(self, x: int, y: int) -> bool:
        return x > y


chase_configurations = [
    (step_class, cq_class)
    for step_class, cq_class in product(
        (
            ChaseNonRecursive,
            ChaseNaive,
            ChaseSemiNaive
        ),
        (
            ChaseMGUMixin,
            ChaseNamedRelationalAlgebraMixin,
            ChaseRelationalAlgebraPlusCeriMixin,
        )
    )
]


@fixture(
    params=chase_configurations,
    ids=[
        f'{strategy}-{step}'
        for strategy, step in chase_configurations
    ]
)
def chase_class(request):
    class C(request.param[0], request.param[1], ChaseGeneral):
        pass

    return C


def test_no_free_variable_case(chase_class):
    datalog_program = Eb_((
        F_(Q(a)),
        Imp_(T(b), Q(a)),
    ))

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())
    rule = datalog_program.expressions[-1]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)
    res = MapInstance({
        T: C_({C_(('b', ))}),
    })

    assert res == instance_update


def test_no_head_argument_case(chase_class):
    datalog_program = Eb_((
        F_(Q(a)),
        Imp_(T(), Q(x)),
    ))

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())
    rule = datalog_program.expressions[-1]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)
    res = MapInstance({
        T: C_({C_(tuple())}),
    })

    assert res == instance_update


def test_symmetric_elements(chase_class):
    datalog_program = Eb_((
        F_(Q(a, a)),
        F_(Q(b, c)),
        Imp_(T(x), Q(x, x)),
    ))

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())
    rule = datalog_program.expressions[-1]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)
    res = MapInstance({
        T: C_({C_((a,))}),
    })

    assert res == instance_update


def test_builtin_equality_only(chase_class):
    datalog_program = Eb_((Imp_(Q(x), eq(x, C_(5))), ))

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())

    rule = datalog_program.expressions[0]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)
    res = MapInstance({
        Q: C_({C_((5, ))}),
    })
    assert instance_update == res

    datalog_program = Eb_((Imp_(Q(x), eq(x, C_(5) + C_(7))), ))

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())

    rule = datalog_program.expressions[0]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)
    res = MapInstance({
        Q: C_({C_((12, ))}),
    })
    assert instance_update == res


def test_builtin_equality_only_sets(chase_class):
    const = C_(frozenset({5, 6}))
    datalog_program = Eb_((Imp_(Q(x), eq(x, const)),))

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())

    rule = datalog_program.expressions[0]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)
    res = MapInstance({
        Q: C_({(const.value,)}),
    })
    assert instance_update == res


def test_builtin_equality_only_sets_and_computations(chase_class):
    const = C_(frozenset({5, 6}))
    len_ = C_(len)
    datalog_program = Eb_((
        Fact(Q(const)),
        Imp_(T(x), eq(x, len_(y)) & Q(y))
    ))

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())
    assert instance_0[Q].type == AbstractSet[Tuple[AbstractSet[int]]]

    rule = dl.symbol_table[T].formulas[0]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)

    res = MapInstance({
        T: C_({(2,)}),
    })
    assert instance_update == res

    const1 = C_(frozenset({6, 8}))
    datalog_program = Eb_((
        Fact(Q(const)),
        Fact(Q(const1)),
        Imp_(T(y), contains(y, C_(5)) & Q(y))
    ))

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())

    rule = dl.symbol_table[T].formulas[0]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)

    res = MapInstance({
        T: C_({(frozenset({5, 6}),)}),
    })
    assert instance_update == res
    assert instance_update[T].type == AbstractSet[Tuple[AbstractSet[int]]]

    datalog_program = Eb_((
        Fact(Q(const)),
        Fact(Q(const1)),
        Fact(Q(C_(frozenset({0, 0})))),
        Imp_(T(x, y), Q(y) & contains(y, x) & eq(x, C_(6))),
        Imp_(S(x, y), Q(y) & eq(x, C_(6)) & contains(y, x)),
        Imp_(S(x, y), Q(y) & eq(x, C_(5)) & contains(y, x)),
    ))

    dl = Datalog()
    dl.walk(datalog_program)

    dc = chase_class(dl)
    instance_result = dc.build_chase_solution()

    res = MapInstance({
        T: C_({
            (C_(6), frozenset({5, 6}),),
            (C_(6), frozenset({6, 8}),)
        }),
        S: C_({
            (C_(5), frozenset({5, 6}),),
            (C_(6), frozenset({5, 6}),),
            (C_(6), frozenset({6, 8}),)
        }),
    })
    assert instance_result[T] == res[T]
    assert instance_result[S] == res[S]
    assert instance_result[T].type == AbstractSet[Tuple[int, AbstractSet[int]]]
    assert instance_result[S].type == AbstractSet[Tuple[int, AbstractSet[int]]]


def test_builtin_equality_simple_chase_solution(chase_class):
    datalog_program = Eb_((
        F_(Q(C_(5), C_(6))),
        F_(Q(C_(7), C_(8))),
        F_(S(C_(5))),
        Imp_(T(x), eq(C_(6), y) & Q(x, y)),
    ))

    dl = Datalog()
    dl.walk(datalog_program)

    dc = chase_class(dl)
    res = dc.build_chase_solution()
    assert res['T'] == res['S']


def test_builtin_equality_chase_solution(chase_class):
    datalog_program = Eb_((
        F_(Q(C_(5), C_(6))),
        F_(Q(C_(7), C_(8))),
        Imp_(T(x, z), eq(z, y) & Q(x, y)),
    ))

    dl = Datalog()
    dl.walk(datalog_program)

    dc = chase_class(dl)
    res = dc.build_chase_solution()
    assert res['Q'] == res['T']

    datalog_program = Eb_((
        F_(Q(C_(5), C_(6))),
        F_(Q(C_(7), C_(8))),
        Imp_(T(x, z), eq(z, y * C_(1)) & Q(x, y)),
    ))

    dl = Datalog()
    dl.walk(datalog_program)

    dc = chase_class(dl)
    res = dc.build_chase_solution()
    assert res['Q'] == res['T']


def test_chase_set_destroy(chase_class):
    consts = [
        C_(frozenset({5, 6})),
        C_(frozenset({5, 8})),
        C_(frozenset({15, 8})),
    ]

    datalog_program = Eb_(
        tuple(Fact(Q(c)) for c in consts) +
        (
            Imp_(T(x), contains(y, x) & Q(y)),
        )
    )

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())

    rule = dl.symbol_table['T'].formulas[0]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)

    res = MapInstance({
        T: C_({(5,), (6,), (8,), (15,)}),
    })
    assert instance_update == res


def test_chase_set_destroy_tuples(chase_class):
    if not issubclass(chase_class, ChaseNamedRelationalAlgebraMixin):
        skip(
            reason="Multiple column destroy only implemented for the RA chase"
        )

    consts = [
        C_(frozenset({(5, 6), (15, 8)})),
        C_(frozenset({(5, 8)})),
        C_(frozenset({(15, 8)})),
    ]

    datalog_program = Eb_(
        tuple(Fact(Q(c)) for c in consts) +
        (
            Imp_(T(x, y), contains(z, C_(((x, y)))) & Q(z)),
        )
    )

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())

    rule = dl.symbol_table['T'].formulas[0]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)

    res = MapInstance({
        T: C_({(5, 6), (5, 8), (15, 8)}),
    })
    assert instance_update == res


def test_builtin_equality_add_column(chase_class):
    datalog_program = Eb_((
        Imp_(Q(y), Conjunction((T(x), eq(y, C_(2) * x)))),
    ))

    dl = Datalog()
    dl.add_extensional_predicate_from_tuples(T, ((i,) for i in range(8)))
    dl.walk(datalog_program)

    dc = chase_class(dl)
    instance_out = dc.build_chase_solution()
    res = MapInstance({
        T: dl.extensional_database()[T],
        Q: C_(
            {C_((2 * i,)) for i in range(8)}
        ),
    })
    assert instance_out == res


def test_python_builtin_equaltiy_chase_step(chase_class):
    datalog_program = DT.walk(Eb_((
        F_(Q(C_(1), C_(2))),
        F_(Q(C_(2), C_(3))),
        Imp_(S(y),
             Q(x, z) & eq(z + C_(1), y)),
        Imp_(S(y),
             Q(x, z) & eq(y, z + C_(1))),
    )))

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())

    rule = DT.walk(datalog_program.formulas[-2])
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)
    res = MapInstance({
        S: C_({C_((3, )), C_((4, ))}),
    })
    assert instance_update == res

    rule = datalog_program.formulas[-1]
    instance_update = dc.chase_step(instance_0, rule)
    assert instance_update == res


def test_python_builtin_chase_step(chase_class):
    datalog_program = DT.walk(Eb_((
        F_(Q(C_(1), C_(2))), F_(Q(C_(2), C_(3))), F_(Q(C_(8), C_(6))),
        Imp_(T(x, y), Q(x, z) & Q(z, y)),
        Imp_(S(x, y), Q(x, y) & gt(x, y))
    )))

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())

    rule = datalog_program.formulas[-1]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)
    assert instance_update == MapInstance({
        S: C_({C_((C_(8), C_(6)))}),
    })

    rule = datalog_program.formulas[-2]
    instance_update = dc.chase_step(instance_0, rule)
    assert instance_update == MapInstance({
        T: C_({C_((C_(1), C_(3)))}),
    })

    instance_1 = instance_0 | instance_update
    instance_update = dc.chase_step(instance_1, rule)
    assert len(instance_update) == 0


def test_python_nested_builtin_chase_step(chase_class):
    datalog_program = DT.walk(Eb_((
        F_(Q(C_(8), C_(15))),
        F_(Q(C_(8), C_(9))),
        Imp_(S(x, y),
             Q(x, y) & gt(x, y - C_(2))),
    )))

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())

    rule = datalog_program.formulas[-1]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)
    assert instance_update == MapInstance({
        S: C_({C_((C_(8), C_(9)))}),
    })


def test_non_recursive_predicate_chase_step(chase_class):
    gt = S_('gt')

    datalog_program = DT.walk(Eb_((
        F_(Q(C_(1), C_(2))),
        F_(Q(C_(2), C_(3))),
        F_(Q(C_(8), C_(6))),
        Imp_(T(x, y),
             Q(x, z) & Q(z, y)),
        Imp_(S(x, y),
             Q(x, y) & gt(x, y))
    )))

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())

    rule = datalog_program.formulas[-1]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)
    res = MapInstance({
        S: C_({C_((C_(8), C_(6)))}),
    })
    assert instance_update == res

    rule = datalog_program.formulas[-2]
    instance_update = dc.chase_step(instance_0, rule)
    assert instance_update == MapInstance({
        T: C_({C_((C_(1), C_(3)))}),
    })

    instance_1 = instance_0 | instance_update
    instance_update = dc.chase_step(instance_1, rule)
    assert len(instance_update) == 0


def test_python_multiple_builtins(chase_class):
    datalog_program = DT.walk(Eb_((
        F_(Q(C_(1), C_(2))),
        F_(Q(C_(2), C_(3))),
        Imp_(S(w),
             Q(x, z) & eq(z + C_(1), y) & eq(y, w)),
    )))

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())

    rule = datalog_program.formulas[-1]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)
    res = MapInstance({
        S: C_({C_((3, )), C_((4, ))}),
    })
    assert instance_update == res

    datalog_program = DT.walk(Eb_((
        F_(Q(C_(1), C_(2))),
        F_(Q(C_(2), C_(3))),
        Imp_(S(w),
             Q(x, z) & eq(y, w) & eq(z + C_(1), y)),
    )))

    dl = Datalog()
    dl.walk(datalog_program)

    instance_0 = MapInstance(dl.extensional_database())

    rule = datalog_program.formulas[-1]
    dc = chase_class(dl)
    instance_update = dc.chase_step(instance_0, rule)
    res = MapInstance({
        S: C_({C_((3, )), C_((4, ))}),
    })
    assert instance_update == res


def test_non_recursive_predicate_chase_tree(chase_class):
    datalog_program = DT.walk(Eb_((
        F_(Q(C_(1), C_(2))), F_(Q(C_(2),
                                  C_(3))), Imp_(T(x, y),
                                                Q(x, z) & Q(z, y))
    )))

    dl = Datalog()
    dl.walk(datalog_program)

    dc = chase_class(dl)
    res = dc.build_chase_tree()

    instance_update = MapInstance({T: C_({C_((C_(1), C_(3)))})})

    instance_1 = instance_update.copy()
    instance_1.update(dl.extensional_database())

    assert res.instance == MapInstance(dl.extensional_database())
    assert res.children == {
        datalog_program.formulas[-1]: ChaseNode(instance_1, dict())
    }


def test_recursive_predicate_chase_tree(chase_class):
    datalog_program = DT.walk(Eb_((
        F_(Q(C_(1), C_(2))), F_(Q(C_(2), C_(3))), Imp_(T(x, y), Q(x, y)),
        Imp_(T(x, y),
             Q(x, z) & T(z, y))
    )))

    dl = Datalog()
    dl.walk(datalog_program)

    dc = chase_class(dl)
    res = dc.build_chase_tree()

    instance_update = MapInstance({T: dl.extensional_database()[Q]})

    instance_1 = instance_update.copy()
    instance_1.update(dl.extensional_database())

    assert res.instance == MapInstance(dl.extensional_database())
    assert len(res.children) == 1
    first_child = res.children[datalog_program.formulas[-2]]
    assert first_child.instance == instance_1
    assert len(first_child.children) == 1
    second_child = first_child.children[datalog_program.formulas[-1]]

    instance_2 = MapInstance({
        Q: C_({
            C_((C_(1), C_(2))),
            C_((C_(2), C_(3))),
        }),
        T: C_({C_((C_(1), C_(2))),
               C_((C_(2), C_(3))),
               C_((C_(1), C_(3)))})
    })

    assert len(second_child.children) == 0
    assert second_child.instance == instance_2


def test_nonrecursive_predicate_chase_solution(chase_class, n=10):
    datalog_program = DT.walk(Eb_(
        tuple(F_(Q(C_(i), C_(i + 1)))
              for i in range(n)) + (Imp_(T(x, y),
                                         Q(x, z) & Q(z, y)), )
    ))

    dl = Datalog()
    dl.walk(datalog_program)

    dc = chase_class(dl)
    solution_instance = dc.build_chase_solution()

    final_instance = MapInstance({
        Q: C_({C_((C_(i), C_(i + 1)))
               for i in range(n)}),
        T: C_({C_((C_(i), C_(i + 2)))
               for i in range(n - 1)})
    })

    assert solution_instance == final_instance


def test_nonrecursive_predicate_chase_solution_constant(chase_class, n=10):
    datalog_program = Eb_(
        tuple(F_(Q(C_(i), C_(i + 1)))
              for i in range(n)) + (Imp_(T(y),
                                         Q(C_(1), z) & Q(z, y)), )
    )

    dl = Datalog()
    dl.walk(datalog_program)

    dc = chase_class(dl)
    solution_instance = dc.build_chase_solution()

    final_instance = MapInstance({
        Q: C_({C_((C_(i), C_(i + 1)))
               for i in range(n)}),
        T: C_({C_((C_(i + 2), ))
               for i in (1, )})
    })

    assert solution_instance == final_instance


def test_recursive_predicate_chase_solution(chase_class):
    datalog_program = Eb_((
        F_(Q(C_(1), C_(2))),
        F_(Q(C_(2), C_(3))),
        Imp_(T(x, y), Q(x, y)),
        Imp_(T(x, y),
             Q(x, z) & T(z, y))
    ))

    dl = Datalog()
    dl.walk(datalog_program)

    dc = chase_class(dl)

    if issubclass(chase_class, ChaseNonRecursive):
        context = raises(NeuroLangProgramHasLoopsException)
    else:
        context = nullcontext()

    with context:
        solution_instance = dc.build_chase_solution()

        final_instance = MapInstance({
            Q: C_({
                C_((C_(1), C_(2))),
                C_((C_(2), C_(3))),
            }),
            T: C_({C_((C_(1), C_(2))),
                C_((C_(2), C_(3))),
                C_((C_(1), C_(3)))})
        })

        assert solution_instance == final_instance


def test_another_recursive_chase(chase_class):
    x = S_('X')
    y = S_('Y')
    z = S_('Z')
    anc = S_('anc')
    par = S_('par')
    q = S_('q')
    a = C_('a')
    b = C_('b')
    c = C_('c')
    d = C_('d')

    edb = Eb_([
        F_(par(a, b)),
        F_(par(b, c)),
        F_(par(c, d)),
    ])

    code = Eb_([
        Imp_(q(x), anc(a, x)),
        Imp_(anc(x, y), par(x, y)),
        Imp_(anc(x, y),
             anc(x, z) & par(z, y)),
    ])

    dl = Datalog()
    dl.walk(code)
    dl.walk(edb)

    dl = Datalog()
    dl.walk(code)
    dl.walk(edb)

    if issubclass(chase_class, ChaseNonRecursive):
        context = raises(NeuroLangProgramHasLoopsException)
    else:
        context = nullcontext()

    with context:
        solution = chase_class(dl).build_chase_solution()
        assert solution['q'].value == {C_((e, )) for e in (b, c, d)}


def test_transitive_closure(chase_class):
    x = S_('X')
    y = S_('Y')
    z = S_('Z')
    edge = S_('edge')
    reaches = S_('reaches')

    dl = Datalog()
    dl.add_extensional_predicate_from_tuples(edge, {(1, 2), (2, 3), (3, 4)})

    code = Eb_([
        Imp_(reaches(x, y), edge(x, y)),
        Imp_(reaches(x, y), reaches(x, z) & reaches(z, y))
    ])

    dl.walk(code)

    if issubclass(chase_class, ChaseNonRecursive):
        context = raises(NeuroLangProgramHasLoopsException)
    elif issubclass(chase_class, ChaseSemiNaive):
        context = raises(NeuroLangNonLinearProgramException)
    else:
        context = nullcontext()

    with context:
        solution = chase_class(dl).build_chase_solution()
        assert solution[reaches].value == {
            C_((i, j))
            for i in range(1, 5)
            for j in range(i, 5)
            if i != j
        }


def test_nested_function_application(chase_class):
    x = S_("x")
    y = S_("y")
    z = S_("z")
    f = S_("f")
    g = S_("g")
    R = S_("R")
    Q = S_("Q")
    dl = Datalog()
    dl.symbol_table[f] = C_(lambda x, y: (x + y) // 2)
    dl.symbol_table[g] = C_(lambda x: x ** 2)
    dl.add_extensional_predicate_from_tuples(R, {(1,), (2,)})
    dl.walk(Implication(Q(z), Conjunction((R(x), R(y), EQ(z, f(g(x), g(y)))))))
    solution = chase_class(dl).build_chase_solution()
    assert solution[Q].value == {
        C_(((1 ** 2 + 1 ** 2) // 2,)),
        C_(((1 ** 2 + 2 ** 2) // 2,)),
        C_(((2 ** 2 + 1 ** 2) // 2,)),
        C_(((2 ** 2 + 2 ** 2) // 2,)),
    }


def test_rule_substitutions_keep_only_the_variables_of_the_head():
    """
    A rule's substitutions are projected on the variables of its head
    before the rows already computed are removed: the variables of the
    body alone (``x`` here) would make them as many as the combinations
    of the body, tens of millions for the voxels of a Euclidean bound,
    for a head of a few rows.
    """
    class Chase(ChaseNonRecursive, ChaseNamedRelationalAlgebraMixin,
                ChaseGeneral):
        compared = []

        def eliminate_already_computed(self, consequent, instance,
                                       substitutions):
            Chase.compared.append(
                (len(substitutions), set(substitutions.columns))
            )
            return super().eliminate_already_computed(
                consequent, instance, substitutions
            )

    big, other, marker = S_('big'), S_('other'), S_('marker')
    datalog = Datalog()
    datalog.add_extensional_predicate_from_tuples(
        big, {(n, n % 3) for n in range(300)}
    )
    datalog.add_extensional_predicate_from_tuples(
        other, {(n, n % 2) for n in range(200)}
    )
    datalog.add_extensional_predicate_from_tuples(marker, {('m',)})
    datalog.walk(Eb_((
        Imp_(Q(y, z), Conjunction((big(x, y), marker(z)))),
        Imp_(Q(y, z), Conjunction((other(x, y), marker(z)))),
    )))
    solution = Chase(datalog).build_chase_solution()
    assert set(solution[Q].value) == {(n, 'm') for n in range(3)}
    assert Chase.compared and all(
        rows <= 3 and columns == {'y', 'z'}
        for rows, columns in Chase.compared
    )


def test_symbol_table_merges_the_deltas_the_rule_uses_only():
    """
    In the semi-naive chase, the symbol table of a rule binds a positive
    atom to its delta and a negated one to its relation and delta merged;
    a predicate the rule does not use keeps its relation, not merged with
    its delta: merging every predicate of the delta, at every step and for
    every rule, cost as much as the relations (minutes and tens of GB on a
    tractogram).
    """
    from nl_expr.logic import Negation
    from ..wrapped_collections import WrappedRelationalAlgebraSet

    def relation(*rows):
        return C_[AbstractSet[Tuple[int]]](
            WrappedRelationalAlgebraSet(rows), verify_type=False
        )

    p, q, r = S_('p'), S_('q'), S_('r')
    instance = MapInstance({p: relation((1,)), q: relation((1,)),
                            r: relation((5,))})
    delta = MapInstance({p: relation((3,)), q: relation((2,)),
                         r: relation((6,))})
    table = ChaseNamedRelationalAlgebraMixin.ra_symbol_table(
        (p(x), Negation(q(x))), instance, delta
    )
    assert set(table[p].value) == {(3,)}
    assert set(table[q].value) == {(1,), (2,)}
    assert set(table[r].value) == {(5,)}


def test_aggregation_rules_keep_the_variables_they_aggregate():
    from ..aggregation import (
        AggregationApplication, BuiltinAggregationMixin,
        ChaseAggregationMixin, DatalogWithAggregationMixin,
    )

    class AggregationDatalog(
        TranslateToLogic, DatalogWithAggregationMixin,
        BuiltinAggregationMixin, DatalogProgram,
        ew.ExpressionBasicEvaluator,
    ):
        pass

    class Chase(ChaseAggregationMixin, ChaseNonRecursive,
                ChaseNamedRelationalAlgebraMixin, ChaseGeneral):
        pass

    pair = S_('pair')
    datalog = AggregationDatalog()
    datalog.add_extensional_predicate_from_tuples(
        pair, {(1, 'a'), (1, 'b'), (2, 'a')}
    )
    datalog.walk(Imp_(
        Q(y, AggregationApplication(S_('count'), (x,))),
        Conjunction((pair(y, x),)),
    ))
    solution = Chase(datalog).build_chase_solution()
    assert set(solution[Q].value) == {(1, 2), (2, 1)}


E, F, P, R = S_('E'), S_('F'), S_('P'), S_('R')
SEMI_NAIVE_PROGRAMS = {
    'transitive closure': (
        Imp_(P(x, y), E(x, y)),
        Imp_(P(x, y), P(x, z) & E(z, y)),
    ),
    'mutual recursion': (
        Imp_(P(x, y), E(x, y)),
        Imp_(Q(x, y), P(x, z) & E(z, y)),
        Imp_(P(x, y), Q(x, z) & E(z, y)),
    ),
    # R(0, 5) joins P(0, 4), derived late, with Q(4, 5), derived early,
    # while Q still grows: binding both atoms to their deltas would lose it.
    'two recursive atoms': (
        Imp_(P(x, y), E(x, y)),
        Imp_(P(x, y), P(x, z) & E(z, y)),
        Imp_(Q(x, y), F(x, y)),
        Imp_(Q(x, y), Q(x, z) & F(z, y)),
        Imp_(R(x, y), P(x, z) & Q(z, y)),
    ),
}


@mark.parametrize('seed', range(3))
@mark.parametrize('program', SEMI_NAIVE_PROGRAMS)
@mark.parametrize('cq_class', (
    ChaseMGUMixin,
    ChaseNamedRelationalAlgebraMixin,
    ChaseRelationalAlgebraPlusCeriMixin,
))
def test_semi_naive_solution_is_the_naive_one(program, cq_class, seed):
    rng = random.Random(seed)
    edges = {(i, i + 1) for i in range(4)} | {
        (rng.randrange(8), rng.randrange(8)) for _ in range(12)
    }
    solutions = []
    for step_class in (ChaseNaive, ChaseSemiNaive):
        class C(step_class, cq_class, ChaseGeneral):
            pass

        dl = Datalog()
        dl.add_extensional_predicate_from_tuples(E, edges)
        dl.add_extensional_predicate_from_tuples(
            F, {(i, i + 1) for i in range(4, 14)}
        )
        dl.walk(Eb_(SEMI_NAIVE_PROGRAMS[program]))
        solutions.append(C(dl).build_chase_solution())
    assert solutions[0] == solutions[1]


def test_semi_naive_skips_a_rule_whose_atoms_have_no_new_tuples():
    """
    R(x, y) :- Q(x, z) & Q(z, y) has two atoms of the rules' predicates:
    it sees the whole instance, and was evaluated at each iteration of
    P's closure, although Q has no new tuples after the first one.
    """
    T = S_('T')
    evaluated = []

    class C(ChaseSemiNaive, ChaseNamedRelationalAlgebraMixin, ChaseGeneral):
        def chase_step(self, instance, rule, restriction_instance=None):
            evaluated.append(rule.consequent.functor)
            return super().chase_step(instance, rule, restriction_instance)

    dl = Datalog()
    dl.add_extensional_predicate_from_tuples(E, {(i, i + 1) for i in range(8)})
    dl.add_extensional_predicate_from_tuples(F, {(0, 1), (1, 2)})
    dl.walk(Eb_((
        Imp_(P(x, y), E(x, y)),
        Imp_(P(x, y), P(x, z) & E(z, y)),
        Imp_(Q(x, y), F(x, y)),
        Imp_(T(x, y), Q(x, z) & Q(z, y)),
    )))
    solution = C(dl).build_chase_solution()
    assert set(solution[T].value) == {(0, 2)}
    assert len(solution[P].value) == 36
    assert evaluated.count(T) == 2 < evaluated.count(P) // 2


def test_semi_naive_first_iteration_sees_the_tuples_of_earlier_strata():
    """P(1, 2), from a stratum before the recursive one, is seen by
    Q(x, y) :- P(x, y) in its first iteration, although P(y, x) :- P(x, y)
    has found P(2, 1) before it."""
    from ..chase import Chase

    dl = Datalog()
    dl.add_extensional_predicate_from_tuples(E, {(1, 2)})
    dl.walk(Eb_((
        Imp_(P(x, y), E(x, y)),
        Imp_(P(y, x), P(x, y)),
        Imp_(Q(x, y), P(x, y)),
        Imp_(P(x, y), Q(x, y)),
    )))
    solution = Chase(dl).build_chase_solution()
    assert set(solution[Q].value) == {(1, 2), (2, 1)}


def test_a_chase_that_ran_is_not_kept(chase_class):
    """Nothing keeps a chase once its query is solved: not the caches of
    its rewritings, which hold its program and the relations of its
    query."""
    import gc
    import weakref

    datalog_program = Eb_((
        F_(Q(a)),
        Imp_(T(x), Q(x)),
    ))
    dl = Datalog()
    dl.walk(datalog_program)
    dc = chase_class(dl)
    dc.chase_step(
        MapInstance(dl.extensional_database()), datalog_program.expressions[-1]
    )
    chase = weakref.ref(dc)
    del dc
    gc.collect()
    assert chase() is None


@fixture(params=(ChaseNonRecursive, ChaseNaive, ChaseSemiNaive))
def named_ra_chase_class(request):
    class C(request.param, ChaseNamedRelationalAlgebraMixin, ChaseGeneral):
        pass

    return C


@mark.parametrize(
    "body_args, used",
    [((x,), 1), ((x, y, z), 3)],
)
def test_predicate_with_wrong_number_of_arguments(
    named_ra_chase_class, body_args, used
):
    """A predicate used with fewer or more arguments than the columns of
    its relation is an error, not a match of its leading columns."""
    datalog_program = DT.walk(Eb_((
        F_(Q(C_(1), C_(2))),
        F_(Q(C_(2), C_(3))),
        Imp_(S(x), Q(*body_args)),
    )))
    dl = Datalog()
    dl.walk(datalog_program)
    instance = MapInstance(dl.extensional_database())
    chase = named_ra_chase_class(dl)

    with raises(WrongArgumentsInPredicateError) as error:
        chase.chase_step(instance, datalog_program.formulas[-1])
    assert str(error.value) == f"`Q` has 2 columns but is used with {used}"


def test_predicate_with_the_arity_of_its_relation(named_ra_chase_class):
    datalog_program = DT.walk(Eb_((
        F_(Q(C_(1), C_(2))),
        F_(Q(C_(2), C_(3))),
        Imp_(S(x), Q(x, y)),
        Imp_(T(x, y), Q(x, z) & Q(z, y)),
    )))
    dl = Datalog()
    dl.walk(datalog_program)
    instance = MapInstance(dl.extensional_database())
    chase = named_ra_chase_class(dl)

    update = chase.chase_step(instance, datalog_program.formulas[-2])
    assert update == MapInstance({S: C_({C_((C_(1),)), C_((C_(2),))})})
    update = chase.chase_step(instance, datalog_program.formulas[-1])
    assert update == MapInstance({T: C_({C_((C_(1), C_(3)))})})


def test_empty_relation_is_not_checked_for_its_arity(named_ra_chase_class):
    """The arity of an empty relation is unknown."""
    P = S_('P')
    datalog_program = DT.walk(Eb_((
        F_(Q(C_(1), C_(2))),
        Imp_(S(x), Q(x, y) & P(x)),
    )))
    dl = Datalog()
    dl.walk(datalog_program)
    instance = MapInstance(dl.extensional_database())
    chase = named_ra_chase_class(dl)

    assert len(chase.chase_step(instance, datalog_program.formulas[-1])) == 0
