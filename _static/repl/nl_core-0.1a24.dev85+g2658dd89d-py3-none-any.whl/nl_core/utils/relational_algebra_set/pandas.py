from collections import OrderedDict
from operator import itemgetter
from typing import Iterable, Callable, Dict, Union
from uuid import uuid1

import numpy as np
import pandas as pd
from nl_expr.config import config
from nl_expr.exceptions import IncompatibleJoinColumnsError

from . import abstract as abc
from .abstract import count_distinct, row_type


NA = pd.NA


class RelationalAlgebraStringExpression(str):
    def __repr__(self):
        return "{}{{ {} }}".format(self.__class__.__name__, super().__repr__())


# Set difference strategy for unnamed relations. The element-wise path
# (``collections.abc.Set.__sub__``) runs one ``__contains__`` scan per row
# of the left operand: about 0.28 ms per row, almost independent of the
# size of the right operand. The merge in ``_anti_join`` costs a flat
# ~6 ms. Measured on two-column relations (pandas 3.0, Python 3.12), they
# break even at about 20 rows of the left operand, so the merge is used
# above that. ``benchmarks/ras_operations.py::TimeUnnamedDifference``
# tracks both regimes.
_ANTI_JOIN_MIN_ROWS = 20


def _copy_on_write() -> bool:
    """Whether pandas copies frames on write: always from pandas 3."""
    if int(pd.__version__.split(".")[0]) >= 3:
        return True
    try:
        return pd.get_option("mode.copy_on_write") is True
    except Exception:  # no such option before pandas 1.5
        return False


# With copy-on-write, a set shares the columns of the frame it is made
# from, which cannot change it; without, it copies them.
_COPY_ON_WRITE = _copy_on_write()

# Operations on many rows go by chunks of this many rows, not to hold
# arrays as long as the relation: the activations of the voxels by the
# studies are tens of millions of rows.
_CHUNK_ROWS = 1 << 22


# The reductions computed a chunk at a time, and the reduction of their
# partial results giving that of the whole.
_COMBINED_REDUCTIONS = {
    "sum": "sum", "max": "max", "min": "min", "size": "sum", "count": "sum"
}

# Python's reductions, which pandas runs per group in Python, and the
# pandas reductions computing the same on columns of numbers.
_BUILTIN_REDUCTIONS = {sum: "sum", max: "max", min: "min"}


def _is_text(dtype):
    """Whether *dtype* is a text dtype, not the object dtype of any value."""
    return (
        pd.api.types.is_string_dtype(dtype)
        and not pd.api.types.is_object_dtype(dtype)
    )


class RelationalAlgebraFrozenSet(abc.RelationalAlgebraFrozenSet):
    """
    RelationalAlgebraFrozenSet implementation using in-memory pandas.DataFrame
    as container for the elements.
    """

    def __init__(self, iterable=None):
        """
        Create a new RelationalAlgebraFrozenSet.
        A RelationalAlgebraSet is a set of n elements, each element being
        a tuple of arity k.

        Parameters
        ----------
        iterable : Iterable
            Initial values for the set

        Examples
        --------
        Constructing a Set from a list.

        >>> a = [(i % 2, i, i * 2) for i in range(5)]
        >>> ras = RelationalAlgebraFrozenSet(a)
        >>> ras
           0  1  2
        0  0  0  0
        1  1  1  2
        2  0  2  4
        3  1  3  6
        4  0  4  8

        Returns
        -------
        RelationalAlgebraFrozenSet
        """
        self._container = None
        self._might_have_duplicates = True
        if iterable is not None:
            if isinstance(iterable, RelationalAlgebraFrozenSet):
                self._container = iterable._container
                self._might_have_duplicates = iterable._might_have_duplicates
            elif isinstance(iterable, pd.DataFrame):
                # A deep copy would also join the columns in one block: a
                # second copy of the rows, gigabytes for those of a
                # Euclidean bound.
                self._container = iterable.copy(deep=not _COPY_ON_WRITE)
            else:
                self._container = pd.DataFrame(iterable)

    @property
    def might_have_duplicates(self):
        """Sets the flag manually on whether the set might have duplicates.
        Careful, if you set it to False and it's not, then the semantics of
        the queries will break.

        Returns
        -------
        bool
            returns whether the set might have duplicates.
        """
        return self._might_have_duplicates

    @might_have_duplicates.setter
    def might_have_duplicates(self, value):
        self._might_have_duplicates = bool(value)

    def _drop_duplicates_if_needed(self):
        if self._might_have_duplicates:
            self._container = self._drop_duplicates(self._container)
            self._might_have_duplicates = False

    @classmethod
    def create_view_from(cls, other):
        if not isinstance(other, cls):
            raise ValueError(
                "View can only be created from an object of the same class"
            )
        output = cls()
        output._container = other._container
        output._might_have_duplicates = other._might_have_duplicates
        return output

    @classmethod
    def dee(cls):
        output = cls()
        output._container = pd.DataFrame([()])
        return output

    @classmethod
    def dum(cls):
        return cls()

    def is_empty(self):
        return self._container is None or len(self._container) == 0

    def __contains__(self, element):
        element = self._normalise_element(element)
        if self.is_empty() or self.is_dee() or len(element) != self.arity:
            res = False
        else:
            col = True
            for e, c in zip(element, self._container.items()):
                col = col & (c[1] == e)
            res = col.any()
        return res

    @staticmethod
    def _normalise_element(element):
        if isinstance(element, tuple):
            pass
        elif hasattr(element, "__iter__"):
            element = tuple(element)
        else:
            element = (element,)
        return element

    def __iter__(self):
        if self.is_empty():
            values = {}
        elif self.is_dee():
            values = {tuple()}
        else:
            self._drop_duplicates_if_needed()
            values = self.itervalues()
        for v in values:
            yield tuple(v)

    def fetch_one(self):
        if self.is_dee():
            return tuple()
        return next(self._container.itertuples(name=None, index=False))

    def __len__(self):
        if self._container is None:
            return 0
        self._drop_duplicates_if_needed()
        return len(self._container)

    @staticmethod
    def _drop_duplicates(container):
        if (
            container is None or len(container) == 0
            or len(container.columns) == 0
        ):
            return container
        container = container.drop_duplicates()
        return container

    @property
    def arity(self):
        if self._container is None:
            return 0
        return len(self._container.columns)

    @property
    def columns(self):
        if self._container is not None:
            return self._container.columns
        else:
            return tuple()

    def row_count_estimate(self):
        """
        Return the number of rows of the container.

        Duplicates are not dropped, so this is an upper bound of
        ``len(self)`` obtained without any computation.

        Returns
        -------
        int
            Number of rows of the underlying ``pandas.DataFrame``.

        """
        if self._container is None:
            return 0
        return len(self._container)

    def as_numpy_array(self):
        self._drop_duplicates_if_needed()
        res = self._container.values.view()
        res.setflags(write=False)
        return res

    def as_pandas_dataframe(self):
        self._drop_duplicates_if_needed()
        return self._container

    def _empty_set_same_structure(self):
        return type(self)()

    def projection(self, *columns):
        """
        Projects the set on the given list of columns.

        Examples
        --------
        >>> ras = RelationalAlgebraFrozenSet(
                [(i % 2, i, i * 2) for i in range(5)])
        >>> ras
           0  1  2
        0  0  0  0
        1  1  1  2
        2  0  2  4
        3  1  3  6
        4  0  4  8
        >>> ras.projection(1)
           0
        0  0
        1  1
        2  2
        3  3
        4  4
        """
        if self.is_empty() and (self.arity == 0 or not columns):
            return self._empty_set_same_structure()
        new_container = self._container[list(columns)]
        new_container.columns = pd.RangeIndex(len(columns))
        output = self._empty_set_same_structure()
        output._container = new_container
        if (len(columns) == self.arity):
            output._might_have_duplicates = self._might_have_duplicates
        return output

    def selection(
        self,
        select_criteria: Union[
            Callable,
            RelationalAlgebraStringExpression,
            Dict[int, Union[int, Callable]],
        ],
    ):
        """
        Select the elements based on the given selet_criteria.
        The select_criteria may be a callable function, a string expression
        or a Dict of columns -> value

        Parameters
        ----------
        select_criteria : Union[Callable, RelationalAlgebraStringExpression,
        Dict[int, Union[int, Callable]]]
            selection criteria

        Returns
        -------
        RelationalAlgebraFrozenSet
            A RelationalAlgebraFrozenSet with elements matching the criteria.
        """
        if self.is_empty():
            return self._empty_set_same_structure()

        if isinstance(select_criteria, abc.ColumnwiseFunction):
            ix = select_criteria.of_columns(self._container)
        elif callable(select_criteria):
            ix = self._container.apply(select_criteria, axis=1)
        elif isinstance(
            select_criteria, RelationalAlgebraStringExpression
        ):
            ix = self._container.eval(select_criteria)
        else:
            ix = self._selection_dict(select_criteria)
        ix = ix.astype(bool)
        new_container = self._container[ix]

        output = self._empty_set_same_structure()
        output._container = new_container
        output._might_have_duplicates = self._might_have_duplicates
        return output

    def _selection_dict(self, select_criteria):
        """
        Performs element-wise logical AND on the selection vector returned
        for each item in the select_criteria
        """
        it = iter(select_criteria.items())
        col, value = next(it)
        if callable(value):
            selector = self._container[col].apply(value)
        else:
            selector = self._container[col] == value
        ix = selector
        for col, value in it:
            if callable(value):
                selector = self._container[col].apply(value)
            else:
                selector = self._container[col] == value
            ix &= selector
        return ix

    def selection_columns(self, select_criteria: Dict[int, int]):
        """
        Select the elements where column pairs indicated as key, value
        items of the select_criteria are equal.
        The select_criteria must be a Dict of Int -> Int.

        Examples
        --------
        Select the elements where col0 == col1 and col1 == col2

        >>> ras = RelationalAlgebraFrozenSet(
        ...     [(i % 2, i, i * 2) for i in range(5)])
        >>> ras.selection_columns({0:1, 1: 2})
           0  1  2
        0  0  0  0

        Parameters
        ----------
        select_criteria : Dict [Int, Int]
            selection criteria

        Returns
        -------
        RelationalAlgebraFrozenSet
            A RelationalAlgebraFrozenSet with elements matching the criteria.
        """
        if self.is_empty():
            return self._empty_set_same_structure()
        it = iter(select_criteria.items())
        col1, col2 = next(it)
        ix = self._container[col1] == self._container[col2]
        for col1, col2 in it:
            ix &= self._container[col1] == self._container[col2]

        new_container = self._container[ix]
        output = self._empty_set_same_structure()
        output._container = new_container
        output._might_have_duplicates = self._might_have_duplicates
        return output

    def equijoin(self, other, join_indices):
        res = self._dee_dum_product(other)
        if res is not None:
            return res
        if self.is_empty() or other.is_empty():
            return self._empty_set_same_structure()
        other_columns = range(
            self.arity, other._container.shape[1] + self.arity
        )
        ocont = other._container.copy(deep=False)
        ocont.columns = other_columns
        left_on, right_on = zip(*join_indices)
        left_on = list(left_on)
        right_on = list(l + self.arity for l in right_on)
        new_container = self._container.merge(
            ocont, left_on=left_on, right_on=right_on, sort=False
        )
        output = self._empty_set_same_structure()
        output._container = new_container
        output._might_have_duplicates = (
            self._might_have_duplicates | other._might_have_duplicates
        )
        return output

    def cross_product(self, other):
        res = self._dee_dum_product(other)
        if res is not None:
            return res
        if self.is_empty() or other.is_empty():
            return self._empty_set_same_structure()
        left = self._container.copy(deep=False)
        right = other._container.copy(deep=False)
        tmpcol = str(uuid1())
        left[tmpcol] = 1
        right[tmpcol] = 1
        col_types = self._extract_unified_column_types(other)
        new_container = pd.merge(
            left.astype(col_types),
            right.astype(col_types),
            on=tmpcol
        )
        del new_container[tmpcol]
        new_container.columns = range(new_container.shape[1])
        output = self._empty_set_same_structure()
        output._container = new_container
        output._might_have_duplicates = (
            self._might_have_duplicates | other._might_have_duplicates
        )
        return output

    def _check_joinable(self, other, on):
        """
        Raise if a column of *on* is text in one set, numbers in the other:
        pandas' merge does not compare the types when a set is empty.
        """
        if self.is_empty() or other.is_empty():
            return
        for col in on:
            s_dtype = self._container[col].dtype
            o_dtype = other._container[col].dtype
            if s_dtype != o_dtype and (
                _is_text(s_dtype) and pd.api.types.is_numeric_dtype(o_dtype)
                or _is_text(o_dtype) and pd.api.types.is_numeric_dtype(s_dtype)
            ):
                raise IncompatibleJoinColumnsError(col, s_dtype, o_dtype)

    def _extract_unified_column_types(self, other):
        col_types = dict()
        for col in self._container.columns.intersection(other._container.columns):
            s_dtype = self._container[col].dtype
            o_dtype = other._container[col].dtype
            if s_dtype != o_dtype:
                if isinstance(s_dtype, pd.core.arrays.numeric.NumericDtype):
                    col_types[col] = s_dtype
                elif isinstance(o_dtype, pd.core.arrays.numeric.NumericDtype):
                    col_types[col] = o_dtype
        return col_types

    def copy(self):
        output = self._empty_set_same_structure()
        if len(self) > 0:
            output._container = self._container.copy()
        return output

    def __repr__(self):
        if self.is_empty():
            return "{}"
        return repr(self._container.reset_index().drop("index", axis=1))

    def __sub__(self, other):
        if isinstance(other, RelationalAlgebraFrozenSet):
            if (
                self.arity > 0 and other.arity > 0
            ) and self.arity != other.arity:
                raise ValueError(
                    "Relational algebra set operators can only"
                    " be used on sets with same columns."
                )
            if self.is_empty() or other.is_empty():
                return self.copy()
            if self.is_dee():
                if other.is_dee():
                    return self.dum()
                return self.dee()
            if other.is_dee():
                return self.copy()
            if len(self._container) > _ANTI_JOIN_MIN_ROWS:
                try:
                    return self._anti_join(other)
                except (TypeError, ValueError):
                    # e.g. unhashable values: fall back to element-wise
                    # membership tests
                    pass
        return super().__sub__(other)

    def _anti_join(self, other):
        """
        Compute the rows of ``self`` not in ``other`` with a single merge.

        The generic ``Set.__sub__`` iterates over ``self`` and tests each
        row with ``__contains__``, which scans ``other`` every time.
        """
        self._drop_duplicates_if_needed()
        col_types = self._extract_unified_column_types(other)
        new_container = self._container.astype(col_types).merge(
            other._container.astype(col_types),
            indicator="_merge_indicator_", how="left",
        )
        new_container = new_container.loc[
            new_container["_merge_indicator_"] == "left_only",
            self._container.columns,
        ]
        new_container = new_container.astype(
            self._container.dtypes.to_dict()
        )
        output = self._empty_set_same_structure()
        output._container = new_container.reset_index(drop=True)
        output._might_have_duplicates = False
        return output

    def __or__(self, other):
        if self is other:
            return self.copy()
        elif isinstance(other, RelationalAlgebraFrozenSet):
            res = self._dee_dum_sum(other)
            if res is not None:
                return res
            ocont = other._container
            new_container = pd.merge(
                left=self._container,
                right=ocont,
                how="outer",
            )
            output = self._empty_set_same_structure()
            output._container = new_container
            return output
        else:
            return super().__or__(other)

    def __and__(self, other):
        if self is other:
            return self.copy()
        if isinstance(other, RelationalAlgebraFrozenSet):
            res = self._dee_dum_product(other)
            if res is not None:
                return res
            new_container = pd.merge(
                left=self._container,
                right=other._container,
                how="inner",
            )
            output = self._empty_set_same_structure()
            output._container = new_container
            output._might_have_duplicates = (
                self._might_have_duplicates | other._might_have_duplicates
            )
            return output
        else:
            return super().__and__(other)

    def __eq__(self, other):
        if isinstance(other, type(self)):
            scont = self._container
            ocont = other._container
            if self.is_empty() and other.is_empty():
                res = True
            elif self.arity != other.arity:
                res = False
            elif self.arity == 0 and other.arity == 0:
                res = self.is_dee() and other.is_dee()
            elif scont is not None and ocont is not None:
                intersection_dups = scont.merge(
                    ocont, how="outer", indicator=True
                ).iloc[:, -1]
                res = (intersection_dups == "both").all()
            else:
                res = False
            return res
        else:
            return super().__eq__(other)

    def groupby(self, columns):
        if not self.is_empty():
            if not isinstance(columns, Iterable):
                columns = [columns]
            for g_id, group in self._container.groupby(
                by=list(columns), dropna=False
            ):
                group_set = self._empty_set_same_structure()
                group_set._container = group
                if isinstance(g_id, tuple) and len(g_id) == 1:
                    g_id = g_id[0]
                yield g_id, group_set

    def itervalues(self):
        if self.is_empty():
            return iter([])
        else:
            return iter(self._container.itertuples(name=None, index=False))

    def sample_rows(self, n, contiguous=False):
        if self.is_empty() or self.is_dee():
            return iter([])
        rows = self._container
        if contiguous:
            rows = rows.head(n)
        elif n < len(rows):
            # a Generator chooses n of the rows without permuting them all
            rows = rows.sample(n, random_state=np.random.default_rng(0))
        return iter(rows[list(self.columns)].itertuples(
            name=None, index=False
        ))

    def __hash__(self):
        if self._container is None:
            return hash((tuple(), None))
        self._drop_duplicates_if_needed()
        v = self._container.values
        v.flags.writeable = False
        return hash((tuple(self._container.columns), v.data.tobytes()))


class NamedRelationalAlgebraFrozenSet(
    RelationalAlgebraFrozenSet, abc.NamedRelationalAlgebraFrozenSet
):
    def __init__(self, columns, iterable=None):
        if isinstance(columns, NamedRelationalAlgebraFrozenSet):
            iterable = columns
            columns = columns.columns
        # ensure there is no duplicated column
        self._check_for_duplicated_columns(columns)
        self._columns = tuple(columns)
        self._might_have_duplicates = True
        if iterable is None:
            iterable = []

        if isinstance(iterable, NamedRelationalAlgebraFrozenSet):
            self._initialize_from_named_ra_set(iterable)
            self._might_have_duplicates = iterable._might_have_duplicates
        elif isinstance(iterable, RelationalAlgebraFrozenSet):
            self._initialize_from_unnamed_ra_set(iterable)
            self._might_have_duplicates = iterable._might_have_duplicates
        elif isinstance(iterable, pd.DataFrame):
            self._container = iterable.copy()
            self._container.columns = self._columns
        else:
            self._container = pd.DataFrame(iterable, columns=self._columns)

    def _initialize_from_named_ra_set(self, other):
        if not other.is_dum() and self.arity != other.arity:
            raise ValueError("Relations must have the same arity")

        if not other.is_empty():
            self._container = other._container[list(other.columns)].copy(
                deep=False
            )
        else:
            self._container = pd.DataFrame(columns=self._columns)

    def _initialize_from_unnamed_ra_set(self, other):
        if other.is_empty():
            self._container = pd.DataFrame(columns=self._columns)
        elif other._container is None:
            self._container = pd.DataFrame(list(other), columns=self._columns)
        else:
            if self.arity != other.arity:
                raise ValueError("Relations must have the same arity")
            self._container = other._container.copy(deep=False)
            self._container.columns = self._columns

    @staticmethod
    def _check_for_duplicated_columns(columns):
        if len(set(columns)) != len(columns):
            columns = list(columns)
            dup_cols = set(c for c in columns if columns.count(c) > 1)
            raise ValueError(
                "Duplicated column names are not allowed. "
                f"Found the following duplicated columns: {dup_cols}"
            )

    @classmethod
    def create_view_from(cls, other):
        if not isinstance(other, cls):
            raise ValueError(
                "View can only be created from an object of the same class"
            )
        output = cls(columns=tuple())
        output._container = other._container
        output._columns = other._columns
        output._might_have_duplicates = other._might_have_duplicates
        return output

    def _empty_set_same_structure(self):
        return type(self)(self.columns)

    @classmethod
    def dee(cls):
        output = cls(())
        output._container = pd.DataFrame([()])
        return output

    @classmethod
    def dum(cls):
        return cls(())

    def _light_init_same_structure(
        self, container, might_have_duplicates=True, columns=None
    ):
        if columns is None:
            columns = self.columns
        output = type(self)(columns)
        output._container = container
        output._might_have_duplicates = might_have_duplicates
        return output

    @property
    def columns(self):
        return self._columns

    @property
    def arity(self):
        return len(self._columns)

    def __contains__(self, element):
        if isinstance(element, dict) and len(element) == self.arity:
            element = tuple(element[c] for c in self._container.columns)
        return super().__contains__(element)

    def projection(self, *columns):
        if self.is_empty():
            return type(self)(columns)
        if self.arity == 0:
            return self
        new_container = self._container[list(columns)]
        return self._light_init_same_structure(
            new_container, might_have_duplicates=(
                self._projection_might_have_duplicates(columns)
            ),
            columns=columns
        )

    def _projection_might_have_duplicates(self, columns):
        """
        Return whether projecting on *columns* might give duplicates.

        Parameters
        ----------
        columns : tuple of str
            Projected columns.

        Returns
        -------
        bool
            False when the set has no duplicates and every column is kept.
        """
        return self._might_have_duplicates or len(set(columns)) < self.arity

    def projection_to_unnamed(self, *columns):
        unnamed_self = self.to_unnamed()
        named_columns = list(self.columns)
        columns = tuple(named_columns.index(c) for c in columns)
        return unnamed_self.projection(*columns)

    def equijoin(self, other, join_indices):
        raise NotImplementedError()

    def naturaljoin(self, other):
        res = self._dee_dum_product(other)
        if res is not None:
            return res
        on = [c for c in self.columns if c in other.columns]

        if len(on) == 0:
            return self.cross_product(other)

        self._check_joinable(other, on)
        new_columns = self.columns + tuple(
            c for c in other.columns if c not in self.columns
        )

        self, other = self._cut_by_smaller(other, on)
        self._drop_duplicates_if_needed()
        other._drop_duplicates_if_needed()
        joined = self._lookup_join(other, on, new_columns)
        if joined is not None:
            return joined
        col_types = self._extract_unified_column_types(other)
        new_container = (
            self._container
            .astype(col_types)
            .merge(other._container.astype(col_types))
        )
        return self._light_init_same_structure(
            new_container,
            might_have_duplicates=(
                self._might_have_duplicates | other._might_have_duplicates
            ),
            columns=new_columns,
        )

    def _cut_by_smaller(self, other, on):
        """
        Return *self* and *other*, the larger one cut to its rows whose
        values of the columns *on* are each among the smaller one's, when
        the smaller has at most ``[RAS] join_cut_rows`` rows and the larger
        ``join_cut_ratio`` times as many: the rows the join keeps, and
        some more, read once, before the duplicates of the larger one are
        dropped and it is merged (the magic set of a term, one row, joined
        with the 10 M rows of NeuroStore's TF-IDF: 9.4 s to 3.1 s).
        """
        if self._container is None or other._container is None:
            return self, other
        small, large = sorted(
            (self, other), key=lambda r: len(r._container)
        )
        rows = len(small._container)
        if not (
            0 < rows <= config.getint("RAS", "join_cut_rows") and
            len(large._container) >= rows * config.getint(
                "RAS", "join_cut_ratio"
            )
        ):
            return self, other
        kept = np.ones(len(large._container), dtype=bool)
        for column in on:
            kept &= large._container[column].isin(
                small._container[column].unique()
            ).to_numpy()
        cut = large._light_init_same_structure(
            large._container[kept],
            might_have_duplicates=large._might_have_duplicates,
            columns=large.columns,
        )
        return (cut, other) if large is self else (self, cut)

    def _lookup_join(self, other, on, new_columns):
        """
        Return the natural join with *other* as a look-up, or None.

        When the smaller of the two relations has no two rows with the
        same value of their only common column, as the probabilities of a
        choice have, each row of the larger one matches at most one of its
        rows: the join keeps the rows of the larger one that match, and
        takes the other columns of the row each one matches. Unlike a merge,
        it copies only the columns it takes, and the rows it keeps when
        some do not match. None is returned in the other cases.
        """
        if len(on) != 1 or self.is_empty() or other.is_empty():
            return None
        key = on[0]
        small, large = sorted((other, self), key=len)
        small_key = small._container[key]
        large_key = large._container[key]
        if small_key.dtype != large_key.dtype or not small_key.is_unique:
            return None
        taken = [
            name for name in new_columns if name not in large.columns
        ]
        if not all(
            isinstance(small._container[name].dtype, np.dtype)
            for name in taken
        ):
            return None
        if isinstance(large_key.dtype, np.dtype):
            index = pd.Index(small_key)
            keys = large_key.to_numpy()
        else:
            # Keys such as pandas' strings, held by Arrow, are looked up as
            # their codes: those of the small relation's keys, unique and
            # first, are their positions.
            codes, _ = pd.factorize(
                pd.concat([small_key, large_key], ignore_index=True),
                use_na_sentinel=False,
            )
            index = pd.RangeIndex(len(small_key))
            keys = codes[len(small_key):]
        chunks = range(0, len(keys), _CHUNK_ROWS)
        # The rows matched, then the columns taken, a chunk at a time: the
        # positions of the rows matched are never whole.
        found = np.empty(len(keys), dtype=bool)
        for start in chunks:
            stop = start + _CHUNK_ROWS
            found[start:stop] = index.get_indexer(keys[start:stop]) >= 0
        values = {
            name: np.empty(int(found.sum()), small._container[name].dtype)
            for name in taken
        }
        filled = 0
        for start in chunks:
            stop = start + _CHUNK_ROWS
            position = index.get_indexer(keys[start:stop][found[start:stop]])
            for name in taken:
                values[name][filled:filled + len(position)] = (
                    small._container[name].to_numpy()[position]
                )
            filled += len(position)
        rows = large._container
        if not found.all():
            rows = rows[found]
        rows = rows.reset_index(drop=True)
        columns = {
            name: rows[name] if name in large.columns else values[name]
            for name in new_columns
        }
        return self._light_init_same_structure(
            pd.DataFrame(columns, copy=False),
            might_have_duplicates=(
                self._might_have_duplicates | other._might_have_duplicates
            ),
            columns=new_columns,
        )

    def left_naturaljoin(self, other):
        if self.is_dee():
            return self

        on = [c for c in self.columns if c in other.columns]

        self._drop_duplicates_if_needed()
        other._drop_duplicates_if_needed()

        if len(on) == 0:
            if other.is_empty():
                new_container = self._container.copy()
                for c in other.columns:
                    new_container[c] = pd.NA
            else:
                return self.cross_product(other)
        else:
            self._check_joinable(other, on)
            col_types = self._extract_unified_column_types(other)
            new_container = (
                self._container.astype(col_types)
                .merge(
                    other._container.astype(col_types),
                    how="left"
                )
            )

        new_columns = self.columns + tuple(
            c for c in other.columns if c not in self.columns
        )
        self._keep_column_types_after_join(
            other, new_container, new_columns, check_for_na=True
        )

        return self._light_init_same_structure(
            new_container,
            might_have_duplicates=(
                self._might_have_duplicates | other._might_have_duplicates
            ),
            columns=new_columns,
        )

    def _keep_column_types_after_join(
        self, other, new_container, new_columns,
        check_for_na=False
    ):
        new_columns_types = {}
        for col in new_columns:
            if col in self.columns:
                new_columns_types[col] = self._container[col].dtype
            else:
                new_columns_types[col] = other._container[col].dtype
        self._keep_column_types_list(
            new_container, new_columns_types, check_for_na=check_for_na
        )

    def replace_null(self, column, value):
        if self._container is None:
            return self.copy()

        new_container = self._container.fillna({column: value})
        return self._light_init_same_structure(
            new_container,
            might_have_duplicates=self._might_have_duplicates,
            columns=self.columns,
        )

    def explode(self, src_column, dst_columns):
        if self._container is None:
            return self.copy()

        if dst_columns == src_column:
            # 1. replace original column by exploded one
            new_container = self._container.explode(
                src_column, ignore_index=True
            )
            new_columns = self.columns
        elif not isinstance(dst_columns, tuple):
            # 2. add new column with exploded values
            new_container = self._container.assign(
                **{dst_columns: self._container[src_column]}
            ).explode(dst_columns, ignore_index=True)
            new_columns = self.columns + (dst_columns,)
        else:
            # 3. explode values into multiple columns
            new_container = self._container.assign(
                **{dst_columns[-1]: self._container[src_column]}
            ).explode(dst_columns[-1], ignore_index=True)
            # Pick each tuple position with ``map``: unlike unzipping the
            # tuples, this also yields the columns of an empty relation.
            exploded = new_container[dst_columns[-1]]
            for i, c in enumerate(dst_columns):
                new_container[c] = exploded.map(itemgetter(i))
            new_columns = self.columns + dst_columns
            new_container = new_container[list(new_columns)]

        return self._light_init_same_structure(
            new_container.convert_dtypes(),
            might_have_duplicates=True,
            columns=new_columns,
        )

    def cross_product(self, other):
        res = self._dee_dum_product(other)
        if res is not None:
            return res.copy()
        if len(self._container.columns.intersection(other.columns)) > 0:
            raise ValueError(
                "Cross product with common columns " "is not valid"
            )

        new_columns = self.columns + other.columns
        if self.is_empty() or other.is_empty():
            res = type(self)(new_columns)
        else:
            col_types = self._extract_unified_column_types(other)
            left = self._container.copy(deep=False).astype(col_types)
            right = other._container.copy(deep=False).astype(col_types)
            tmpcol = str(uuid1())
            left[tmpcol] = 1
            right[tmpcol] = 1
            new_container = pd.merge(left, right, on=tmpcol)
            del new_container[tmpcol]
            new_container.columns = tuple(self._container.columns) + tuple(
                other._container.columns
            )
            res = self._light_init_same_structure(
                new_container,
                might_have_duplicates=(
                    self._might_have_duplicates | other._might_have_duplicates
                ),
                columns=new_columns,
            )
        return res

    def rename_column(self, src, dst):
        if self.is_dum():
            return self
        if src not in self._columns:
            raise ValueError(f"{src} not in columns")
        if src == dst:
            return self
        if dst in self._columns:
            raise ValueError(f"{dst} cannot be in the columns")
        src_idx = self._columns.index(src)
        new_columns = (
            self._columns[:src_idx] + (dst,) + self._columns[src_idx + 1 :]
        )
        new_container = self._container.rename(columns={src: dst})
        return self._light_init_same_structure(
            new_container,
            might_have_duplicates=self._might_have_duplicates,
            columns=new_columns,
        )

    def rename_columns(self, renames):
        if self.is_dum():
            return self
        # prevent duplicated destination columns
        self._check_for_duplicated_columns(renames.values())
        if not set(renames).issubset(self.columns):
            # get the missing source columns
            # for a more convenient error message
            not_found_cols = set(c for c in renames if c not in self._columns)
            raise ValueError(
                f"Cannot rename non-existing columns: {not_found_cols}"
            )
        new_columns = tuple(renames.get(col, col) for col in self._columns)
        new_container = self._container.rename(columns=renames)
        return self._light_init_same_structure(
            new_container,
            might_have_duplicates=self._might_have_duplicates,
            columns=new_columns,
        )

    def __eq__(self, other):
        scont = self._container
        ocont = other._container
        if len(scont.columns.symmetric_difference(ocont.columns)) > 0:
            res = False
        elif len(scont) == 0 and len(ocont) == 0:
            res = True
        elif len(scont.columns) == 0 and len(ocont.columns) == 0:
            res = len(scont) > 0 and len(ocont) > 0
        else:
            intersection_dups = scont.merge(
                ocont, how="outer", indicator=True
            ).iloc[:, -1]
            res = (intersection_dups == "both").all()
        return res

    def groupby(self, columns):
        if self.is_empty():
            return
        for g_id, group in self._container.groupby(
            by=list(columns), dropna=False
        ):
            group_set = self._light_init_same_structure(
                group,
                might_have_duplicates=self._might_have_duplicates,
                columns=self.columns,
            )
            if isinstance(g_id, tuple) and len(g_id) == 1:
                g_id = g_id[0]
            yield g_id, group_set

    def aggregate(self, group_columns, aggregate_function):
        group_columns = list(group_columns)
        if len(set(group_columns)) < len(group_columns):
            raise ValueError("Cannot group on repeated columns")
        if self.is_dee():
            raise ValueError(
                "Aggregation on non-empty sets with arity == 0 is unsupported."
            )
        if self.is_empty():
            if isinstance(aggregate_function, dict):
                agg_columns = list(aggregate_function.keys())
            elif isinstance(aggregate_function, (tuple, list)):
                agg_columns = list(col for col, _, _ in aggregate_function)
            return NamedRelationalAlgebraFrozenSet(
                columns=group_columns + agg_columns
            )
        self._drop_duplicates_if_needed()
        if len(group_columns) > 0:
            # A set has no order: sorting the groups would only cost memory.
            groups = self._container.groupby(
                group_columns, dropna=False, sort=False
            )
        else:
            groups = self._container.groupby(lambda x: 0, dropna=False)

        aggs, aggs_multi_column = self._classify_aggregations(
            group_columns, aggregate_function
        )

        new_containers = []
        if self._by_chunks(group_columns, aggs, aggs_multi_column):
            new_containers.append(self._aggregate_by_chunks(
                group_columns, aggs
            ))
        elif len(aggs) > 0:
            new_containers.append(groups.agg(**aggs))

        for dst, fun in aggs_multi_column.items():
            new_col = (
                self._apply_aggregation(groups, fun)
                .rename(dst)
                .to_frame()
            )
            new_containers.append(new_col)

        new_container = pd.concat(new_containers, axis=1)

        if len(group_columns) > 0:
            new_container = new_container.reset_index()

        self._keep_column_types(
            new_container, set(aggs) | set(aggs_multi_column)
        )

        output = self._light_init_same_structure(
            new_container,
            might_have_duplicates=False,
            columns=list(new_container.columns),
        )
        return output

    def _by_chunks(self, group_columns, aggs, aggs_multi_column):
        """Whether the aggregation is computed a chunk of rows at a time:
        a grouped one of many rows by reductions combining their partial
        results (see ``_COMBINED_REDUCTIONS``)."""
        return (
            len(self._container) > _CHUNK_ROWS
            and len(group_columns) > 0
            and len(aggs) > 0
            and not aggs_multi_column
            and all(
                isinstance(named.aggfunc, str)
                and named.aggfunc in _COMBINED_REDUCTIONS
                for named in aggs.values()
            )
        )

    def _aggregate_by_chunks(self, group_columns, aggs):
        """
        Return the aggregation *aggs* grouped by *group_columns*, computed
        a chunk of rows at a time and combined: grouping all the rows at
        once makes arrays of group codes as long as the relation.
        """
        container = self._container
        partials = pd.concat([
            container.iloc[start:start + _CHUNK_ROWS]
            .groupby(group_columns, dropna=False, sort=False)
            .agg(**aggs)
            for start in range(0, len(container), _CHUNK_ROWS)
        ])
        return partials.groupby(
            level=list(range(len(group_columns))), dropna=False, sort=False
        ).agg(**{
            dst: pd.NamedAgg(dst, _COMBINED_REDUCTIONS[named.aggfunc])
            for dst, named in aggs.items()
        })

    @staticmethod
    def _apply_aggregation(groups, fun):
        fun_dict = {len: 'count', **_BUILTIN_REDUCTIONS}
        if fun in fun_dict:
            res = getattr(groups, fun_dict[fun])()
            res = res.iloc[:, 0]
        else:
            res = groups.apply(fun)
        return res

    def _keep_column_types(self, new_container, skip=None, check_for_na=True):
        column_types = {
            col: self._container[col].dtype
            for col in self._container.columns
        }

        return self._keep_column_types_list(
            new_container, column_types,
            skip=skip, check_for_na=check_for_na
        )

    def _keep_column_types_list(
        self, new_container, column_types,
        skip=None, check_for_na=False
    ):
        if self.is_empty():
            return

        if skip is None:
            skip = {}
        for col in new_container.columns:
            if col in skip:
                continue
            if (
                col in column_types
                and new_container[col].dtype != column_types[col]
            ):
                if (
                    check_for_na and
                    isinstance(column_types[col], np.dtype) and
                    column_types[col].kind == 'i' and
                    new_container[col].hasnans
                ):
                    column_type = getattr(
                        pd,
                        f"Int{column_types[col].itemsize * 8}Dtype"
                    )()
                else:
                    column_type = column_types[col]
                new_container[col] = new_container[col].astype(
                    column_type
                )

    def _classify_aggregations(self, group_columns, aggregate_function):
        aggs = OrderedDict()
        aggs_multi_columns = OrderedDict()
        if isinstance(aggregate_function, dict):
            arg_iterable = (
                (k, k if k in self.columns else None, v)
                for k, v in aggregate_function.items()
            )
        elif isinstance(aggregate_function, (tuple, list)):
            arg_iterable = aggregate_function
        else:
            raise ValueError(
                "Unsupported aggregate_function: {} of type {}".format(
                    aggregate_function, type(aggregate_function)
                )
            )

        for dst, src, fun in arg_iterable:
            if dst in group_columns:
                raise ValueError(
                    f"Destination column {dst} can't be part of the grouping"
                )
            if src in self.columns:
                aggs[dst] = pd.NamedAgg(src, self._reduction(src, fun))
            elif src is None or all(s in self.columns for s in src):
                aggs_multi_columns[dst] = fun
            else:
                raise ValueError(f"Source column {src} not in columns")

        return aggs, aggs_multi_columns

    def _reduction(self, column, fun):
        """
        Return the pandas reduction computing *fun* on *column*, or *fun*.

        Python's ``sum``, ``max`` and ``min`` are pandas' on a column of
        numbers without missing values (Python's give NaN, or an order
        dependent result, on one with them), and ``len`` is the size of
        each group. ``count_distinct`` is pandas' ``nunique`` on a column
        without missing values.
        """
        if fun is len:
            return "size"
        if fun is count_distinct and not self._container[column].hasnans:
            return "nunique"
        if fun not in _BUILTIN_REDUCTIONS:
            return fun
        values = self._container[column]
        if values.dtype.kind in "iuf" and not values.hasnans:
            return _BUILTIN_REDUCTIONS[fun]
        return fun

    def extended_projection(self, eval_expressions):
        proj_columns = list(eval_expressions.keys())
        if self.is_empty():
            return NamedRelationalAlgebraFrozenSet(
                columns=proj_columns,
                iterable=[],
            )
        if any(callable(op) for op in eval_expressions.values()):
            # Python callables run once per row: don't run them on duplicates
            self._drop_duplicates_if_needed()
        new_container = self._container.copy()
        new_container = new_container.infer_objects()
        seen_pure_columns = set()
        for dst_column, operation in eval_expressions.items():
            if isinstance(operation, RelationalAlgebraStringExpression):
                if str(operation) != str(dst_column):
                    new_container.eval(
                        "{}={}".format(str(dst_column), str(operation)),
                        engine="python",
                        inplace=True
                    )
            elif isinstance(operation, abc.RelationalAlgebraColumn):
                seen_pure_columns.add(operation)
                new_container[dst_column] = new_container.loc[:, operation]
            elif isinstance(operation, abc.ColumnwiseFunction):
                new_container[dst_column] = operation.of_columns(
                    new_container
                )
            elif callable(operation):
                # A row as a tuple read by label: a pandas row of
                # DataFrame.apply costs ten times the function, e.g.
                # query_similarity over the 65,000 studies of NeuroStore.
                row = row_type(new_container.columns)
                new_container[dst_column] = [
                    operation(row(values)) for values in
                    new_container.itertuples(index=False, name=None)
                ]
            else:
                new_container[dst_column] = operation
        new_container = new_container.loc[:, proj_columns]
        might_have_duplicates = not (
            (len(seen_pure_columns) == len(self.columns))
            and not self._might_have_duplicates
        )
        output = self._light_init_same_structure(
            new_container,
            might_have_duplicates=might_have_duplicates,
            columns=proj_columns,
        )
        return output

    def __iter__(self):
        self._drop_duplicates_if_needed()
        if self.is_dee():
            return iter([tuple()])
        container = self._container[list(self.columns)]
        return container.itertuples(index=False, name="tuple")

    def fetch_one(self):
        if self.is_dee():
            return tuple()
        container = self._container[list(self.columns)]
        return next(container.itertuples(index=False, name="tuple"))

    def to_unnamed(self):
        container = self._container[list(self.columns)]
        container.columns = range(len(container.columns))
        output = RelationalAlgebraFrozenSet()
        output._container = container
        output._might_have_duplicates = self._might_have_duplicates
        return output

    def __sub__(self, other):
        if (self.arity > 0 and other.arity > 0) and len(
            self._container.columns.difference(other._container.columns)
        ) > 0:
            raise ValueError(
                "Difference defined only for sets with the same columns"
            )
        if self.is_empty() or other.is_empty():
            return self.copy()
        if self.is_dee():
            if other.is_dee():
                return self.dum()
            return self.dee()
        self._drop_duplicates_if_needed()
        other._drop_duplicates_if_needed()

        self._check_joinable(other, list(self.columns))
        col_types = self._extract_unified_column_types(other)

        new_container = (
            self._container
            .astype(col_types)
            .merge(
                other._container.astype(col_types),
                indicator=True, how="left"
            )
        )
        new_container = new_container[
            new_container.iloc[:, -1] == "left_only"
        ].iloc[:, :-1]

        self._keep_column_types(new_container)
        output = self._light_init_same_structure(
            new_container,
            might_have_duplicates=self._might_have_duplicates,
        )
        return output

    def __or__(self, other):
        res = self._dee_dum_sum(other)
        if res is not None:
            return res
        elif set(self.columns) != set(other.columns):
            raise ValueError(
                "Union defined only for sets with the same columns"
            )

        col_types = self._extract_unified_column_types(other)
        # Integers and floats in a column are floats, not integers, which
        # would truncate the floats.
        numbers = {
            col: pd.core.dtypes.cast.find_common_type(
                [self._container[col].dtype, other._container[col].dtype]
            )
            for col in self._container.columns
            if self._container[col].dtype.kind in "iuf" and
            other._container[col].dtype.kind in "iuf" and
            self._container[col].dtype != other._container[col].dtype
        }
        col_types.update(numbers)

        new_container = pd.concat(
            [
                self._container.astype(col_types),
                other._container.astype(col_types),
            ],
            ignore_index=True,
        )

        self._keep_column_types(new_container, skip=numbers)
        output = self._light_init_same_structure(
            new_container,
            might_have_duplicates=True,
        )
        return output

    def __and__(self, other):
        res = self._dee_dum_product(other)
        if res is not None:
            return res
        if set(self.columns) != set(other.columns):
            raise ValueError(
                "Union defined only for sets with the same columns"
            )
        if self.is_empty():
            return self.copy()
        self._drop_duplicates_if_needed()
        other._drop_duplicates_if_needed()
        col_types = self._extract_unified_column_types(other)
        new_container = pd.merge(
            left=self._container.astype(col_types),
            right=other._container.astype(col_types),
            how="inner",
        )
        self._keep_column_types(new_container)
        output = self._light_init_same_structure(
            new_container,
            might_have_duplicates=(
                self._might_have_duplicates & other._might_have_duplicates
            ),
        )
        return output

    def __lt__(self, other):
        raise NotImplementedError()

    def __le__(self, other):
        raise NotImplementedError()

    def __gt__(self, other):
        raise NotImplementedError()

    def __ge__(self, other):
        raise NotImplementedError()


class RelationalAlgebraSet(
    RelationalAlgebraFrozenSet, abc.RelationalAlgebraSet
):
    def add(self, value):
        value = self._normalise_element(value)
        if self.is_empty():
            self._container = pd.DataFrame([value])
        else:
            new_row = pd.DataFrame([value], columns=self._container.columns)
            self._container = pd.concat(
                [self._container, new_row], ignore_index=True
            )

    def discard(self, value):
        if not self.is_empty():
            try:
                value = self._normalise_element(value)
                col = True
                for e, c in zip(value, self._container.items()):
                    col = col & (c[1] == e)
                ix = self._container.index[col]
                self._container.drop(index=ix, inplace=True)
            except KeyError:
                pass

    def __ior__(self, other):
        if isinstance(other, RelationalAlgebraSet):
            if other.is_empty() or other.arity == 0:
                return self
            if self.is_empty():
                self._container = other._container.copy()
                self._might_have_duplicates = other._might_have_duplicates
                return self
            if other.arity != self.arity:
                raise ValueError(
                    "Operation only valid for sets with the same arity"
                )
            new_container = pd.merge(
                left=self._container,
                right=other._container,
                how="outer",
            )
            self._might_have_duplicates = True
            self._container = new_container
            return self
        else:
            return super().__ior__(other)

    def __isub__(self, other):
        if self.is_empty():
            return self
        if isinstance(other, RelationalAlgebraSet):
            if other.is_empty() or other.arity == 0:
                if self.is_empty() or self.arity == 0:
                    self._container = self._container.iloc[:0]
            elif other.arity != self.arity:
                raise ValueError(
                    "Operation only valid for sets with the same arity"
                )
            else:
                new_container = pd.merge(
                    left=self._container,
                    right=other._container,
                    how="left",
                    indicator=True,
                )
                new_container = new_container[
                    new_container.iloc[:, -1] == "left_only"
                ].iloc[:, :-1]
                self._container = new_container
            return self
        else:
            return super().__isub__(other)
