from abc import abstractmethod, abstractproperty
from collections.abc import Iterable, MutableSet, Set

class RelationalAlgebraColumn:
    pass


class ColumnwiseFunction:
    """
    A function of named columns whose operations numpy applies to whole
    columns as to one row's values (comparisons, arithmetic, functions
    marked ``columnwise``): called with a row, an object of its columns as
    attributes, it gives the row's value, as any callable of a selection
    or a projection; a backend that can calls :meth:`of_columns` once,
    with the columns' arrays, rather than once a row.
    """

    def __init__(self, function, columns):
        self.function, self.columns = function, tuple(columns)

    def __call__(self, row):
        return self.function(**{c: getattr(row, c) for c in self.columns})

    def of_columns(self, columns):
        """The values of the rows, from *columns*, a mapping of the names
        of the columns to their arrays."""
        return self.function(**{c: columns[c] for c in self.columns})


def count_distinct(*columns: Iterable) -> int:
    """
    Return the number of distinct tuples of the values of *columns*, the
    aggregation ``count``: ``P(x, count(y)) :- Q(x, y, z)`` counts the
    ``y`` of each ``x``, not the pairs ``(y, z)``.
    """
    if len(columns) == 1:
        return len(set(columns[0]))
    return len(set(zip(*columns)))


def row_type(columns):
    """
    The type of the rows of *columns* given to a function of a row by
    ``extended_projection``: tuples of their values whose column is read
    as an attribute or by its label, whatever the label (``_x`` as well).
    """
    positions = {column: i for i, column in enumerate(columns)}

    class Row(tuple):
        __slots__ = ()

        def __getattr__(self, name):
            if name not in positions:
                raise AttributeError(name)
            return tuple.__getitem__(self, positions[name])

        def __getitem__(self, label):
            return tuple.__getitem__(self, positions[label])

    return Row


class RelationalAlgebraColumnInt(int, RelationalAlgebraColumn):
    pass


class RelationalAlgebraColumnStr(str, RelationalAlgebraColumn):
    pass


class RelationalAlgebraFrozenSet(Set):
    def __init__(self, columns):
        raise NotImplementedError()

    @classmethod
    def create_view_from(cls, other):
        raise NotImplementedError()

    @classmethod
    def dee(cls):
        raise NotImplementedError()

    @classmethod
    def dum(cls):
        raise NotImplementedError()

    @abstractmethod
    def is_empty(self):
        pass

    def is_dum(self):
        return self.arity == 0 and self.is_empty()

    def is_dee(self):
        return self.arity == 0 and not self.is_empty()

    @abstractmethod
    def __contains__(self, element):
        pass

    @abstractmethod
    def __iter__(self):
        pass

    @abstractmethod
    def fetch_one(self):
        pass

    @abstractproperty
    def arity(self):
        pass

    @abstractproperty
    def columns(self):
        pass

    @abstractmethod
    def projection(self, *columns):
        pass

    @abstractmethod
    def selection(self, select_criteria):
        pass

    @abstractmethod
    def selection_columns(self, select_criteria):
        pass

    @abstractmethod
    def equijoin(self, other, join_indices):
        pass

    @abstractmethod
    def cross_product(self, other):
        pass

    @abstractmethod
    def copy(self):
        pass

    @abstractmethod
    def groupby(self, columns):
        pass

    @abstractmethod
    def itervalues(self):
        pass

    @abstractmethod
    def as_numpy_array(self):
        pass

    def sample_rows(self, n, contiguous=False):
        """
        Return an iterator of at most *n* rows of the set chosen at random,
        always the same for one set, or its first *n* rows if *contiguous*,
        tuples in the order of its columns, read without dropping
        duplicates (so without reading the whole set), or None if the
        backend cannot. A sample to disprove a property of the set with,
        cheaply.
        """
        return None

    def row_count_estimate(self):
        """
        Return a cheap upper bound of the number of rows of the set.

        The estimate must not trigger any deduplication or materialisation
        of the set, it is meant for query planning. Backends that cannot
        provide one cheaply return ``None``.

        Returns
        -------
        int or None
            Upper bound of the number of rows, or ``None`` if unknown.

        """
        return None

    def _dee_dum_product(self, other):
        res = None
        if self.is_dum():
            res = self
        elif other.is_dum():
            res = other
        elif self.is_dee():
            res = other
        elif other.is_dee():
            res = self
        return res

    def _dee_dum_sum(self, other):
        res = None
        if self.is_dum():
            res = other
        elif other.is_dum():
            res = self
        elif self.is_dee() and other.is_dee():
            return self
        return res


class NamedRelationalAlgebraFrozenSet(RelationalAlgebraFrozenSet):
    def __init__(self, columns, iterable=None):
        raise NotImplementedError()

    @classmethod
    def dee(cls):
        raise NotImplementedError()

    @classmethod
    def dum(cls):
        raise NotImplementedError()

    @abstractproperty
    def columns(self):
        pass

    @abstractproperty
    def arity(self):
        pass

    @abstractmethod
    def __contains__(self, element):
        pass

    @abstractmethod
    def projection(self, *columns):
        pass

    def equijoin(self, other, join_indices):
        raise NotImplementedError()

    @abstractmethod
    def naturaljoin(self, other):
        pass

    @abstractmethod
    def left_naturaljoin(self, other):
        pass

    @abstractmethod
    def cross_product(self, other):
        pass

    @abstractmethod
    def rename_column(self, src, dst):
        pass

    @abstractmethod
    def rename_columns(self, renames):
        pass

    @abstractmethod
    def groupby(self, columns):
        pass

    @abstractmethod
    def aggregate(self, group_columns, aggregate_function):
        pass

    @abstractmethod
    def extended_projection(self, eval_expressions):
        pass

    @abstractmethod
    def replace_null(self, dst_column, value):
        pass

    @abstractmethod
    def explode(self, src_column, dst_columns):
        pass

    @abstractmethod
    def __iter__(self):
        pass

    @abstractmethod
    def fetch_one(self):
        pass

    @abstractmethod
    def to_unnamed(self):
        pass

    @abstractmethod
    def projection_to_unnamed(self, *columns):
        pass

    def __lt__(self, other):
        raise NotImplementedError()

    def __le__(self, other):
        raise NotImplementedError()

    def __gt__(self, other):
        raise NotImplementedError()

    def __ge__(self, other):
        raise NotImplementedError()


class RelationalAlgebraSet(RelationalAlgebraFrozenSet, MutableSet):
    @abstractmethod
    def add(self, value):
        pass

    @abstractmethod
    def discard(self, value):
        pass
