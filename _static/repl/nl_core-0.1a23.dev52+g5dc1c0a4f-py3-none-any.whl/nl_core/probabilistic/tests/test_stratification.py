import pytest

from ...datalog.expressions import Fact
from nl_expr.exceptions import (
    ForbiddenRecursivityError,
    UnsupportedProgramError,
)
from nl_expr.expressions import Constant, Symbol
from nl_expr.logic import TRUE, Conjunction, Implication, Union
from ..cplogic.program import CPLogicProgram
from ..expressions import PROB, ProbabilisticFact, ProbabilisticQuery
from ..query_resolution import QueryBasedProbFactToDetRule
from .. import stratification
from ..stratification import stratify_program

P = Symbol("P")
Q = Symbol("Q")
R = Symbol("R")
Z = Symbol("Z")
S = Symbol("S")
T = Symbol("T")
A = Symbol("A")
B = Symbol("B")
C = Symbol("C")
WLQ = Symbol("WLQ")
WLQ1 = Symbol("WLQ1")
WLQ2 = Symbol("WLQ2")
Query = Symbol("Query")
x = Symbol("x")
y = Symbol("y")
p = Symbol("p")
p1 = Symbol("p1")
p2 = Symbol("p2")
a = Constant("a")
b = Constant("b")
c = Constant("c")


def test_stratify_deterministic():
    code = Union(
        (
            Fact(Q(a)),
            Fact(R(b)),
            Fact(S(a)),
            Implication(P(x, y), Conjunction((Q(x), R(y)))),
            Implication(Z(x), S(x)),
        )
    )
    program = CPLogicProgram()
    program.walk(code)
    query = Implication(Query(y), Conjunction((Z(x), P(x, y))))
    idbs = stratify_program(query, program)
    assert len(idbs["deterministic"].formulas) == 2
    assert "probabilistic" not in idbs
    assert "post_probabilistic" not in idbs


def test_stratify_several_queries_together():
    code = Union(
        (
            Fact(Q(a)),
            Fact(R(b)),
            Fact(S(a)),
            Implication(P(x, y), Conjunction((Q(x), R(y)))),
            Implication(Z(x), S(x)),
        )
    )
    program = CPLogicProgram()
    program.walk(code)
    through_p = Implication(Query(y), Conjunction((P(x, y),)))
    through_z = Implication(Symbol("Other")(x), Conjunction((Z(x),)))
    alone = [
        stratify_program(query, program)["deterministic"].formulas
        for query in (through_p, through_z)
    ]
    together = stratify_program([through_p, through_z], program)
    assert set(together["deterministic"].formulas) == set(alone[0] + alone[1])
    assert len(together["deterministic"].formulas) == 2


def test_stratify_deterministic_probabilistic():
    code = Union(
        (
            Fact(Q(a)),
            Fact(R(b)),
            Implication(ProbabilisticFact(Constant(0.5), S(a)), TRUE),
            Implication(P(x, y), Conjunction((Q(x), R(y)))),
            Implication(Z(x), S(x)),
        )
    )
    program = CPLogicProgram()
    program.walk(code)
    query = Implication(Query(y), Conjunction((Z(x), P(x, y))))
    idbs = stratify_program(query, program)
    assert len(idbs["deterministic"].formulas) == 1
    assert idbs["deterministic"].formulas[0].consequent.functor == P
    assert len(idbs["probabilistic"].formulas) == 1
    assert idbs["probabilistic"].formulas[0].consequent.functor == Z
    assert "post_probabilistic" not in idbs


def test_stratify_deterministic_probabilistic_wlq():
    det_idb = [
        Implication(P(x, y), Conjunction((Q(x), R(y)))),
    ]
    prob_idb = [
        Implication(Z(x), S(x)),
        Implication(
            WLQ(x, y, ProbabilisticQuery(PROB, (x, y))),
            Conjunction((P(x, y), Z(x))),
        ),
    ]
    ppq_det_idb = [
        Implication(B(x, p), Conjunction((A(x), A(y), WLQ(x, y, p)))),
    ]
    code = Union(
        [
            Fact(Q(a)),
            Fact(R(b)),
            Implication(ProbabilisticFact(Constant(0.5), S(a)), TRUE),
            Fact(A(b)),
            Fact(C(b)),
        ]
        + det_idb
        + prob_idb
        + ppq_det_idb
    )
    program = CPLogicProgram()
    program.walk(code)
    query = Implication(Query(x, p), Conjunction((B(x, p), C(x))))
    idbs = stratify_program(query, program)
    assert set(idbs["deterministic"].formulas) == set(det_idb)
    assert set(idbs["probabilistic"].formulas) == set(prob_idb)
    assert set(idbs["post_probabilistic"].formulas) == set(ppq_det_idb)


def test_stratify_multiple_wlqs():
    det_idb = [
        Implication(P(x, y), Conjunction((Q(x), R(y)))),
    ]
    prob_idb = [
        Implication(Z(x), Conjunction((S(x), T(x, y)))),
        Implication(
            WLQ1(x, y, ProbabilisticQuery(PROB, (x, y))),
            Conjunction((P(x, y), Z(x))),
        ),
        Implication(
            WLQ2(y, ProbabilisticQuery(PROB, (y,))),
            Conjunction((P(y, y), Z(y))),
        ),
    ]
    ppq_det_idb = [
        Implication(
            B(x, p1, p2),
            Conjunction((A(x), A(y), WLQ1(x, y, p1), WLQ2(y, p2))),
        ),
    ]
    code = Union(
        [
            Fact(Q(a)),
            Fact(R(b)),
            Implication(ProbabilisticFact(Constant(0.5), S(a)), TRUE),
            Implication(ProbabilisticFact(Constant(0.5), T(a)), TRUE),
            Fact(A(b)),
            Fact(C(b)),
        ]
        + det_idb
        + prob_idb
        + ppq_det_idb
    )
    program = CPLogicProgram()
    program.walk(code)
    query = Implication(Query(x, p1, p2), Conjunction((B(x, p1, p2), C(x))))
    idbs = stratify_program(query, program)
    assert set(idbs["deterministic"].formulas) == set(det_idb)
    assert set(idbs["probabilistic"].formulas) == set(prob_idb)
    assert set(idbs["post_probabilistic"].formulas) == set(ppq_det_idb)


def test_wlq_dependence_on_other_wlq():
    det_idb = [
        Implication(P(x, y), Conjunction((Q(x), R(y)))),
    ]
    prob_idb = [
        Implication(Z(x), Conjunction((S(x), T(x, y)))),
        Implication(
            WLQ1(x, y, ProbabilisticQuery(PROB, (x, y))),
            Conjunction((P(x, y), Z(x))),
        ),
        Implication(
            WLQ2(y, p, ProbabilisticQuery(PROB, (y, p))),
            Conjunction((WLQ1(y, y, p), Z(y))),
        ),
    ]
    code = Union(
        [
            Fact(Q(a)),
            Fact(R(b)),
            Implication(ProbabilisticFact(Constant(0.5), S(a)), TRUE),
            Implication(ProbabilisticFact(Constant(0.5), T(a)), TRUE),
        ]
        + det_idb
        + prob_idb
    )
    program = CPLogicProgram()
    program.walk(code)
    query = Implication(Query(x, p), Conjunction((WLQ2(x, p), C(x))))
    with pytest.raises(UnsupportedProgramError):
        stratify_program(query, program)


def test_cannot_stratify_recursive_program():
    prob_idb = [
        Implication(B(x), Conjunction((A(x), C(x)))),
        Implication(A(x), B(x)),
    ]
    code = Union(
        [
            Fact(C(a)),
            Fact(C(b)),
        ]
        + prob_idb
    )
    program = CPLogicProgram()
    program.walk(code)
    query = Implication(Query(x), A(x))
    with pytest.raises(ForbiddenRecursivityError):
        stratify_program(query, program)


def test_stratification_multiple_post_probabilistic_rules():
    facts = [Fact(R(a)), Fact(R(b)), Fact(B(a)), Fact(B(c)), Fact(B(b))]
    det_idb = [Implication(A(x, y), Conjunction((B(y), R(x))))]
    pfacts = [
        Implication(ProbabilisticFact(Constant(0.2), C(a, b)), TRUE)
    ]
    prob_idb = [
        Implication(
            WLQ(x, y, ProbabilisticQuery(PROB, (x, y))),
            Conjunction((A(x, y), C(x, y))),
        )
    ]
    post_prob_idb = [
        Implication(Z(x, p), Conjunction((WLQ(x, y, p), R(y)))),
        Implication(T(p), Z(x, p)),
    ]
    code = Union(tuple(facts + pfacts + prob_idb + det_idb + post_prob_idb))
    program = CPLogicProgram()
    program.walk(code)
    query = Implication(Query(x), T(x))
    idbs = stratify_program(query, program)
    assert set(idbs["deterministic"].formulas) == set(det_idb)
    assert set(idbs["probabilistic"].formulas) == set(prob_idb)
    assert set(idbs["post_probabilistic"].formulas) == set(post_prob_idb)


def _stratify_with_rules_in_order(query, program, rules, monkeypatch):
    """Stratify *program* with its reachable rules in the order *rules*."""
    monkeypatch.setattr(
        stratification, "reachable_code_from_query",
        lambda query, program: Union(tuple(rules)),
    )
    return stratify_program(query, program)


@pytest.mark.parametrize("reverse", [False, True])
def test_predicate_with_a_deterministic_and_a_probabilistic_rule(
    reverse, monkeypatch
):
    """
    A predicate with a deterministic rule and a probabilistic one is
    probabilistic, whatever the order of its rules. Typed from its first
    rule, it was deterministic when the deterministic rule came first,
    and its probabilistic rule was solved as a deterministic one.
    """
    pfacts = [Implication(ProbabilisticFact(Constant(0.5), S(a)), TRUE)]
    rules = [
        Implication(Z(x), Conjunction((Q(x), R(x)))),
        Implication(Z(x), Conjunction((Q(x), S(x)))),
    ]
    program = CPLogicProgram()
    program.walk(Union(tuple([Fact(Q(a)), Fact(R(b))] + pfacts + rules)))
    if reverse:
        rules = rules[::-1]
    idbs = _stratify_with_rules_in_order(
        Implication(Query(x), Z(x)), program, rules, monkeypatch
    )
    assert set(idbs["probabilistic"].formulas) == set(rules)
    assert "deterministic" not in idbs


@pytest.mark.parametrize("reverse", [False, True])
def test_predicate_with_a_deterministic_and_a_post_probabilistic_rule(
    reverse, monkeypatch
):
    """
    A predicate with a deterministic rule and one using the result of a
    probabilistic query is post-probabilistic, whatever their order.
    """
    pfacts = [Implication(ProbabilisticFact(Constant(0.5), S(a)), TRUE)]
    wlq = Implication(WLQ(x, ProbabilisticQuery(PROB, (x,))), S(x))
    rules = [
        Implication(Z(x, y), Conjunction((Q(x), R(y)))),
        Implication(Z(x, p), WLQ(x, p)),
    ]
    program = CPLogicProgram()
    program.walk(
        Union(tuple([Fact(Q(a)), Fact(R(b))] + pfacts + [wlq] + rules))
    )
    if reverse:
        rules = rules[::-1]
    idbs = _stratify_with_rules_in_order(
        Implication(Query(x, y), Z(x, y)), program, rules + [wlq], monkeypatch
    )
    assert set(idbs["post_probabilistic"].formulas) == set(rules)
    assert set(idbs["probabilistic"].formulas) == {wlq}
    assert "deterministic" not in idbs


@pytest.mark.parametrize("reverse", [False, True])
def test_mutually_recursive_predicates_share_their_type(reverse, monkeypatch):
    """
    Mutually recursive predicates are typed together, from all their
    rules: a probabilistic rule of one makes both probabilistic.
    """
    pfacts = [Implication(ProbabilisticFact(Constant(0.5), S(a)), TRUE)]
    rules = [
        Implication(A(x), C(x)),
        Implication(B(x), Conjunction((A(x), C(x)))),
        Implication(A(x), Conjunction((B(x), S(x)))),
    ]
    program = CPLogicProgram()
    program.walk(Union(tuple([Fact(C(a)), Fact(C(b))] + pfacts + rules)))
    if reverse:
        rules = rules[::-1]
    idbs = _stratify_with_rules_in_order(
        Implication(Query(x), B(x)), program, rules, monkeypatch
    )
    assert set(idbs["probabilistic"].formulas) == set(rules)
    assert "deterministic" not in idbs


class CPLogicWithQueryBasedProbFactProgram(
    QueryBasedProbFactToDetRule,
    CPLogicProgram,
):
    pass


def test_stratify_query_based_probfact():
    code = Union(
        (
            Fact(Q(a, Constant(0.4))),
            Fact(Q(b, Constant(0.2))),
            Implication(
                ProbabilisticFact(p / Constant(2), P(x)),
                Q(x, p),
            ),
            Implication(
                ProbabilisticFact(p / Constant(4), Z(y)),
                Q(y, p),
            ),
        )
    )
    program = CPLogicWithQueryBasedProbFactProgram()
    program.walk(code)
    query = Implication(Query(x, y), Conjunction((P(x), Z(y))))
    idbs = stratify_program(query, program)
    P_formula = next(
        formula
        for formula in idbs["probabilistic"].formulas
        if formula.consequent.functor == P
        and formula.antecedent.functor.is_fresh
    )
    Z_formula = next(
        formula
        for formula in idbs["probabilistic"].formulas
        if formula.consequent.functor == Z
        and formula.antecedent.functor.is_fresh
    )
    assert any(
        formula.consequent.functor == P_formula.antecedent.functor
        for formula in idbs["deterministic"].formulas
    )
    assert any(
        formula.consequent.functor == Z_formula.antecedent.functor
        for formula in idbs["deterministic"].formulas
    )


def test_cannot_stratify_qbased_probfact_with_prob_dependency():
    code = Union(
        (
            Implication(
                ProbabilisticFact(Constant(0.2), P(a)),
                TRUE,
            ),
            Implication(
                ProbabilisticFact(Constant(0.6), Q(x)),
                P(x),
            ),
        )
    )
    program = CPLogicWithQueryBasedProbFactProgram()
    program.walk(code)
    query = Implication(Query(x), Q(x))
    with pytest.raises(UnsupportedProgramError):
        stratify_program(query, program)


def test_stratification_deep_post_probabilistic_dependency():
    code = Union(
        (
            Implication(ProbabilisticFact(Constant(0.2), P(a)), TRUE),
            Implication(ProbabilisticFact(Constant(0.4), T(a)), TRUE),
            Implication(Z(x, y, p1, p2), Conjunction((Q(x, p1), R(y, p2)))),
            Implication(Q(x, ProbabilisticQuery(PROB, (x,))), P(x)),
            Implication(R(y, ProbabilisticQuery(PROB, (y,))), T(x)),
        )
    )
    program = CPLogicWithQueryBasedProbFactProgram()
    program.walk(code)
    query = Implication(Query(x, y, p1, p2), Z(x, y, p1, p2))
    strats = stratify_program(query, program)
    assert any(
        rule.consequent.functor == "Z"
        for rule in strats["post_probabilistic"].formulas
    )
    assert any(
        rule.consequent.functor == "Q"
        for rule in strats["probabilistic"].formulas
    )
    assert any(
        rule.consequent.functor == "R"
        for rule in strats["probabilistic"].formulas
    )
