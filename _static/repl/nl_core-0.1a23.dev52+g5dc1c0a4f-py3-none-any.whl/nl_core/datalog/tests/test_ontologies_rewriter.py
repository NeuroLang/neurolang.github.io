import io

from nl_expr import expression_walker as ew
from nl_expr.expression_walker import ReplaceExpressionWalker
from nl_expr.expressions import Constant, ExpressionBlock, Symbol
from nl_expr.logic import (
    Conjunction,
    ExistentialPredicate,
    FunctionApplication,
    Implication,
    Union,
)
from nl_expr.logic.transformations import CollapseConjunctions
from ..aggregation import DatalogWithAggregationMixin
from ..expressions import TranslateToLogic
from ..ontologies_parser import OntologyParser, RightImplication
from ..expression_processing import extract_logic_atoms
from ..ontologies_rewriter import (
    OntologyRewriter,
    chase_rules,
    constraints_that_can_hold,
)

S_ = Symbol
C_ = Constant
EP_ = ExistentialPredicate
EB_ = ExpressionBlock
FA_ = FunctionApplication
I_ = Implication
RI_ = RightImplication


class DatalogTranslator(
    TranslateToLogic, ew.IdentityWalker, DatalogWithAggregationMixin
):
    pass

def  _categorize_constraints(formulas):
    parsed_constraints = {}
    for sigma in formulas:
        sigma_functor = sigma.consequent.functor.name
        if sigma_functor in parsed_constraints:
            cons_set = parsed_constraints[sigma_functor]
            if sigma not in cons_set:
                cons_set.add(sigma)
                parsed_constraints[sigma_functor] = cons_set
        else:
            parsed_constraints[sigma_functor] = set([sigma])

    return parsed_constraints

def test_normal_rewriting_step():
    project = S_("project")
    inArea = S_("inArea")
    hasCollaborator = S_("hasCollaborator")
    p = S_("p")

    x = S_("x")
    y = S_("y")
    z = S_("z")
    a = S_("a")
    b = S_("b")
    db = C_("db")

    sigma = RI_(project(x) & inArea(x, y), hasCollaborator(z, y, x))
    q = I_(p(b), hasCollaborator(a, db, b))

    qB = EB_((q,))

    dt = DatalogTranslator()
    qB = dt.walk(qB)

    sigmaB = _categorize_constraints([sigma])

    orw = OntologyRewriter(qB, sigmaB)
    rewrite = orw.Xrewrite()

    assert len(rewrite) == 2
    imp1 = rewrite.pop()
    imp2 = rewrite.pop()
    assert imp1 == q or imp2 == q
    q2 = I_(p(b), project(b) & inArea(b, db))
    assert imp1 == q2 or imp2 == q2


def test_more_than_one_free_variable():
    project = S_("project")
    inArea = S_("inArea")
    hasCollaborator = S_("hasCollaborator")
    p = S_("p")

    w = S_("w")
    x = S_("x")
    y = S_("y")
    z = S_("z")
    a = S_("a")
    b = S_("b")
    c = S_("c")
    db = C_("db")

    sigma = RI_(project(x) & inArea(x, y), hasCollaborator(w, z, y, x))
    q = I_(p(b), hasCollaborator(c, a, db, b))

    qB = EB_((q,))

    dt = DatalogTranslator()
    qB = dt.walk(qB)

    sigmaB = _categorize_constraints([sigma])

    orw = OntologyRewriter(qB, sigmaB)
    rewrite = orw.Xrewrite()

    assert len(rewrite) == 2
    imp1 = rewrite.pop()
    imp2 = rewrite.pop()
    assert imp1 == q or imp2 == q
    q2 = I_(p(b), project(b) & inArea(b, db))
    assert imp1 == q2 or imp2 == q2


def test_unsound_rewriting_step_constant():
    project = S_("project")
    inArea = S_("inArea")
    hasCollaborator = S_("hasCollaborator")
    p = S_("p")

    x = S_("x")
    y = S_("y")
    z = S_("z")
    b = S_("b")
    db = C_("db")
    c = C_("c")

    sigma = RI_(project(x) & inArea(x, y), hasCollaborator(z, y, x))
    q = I_(p(b), hasCollaborator(c, db, b))

    qB = EB_((q,))

    dt = DatalogTranslator()
    qB = dt.walk(qB)

    sigmaB = _categorize_constraints([sigma])

    orw = OntologyRewriter(qB, sigmaB)
    rewrite = orw.Xrewrite()

    assert len(rewrite) == 1
    imp = rewrite.pop()
    assert imp == q


def test_unsound_rewriting_step_shared():
    project = S_("project")
    inArea = S_("inArea")
    hasCollaborator = S_("hasCollaborator")
    p = S_("p")

    x = S_("x")
    y = S_("y")
    z = S_("z")
    b = S_("b")
    db = C_("db")

    sigma = RI_(project(x) & inArea(x, y), hasCollaborator(z, y, x))
    q = I_(p(b), hasCollaborator(b, db, b))

    qB = EB_((q,))

    dt = DatalogTranslator()
    qB = dt.walk(qB)

    sigmaB = _categorize_constraints([sigma])

    orw = OntologyRewriter(qB, sigmaB)
    rewrite = orw.Xrewrite()

    assert len(rewrite) == 1
    imp = rewrite.pop()
    assert imp == q


def test_outside_variable():
    s = S_("s")
    r = S_("r")
    t = S_("t")
    p = S_("p")

    x = S_("x")
    y = S_("y")
    z = S_("z")

    a = S_("a")
    b = S_("b")
    c = S_("c")
    e = S_("e")

    sigma = RI_(s(x) & r(x, y), t(x, y, z))
    q2 = I_(p(a), s(c) & t(a, b, c) & t(a, e, c))

    qB = EB_((q2,))

    dt = DatalogTranslator()
    qB = dt.walk(qB)

    sigmaB = _categorize_constraints([sigma])

    orw = OntologyRewriter(qB, sigmaB)
    rewrite = orw.Xrewrite()

    assert len(rewrite) == 1


def test_example_4_3():
    project = S_("project")
    inArea = S_("inArea")
    hasCollaborator = S_("hasCollaborator")
    collaborator = S_("collaborator")
    p = S_("p")

    x = S_("x")
    y = S_("y")
    z = S_("z")
    a = S_("a")
    b = S_("b")
    c = S_("c")

    sigma1 = RI_(project(x) & inArea(x, y), hasCollaborator(z, y, x))
    sigma2 = RI_(hasCollaborator(x, y, z), collaborator(x))

    q = I_(p(b, c), hasCollaborator(a, b, c) & collaborator(a))

    qB = EB_((q,))

    dt = DatalogTranslator()
    qB = dt.walk(qB)

    sigmaB = _categorize_constraints([sigma1, sigma2])

    orw = OntologyRewriter(qB, sigmaB)
    rewrite = orw.Xrewrite()

    assert len(rewrite) == 4


def test_infinite_walker():

    subClassOf = Symbol(str("subClassOf"))
    rest = Symbol("rest")
    reg = Symbol("reg")

    x1 = Symbol("x1")
    y1 = Symbol("y1")
    x = Symbol("x")
    y = Symbol("y")

    sigma_ant = Conjunction((subClassOf(x1, y1), rest(x1, y1), rest(y1, y1)))
    S = subClassOf(x1, y1)
    q_ant = Conjunction((subClassOf(x1, y1), rest(y, x1), rest(x, y1), reg(x)))

    replace = dict({S: sigma_ant})
    rsw = ReplaceExpressionWalker(replace)
    sigma_rep = rsw.walk(q_ant)
    sigma_rep = CollapseConjunctions().walk(sigma_rep)

    expected = Conjunction((sigma_ant, rest(y, x1), rest(x, y1), reg(x)))
    expected = CollapseConjunctions().walk(expected)

    assert sigma_rep == expected


def test_distinguished_variables():
    project = S_("project")
    inArea = S_("inArea")
    hasCollaborator = S_("hasCollaborator")
    p = S_("p")

    x = S_("x")
    y = S_("y")
    a = S_("a")
    b = S_("b")

    sigma = RI_(project(x), hasCollaborator(y, x))
    q = I_(p(a), hasCollaborator(a, b) & inArea(b))

    qB = EB_((q,))

    dt = DatalogTranslator()
    qB = dt.walk(qB)

    sigmaB = _categorize_constraints([sigma])

    orw = OntologyRewriter(qB, sigmaB)
    rewrite = orw.Xrewrite()

    assert len(rewrite) == 1
    imp1 = rewrite.pop()
    assert imp1 == qB.formulas[0]

def test_empty_rewrite():
    owl = '''<?xml version="1.0"?>
    <rdf:RDF xmlns="http://www.w3.org/2002/07/owl#"
        xmlns:owl="http://www.w3.org/2002/07/owl#"
        xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
        xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#">
        <Ontology>
            <versionInfo>0.3.1</versionInfo>
        </Ontology>

        <owl:Class rdf:ID="AdministrativeStaff">
            <rdfs:label>administrative staff worker</rdfs:label>
            <rdfs:subClassOf rdf:resource="#Employee"/>
        </owl:Class>

        <owl:Class rdf:ID="Article">
            <rdfs:label>article</rdfs:label>
            <rdfs:subClassOf rdf:resource="#Publication"/>
        </owl:Class>

        <owl:Class rdf:ID="AssistantProfessor">
            <rdfs:label>assistant professor</rdfs:label>
            <rdfs:subClassOf rdf:resource="#Professor"/>
        </owl:Class>

        <owl:Class rdf:ID="AssociateProfessor">
            <rdfs:label>associate professor</rdfs:label>
            <rdfs:subClassOf rdf:resource="#Professor"/>
        </owl:Class>

        <owl:Class rdf:ID="Book">
            <rdfs:label>book</rdfs:label>
            <rdfs:subClassOf rdf:resource="#Publication"/>
        </owl:Class>
    </rdf:RDF>'''

    book = Symbol('book')
    x = Symbol('x')
    p = Symbol('p')

    onto = OntologyParser(io.StringIO(owl))
    constraints, _, _ = onto.parse_ontology()

    q = I_(p(x), book(x))

    qB = EB_((q,))

    dt = DatalogTranslator()
    qB = dt.walk(qB)

    orw = OntologyRewriter(qB, constraints)
    rewritten = orw.Xrewrite()

    assert len(rewritten) == 1
    imp = rewritten.pop()
    assert imp == q


def test_ontology_parsed_rewrite():
    owl = '''<?xml version="1.0"?>
    <rdf:RDF xmlns="http://www.w3.org/2002/07/owl#"
        xmlns:owl="http://www.w3.org/2002/07/owl#"
        xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
        xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#">
        <Ontology>
            <versionInfo>0.3.1</versionInfo>
        </Ontology>

        <owl:Class rdf:ID="Chair">
            <rdfs:label>chair</rdfs:label>
            <rdfs:subClassOf>
                <owl:Class>
                    <owl:intersectionOf rdf:parseType="Collection">
                        <owl:Class rdf:about="#Person" />
                        <owl:Restriction>
                            <owl:onProperty rdf:resource="#headOf" />
                            <owl:someValuesFrom>
                                <owl:Class rdf:about="#Department" />
                            </owl:someValuesFrom>
                        </owl:Restriction>
                    </owl:intersectionOf>
                </owl:Class>
            </rdfs:subClassOf>
            <rdfs:subClassOf rdf:resource="#Professor" />
        </owl:Class>
    </rdf:RDF>'''

    headof = Symbol('headOf')
    chair = Symbol('Chair')
    x = Symbol('x')
    y = Symbol('y')
    p = Symbol('p')

    onto = OntologyParser(io.StringIO(owl))
    constraints, _, _ = onto.parse_ontology()

    q = I_(p(x), headof(x, y))

    qB = EB_((q,))

    dt = DatalogTranslator()
    qB = dt.walk(qB)

    orw = OntologyRewriter(qB, constraints)
    rewritten = orw.Xrewrite()

    rewritten = list(rewritten)

    assert len(rewritten) == 3
    assert q in rewritten
    index_no_q = [i for i, e in enumerate(rewritten) if e != q]
    assert len(index_no_q) == 2
    index_1 = index_no_q[0]
    index_2 = index_no_q[1]

    if rewritten[index_1].antecedent == chair(x):
        assert len(rewritten[index_2].antecedent.args) == 2
        assert rewritten[index_2].antecedent.args[0] == rewritten[index_2].consequent.args[0]
    elif rewritten[index_2].antecedent == chair(x):
        assert len(rewritten[index_1].antecedent.args) == 2
        assert rewritten[index_1].antecedent.args[0] == rewritten[index_1].consequent.args[0]
    else:
        assert False


def test_constraints_that_can_hold():
    """A constraint is kept when its antecedent's predicates hold, or are
    derived by kept constraints: ``Dean`` holds, so ``headOf`` can, and
    ``Chair`` neither holds nor is derived."""
    Dean, Chair, headOf, Person = S_("Dean"), S_("Chair"), S_("headOf"), S_(
        "Person"
    )
    x, y = S_("x"), S_("y")
    dean = RI_(Dean(x), headOf(x, y))
    chair = RI_(Chair(x), headOf(x, y))
    person = RI_(headOf(x, y), Person(x))
    constraints = _categorize_constraints([dean, chair, person])

    assert constraints_that_can_hold(constraints, {Dean}) == {
        "headOf": {dean}, "Person": {person}
    }
    assert constraints_that_can_hold(constraints, set()) == {}


def test_variable_in_a_head_term_is_distinguished():
    """``b`` in ``count(b)`` is distinguished: the existential of
    ``Dean(x) -> headOf(x, y)`` does not rewrite ``headOf(a, b)``."""
    Dean, headOf, q, count = S_("Dean"), S_("headOf"), S_("q"), S_("count")
    x, y, a, b = S_("x"), S_("y"), S_("a"), S_("b")
    constraints = _categorize_constraints([RI_(Dean(x), headOf(x, y))])

    rule = I_(q(count(a)), headOf(a, b))
    assert len(OntologyRewriter(Union((rule,)), constraints).Xrewrite()) == 2
    rule = I_(q(count(b)), headOf(a, b))
    assert OntologyRewriter(Union((rule,)), constraints).Xrewrite() == {rule}


def _bodies(rewriting):
    """The rewritings as (head, body) of functor names and arguments."""
    return {
        (q.consequent.args, frozenset(
            (a.functor.name, a.args) for a in extract_logic_atoms(q.antecedent)
        )) for q in rewriting
    }


def test_factorisation_keeps_the_rest_of_the_body():
    """Factorising the ``aux`` atoms of ``q(v) :- aux(u, x), aux(v, x),
    E(v)`` keeps ``E(v)``, so the existential gives ``C(v) ∧ E(v)``."""
    C, E, aux, q = S_("C"), S_("E"), S_("aux"), S_("q")
    u, v, x, y = S_("u"), S_("v"), S_("x"), S_("y")
    constraints = _categorize_constraints([RI_(C(x), aux(x, y))])
    rule = I_(q(v), Conjunction((aux(u, x), aux(v, x), E(v))))

    rewriting = OntologyRewriter(Union((rule,)), constraints).Xrewrite()
    heads_bodies = {
        (head, frozenset(name for name, _ in body))
        for head, body in _bodies(rewriting)
    }
    assert all(
        set(head) <= {
            arg for q in rewriting for a in extract_logic_atoms(q.antecedent)
            for arg in a.args
        } for head, _ in heads_bodies
    )
    assert any(names == {"C", "E"} for _, names in heads_bodies)


def test_renamed_constraint_variables_are_new():
    """Applying ``aux(x, y) → C(y)`` twice must not reuse a query variable:
    ``q(z) :- C(x), r(y, x), r(z, y)`` rewrites to ``q(z) :- C(z)``."""
    C, aux, r, q = S_("C"), S_("aux"), S_("r"), S_("q")
    x, y, z = S_("x"), S_("y"), S_("z")
    constraints = _categorize_constraints([
        RI_(C(x), aux(x, y)), RI_(aux(x, y), r(x, y)),
        RI_(aux(x, y), C(y)),
    ])
    rule = I_(q(z), Conjunction((C(x), r(y, x), r(z, y))))

    rewriting = OntologyRewriter(Union((rule,)), constraints).Xrewrite()
    assert any(
        body == frozenset({("C", head)}) for head, body in _bodies(rewriting)
    )


def test_chased_full_constraints_rewrite_atoms_out_of_the_head():
    """With ``chased``, ``Dept(x) → Unit(x)`` rewrites ``Unit(y)``, which
    may stand for an unnamed value, and not ``Unit(x)`` in the head."""
    Dept, Unit, headOf, q = S_("Dept"), S_("Unit"), S_("headOf"), S_("q")
    x, y = S_("x"), S_("y")
    constraints = _categorize_constraints([RI_(Dept(x), Unit(x))])

    rule = I_(q(x), Unit(x))
    assert OntologyRewriter(
        Union((rule,)), constraints, chased=True
    ).Xrewrite() == {rule}
    rule = I_(q(x), Conjunction((headOf(x, y), Unit(y))))
    assert len(OntologyRewriter(
        Union((rule,)), constraints, chased=True
    ).Xrewrite()) == 2


def test_chase_rules():
    """The full constraints the rule depends on become rules; ``Unit``,
    with facts, is derived into a copy; rules over ``aux``, which has no
    values, are left out."""
    Dean, Dept, Unit, aux, q = (
        S_("Dean"), S_("Dept"), S_("Unit"), S_("aux"), S_("q")
    )
    x, y = S_("x"), S_("y")
    constraints = _categorize_constraints([
        RI_(Dean(x), aux(x, y)), RI_(aux(x, y), Dept(y)),
        RI_(Dept(x), Unit(x)),
    ])
    rules = chase_rules(
        constraints, {Dept, Unit}, [I_(q(x), Unit(x)), I_(q(x), aux(x, y))],
        {Unit, Dept},
    )
    assert len(rules) == 3
    query, chased, copy = rules
    unit = query.antecedent.functor
    assert unit != Unit and chased.consequent.functor == unit
    assert chased.antecedent.functor == Dept
    assert copy.consequent.functor == unit
    assert copy.antecedent.functor == Unit
