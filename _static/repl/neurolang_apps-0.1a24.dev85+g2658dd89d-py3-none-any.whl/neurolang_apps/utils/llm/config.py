"""
Configuration of the LLM query assistant.

The providers and the settings of the assistant are read from a YAML
file (see ``llm.example.yaml``, next to this module). It is looked up,
in order, at the path given explicitly (``--llm-config``), at the path
of the ``NEUROLANG_LLM_CONFIG`` environment variable, at
``~/.config/neurolang/llm.yaml`` and, failing those, the example file
shipped with NeuroLang is used.

A provider speaks the OpenAI chat completions API (``api: openai``:
OpenRouter, Albert, vLLM, Ollama…), the Anthropic messages API
(``api: anthropic``) or is a local command reading the conversation on
its standard input (``api: command``, e.g. ``claude -p``), or is Claude
Code itself (``api: claude-code``, run by the Agent SDK with the user's
own sign-in to the ``claude`` CLI, no key). Its API key is read from the
environment variable named by ``api_key_env``: keys are never written in
the file.
"""

import os
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Optional

import yaml

CONFIG_ENV = "NEUROLANG_LLM_CONFIG"
USER_CONFIG = Path("~/.config/neurolang/llm.yaml")
EXAMPLE_CONFIG = Path(__file__).with_name("llm.example.yaml")
# The defaults of the settings, those a configuration file does not give.
DEFAULTS_FILE = Path(__file__).with_name("defaults.yaml")
DEFAULTS = yaml.safe_load(DEFAULTS_FILE.read_text(encoding="utf-8"))
_PROVIDER = DEFAULTS["provider"]
_ASSISTANT = DEFAULTS["assistant"]

APIS = ("openai", "anthropic", "command", "claude-code")
# "1" in the sessions of a shared server (neurolang-repl-serve --users): the
# sign-in to Claude of whoever runs it is not theirs, the provider
# claude-code is refused there.
MULTI_USER_ENV = "NEUROLANG_REPL_USERS"
TOOL_CALLING = ("text", "native")
STRATEGIES = ("react", "icl")
LANGUAGES = ("auto", "squall", "datalog")


class LLMConfigError(ValueError):
    """Raised when the LLM configuration is invalid or incomplete."""


@dataclass(frozen=True)
class ProviderConfig:
    """
    An LLM provider: its API, endpoint, model and credentials.

    *api* is ``openai`` or ``anthropic``, the protocol spoken at
    *base_url*, or ``command``: *command* is then run for each request,
    reading the conversation on its standard input and writing the
    reply on its standard output; ``{system}`` in its arguments is
    replaced by the system prompt. The API key is read from the
    environment variable *api_key_env*, if any (local servers need
    none). *tool_calling* tells
    whether the ReAct agent uses the provider's ``native`` tool calls or
    the ``text`` Thought/Action/Observation protocol, which any chat
    model can follow. *requests_per_minute* spaces the requests to the
    provider's rate limit, if any.
    """

    name: str
    api: str
    model: str
    base_url: str = ""
    api_key_env: Optional[str] = None
    headers: dict = field(default_factory=dict)
    tool_calling: str = _PROVIDER["tool_calling"]
    max_tokens: int = _PROVIDER["max_tokens"]
    command: tuple = ()
    requests_per_minute: Optional[float] = None

    def api_key(self) -> Optional[str]:
        """Return the API key of the provider, read from the environment."""
        if self.api == "claude-code" and os.environ.get(MULTI_USER_ENV) == "1":
            raise LLMConfigError(
                f"The LLM provider {self.name!r} uses the sign-in of the "
                "user who runs it: it is not allowed on a shared server "
                "unless an admin allows it to you (--claude-code)."
            )
        if not self.api_key_env:
            return None
        key = os.environ.get(self.api_key_env)
        if not key:
            raise LLMConfigError(
                f"The LLM provider {self.name!r} needs an API key: set the "
                f"environment variable {self.api_key_env}."
            )
        return key


@dataclass
class AssistantConfig:
    """
    Settings of the query assistant.

    *strategy* is ``react`` (an agent exploring the engine with tools)
    or ``icl`` (a few-shot prompt, then validation and repair).
    *language* is ``auto`` (the language of the REPL), ``squall`` or
    ``datalog``. *samples* above 1 generate several candidates and
    keep the one most of them agree on (self-consistency); without a
    majority, more than half of them giving the same rows, or when none
    is valid, the provider *fallback_provider* (a name in the file),
    if any, answers instead.
    *query_timeout* and *query_memory_mb* stop a query the agent runs
    after that many seconds, or when it uses that much memory: it runs in
    a child process. With *comment_rules*, the accepted query is shown
    with a comment line explaining each rule (see
    :mod:`~neurolang_apps.utils.llm.comments`). *verify_rounds* is the number
    of final answers of the ReAct agent that its verification may reject:
    each final answer is translated back into English, without the
    question, and the model judges whether that answers the question; 0
    turns the verification off.
    """

    # Their defaults are those of defaults.yaml.
    strategy: str = _ASSISTANT["strategy"]
    language: str = _ASSISTANT["language"]
    max_steps: int = _ASSISTANT["max_steps"]
    max_repairs: int = _ASSISTANT["max_repairs"]
    few_shot_k: int = _ASSISTANT["few_shot_k"]
    samples: int = _ASSISTANT["samples"]
    fallback_provider: Optional[ProviderConfig] = None
    temperature: float = _ASSISTANT["temperature"]
    timeout: float = _ASSISTANT["timeout"]
    preview_rows: int = _ASSISTANT["preview_rows"]
    query_timeout: float = _ASSISTANT["query_timeout"]
    query_memory_mb: float = _ASSISTANT["query_memory_mb"]
    verify_rounds: int = _ASSISTANT["verify_rounds"]
    comment_rules: bool = _ASSISTANT["comment_rules"]


@dataclass(frozen=True)
class FeedbackConfig:
    """
    Sharing of the questions and answers with a feedback server
    (:mod:`.feedback`): off unless *enabled*, to the server at *url*,
    signed with *user*, if given; or, with *grist_doc*, to that document
    of the Grist instance at *url*, with the API key in *api_key_env*.
    """

    enabled: bool = False
    url: str = ""
    user: str = ""
    grist_doc: str = ""
    api_key_env: str = "GRIST_API_KEY"


@dataclass
class LLMConfig:
    """The providers and the assistant settings of a configuration file."""

    providers: dict
    default_provider: str
    assistant: AssistantConfig = field(default_factory=AssistantConfig)
    path: Optional[Path] = None
    feedback: FeedbackConfig = field(default_factory=FeedbackConfig)

    def provider(self, name: Optional[str] = None) -> ProviderConfig:
        """Return the provider *name*, by default the default provider."""
        name = name or self.default_provider
        if name not in self.providers:
            available = ", ".join(sorted(self.providers)) or "none"
            raise LLMConfigError(
                f"Unknown LLM provider {name!r}. Available providers: "
                f"{available}."
            )
        return self.providers[name]


def config_path(path=None) -> Path:
    """Return the path of the configuration file to read (see the module)."""
    if path:
        return Path(path).expanduser()
    if os.environ.get(CONFIG_ENV):
        return Path(os.environ[CONFIG_ENV]).expanduser()
    user = USER_CONFIG.expanduser()
    if user.exists():
        return user
    return EXAMPLE_CONFIG


def _check_choice(value, choices, what: str):
    """Return *value*, raising LLMConfigError if it is not in *choices*."""
    if value not in choices:
        raise LLMConfigError(
            f"Invalid {what} {value!r}: expected one of {', '.join(choices)}."
        )
    return value


def _provider(name: str, entry) -> ProviderConfig:
    """Return the provider *name* described by the YAML mapping *entry*."""
    if not isinstance(entry, dict):
        raise LLMConfigError(f"Provider {name!r} must be a mapping.")
    if "api_key" in entry:
        raise LLMConfigError(
            f"Provider {name!r} has an inline api_key: put the key in an "
            "environment variable and name it with api_key_env."
        )
    required = {
        "command": ("command",), "claude-code": ("model",),
    }.get(entry.get("api"), ("base_url", "model"))
    missing = [key for key in required if not entry.get(key)]
    if missing:
        raise LLMConfigError(
            f"Provider {name!r} lacks {' and '.join(missing)}."
        )
    known = {f.name for f in fields(ProviderConfig)} - {"name"}
    unknown = sorted(set(entry) - known)
    if unknown:
        raise LLMConfigError(
            f"Provider {name!r} has unknown keys: {', '.join(unknown)}."
        )
    entry = {"api": "openai", "model": "", **entry}
    if entry["api"] == "claude-code":
        entry = {"tool_calling": "native", **entry}
    if entry.get("command"):
        entry["command"] = tuple(str(arg) for arg in entry["command"])
    provider = ProviderConfig(name=name, **entry)
    _check_choice(provider.api, APIS, f"api of provider {name!r}")
    _check_choice(
        provider.tool_calling, TOOL_CALLING,
        f"tool_calling of provider {name!r}",
    )
    if provider.api == "command" and provider.tool_calling != "text":
        raise LLMConfigError(
            f"Provider {name!r} is a command: it supports only "
            "tool_calling: text."
        )
    if provider.api == "claude-code":
        _check_claude_code(provider)
    return provider


def _check_claude_code(provider: ProviderConfig) -> None:
    """Raise LLMConfigError if the ``claude-code`` *provider* is invalid."""
    name = provider.name
    if provider.tool_calling != "native":
        raise LLMConfigError(
            f"Provider {name!r} is Claude Code: it supports only "
            "tool_calling: native."
        )
    if provider.base_url or provider.command or provider.api_key_env:
        raise LLMConfigError(
            f"Provider {name!r} is Claude Code: it uses your sign-in to "
            "claude and takes no base_url, command nor api_key_env."
        )


def _assistant(entry) -> AssistantConfig:
    """Return the assistant settings of the YAML mapping *entry*."""
    entry = entry or {}
    known = {f.name for f in fields(AssistantConfig)}
    unknown = sorted(set(entry) - known)
    if unknown:
        raise LLMConfigError(
            f"Unknown assistant settings: {', '.join(unknown)}."
        )
    assistant = AssistantConfig(**entry)
    _check_choice(assistant.strategy, STRATEGIES, "strategy")
    _check_choice(assistant.language, LANGUAGES, "language")
    return assistant


def parse_config(data: dict, path: Optional[Path] = None) -> LLMConfig:
    """Return the configuration described by the YAML mapping *data*."""
    if not isinstance(data, dict):
        raise LLMConfigError("The LLM configuration must be a mapping.")
    providers = {
        name: _provider(name, entry)
        for name, entry in (data.get("providers") or {}).items()
    }
    if not providers:
        raise LLMConfigError("The LLM configuration declares no provider.")
    default = data.get("default_provider") or next(iter(providers))
    try:
        feedback = FeedbackConfig(**(data.get("feedback") or {}))
    except TypeError as exc:
        raise LLMConfigError(f"Invalid feedback settings: {exc}.") from exc
    config = LLMConfig(
        providers, default, _assistant(data.get("assistant")), path, feedback
    )
    config.provider()
    if config.assistant.fallback_provider is not None:
        config.assistant.fallback_provider = config.provider(
            config.assistant.fallback_provider
        )
    return config


def load_config(path=None) -> LLMConfig:
    """Read the configuration file (see :func:`config_path`)."""
    path = config_path(path)
    try:
        with open(path, encoding="utf-8") as stream:
            data = yaml.safe_load(stream)
    except OSError as exc:
        raise LLMConfigError(
            f"Cannot read the LLM configuration {path}: {exc.strerror}."
        ) from exc
    except yaml.YAMLError as exc:
        raise LLMConfigError(
            f"Invalid YAML in the LLM configuration {path}: {exc}"
        ) from exc
    return parse_config(data, path)
