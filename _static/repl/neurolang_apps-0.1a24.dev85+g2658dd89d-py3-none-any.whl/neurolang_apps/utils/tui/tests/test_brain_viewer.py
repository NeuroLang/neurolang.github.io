"""Tests for the interactive brain viewer page that ``.view`` writes."""

import base64
import gzip
import json
import os
import re
import shutil
import subprocess
import zlib
from pathlib import Path

import nibabel as nib
import numpy as np
import pytest

pytest.importorskip("prompt_toolkit")
pytest.importorskip("rich")

from neurolang_apps.utils.tui import brain_viewer  # noqa: E402

AFFINE = np.array([
    [2.0, 0.0, 0.0, -3.0],
    [0.0, 2.0, 0.0, -5.0],
    [0.0, 0.0, 2.0, -7.0],
    [0.0, 0.0, 0.0, 1.0],
])


def _decode(text, dtype):
    """Decode an array of the page: base64 of deflated bytes."""
    return np.frombuffer(zlib.decompress(base64.b64decode(text)), dtype)


def _nifti(item):
    """Return the NIfTI image of an item of the page: base64 of gzip."""
    data = gzip.decompress(base64.b64decode(item["nifti"]))
    return nib.Nifti1Image.from_bytes(data)


def _overlay_volume(overlay, shape=None):
    """Return the volume of an overlay of the page."""
    volume = np.asarray(_nifti(overlay).dataobj)
    assert shape is None or volume.shape == shape
    return volume


def _state(html):
    """Return the state the page embeds as JSON."""
    match = re.search(
        r'<script id="viewer-data" type="application/json">(.*?)</script>',
        html, re.S,
    )
    return json.loads(match.group(1))


def _image(data, affine=AFFINE):
    return nib.Nifti1Image(np.asarray(data), affine)


class TestOverlayEncoding:
    """Check the overlays are embedded as gzipped NIfTI images."""

    def test_round_trip(self):
        data = np.zeros((20, 30, 10), dtype=np.float32)
        data[1, 2, 3], data[19, 29, 9], data[5, 0, 7] = 0.25, -1.5, 3.1
        image = _nifti({"nifti": brain_viewer.encode_nifti(data, AFFINE)})
        assert np.array_equal(np.asarray(image.dataobj), data)
        assert np.allclose(image.affine, AFFINE)

    def test_nan_is_no_value(self):
        data = np.zeros((4, 4, 4), dtype=np.float32)
        data[0, 0, 0], data[1, 1, 1] = np.nan, 2.0
        volume = brain_viewer.overlay_values(data)
        assert volume[0, 0, 0] == 0 and volume[1, 1, 1] == 2

    def test_infinite_values_take_the_largest_finite_ones(self):
        """An infinite value is drawn at the end of the colour scale."""
        data = np.zeros((2, 2, 2), dtype=np.float32)
        data[0, 0, 0], data[1, 0, 0] = np.inf, 3.0
        data[0, 1, 0], data[1, 1, 0] = -np.inf, -2.0
        volume = brain_viewer.overlay_values(data)
        assert volume[0, 0, 0] == 3.0 and volume[0, 1, 0] == -2.0


class TestColormaps:
    """Check the colormaps are embedded as 256 RGB colours."""

    def test_lut_shapes(self):
        luts = brain_viewer.colormap_luts(["viridis"])
        assert set(brain_viewer.COLORMAPS) <= set(luts)
        for lut in luts.values():
            assert _decode(lut, np.uint8).shape == (256 * 3,)

    def test_luts_follow_matplotlib_and_nilearn(self):
        import matplotlib

        luts = brain_viewer.colormap_luts([])
        hot = _decode(luts["hot"], np.uint8).reshape(256, 3)
        expected = matplotlib.colormaps["hot"](np.linspace(0, 1, 256))
        assert np.abs(hot - expected[:, :3] * 255).max() <= 1
        assert "cold_hot" in luts

    def test_the_requested_colormap_is_added(self):
        luts = brain_viewer.colormap_luts(["Spectral"])
        assert "Spectral" in luts and "hot" in luts

    def test_unknown_colormap_is_left_out(self):
        assert "no_such_map" not in brain_viewer.colormap_luts(["no_such_map"])


class TestBackground:
    """Check the background is resampled to the overlay grid."""

    def test_same_grid(self):
        data = np.arange(64, dtype=np.float32).reshape(4, 4, 4)
        volume, factor = brain_viewer.resample_background(
            _image(data), (4, 4, 4), AFFINE
        )
        assert factor == 1 and volume.dtype == np.uint8
        assert volume.shape == (4, 4, 4)
        assert volume[3, 3, 3] == 255 and volume[0, 0, 0] == 0
        assert np.all(np.diff(volume.ravel()) >= 0)

    def test_capped_resolution(self):
        volume, factor = brain_viewer.resample_background(
            _image(np.ones((10, 10, 10), dtype=np.float32)), (40, 30, 20),
            AFFINE, max_voxels=2000,
        )
        assert factor == 3 and volume.shape == (14, 10, 7)

    def test_mni_template_on_the_mni_grid(self):
        template = brain_viewer.mni_background()
        assert template is not None and template.shape == (197, 233, 189)
        volume, factor = brain_viewer.resample_background(
            template, template.shape, template.affine
        )
        assert factor == 1 and volume.shape == template.shape
        data = template.get_fdata()
        assert np.abs(volume - data / data.max() * 255).max() <= 1


class TestPage:
    """Check the page holds NiiVue, its controls, its data and no URL."""

    @pytest.fixture
    def html(self):
        data = np.zeros((4, 4, 4), dtype=np.float32)
        data[1, 2, 3], data[0, 0, 0] = -2.0, 3.0
        return brain_viewer.viewer_html(
            _image(data), _image(np.ones((4, 4, 4), np.float32)),
            title="signed <map>", threshold="95%", cmap="viridis",
            symmetric=True,
        )

    def test_controls(self, html):
        for control in (
            'id="threshold"', 'id="threshold-slider"',
            'id="threshold-mode"', 'id="cmap"', 'id="symmetric"',
            'id="opacity"', 'id="reset"', 'id="colorbar"', 'id="gl"',
            'id="layer"', 'id="layer-up"', 'id="layer-down"',
            'id="visible"', 'id="readout"',
        ):
            assert control in html

    def test_the_page_follows_the_theme_of_the_repl(self, html):
        """In the REPL it is told the theme of the page, and says how tall
        it is, so that its frame has no scrollbars: no colour of the page
        is fixed to dark."""
        style = html.split("<style>")[1].split("</style>")[0]
        assert ":root[data-theme=light]" in style
        assert "prefers-color-scheme" in style
        for rule in ("body {", "input, select, button {", "#readout b {"):
            body = style.split(rule)[1].split("}")[0]
            assert "var(--" in body and "#" not in body
        assert "'neurolang-theme'" in html
        assert "'neurolang-height'" in html
        assert "parent.postMessage" in html

    def test_the_canvas_and_the_colour_bar_follow_the_theme(self, html):
        script = html.split("<script>")[-1]
        assert "backColor" in script and "neurolang-theme" in script
        assert "rgba(17, 17, 17, 0.75)" not in script
        assert "'#ddd'" not in script

    def test_initial_state(self, html):
        state = _state(html)
        assert state["initial"] == {
            "cursor": [0, 0, 0], "active": 0,
            "layers": [{
                "threshold": 95.0, "thresholdMode": "percentile",
                "cmap": "viridis", "symmetric": True, "opacity": 1.0,
                "visible": True,
            }],
        }
        assert [o["name"] for o in state["overlays"]] == [""]
        assert np.array_equal(state["affine"], AFFINE)
        assert "viridis" in state["colormaps"]

    def test_the_overlay_keeps_its_grid(self, html):
        image = _nifti(_state(html)["overlays"][0])
        assert image.shape == (4, 4, 4)
        assert np.allclose(image.affine, AFFINE)
        assert np.asarray(image.dataobj)[1, 2, 3] == -2

    def test_background_on_the_grid_of_the_overlays(self, html):
        background = _nifti(_state(html)["background"])
        assert background.shape == (4, 4, 4)
        assert np.allclose(background.affine, AFFINE)
        assert np.asarray(background.dataobj).dtype == np.uint8

    def test_without_a_background_one_of_zeros(self):
        state = _state(brain_viewer.viewer_html(
            _image(np.ones((2, 2, 2), np.float32)), None, title="t",
            threshold=0.5, cmap=None, symmetric=False,
        ))
        background = np.asarray(_nifti(state["background"]).dataobj)
        assert background.shape == (2, 2, 2) and not background.any()

    def test_value_threshold_and_default_colormap(self):
        html = brain_viewer.viewer_html(
            _image(np.ones((2, 2, 2), np.float32)), None, title="t",
            threshold=0.5, cmap=None, symmetric=False,
        )
        layer = _state(html)["initial"]["layers"][0]
        assert layer["threshold"] == 0.5
        assert layer["thresholdMode"] == "value"
        assert layer["cmap"] == brain_viewer.DEFAULT_CMAP

    def test_default_colormap_is_plasma_and_percentile_threshold(self):
        html = brain_viewer.viewer_html(
            _image(np.ones((2, 2, 2), np.float32)), None, title="t",
            threshold="95%", cmap=None, symmetric=False,
        )
        layer = _state(html)["initial"]["layers"][0]
        assert layer["cmap"] == "plasma"
        assert layer["threshold"] == 95.0
        assert layer["thresholdMode"] == "percentile"

    def test_title_is_escaped(self, html):
        assert "<title>signed &lt;map&gt;</title>" in html

    def test_niivue_is_inlined(self, html):
        bundle = (
            Path(brain_viewer.__file__).parent / "static" / "niivue"
            / "niivue.umd.js"
        ).read_text(encoding="utf-8")
        assert bundle in html
        assert "<script src" not in html
        # the data, the hooks of the frame, NiiVue and the viewer
        assert html.count("</script>") == 4

    def test_no_external_urls(self, html):
        """No URL outside the NiiVue bundle, whose comments have some,
        but the favicon's data URI."""
        bundle = (
            Path(brain_viewer.__file__).parent / "static" / "niivue"
            / "niivue.umd.js"
        ).read_text(encoding="utf-8")
        page = html.replace(bundle, "")
        assert not re.search(
            r'https?://|//cdn|\bsrc=|\bhref=(?!"data:)', page
        )

    def test_cursor_on_the_peak(self):
        data = np.zeros((5, 5, 5), dtype=np.float32)
        data[1, 1, 1], data[3, 2, 4] = 1.0, -4.0
        state = _state(brain_viewer.viewer_html(
            _image(data), None, title="t", threshold=0, cmap="hot",
            symmetric=True,
        ))
        assert state["initial"]["cursor"] == [3, 2, 4]

    def test_cursor_in_the_voxels_of_the_image(self):
        """The cursor is in the voxels of the image as it is, NiiVue
        reorienting it to draw it."""
        flip = np.diag([-2.0, 2.0, 2.0, 1.0])
        data = np.zeros((4, 4, 4), dtype=np.float32)
        data[0, 1, 2] = 5.0
        state = _state(brain_viewer.viewer_html(
            _image(data, flip), None, title="t", threshold=0,
            cmap="hot", symmetric=False,
        ))
        assert state["initial"]["cursor"] == [0, 1, 2]
        assert np.array_equal(state["affine"], flip)



def test_the_page_has_the_neurolang_favicon():
    """The page's icon is NeuroLang's favicon, inlined: the page needs
    no network."""
    page = brain_viewer.viewer_html(
        _image(np.ones((2, 2, 2), np.float32)), None, title="t",
        threshold=0, cmap=None, symmetric=False,
    )
    icon = re.search(
        r'<link rel="icon" type="image/svg\+xml" '
        r'href="data:image/svg\+xml;base64,([A-Za-z0-9+/=]+)">', page
    )
    assert icon is not None
    svg = base64.b64decode(icon.group(1)).decode()
    assert svg.startswith("<svg") and "prefers-color-scheme:dark" in svg

_CHROME_PATHS = (
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
)


def _chrome():
    """Return the path of a Chrome or Chromium to run headless, or None."""
    names = ("google-chrome", "chromium", "chromium-browser", "chrome")
    found = [os.environ.get("NEUROLANG_TEST_CHROME")]
    found += [shutil.which(name) for name in names]
    found += [p for p in _CHROME_PATHS if Path(p).exists()]
    return next((p for p in found if p), None)


# The flags running WebGL2 in headless Chrome, which NiiVue draws with.
_CHROME_FLAGS = (
    "--headless=new", "--use-angle=swiftshader",
    "--enable-unsafe-swiftshader", "--no-first-run",
    "--host-rules=MAP * ~NOTFOUND",
)


def _run_in_chrome(tmp_path, html, check):
    """Return what the *check* script writes once the page has loaded,
    the page being offline."""
    page = tmp_path / "page.html"
    # Before the last </body>: the NiiVue bundle holds one.
    head, _, tail = html.rpartition("</body>")
    page.write_text(head + check + "</body>" + tail)
    dom = subprocess.run(
        [
            _chrome(), *_CHROME_FLAGS,
            f"--user-data-dir={tmp_path / 'profile'}",
            "--virtual-time-budget=20000", "--dump-dom", page.as_uri(),
        ],
        capture_output=True, text=True, timeout=180,
    ).stdout
    return json.loads(
        re.search(r'<pre id="test-result">(.*?)</pre>', dom, re.S).group(1)
    )


# The helpers of the checks: the pixels NiiVue draws, read right after
# it draws them, and the setting of a control as the user would.
_CHECK_HELPERS = """
<script>
window.addEventListener('error', function (e) {
  window.__errors = (window.__errors || []).concat([String(e.message)]);
});
function pixels() {
  var nv = brainViewer.nv, gl = nv.gl;
  nv.drawScene();
  var w = gl.drawingBufferWidth, h = gl.drawingBufferHeight;
  var p = new Uint8Array(4 * w * h);
  gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, p);
  return p;
}
function changed(a, b) {
  for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return true;
  return false;
}
function changes(a, b) {
  var n = 0;
  for (var i = 0; i < a.length; i += 4) {
    if (a[i] !== b[i] || a[i + 1] !== b[i + 1] || a[i + 2] !== b[i + 2]) n++;
  }
  return n;
}
function set(id, value, kind) {
  var el = document.getElementById(id);
  if (el.type === 'checkbox') el.checked = value; else el.value = value;
  el.dispatchEvent(new Event(kind || 'input', {bubbles: true}));
}
function click(id) {
  document.getElementById(id).dispatchEvent(new Event('click'));
}
function report(out) {
  out.errors = window.__errors || [];
  document.getElementById('test-result').textContent = JSON.stringify(out);
}
</script>
<pre id="test-result">pending</pre>
"""

_BROWSER_CHECK = _CHECK_HELPERS + """
<script>
brainViewer.ready.then(function () {
  var out = {};
  var volume = brainViewer.nv.volumes[1];
  out.volumes = brainViewer.nv.volumes.length;
  var before = pixels();
  set('symmetric', false, 'change');
  out.oneSidedNegative = volume.colormapNegative;
  var oneSided = pixels();
  out.symmetric = changed(before, oneSided);
  set('threshold', '2.5', 'change');
  out.calMin = volume.cal_min;
  var thresholded = pixels();
  out.threshold = changed(oneSided, thresholded);
  set('cmap', 'viridis', 'change');
  out.colormap = volume.colormap;
  out.cmap = changed(thresholded, pixels());
  out.colorbarTicks = document.getElementById('colorbar').dataset.ticks;
  brainViewer.moveCursor([1, 2, 3]);
  out.value = document.getElementById('value').textContent;
  out.mm = document.getElementById('mm').textContent;
  out.voxel = document.getElementById('voxel').textContent;
  click('reset');
  out.resetCmap = document.getElementById('cmap').value;
  out.resetNegative = volume.colormapNegative;
  report(out);
}).catch(function (e) { report({failed: String(e)}); });
</script>
"""


@pytest.mark.skipif(_chrome() is None, reason="no headless Chrome")
def test_the_page_in_a_headless_browser(tmp_path):
    """Check the page runs offline, and its controls set the NiiVue
    overlay and redraw it."""
    data = np.zeros((4, 4, 4), dtype=np.float32)
    data[1, 2, 3], data[0, 0, 3], data[2, 2, 3] = -2.0, 3.0, 1.0
    html = brain_viewer.viewer_html(
        _image(data), _image(np.linspace(0, 1, 64).reshape(4, 4, 4)),
        title="signed", threshold=0.5, cmap="hot", symmetric=True,
    )
    result = _run_in_chrome(tmp_path, html, _BROWSER_CHECK)
    assert result["errors"] == [] and "failed" not in result
    assert result["volumes"] == 2
    assert result["oneSidedNegative"] == ""
    assert result["resetNegative"] != ""
    assert result["calMin"] == 2.5
    assert result["colormap"].endswith("viridis")
    assert result["threshold"] and result["cmap"] and result["symmetric"]
    assert result["value"] == "-2"
    assert result["mm"] == "(-1, -1, -1)"
    assert result["voxel"] == "(1, 2, 3)"
    assert result["resetCmap"] == "hot"
    assert "3" in result["colorbarTicks"]


class TestLayers:
    """Check several images on one grid become the overlays of a page."""

    @pytest.fixture
    def state(self):
        first = np.zeros((4, 4, 4), dtype=np.float32)
        second = np.zeros((4, 4, 4), dtype=np.float32)
        first[1, 2, 3], second[0, 0, 0], second[1, 1, 1] = 2.0, -1.0, 4.0
        return _state(brain_viewer.viewer_html(
            [("lift", _image(first)), ("uniformity", _image(second))],
            None, title="t", threshold="95%", cmap="hot",
            symmetric=[False, True],
        ))

    def test_one_overlay_per_image(self, state):
        assert [o["name"] for o in state["overlays"]] == [
            "lift", "uniformity"
        ]
        assert _overlay_volume(state["overlays"][0], (4, 4, 4))[1, 2, 3] == 2
        second = _overlay_volume(state["overlays"][1], (4, 4, 4))
        assert second[0, 0, 0] == -1 and second[1, 1, 1] == 4

    def test_each_overlay_has_its_own_settings(self, state):
        layers = state["initial"]["layers"]
        assert [layer["symmetric"] for layer in layers] == [False, True]
        assert layers[0]["cmap"] == "hot"
        assert layers[1]["cmap"] != "hot"
        assert all(layer["visible"] for layer in layers)
        assert all(
            layer["threshold"] == 95.0
            and layer["thresholdMode"] == "percentile" for layer in layers
        )
        assert {layer["cmap"] for layer in layers} <= set(state["colormaps"])
        assert state["initial"]["active"] == 0

    def test_masks_of_several_answers_have_distinct_colours(self):
        """The masks of the answers of a program with several, value 1
        each, are drawn in the top colours of their colormaps: those of
        the masks, single hues in turn, not those whose top is alike
        (plasma and viridis both end in cyan)."""
        mask = np.zeros((4, 4, 4), dtype=np.float32)
        mask[1, 1, 1] = 1.0
        state = _state(brain_viewer.viewer_html(
            [("front: mask", _image(mask)), ("temp: mask", _image(mask)),
             ("weighted: w", _image(mask))],
            None, title="t", threshold="0", cmap=None, symmetric=False,
        ))
        cmaps = [layer["cmap"] for layer in state["initial"]["layers"]]
        assert cmaps[:2] == list(brain_viewer.MASK_CMAPS[:2])
        assert cmaps[2] not in brain_viewer.MASK_CMAPS
        assert set(cmaps) <= set(state["colormaps"])

    def test_a_mask_alone_keeps_the_colormap(self):
        mask = np.zeros((4, 4, 4), dtype=np.float32)
        mask[1, 1, 1] = 1.0
        state = _state(brain_viewer.viewer_html(
            _image(mask), None, title="t", threshold="0", cmap=None,
            symmetric=False,
        ))
        assert state["initial"]["layers"][0]["cmap"] == (
            brain_viewer.DEFAULT_CMAP
        )

    def test_the_cursor_starts_on_the_peak_of_the_first(self, state):
        assert state["initial"]["cursor"] == [1, 2, 3]

    def test_images_of_several_grids_are_drawn_on_the_finest(self):
        """
        The regions of an answer, on the 2 mm grid of their atlas, beside
        the streamlines of another, counted on the 1 mm grid of the
        background, failed ("not on the grid of the first one"). The
        coarser image is resampled to the finer grid, each voxel taking the
        value of the nearest: a mask stays a mask and a count keeps its
        value.
        """
        coarse = np.zeros((4, 4, 4), dtype=np.float32)
        coarse[1, 1, 1] = 1.0
        fine_affine = AFFINE.copy()
        fine_affine[:3, :3] /= 2
        fine = np.zeros((8, 8, 8), dtype=np.float32)
        fine[6, 6, 6] = 7.0
        state = _state(brain_viewer.viewer_html(
            [("regions: mask", _image(coarse)),
             ("tract: streamlines", _image(fine, fine_affine))],
            None, title="t", threshold="95%", cmap=None, symmetric=False,
        ))
        assert state["shape"] == [8, 8, 8]
        assert np.allclose(state["affine"], fine_affine)
        mask = _overlay_volume(state["overlays"][0], (8, 8, 8))
        assert set(np.unique(mask)) == {0.0, 1.0}
        # the 2 mm voxel (1, 1, 1), at (-1, -3, -5) mm, is the 1 mm voxel
        # (2, 2, 2) and some of its neighbours, no more than the 8 it covers
        assert mask[2, 2, 2] == 1 and 1 <= mask.sum() <= 8
        assert _overlay_volume(state["overlays"][1])[6, 6, 6] == 7.0


_LAYERS_CHECK = _CHECK_HELPERS + """
<script>
brainViewer.ready.then(function () {
  var out = {};
  var names = function () {
    return brainViewer.nv.volumes.slice(1).map(function (v) {
      return v.neurolangName;
    });
  };
  out.colorbars = document.querySelectorAll('#colorbars canvas').length;
  out.layerShown = getComputedStyle(
    document.getElementById('layer-control')).display !== 'none';
  brainViewer.moveCursor([1, 2, 3]);
  out.value = document.getElementById('value').textContent;
  out.firstCmap = document.getElementById('cmap').value;
  set('layer', '1', 'change');
  out.secondCmap = document.getElementById('cmap').value;
  var before = pixels();
  set('visible', false, 'change');
  out.hidden = changed(before, pixels());
  out.hiddenOpacity = brainViewer.nv.volumes[2].opacity;
  set('visible', true, 'change');
  out.order = names();
  set('layer', '0', 'change');
  var drawn = pixels();
  click('layer-up');
  out.raised = names();
  out.raisedChanged = changed(drawn, pixels());
  click('layer-down');
  out.lowered = names();
  click('layer-up');
  click('reset');
  out.reset = names();
  report(out);
}).catch(function (e) { report({failed: String(e)}); });
</script>
"""


@pytest.mark.skipif(_chrome() is None, reason="no headless Chrome")
def test_the_overlays_in_a_headless_browser(tmp_path):
    """Check each overlay has a colour bar, a value at the cursor and
    its own controls, that hiding one redraws the slices, and that the
    order they are drawn in changes."""
    first = np.zeros((4, 4, 4), dtype=np.float32)
    second = np.zeros((4, 4, 4), dtype=np.float32)
    first[1:3, 1:3, :], second[1:3, 1:3, :] = 2.0, 5.0
    html = brain_viewer.viewer_html(
        [("lift", _image(first)), ("uniformity", _image(second))],
        None, title="layers", threshold=0.5, cmap="hot",
        symmetric=[False, False],
    )
    result = _run_in_chrome(tmp_path, html, _LAYERS_CHECK)
    assert result["errors"] == [] and "failed" not in result
    assert result["colorbars"] == 2 and result["layerShown"]
    assert result["value"] == "lift 2 · uniformity 5"
    assert result["firstCmap"] == "hot" and result["secondCmap"] != "hot"
    assert result["hidden"] and result["hiddenOpacity"] == 0
    assert result["order"] == ["lift", "uniformity"]
    assert result["raised"] == ["uniformity", "lift"]
    assert result["raisedChanged"]
    assert result["lowered"] == ["lift", "uniformity"]
    assert result["reset"] == ["lift", "uniformity"]


_DISPLAY_CHECK = _CHECK_HELPERS + """
<script>
brainViewer.ready.then(function () {
  var nv = brainViewer.nv, out = {};
  var view = function () { return document.getElementById('slice-type').value; };
  var before = pixels();
  set('slice-type', 'render', 'change');
  out.render = nv.opts.sliceType === nv.sliceTypeRender;
  out.renderDrawn = changed(before, pixels());
  set('slice-type', 'axial', 'change');
  out.axial = nv.opts.sliceType === nv.sliceTypeAxial;
  set('slice-type', 'multiplanar', 'change');
  set('layout', 'grid', 'change');
  out.grid = nv.opts.multiplanarLayout === niivue.MULTIPLANAR_TYPE.GRID;
  set('render-tile', true, 'change');
  out.renderTile = nv.opts.multiplanarShowRender === niivue.SHOW_RENDER.ALWAYS;
  set('drag-mode', 'pan', 'change');
  out.pan = nv.opts.dragMode === nv.dragModes.pan;
  before = pixels();
  set('nv-colorbar', true, 'change');
  out.colorbar = nv.opts.isColorbar;
  out.colorbarDrawn = changed(before, pixels());
  set('orient-cube', true, 'change');
  out.cube = nv.opts.isOrientCube;
  set('ruler', true, 'change');
  out.ruler = nv.opts.isRuler;
  set('orientation-text', false, 'change');
  out.orientationText = nv.opts.isOrientationTextVisible;
  set('crosshair-width', '3', 'change');
  out.crosshairWidth = nv.opts.crosshairWidth;
  set('crosshair-color', '#ff0000', 'input');
  out.crosshairColor = Array.from(nv.opts.crosshairColor).slice(0, 3);
  set('crosshair-3d', true, 'change');
  out.crosshair3D = nv.opts.show3Dcrosshair;
  set('radiological', true, 'change');
  out.radiological = nv.opts.isRadiologicalConvention;
  set('smooth', false, 'change');
  out.nearest = nv.opts.isNearestInterpolation;
  before = pixels();
  set('gamma', '2.5', 'input');
  out.gammaDrawn = changed(before, pixels());
  set('clip-plane', true, 'change');
  out.clip = nv.scene.clipPlaneDepthAziElevs[0][0] < 2;
  set('slice-type', 'axial', 'change');
  // NiiVue ignores the keys within its debounce time of the last one.
  return new Promise(function (r) { setTimeout(r, 200); }).then(function () {
  nv.canvas.dispatchEvent(new KeyboardEvent('keyup', {code: 'KeyV', bubbles: true}));
  out.hotKeyView = nv.opts.sliceType !== nv.sliceTypeAxial;
  out.hotKeyListed = view() === ['axial', 'coronal', 'sagittal', 'multiplanar', 'render'][nv.opts.sliceType];
  click('reset');
  out.reset = {
    view: view(), sliceType: nv.opts.sliceType === nv.sliceTypeMultiplanar,
    layout: nv.opts.multiplanarLayout === niivue.MULTIPLANAR_TYPE.ROW,
    renderTile: nv.opts.multiplanarShowRender === niivue.SHOW_RENDER.NEVER,
    drag: nv.opts.dragMode === nv.dragModes.contrast,
    colorbar: nv.opts.isColorbar, cube: nv.opts.isOrientCube,
    ruler: nv.opts.isRuler, radiological: nv.opts.isRadiologicalConvention,
    crosshairWidth: nv.opts.crosshairWidth,
    clip: nv.scene.clipPlaneDepthAziElevs[0][0] < 2,
    checkbox: document.getElementById('nv-colorbar').checked
  };
  report(out);
  });
}).catch(function (e) { report({failed: String(e)}); });
</script>
"""


@pytest.mark.skipif(_chrome() is None, reason="no headless Chrome")
def test_the_niivue_display_controls_in_a_headless_browser(tmp_path):
    """Check the controls of NiiVue's display: the view (a slice, the
    three slices, with or without the 3D render, or the 3D render), the
    layout, the drag mode, the colour bar, orientation cube, ruler and
    labels, the crosshair, the radiological convention, the
    interpolation, the gamma and the clip plane; that the view hot key
    keeps the list of the views in step; and that Reset restores them."""
    data = np.zeros((8, 8, 8), dtype=np.float32)
    data[2:6, 2:6, 2:6] = 3.0
    html = brain_viewer.viewer_html(
        _image(data), _image(np.linspace(0, 1, 512).reshape(8, 8, 8)),
        title="display", threshold=0.5, cmap="hot", symmetric=False,
    )
    result = _run_in_chrome(tmp_path, html, _DISPLAY_CHECK)
    assert result["errors"] == [] and "failed" not in result, result
    assert result["render"] and result["renderDrawn"] and result["axial"]
    assert result["grid"] and result["renderTile"] and result["pan"]
    assert result["colorbar"] and result["colorbarDrawn"]
    assert result["cube"] and result["ruler"]
    assert result["orientationText"] is False
    assert result["crosshairWidth"] == 3
    assert result["crosshairColor"] == [1, 0, 0]
    assert result["crosshair3D"] and result["radiological"]
    assert result["nearest"] and result["gammaDrawn"] and result["clip"]
    assert result["hotKeyView"] and result["hotKeyListed"]
    assert result["reset"] == {
        "view": "multiplanar", "sliceType": True, "layout": True,
        "renderTile": True, "drag": True, "colorbar": False,
        "cube": False, "ruler": False, "radiological": False,
        "crosshairWidth": 1, "clip": False, "checkbox": False,
    }


_NETWORK_CHECK = _CHECK_HELPERS + """
<script>
brainViewer.ready.then(function () {
  var nv = brainViewer.nv;
  var out = {
    meshes: nv.meshes.length,
    nodes: nv.meshes.length ? nv.meshes[0].nodes.length : 0,
    renderTile: document.getElementById('render-tile').checked,
    listed: document.querySelectorAll('#edges li').length,
    count: document.getElementById('network-count').textContent,
    first: document.querySelector('#edges li').textContent,
    errors: window.__errors || []
  };
  var mesh = nv.meshes[0];
  out.radii = mesh.edges.map(function (e) {
    return e.colorValue * mesh.edgeScale;
  });
  out.strength = mesh.nodes.map(function (n) { return n.colorValue; });
  var input = document.getElementById('edge-threshold');
  input.value = '0.15';
  input.dispatchEvent(new Event('input'));
  out.thresholded = {
    meshes: nv.meshes.length, nodes: nv.meshes[0].nodes.length,
    edges: nv.meshes[0].edges.length,
    count: document.getElementById('network-count').textContent,
    slider: document.getElementById('edge-slider').value
  };
  report(out);
}).catch(function (e) { report({failed: String(e)}); });
</script>
"""


@pytest.mark.skipif(_chrome() is None, reason="no headless Chrome")
def test_the_network_in_a_headless_browser(tmp_path):
    """Check NiiVue draws a network, in the 3D render, and the page lists
    its strongest edges."""
    network = brain_viewer.connectome_state(
        ["a", "b", "c"], np.array([[0.0, 0, 0], [10, 0, 0], [0, 10, 0]]),
        [(0, 1, 0.1), (1, 2, 0.2), (0, 2, 0.4)], 0,
    )
    html = brain_viewer.viewer_html(
        _image(np.ones((4, 4, 4), dtype=np.float32)), None, title="network",
        threshold=0, cmap=None, symmetric=False, connectome=network,
    )
    result = _run_in_chrome(tmp_path, html, _NETWORK_CHECK)
    assert result["errors"] == [] and "failed" not in result
    assert result["meshes"] == 1 and result["nodes"] == 3
    assert result["renderTile"] is True
    assert result["listed"] == 3 and "3 nodes, 3 edges" in result["count"]
    assert result["first"] == "a — c: 0.4"
    # thicker with the value: from a fifth of the thickest at the
    # threshold (0, the thinnest edge 0.1 above it) to the largest
    assert result["radii"] == pytest.approx([
        brain_viewer.EDGE_RADIUS * (v + 0.1) / 0.5 for v in (0.4, 0.2, 0.1)
    ])
    assert result["strength"] == pytest.approx([0.5, 0.3, 0.6])
    # the edge threshold draws the network again, of the edges above it
    assert result["thresholded"] == {
        "meshes": 1, "nodes": 3, "edges": 2,
        "count": "3 nodes, 2 edges shown", "slider": "167",
    }


_NETWORK_HOVER_CHECK = _CHECK_HELPERS + """
<script>
brainViewer.ready.then(function () {
  // the mouse over every point of the views, the names shown beside it
  var canvas = document.getElementById('gl');
  var tip = document.getElementById('region-tip');
  var rect = canvas.getBoundingClientRect(), named = {};
  for (var x = 0; x < rect.width; x += 3) {
    for (var y = 0; y < rect.height; y += 3) {
      canvas.dispatchEvent(new MouseEvent('mousemove', {
        clientX: rect.left + x, clientY: rect.top + y, bubbles: true}));
      if (!tip.hidden) named[tip.textContent] = true;
    }
  }
  canvas.dispatchEvent(new MouseEvent('mouseleave'));
  report({named: Object.keys(named).sort(), hidden: tip.hidden});
}).catch(function (e) { report({failed: String(e)}); });
</script>
"""


@pytest.mark.skipif(_chrome() is None, reason="no headless Chrome")
def test_the_network_is_named_under_the_mouse(tmp_path):
    """Check the mouse over a node of the network shows its name, and
    over an edge the names of the nodes it joins and its value."""
    network = brain_viewer.connectome_state(
        ["a", "b", "c"],
        np.array([[5.0, 15, 13], [29, 15, 13], [17, 27, 13]]),
        [(0, 1, 0.4), (1, 2, 0.2)], 0,
    )
    html = brain_viewer.viewer_html(
        _image(np.ones((20, 20, 20), dtype=np.float32)), None,
        title="network", threshold=0, cmap=None, symmetric=False,
        connectome=network,
    )
    result = _run_in_chrome(tmp_path, html, _NETWORK_HOVER_CHECK)
    assert result["errors"] == [] and "failed" not in result
    assert set(result["named"]) == {"a", "b", "c", "a — b: 0.4", "b — c: 0.2"}
    assert result["hidden"]

# Three streamlines in the millimetres of the 4×4×4 grid of AFFINE.
_LINES = [
    np.array([[-3.0, -5.0, -7.0], [-1.0, -3.0, -5.0], [1.0, -1.0, -3.0]]),
    np.array([[-3.0, -1.0, -3.0], [3.0, -1.0, -3.0]]),
    np.array([[1.0, -5.0, -7.0], [1.0, 1.0, -7.0], [1.0, 1.0, -1.0]]),
]


class TestStreamlines:
    """Check the streamlines the page draws."""

    def test_shown_streamlines_are_evenly_subsampled(self):
        assert brain_viewer.shown_streamlines(range(10), 4) == [0, 3, 6, 9]
        assert brain_viewer.shown_streamlines([5, 7], 4) == [5, 7]

    def test_the_default_cap(self, monkeypatch):
        monkeypatch.setattr(brain_viewer, "MAX_STREAMLINES", 3)
        assert brain_viewer.shown_streamlines(range(5)) == [0, 2, 4]

    def test_trk_round_trip(self):
        import io

        trk = nib.streamlines.TrkFile.load(
            io.BytesIO(brain_viewer.trk_bytes(_LINES))
        )
        assert len(trk.streamlines) == 3
        for read, line in zip(trk.streamlines, _LINES):
            assert np.allclose(read, line)
        # each with its rank, for the page to draw as many as asked
        ranks = trk.tractogram.data_per_streamline["rank"]
        assert ranks.ravel().tolist() == [3.0, 1.0, 2.0]

    def test_the_k_highest_ranks_are_an_even_sample(self):
        for n in (1, 3, 10, 16, 100):
            ranks = brain_viewer.streamline_ranks(n)
            assert sorted(ranks.tolist()) == list(range(1, n + 1))
        ranks = brain_viewer.streamline_ranks(16)
        # the 4 highest of 16 are every fourth; the 2 highest, 0 and 8
        assert np.flatnonzero(ranks >= 16 - 4 + 1).tolist() == [0, 4, 8, 12]
        assert np.flatnonzero(ranks >= 16 - 2 + 1).tolist() == [0, 8]
        # not the first k of the file, whatever n is
        ranks = brain_viewer.streamline_ranks(100)
        shown = np.flatnonzero(ranks >= 100 - 10 + 1)
        assert shown.max() > 80 and np.diff(shown).max() < 25
        assert len(brain_viewer.streamline_ranks(0)) == 0

    def test_the_page_holds_the_streamlines(self):
        html = brain_viewer.viewer_html(
            _image(np.ones((4, 4, 4), dtype=np.float32)), None,
            title="streamlines", threshold=0, cmap=None, symmetric=False,
            streamlines=brain_viewer.streamlines_state(_LINES, 7),
        )
        state = _state(html)
        streamlines = state["streamlines"]
        assert streamlines["shown"] == 3 and streamlines["total"] == 7
        trk = _decode(streamlines["trk"], np.uint8).tobytes()
        assert trk == brain_viewer.trk_bytes(_LINES)
        assert state["initial"]["display"] == {
            "renderTile": True, "layout": "grid",
        }
        assert 'id="streamline-number"' in html
        assert 'id="streamline-opacity"' not in html
        assert state["space"] == "MNI"
        assert "bundles" not in streamlines

    def test_the_page_holds_the_bundles(self):
        state = brain_viewer.streamlines_state(
            _LINES, 7, (["left", "right"], ["#1f77b4", "#aec7e8"], [1, 0, 1])
        )
        bundles = state["bundles"]
        assert bundles["names"] == ["left", "right"]
        assert bundles["colours"] == ["#1f77b4", "#aec7e8"]
        assert _decode(bundles["of"], np.uint16).tolist() == [1, 0, 1]


_STREAMLINES_CHECK = _CHECK_HELPERS + """
<script>
brainViewer.ready.then(function () {
  var nv = brainViewer.nv, mesh = nv.meshes[0];
  var out = {
    meshes: nv.meshes.length,
    offsets: Array.from(mesh.offsetPt0),
    points: Array.from(mesh.pts).map(function (v) {
      return Math.round(v * 1000) / 1000;
    }),
    fiberColor: mesh.fiberColor,
    sliceMM: nv.opts.isSliceMM,
    space: document.getElementById('space').textContent,
    count: document.getElementById('streamline-count').textContent,
    shown: document.getElementById('streamlines').style.display
  };
  var before = pixels();
  set('streamlines-visible', false, 'change');
  out.hidden = mesh.visible === false && changed(before, pixels());
  set('streamlines-visible', true, 'change');
  // The number: all of them at first; at the foot of the slider, one, the
  // first of the ranks; the label tells it. Back to the top, all again.
  var label = document.getElementById('streamline-count');
  out.all = {drawn: mesh.indexCount, label: label.textContent};
  set('streamline-number', '0');
  out.one = {drawn: mesh.indexCount, label: label.textContent};
  set('streamline-number', '1000');
  out.again = {drawn: mesh.indexCount, label: label.textContent};
  out.opacity = mesh.opacity;
  out.colourControl = !document.getElementById('streamline-colour-control').hidden;
  report(out);
}).catch(function (e) { report({failed: String(e)}); });
</script>
"""

_BUNDLES_CHECK = _CHECK_HELPERS + """
<script>
brainViewer.ready.then(function () {
  var nv = brainViewer.nv, mesh = nv.meshes[0];
  var legend = document.getElementById('bundle-legend');
  // the number of pixels near magenta and near cyan, the colours of the
  // bundles (NiiVue dithers each streamline a little)
  function near(p) {
    var magenta = 0, cyan = 0;
    for (var i = 0; i < p.length; i += 4) {
      if (p[i] > 200 && p[i + 1] < 60 && p[i + 2] > 200) magenta++;
      if (p[i] < 60 && p[i + 1] > 200 && p[i + 2] > 200) cyan++;
    }
    return {magenta: magenta, cyan: cyan};
  }
  function colours() {
    return Array.from(legend.querySelectorAll('.swatch'))
      .map(function (s) { return s.style.background; });
  }
  var out = {
    control: !document.getElementById('streamline-colour-control').hidden,
    choice: document.getElementById('streamline-colour').value,
    legend: Array.from(legend.children).map(function (li) {
      return li.textContent; }),
    colours: colours(), legendShown: !legend.hidden,
    groups: mesh.groups.map(function (g) { return Array.from(g.vals); }),
    byBundle: mesh.fiberGroupColormap !== null
  };
  out.drawnColours = near(pixels());
  // NiiVue dithers each streamline with Math.random() on every rebuild of
  // the mesh, as a change of colours is: the pixels at the edge of near()
  // would come and go. Undithered, the drawings to compare are the same.
  nv.setMeshProperty(mesh.id, 'fiberDither', 0);
  var undithered = pixels();
  out.undithered = near(undithered);
  set('streamline-colour', 'direction', 'change');
  out.direction = {
    byBundle: mesh.fiberGroupColormap !== null, legendShown: !legend.hidden,
    colours: near(pixels()), drawn: mesh.indexCount
  };
  set('streamline-colour', 'bundle', 'change');
  var back = pixels();
  out.back = near(back);
  out.backRedrawn = changes(undithered, back);
  // the number still follows the ranks, whatever the colours
  set('streamline-number', '0');
  out.one = mesh.indexCount;
  report(out);
}).catch(function (e) { report({failed: String(e)}); });
</script>
"""


@pytest.mark.skipif(_chrome() is None, reason="no headless Chrome")
def test_the_bundles_in_a_headless_browser(tmp_path):
    """Check the streamlines of bundles are in the colours of their
    bundles, which a legend names, or by direction, as "Colour by"
    chooses, and the number of them drawn still follows their ranks."""
    html = brain_viewer.viewer_html(
        _image(np.ones((4, 4, 4), dtype=np.float32)), None,
        title="bundles", threshold=0, cmap=None, symmetric=False,
        streamlines=brain_viewer.streamlines_state(
            _LINES, 7, (["a", "b"], ["#ff00ff", "#00ffff"], [0, 1, 0])
        ), space="RAS",
    )
    result = _run_in_chrome(tmp_path, html, _BUNDLES_CHECK)
    assert result["errors"] == [] and "failed" not in result, result
    assert result["control"] and result["choice"] == "bundle"
    assert result["legend"] == ["a (2)", "b (1)"] and result["legendShown"]
    assert result["colours"] == ["rgb(255, 0, 255)", "rgb(0, 255, 255)"]
    assert result["groups"] == [[0, 2], [1]] and result["byBundle"]
    # pixels of the colours of the bundles, which no direction of these
    # streamlines gives, and the same drawing again when back to bundles
    by_bundle, by_direction = result["drawnColours"], result["direction"]
    for colour in ("magenta", "cyan"):
        assert by_bundle[colour] > 0
        assert result["undithered"][colour] > 0
        assert by_direction["colours"][colour] == 0
    assert by_direction["byBundle"] is False
    assert by_direction["legendShown"] is False
    assert by_direction["drawn"] == 11
    assert result["back"] == result["undithered"]
    assert result["backRedrawn"] == 0
    assert result["one"] == 4


@pytest.mark.skipif(_chrome() is None, reason="no headless Chrome")
def test_the_streamlines_in_a_headless_browser(tmp_path):
    """Check NiiVue reads every streamline of the page, at its points,
    coloured by direction, and the controls hide them and set their
    number."""
    html = brain_viewer.viewer_html(
        _image(np.ones((4, 4, 4), dtype=np.float32)), None,
        title="streamlines", threshold=0, cmap=None, symmetric=False,
        streamlines=brain_viewer.streamlines_state(_LINES, 7), space="RAS",
    )
    result = _run_in_chrome(tmp_path, html, _STREAMLINES_CHECK)
    assert result["errors"] == [] and "failed" not in result, result
    assert result["meshes"] == 1 and result["offsets"] == [0, 3, 5, 8]
    assert result["points"] == pytest.approx(
        np.concatenate(_LINES).ravel().tolist(), abs=1e-3
    )
    assert result["fiberColor"] == "Local"
    # the slices are cut in mm, as the streamlines are drawn: an oblique
    # background is not straightened under them
    assert result["sliceMM"] is True
    assert result["space"] == "RAS"
    assert result["count"] == "3 of 7 streamlines shown"
    assert result["shown"] == "" and result["hidden"]
    # 3 + 2 + 3 points, and an end of line each: 11 indices for all of them,
    # 4 for the first, the highest rank
    assert result["all"] == {
        "drawn": 11, "label": "3 of 7 streamlines shown",
    }
    assert result["one"] == {
        "drawn": 4, "label": "1 of 7 streamlines shown",
    }
    assert result["again"] == result["all"]
    assert result["opacity"] == 1
    assert result["colourControl"] is False


_REGIONS_CHECK = _CHECK_HELPERS + """
<script>
brainViewer.ready.then(function () {
  var nv = brainViewer.nv, canvas = document.getElementById('gl');
  var tip = document.getElementById('region-tip');
  // the mouse over every point of the slices, until a region is under it
  var named = '', rect = canvas.getBoundingClientRect();
  for (var x = 0; x < rect.width && !named; x += 12) {
    for (var y = 0; y < rect.height && !named; y += 12) {
      canvas.dispatchEvent(new MouseEvent('mousemove', {
        clientX: rect.left + x, clientY: rect.top + y, bubbles: true}));
      if (!tip.hidden) named = tip.textContent;
    }
  }
  var colours = nv.volumes[nv.volumes.length - 1];
  var before = colours.opacity;
  set('atlas-colours', true, 'change');
  report({
    named: named, before: before, after: colours.opacity,
    control: !document.getElementById('atlas-colours-control').hidden,
    readout: document.getElementById('region').textContent
  });
}).catch(function (e) { report({failed: String(e)}); });
</script>
"""


@pytest.mark.skipif(_chrome() is None, reason="no headless Chrome")
def test_the_regions_are_named_under_the_mouse(tmp_path):
    """Check the page names the region of the result under the mouse, and
    draws the regions in their colours when asked."""
    from neurolang_apps.utils.tui.nifti import RegionLayer

    numbers = np.zeros((4, 4, 4), dtype=np.int16)
    numbers[:2] = 1
    numbers[2:] = 2
    regions = RegionLayer(
        _image(numbers), ["left part", "right part"],
        ["#ff0000", "#0000ff"], False,
    )
    html = brain_viewer.viewer_html(
        _image(numbers.astype(np.float32)), None, title="regions",
        threshold=0, cmap=None, symmetric=False, regions=regions,
    )
    result = _run_in_chrome(tmp_path, html, _REGIONS_CHECK)
    assert result["errors"] == [] and "failed" not in result
    assert result["named"] in ("left part", "right part")
    assert result["readout"] in ("left part", "right part")
    assert result["control"]
    assert (result["before"], result["after"]) == (0, 1)


_RANGE_CHECK = _CHECK_HELPERS + """
<script>
brainViewer.ready.then(function () {
  var out = {};
  var volume = brainViewer.nv.volumes[1];
  var histogram = document.getElementById('threshold-histogram');
  out.bins = histogram.dataset.bins;
  out.rangeBefore = histogram.dataset.range;
  var before = pixels();
  set('threshold-high', '2.5', 'change');
  out.calMax = volume.cal_max;
  out.hidden = changed(before, pixels());
  out.rangeAfter = histogram.dataset.range;
  brainViewer.moveCursor([2, 2, 3]);  // 3, above the high threshold
  out.value = document.getElementById('value').textContent;
  set('threshold-high-slider', '1000', 'input');
  out.sliderTop = document.getElementById('threshold-high').value;
  set('threshold-high', '2', 'change');
  click('reset');
  out.resetHigh = document.getElementById('threshold-high').value;
  out.resetRange = histogram.dataset.range;
  report(out);
}).catch(function (e) { report({failed: String(e)}); });
</script>
"""


@pytest.mark.skipif(_chrome() is None, reason="no headless Chrome")
def test_a_range_of_values_with_their_histogram_in_a_headless_browser(
    tmp_path,
):
    """Check the high threshold hides the voxels above it, the value
    under the cursor staying the image's, and the histogram of the
    values marks the range shown."""
    data = np.zeros((4, 4, 4), dtype=np.float32)
    data[0, 0, 3], data[1, 1, 3], data[2, 2, 3] = 1.0, 2.0, 3.0
    html = brain_viewer.viewer_html(
        _image(data), None, title="range", threshold=0.5, cmap="hot",
        symmetric=False,
    )
    result = _run_in_chrome(tmp_path, html, _RANGE_CHECK)
    assert result["errors"] == [] and "failed" not in result
    bins = [int(count) for count in result["bins"].split()]
    assert sum(bins) == 3  # the three nonzero values
    assert result["rangeBefore"] == "0.5 3"
    assert result["calMax"] == 2.5
    assert result["hidden"]
    assert result["rangeAfter"] == "0.5 2.5"
    assert result["value"] == "3"
    assert result["sliderTop"] == "3"
    assert result["resetHigh"] == "3" and result["resetRange"] == "0.5 3"


_SLIDER_CHECK = _CHECK_HELPERS + """
<script>
brainViewer.ready.then(function () {
  // The x of a thumb, its centre running from 7px to 7px short of the
  // end of its 14px-thumbed range, against the x of the threshold drawn
  // on the histogram.
  var histogram = document.getElementById('threshold-histogram');
  function offsets() {
    var box = histogram.getBoundingClientRect();
    var range = histogram.dataset.range.split(' ').map(Number);
    return ['threshold-slider', 'threshold-high-slider'].map(function (id, i) {
      var input = document.getElementById(id), r = input.getBoundingClientRect();
      var thumb = r.left + 7 + input.value / 1000 * (r.width - 14);
      return Math.abs(thumb - (box.left + range[i] / 3 * box.width));
    });
  }
  var out = {percentile: offsets()};
  set('threshold-slider', '500', 'input');
  out.dragged = Number(histogram.dataset.range.split(' ')[0]);
  out.draggedOffsets = offsets();
  set('threshold-mode', 'value', 'change');
  set('threshold', '0.75', 'change');
  out.value = offsets();
  report(out);
}).catch(function (e) { report({failed: String(e)}); });
</script>
"""


@pytest.mark.skipif(_chrome() is None, reason="no headless Chrome")
def test_the_threshold_sliders_follow_the_histogram(tmp_path):
    """Check a thumb of the threshold sliders sits over the value it
    sets on the histogram, also in percentiles of skewed values."""
    data = np.zeros((4, 4, 4), dtype=np.float32)
    data.flat[:20] = 3 * (np.arange(1, 21) / 20) ** 3  # most values small
    html = brain_viewer.viewer_html(
        _image(data), None, title="sliders", threshold="50%", cmap="hot",
        symmetric=False,
    )
    result = _run_in_chrome(tmp_path, html, _SLIDER_CHECK)
    assert result["errors"] == [] and "failed" not in result
    for offsets in ("percentile", "draggedOffsets", "value"):
        assert max(result[offsets]) < 2, (offsets, result[offsets])
    assert result["dragged"] >= 1.5  # half way along the values, not percentiles


_OVERLAP_CHECK = _CHECK_HELPERS + """
<script>
brainViewer.ready.then(function () {
  var histogram = document.getElementById('threshold-histogram');
  var out = {};
  set('threshold', '2.9', 'change');  // the low thumb under the high one
  set('threshold-high-slider', '500', 'input');  // dragged down
  out.down = histogram.dataset.range;
  set('threshold-high-slider', '900', 'input');  // dragged up
  out.up = histogram.dataset.range;
  set('threshold-slider', '950', 'input');  // the low one past the high one
  out.past = histogram.dataset.range;
  report(out);
}).catch(function (e) { report({failed: String(e)}); });
</script>
"""


@pytest.mark.skipif(_chrome() is None, reason="no headless Chrome")
def test_overlapping_threshold_thumbs_can_both_be_dragged(tmp_path):
    """Check the high thumb, on top of the low one when the thresholds
    are close, moves the low threshold when dragged below it, and the
    low thumb dragged above the high one moves the high threshold."""
    data = np.zeros((4, 4, 4), dtype=np.float32)
    data[0, 0, 3], data[1, 1, 3], data[2, 2, 3] = 1.0, 2.0, 3.0
    html = brain_viewer.viewer_html(
        _image(data), None, title="overlap", threshold=0.5, cmap="hot",
        symmetric=False,
    )
    result = _run_in_chrome(tmp_path, html, _OVERLAP_CHECK)
    assert result["errors"] == [] and "failed" not in result
    assert result["down"] == "1.5 3"
    assert result["up"] == "1.5 2.7"
    assert result["past"] == "1.5 2.85"

_EDGE_VALUE_CHECK = _CHECK_HELPERS + """
<script>
brainViewer.ready.then(function () {
  var out = {};
  out.shown = !document.getElementById('edge-value-control').hidden;
  out.options = Array.from(document.getElementById('edge-value').options)
    .map(function (o) { return o.textContent; });
  out.before = document.getElementById('edges').textContent;
  set('edge-value', '1', 'change');
  out.after = document.getElementById('edges').textContent;
  out.threshold = document.getElementById('edge-threshold').value;
  report(out);
}).catch(function (e) { report({failed: String(e)}); });
</script>
"""


def _network_of_two_values():
    """A page of a network whose edges have two value columns, p and q."""
    names, coordinates = ["a", "b"], np.array([[0.0, 0, 0], [10, 0, 0]])
    states = [
        brain_viewer.connectome_state(names, coordinates, [(0, 1, w)], 0)
        for w in (0.25, 3.0)
    ]
    connectome = dict(states[0], value="p", values=[
        dict(state, value=name) for name, state in zip("pq", states)
    ])
    img = nib.Nifti1Image(np.ones((4, 4, 4), np.float32), np.eye(4))
    return brain_viewer.viewer_html(
        img, None, title="t", threshold=0, cmap=None, symmetric=False,
        connectome=connectome,
    )


@pytest.mark.skipif(_chrome() is None, reason="no headless Chrome")
def test_the_edge_value_of_a_network_in_a_headless_browser(tmp_path):
    """Check a network of several value columns offers each, and draws
    its edges and threshold anew when another is chosen."""
    result = _run_in_chrome(
        tmp_path, _network_of_two_values(), _EDGE_VALUE_CHECK
    )
    assert result["errors"] == [] and "failed" not in result
    assert result["shown"] and result["options"] == ["p", "q"]
    assert "0.25" in result["before"] and "3" in result["after"]
    assert result["threshold"] == "0"


def test_the_defaults_of_the_viewer_are_those_of_its_file():
    """The constants are read from viewer.yaml, the page's script is
    given its part, and the help of .view quotes the threshold."""
    import yaml
    from neurolang_apps.utils.tui import nifti

    defaults = yaml.safe_load(brain_viewer.DEFAULTS_FILE.read_text())
    assert brain_viewer.DEFAULT_CMAP == defaults["colormap"]
    assert brain_viewer.OVERLAY_CMAPS == tuple(defaults["overlay_colormaps"])
    assert brain_viewer.MASK_CMAPS == tuple(defaults["mask_colormaps"])
    assert brain_viewer.COLORMAPS == tuple(defaults["colormaps"])
    assert brain_viewer.BACKGROUND_MAX_VOXELS == defaults[
        "background_max_voxels"]
    network = defaults["network"]
    assert (brain_viewer.NODE_RADIUS, brain_viewer.EDGE_RADIUS) == (
        network["node_radius"], network["edge_radius"])
    assert brain_viewer.NETWORK_OVERLAY_OPACITY == network["overlay_opacity"]
    assert brain_viewer.MIN_SHOWN_EDGES == network["min_shown_edges"]
    assert brain_viewer.MAX_EDGES == network["max_edges"]
    assert brain_viewer.MAX_STREAMLINES == defaults["streamlines"][
        "max_shown"]
    assert brain_viewer.MAX_BUNDLES == defaults["streamlines"][
        "max_bundles"]
    assert nifti.VIEW_THRESHOLD == defaults["view_threshold"]
    help_text = " ".join(nifti.VIEW_HELP.split())
    assert f"default: {defaults['view_threshold']}" in help_text
    assert f"default: {defaults['colormap']}" in help_text
    streamlines = defaults["streamlines"]
    assert f"{streamlines['max_shown']} at most are drawn" in help_text
    assert f"of {streamlines['max_bundles']} values at most" in help_text
    img = nib.Nifti1Image(np.ones((2, 2, 2), np.float32), np.eye(4))
    state = _state(brain_viewer.viewer_html(
        img, None, title="t", threshold=0, cmap=None, symmetric=False,
    ))
    assert state["settings"] == defaults["page"]
    script = (brain_viewer._STATIC / "brain_viewer.js").read_text()
    for name in defaults["page"]:
        assert f"pageSettings.{name}" in script, name


_CONSTANT_CHECK = _CHECK_HELPERS + """
<script>
brainViewer.ready.then(function () {
  var volume = brainViewer.nv.volumes[1];
  var shown = pixels();
  volume.opacity = 0;
  brainViewer.nv.updateGLVolume();
  var out = {drawn: changes(shown, pixels())};
  report(out);
}).catch(function (e) { report({failed: String(e)}); });
</script>
"""


def _pixels_of_a_region(directory, region, value, symmetric):
    """The pixels drawn of the *region* of an image, its voxels of one
    *value*, at the default threshold, a percentile, which is that value."""
    data = np.zeros((4, 4, 4), dtype=np.float32)
    data[region] = value
    html = brain_viewer.viewer_html(
        _image(data), None, title="region", threshold="95%", cmap="hot",
        symmetric=symmetric,
    )
    directory.mkdir()
    result = _run_in_chrome(directory, html, _CONSTANT_CHECK)
    assert result["errors"] == [] and "failed" not in result
    return result["drawn"]


@pytest.mark.skipif(_chrome() is None, reason="no headless Chrome")
@pytest.mark.parametrize("value, symmetric", [
    (1.0, False), (0.25, False), (1.0, True), (-1.0, True),
])
def test_a_region_is_drawn_at_a_percentile_threshold(
    tmp_path, value, symmetric,
):
    """Check a region, or a constant overlay, is drawn at a percentile
    threshold, all its voxels at the threshold, and its other voxels
    are not: a region of one voxel draws fewer pixels."""
    region = _pixels_of_a_region(
        tmp_path / "region", np.s_[1:3, 1:3, 1:3], value, symmetric
    )
    voxel = _pixels_of_a_region(
        tmp_path / "voxel", np.s_[1, 1, 1], value, symmetric
    )
    assert 0 < voxel < region, (voxel, region)
