"""NeuroStore engine initialization."""
