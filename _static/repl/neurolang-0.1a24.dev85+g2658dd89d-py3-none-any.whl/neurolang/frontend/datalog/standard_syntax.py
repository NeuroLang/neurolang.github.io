import functools
import json
import os
import re
from itertools import chain, combinations
from typing import Tuple

from lark import Lark, Transformer
from operator import add, eq, ge, gt, le, lt, mul, ne, pow, sub, truediv

from nl_core.datalog import Conjunction, Fact, Implication, Negation, Union
from nl_core.datalog.constraints_representation import RightImplication
from nl_core.datalog.expressions import AggregationApplication
from nl_expr.expressions import (
    Command,
    Constant,
    Expression,
    FunctionApplication,
    Lambda,
    Query,
    Statement,
    Symbol,
)
from nl_expr.exceptions import NeuroLangFrontendException, ParserError
from nl_expr.expression_pattern_matching import add_match
from nl_expr.expression_walker import PatternWalker, ReplaceExpressionWalker
from nl_expr.logic import Disjunction, ExistentialPredicate
from nl_expr.logic.expression_processing import (
    extract_conjuncts,
    extract_logic_free_variables,
)
from nl_core.probabilistic.expressions import (
    PROB,
    Condition,
    Expectation,
    contains_expectation,
    expectation,
    ProbabilisticChoice,
    ProbabilisticFact,
)
from nl_expr.type_system import Unknown
from ...utils.interactive_parsing import LarkCompleter
from ..resampling import RESAMPLE_MARKER
from .lark_errors import lark_errors_as_neurolang

# The greatest number of conjuncts of the query of PROB[COUNT(x) >= k]: k
# copies of the event and the comparison of each pair, whose size the
# transformations of the lifting, which recurse on it, bear to about 240
# (k = 21 of an atom); its preparation takes some 10 s at k = 20.
MAX_COUNT_CONJUNCTS = 200

# The greatest count of an event that the lifted solvers do not plan, which
# model counting solves in a time exponential in it.
MAX_UNLIFTED_COUNT = 4

# Aggregation function names recognised in rule head arguments.
AGGREGATION_FUNCS = frozenset(
    {"count", "sum", "max", "min", "mean", "avg", "std", "percentile"}
)


ANS = "ans"


def query_symbol(name=None):
    """
    Return the head symbol of a query: ``ans``, or ``ans[name]`` of the
    query ``ans[name](...) :- ...`` that is named, which a program holds
    several of.
    """
    return Symbol(ANS if name is None else f"{ANS}[{name}]")


def is_query_head(head):
    """Return whether *head* is the head of a query, named or not."""
    functor = getattr(head, "functor", None)
    return isinstance(functor, Symbol) and (
        functor.name == ANS or (
            functor.name.startswith(f"{ANS}[") and functor.name.endswith("]")
        )
    )


def query_name(head):
    """
    Return the name of the query of *head*, that of ``ans[name](...)``;
    ``ans`` for a query that is not named.
    """
    name = head.functor.name
    return name[len(ANS) + 1:-1] if name != ANS else ANS


GRAMMAR = u"""
start: expressions
expressions : (expression)+

?expression : rule
            | constraint
            | fact
            | probabilistic_rule
            | probabilistic_fact
            | probabilistic_choice_rule
            | probabilistic_choice_fact
            | prob_head_rule
            | marg_head_rule
            | succ_head_rule
            | statement
            | statement_function
            | command

agg_assign : "AGGREGATE" "[" agg_group_vars "]" "(" conjunction "@" agg_fn_call ")" "=" argument -> agg_assign_vars
           | "AGGREGATE" "[" "(" ")" "]" "(" conjunction "@" agg_fn_call ")" "=" argument -> agg_assign_empty
           | "AGGREGATE" "[" "]" "(" conjunction "@" agg_fn_call ")" "=" argument -> agg_assign_empty

agg_group_vars : cmd_identifier ("," cmd_identifier)*

agg_fn_call : cmd_identifier "(" argument ")"

probabilistic_rule : head PROBA_OP arithmetic_operation IMPLICATION (condition | body)

rule : (head | query) IMPLICATION (condition | body | agg_assign)
IMPLICATION : ":-" | "\N{LEFTWARDS ARROW}"

// PROB[pred] :- body  —  declare a probabilistic rule
prob_head_rule : "PROB" "[" predicate "]" IMPLICATION (condition | body)
               | "PROB" "[" predicate PROB_SEP body "]" IMPLICATION (condition | body)

query : "ans" "(" [ arguments ] ")"
      | "ans" "[" cmd_identifier "]" "(" [ arguments ] ")" -> named_query

condition : composite_predicate PROB_SEP composite_predicate
?composite_predicate : predicate

constraint : body RIGHT_IMPLICATION head
RIGHT_IMPLICATION : "-:" | "\N{RIGHTWARDS ARROW}"

existential_predicate : exists "(" existential_body ")"
?existential_body : arguments (";" | SUCH_THAT_WORD) predicate ( "," predicate )*
SUCH_THAT_WORD : "st"

?head : head_predicate
head_predicate : (identifier | iri_identifier) "(" [ arguments ] ")"

// "|" (or "\N{LOGICAL OR}") is a disjunction; "," binds tighter than it.
?body : disjunction
?disjunction : conjunction (OR_SYMBOL conjunction)*
OR_SYMBOL : "|" | "\N{LOGICAL OR}"
//conjunction : predicate ("," predicate)*
conjunction : predicate (("," | "&" | AND_SYMBOL) predicate)*
AND_SYMBOL : "\N{LOGICAL AND}"

// In parentheses a comparison is a formula of its own, a disjunct or a
// conjunct: (t == 'a' | t == 'b'), (x < 3, y > 2).
?parenthesised_disjunction : parenthesised_conjunction (OR_SYMBOL parenthesised_conjunction)* -> disjunction
parenthesised_conjunction : (predicate | comparison) (("," | "&" | AND_SYMBOL) (predicate | comparison))* -> conjunction

negated_predicate : ("~" | NEG_UNICODE ) predicate
NEG_UNICODE : "\u00AC"
// After "((f(x)" a "," or ")" cannot tell a parenthesised body formula
// from a parenthesised argument or tuple of a comparison (an LALR
// reduce/reduce collision): the priority reads it as a body formula, so
// write "(f(x) < 3)" rather than "((f(x)) < 3)".
predicate.2 : id_application
          | iri_identifier "(" [ arguments ] ")" -> id_application
          | negated_predicate
          | existential_predicate
          | "(" parenthesised_disjunction ")"
          | logical_constant
          | prob_body_predicate
          | expect_body_predicate
          | expect_norm_body_predicate
          | resample_body_predicate
          | marg_body_predicate
          | succ_body_predicate

// PROB[pred] = var  or  PROB[pred // cond] = var  —  probability query inside a rule body
// PROB[COUNT(x) >= k | event] = var  —  the probability that the event holds for at
// least k values of x (any comparison); "|" is also a disjunction in the event
prob_body_predicate : "PROB" "[" bracketed_conjunction "]" "=" argument
                    | "PROB" "[" bracketed_conjunction PROB_SEP bracketed_conjunction "]" "=" argument
                    | "PROB" "[" "COUNT" "(" argument ")" COMPARISON_OPERATOR argument OR_SYMBOL bracketed_conjunction "]" "=" argument -> count_body_predicate
                    | "PROB" "[" "COUNT" "(" argument ")" COMPARISON_OPERATOR argument OR_SYMBOL bracketed_conjunction PROB_SEP bracketed_conjunction "]" "=" argument -> count_body_predicate

// EXPECT[f | event] = e  —  the expected value of f summed over the answers
// of the event, EXPECT[f | event // knowing] = e conditioned as PROB is;
// EXPECT_NORM divides by the sum of their probabilities. The "|" after f is
// that of a disjunction in the event.
expect_body_predicate : "EXPECT" "[" argument OR_SYMBOL bracketed_conjunction [PROB_SEP bracketed_conjunction] "]" "=" argument
expect_norm_body_predicate : "EXPECT_NORM" "[" argument OR_SYMBOL bracketed_conjunction [PROB_SEP bracketed_conjunction] "]" "=" argument

// Inside PROB[...] and MARG[...], a formula may be in parentheses, as in
// a rule's condition: PROB[(a(x), (x < y)) // (b(x), c(x))] = p
?bracketed_conjunction : disjunction

// RESAMPLE[boot](pred(x)) = b  —  pred(x) on each replicate b of the resampling boot
resample_body_predicate : "RESAMPLE" "[" cmd_identifier "]" "(" id_application ")" "=" argument

// MARG[pred] = var  —  marginal probability query inside a rule body
// MARG[pred1, pred2] = var  —  conjunction inside MARG (same semantics as PROB)
marg_body_predicate : "MARG" "[" bracketed_conjunction "]" "=" argument
                    | "MARG" "[" bracketed_conjunction PROB_SEP bracketed_conjunction "]" "=" argument

// SUCC[...] = var  —  success probability query (skipped in execution)
succ_body_predicate : "SUCC" "[" SUCC_INNER "]" "=" argument
SUCC_INNER : /[a-zA-Z_*+.,()&@\\/ \t-]+/

// Separator of the conditional form, in a rule body and inside PROB/MARG
PROB_SEP : "//"

// MARG head rule  —  declare a marginal probability rule
marg_head_rule : "MARG" "[" bracketed_conjunction "]" IMPLICATION (condition | body)
               | "MARG" "[" bracketed_conjunction PROB_SEP bracketed_conjunction "]" IMPLICATION (condition | body)

// SUCC head rule  —  success probability rule (skipped in execution)
succ_head_rule : "SUCC" "[" SUCC_INNER "]" IMPLICATION (condition | body)

id_application : int_ext_identifier "(" [ arguments ] ")"

comparison : argument COMPARISON_OPERATOR argument
COMPARISON_OPERATOR : "==" | "<" | "<=" | ">=" | ">" | "!="

statement : identifier STATEMENT_OP arithmetic_operation
statement_function : identifier "(" [ arguments ] ")" STATEMENT_OP argument
STATEMENT_OP : ":="

probabilistic_fact : ( arithmetic_operation | int_ext_identifier ) PROBA_OP constant_predicate
PROBA_OP : "::"

probabilistic_choice_fact : ( arithmetic_operation | int_ext_identifier ) CHOICE_OP constant_predicate
probabilistic_choice_rule : head CHOICE_OP arithmetic_operation IMPLICATION (condition | body)
CHOICE_OP : "^" | ":~:"

command : "." cmd_identifier "(" [ cmd_args ] ")"
cmd_args : cmd_arg ("," cmd_arg)*
?cmd_arg : pos_item
         | keyword_item

keyword_item : identifier "=" pos_item
pos_item : arithmetic_operation

?function_application : "(" lambda_expression ")" "(" [ arguments ] ")" -> lambda_application
                     | id_application

signed_int_ext_identifier : int_ext_identifier     -> signed_int_ext_identifier
                          | "-" int_ext_identifier -> minus_signed_id
?int_ext_identifier : identifier
                    | ext_identifier
                    | lambda_expression

lambda_expression : "lambda" arguments ":" argument

arguments : argument ("," argument)*
argument : arithmetic_operation | DOTS
DOTS : "..."

arithmetic_operation : term                          -> sing_op
                     | arithmetic_operation "+" term -> plus_op
                     | arithmetic_operation "-" term -> minus_op
term : factor          -> sing_term
     | term "*" factor -> mul_term
     | term "/" factor -> div_term
factor : exponent             -> sing_factor
       | factor POW exponent -> pow_factor
POW : "**"
?exponent : literal | function_application | signed_int_ext_identifier | "(" argument ")"

fact : head_predicate
constant_predicate : identifier "(" (literal | ext_identifier) ("," (literal | ext_identifier))* ")"
                   | identifier "(" ")"

?literal : number | text | iri | tuple_literal

tuple_literal : "(" argument ("," argument)+ ")"

ext_identifier : "@" identifier
identifier : cmd_identifier | identifier_regexp
identifier_regexp : IDENTIFIER_REGEXP
IDENTIFIER_REGEXP : "`" /[0-9a-zA-Z\\/#%._:-]+/ "`"
cmd_identifier : CMD_IDENTIFIER
CMD_IDENTIFIER : /\\b(?!\\bexists\\b)(?!\\b\\u2203\\b)(?!\\bEXISTS\\b)(?!\\bst\\b)(?!\\bans\\b)(?!\\bAGGREGATE\\b)[a-zA-Z_][a-zA-Z0-9_]*(?:\\:[a-zA-Z_][a-zA-Z0-9_-]*(?=\\s*\\())?\\b/

exists : EXISTS_WORD | EXISTS_SYMBOL
EXISTS_WORD : "exists" | "EXISTS"
EXISTS_SYMBOL : "\u2203"

text : TEXT
TEXT : DOUBLE_QUOTE /[^"\\n]*/ DOUBLE_QUOTE
     | SINGLE_QUOTE /[^'\\n]*/ SINGLE_QUOTE

// An IRI, as in SPARQL and Turtle: <http://example.org/a>; as the functor
// of an atom, the predicate named by the IRI.
iri : IRI
iri_identifier : IRI
IRI : /<[a-zA-Z][a-zA-Z0-9+.-]*:[^<>"{}|^`\\\\\\s]*>/
DOUBLE_QUOTE : "\\""
SINGLE_QUOTE : "'"

?number : integer | float
?integer : INT     -> pos_int
         | "-" INT -> neg_int
?float : FLOAT     -> pos_float
       | "-" FLOAT -> neg_float

logical_constant : FALSE | TRUE
TRUE             : "True" | "\u22A4"
FALSE            : "False" | "\u22A5"

WHITESPACE : /[\t ]+/
//NEWLINE : /[(\\u000C)? (\\r)? \\n]+/

%import common.INT
%import common.FLOAT
%import common.NEWLINE

%ignore WHITESPACE
%ignore NEWLINE
"""


OPERATOR = {
    "+": add,
    "-": sub,
    "==": eq,
    ">=": ge,
    ">": gt,
    "<=": le,
    "<": lt,
    "*": mul,
    "!=": ne,
    "**": pow,
    "/": truediv,
}


@functools.lru_cache(maxsize=None)
def compiled_grammar():
    """
    Compile the Datalog grammar on first use (it takes ~0.15 s).

    The nodes of its trees have their lines, which attach a ``%%``
    documentation block to the statement it precedes.
    """
    return Lark(GRAMMAR, parser='lalr', propagate_positions=True)


def __getattr__(name):
    # Lazily expose the compiled grammar as the ``COMPILED_GRAMMAR``
    # module attribute, kept for backwards compatibility.
    if name == "COMPILED_GRAMMAR":
        return compiled_grammar()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


class ExternalSymbol(Symbol):
    def __repr__(self):
        return "@S{{{}: {}}}".format(self.name, self.__type_repr__)


class DatalogTransformer(Transformer):

    def __init__(self, locals=None, globals=None):
        super().__init__()

        if locals is None:
            locals = {}
        if globals is None:
            globals = {}

        self.locals = locals
        self.globals = globals
        # the variables written "_", each a fresh symbol
        self.anonymous = set()

    def _hide_anonymous(self, formula):
        """``∃`` the anonymous variables of a formula: in a negation or a
        disjunct, ``_`` is quantified there, ``~p(x, _)`` is ``~∃y p(x, y)``.
        """
        for v in extract_logic_free_variables(formula):
            if v in self.anonymous:
                formula = ExistentialPredicate(v, formula)
        return formula

    def start(self, ast):
        return ast[0]

    def expressions(self, ast):
        if isinstance(ast[0], Expression):
            all_formulas = []
            for item in ast:
                if isinstance(item, Union):
                    all_formulas.extend(item.formulas)
                elif isinstance(item, Expression):
                    all_formulas.append(item)
            return Union(tuple(all_formulas))
        else:
            ast = ast[0]
        return Union(ast)

    def probabilistic_rule(self, ast):
        head = ast[0]
        probability = ast[2]
        body = ast[4]
        return Implication(
            ProbabilisticFact(probability, head),
            body,
        )

    def prob_head_rule(self, ast):
        # PROB[pred] :- body              → [pred, IMPLICATION_token, body]
        # PROB[pred // cond] :- body      → [pred, SEP_token, cond, IMPLICATION_token, body]
        if len(ast) >= 4:
            # Conditional form: PROB[pred // cond] :- body
            pred = ast[0]
            cond_body = ast[2]
            body = ast[4] if len(ast) > 4 else ast[3]
            prob_vars = tuple(
                v for v in extract_logic_free_variables(pred)
            )
            prob_head = self._add_prob_arg_to_predicate(pred, prob_vars)
            return Implication(prob_head, Condition(pred, cond_body))
        else:
            # Simple form: PROB[pred] :- body
            pred = ast[0]
            body = ast[2]
            prob_vars = tuple(
                v for v in extract_logic_free_variables(pred)
            )
            prob_head = self._add_prob_arg_to_predicate(pred, prob_vars)
            return Implication(prob_head, body)

    @staticmethod
    def _add_prob_arg_to_predicate(pred, prob_vars):
        """Add PROB(prob_vars) as an extra argument to a predicate."""
        if isinstance(pred, FunctionApplication) and hasattr(pred, 'args'):
            return pred.functor(*pred.args, FunctionApplication(PROB, prob_vars))
        return pred

    def marg_head_rule(self, ast):
        # MARG[pred] :- body         → [conjunction, IMPLICATION_token, body]
        # MARG[pred // cond] :- body → [conjunction, SEP_token, cond, IMPLICATION_token, body]
        if len(ast) >= 4:
            conjunction = ast[0]
            cond_body = ast[2]
            body = ast[4] if len(ast) > 4 else ast[3]
            prob_vars = tuple(
                v for v in extract_logic_free_variables(conjunction)
            )
            prob_head = self._add_prob_arg_to_conjunction(
                conjunction, prob_vars, unwrap=True
            )
            return Implication(prob_head, Condition(conjunction, cond_body))
        else:
            conjunction = ast[0]
            body = ast[2]
            prob_vars = tuple(
                v for v in extract_logic_free_variables(conjunction)
            )
            prob_head = self._add_prob_arg_to_conjunction(
                conjunction, prob_vars, unwrap=False
            )
            return Implication(prob_head, body)

    @staticmethod
    def _add_prob_arg_to_conjunction(conjunction, prob_vars, unwrap=True):
        """Add PROB(prob_vars) as an extra argument to each atom in a conjunction.

        When *unwrap* is True and the conjunction has a single atom, return
        the augmented atom directly (not wrapped in Conjunction). Otherwise
        return Conjunction with PROB appended to each atom.
        """
        prob_arg = FunctionApplication(PROB, prob_vars)
        if isinstance(conjunction, Conjunction):
            augmented = tuple(
                a.functor(*a.args, prob_arg)
                if isinstance(a, FunctionApplication) and hasattr(a, 'args')
                else a
                for a in conjunction.formulas
            )
            if unwrap and len(augmented) == 1:
                return augmented[0]
            return Conjunction(augmented)
        elif isinstance(conjunction, FunctionApplication) and hasattr(conjunction, 'args'):
            return conjunction.functor(*conjunction.args, prob_arg)
        return conjunction

    def succ_head_rule(self, ast):
        # SUCC[...] :- body → skipped (no-op)
        return Constant(True)

    def agg_assign_vars(self, ast):
        # "AGGREGATE" "[" agg_group_vars "]" "(" conjunction "@" agg_fn_call ")" "=" argument
        # Children: [group_vars, conjunction, agg_fn_call, argument]
        group_vars, conjunction, agg_fn_call, result_var = ast
        return (group_vars, conjunction, agg_fn_call, result_var)

    def agg_assign_empty(self, ast):
        # "AGGREGATE" "[" ("(" ")")? "]" "(" conjunction "@" agg_fn_call ")" "=" argument
        # Children: [conjunction, agg_fn_call, argument] (no group_vars)
        conjunction, agg_fn_call, result_var = ast
        return ((), conjunction, agg_fn_call, result_var)

    def agg_group_vars(self, ast):
        # CMD_IDENTIFIER ("," CMD_IDENTIFIER)*
        # Children are the Symbol tokens from each CMD_IDENTIFIER
        # Return them as a tuple
        return tuple(ast)

    def agg_fn_call(self, ast):
        # CMD_IDENTIFIER "(" argument ")"
        # Children: [cmd_identifier_symbol, argument_expression]
        fn_sym = ast[0]     # Symbol, e.g. Symbol("count")
        arg_expr = ast[1]   # argument expression, e.g. Symbol("s")
        return fn_sym(arg_expr)

    @staticmethod
    def _extract_special_body_atoms(conjunction):
        """Separate __PROB__, __MARG__ and __COUNT__ marker atoms from regular atoms.

        Returns (regular_formulas, prob_specs) where each prob_spec is
        a tuple of (marker_name, args).
        """
        formulas = list(conjunction.formulas)
        regular = []
        prob_specs = []
        for f in formulas:
            if (isinstance(f, FunctionApplication)
                    and isinstance(f.functor, Symbol)
                    and f.functor.name in ("__PROB__", "__MARG__", "__COUNT__")):
                prob_specs.append((f.functor.name, f.args))
            else:
                regular.append(f)
        return regular, prob_specs

    def rule(self, ast):
        head = ast[0]
        body_or_cond = ast[2]

        if isinstance(body_or_cond, tuple):
            group_vars, conjunction, agg_fn_call, result_var = body_or_cond
            result = self._build_aggregate_rule(
                head, group_vars, conjunction, agg_fn_call, result_var
            )
            return self._ans_main_rule_as_query(head, result)

        if isinstance(body_or_cond, Conjunction):
            expectations = [
                f for f in body_or_cond.formulas if isinstance(f, Expectation)
            ]
            if expectations:
                # the expectations join the head, as the probability of PROB
                head = head.functor(*head.args, *(
                    e.result for e in expectations if e.result not in head.args
                ))
            regular, prob_specs = self._extract_special_body_atoms(
                body_or_cond
            )
            if prob_specs:
                new_body = Conjunction(regular) if regular else Constant(True)
                result = self._build_prob_rule(head, prob_specs, new_body)
                return self._ans_main_rule_as_query(head, result)
            if expectations:
                return self._ans_main_rule_as_query(
                    head, Implication(head, body_or_cond)
                )

        if is_query_head(head):
            return Query(ast[0], body_or_cond)
        else:
            return Implication(ast[0], body_or_cond)

    @staticmethod
    def _ans_main_rule_as_query(head, result):
        """
        PROB and AGGREGATE body desugaring produce an Implication for the
        main formula, alone or last in a Union. Wrap it as Query when the
        head is ans so that execute_datalog_program can dispatch it as a
        query. A query head cannot hold an aggregation, nor can a query
        body an EXPECT, which only rules rewrite, so a main formula
        ``ans(t, count(s)) :- body`` becomes ``fresh(t, count(s)) :- body``
        queried as ``ans(t, n) :- fresh(t, n)``.
        """
        if not is_query_head(head):
            return result
        if isinstance(result, Implication):
            result = Union((result,))
        formulas = list(result.formulas)
        main = formulas[-1]
        if not isinstance(main, Implication):
            return result
        aggregation = any(
            isinstance(arg, AggregationApplication)
            for arg in main.consequent.args
        )
        if aggregation or any(
            isinstance(f, Expectation)
            for f in getattr(main.antecedent, "formulas", ())
        ):
            answer = head if aggregation else main.consequent
            fresh_pred_sym = Symbol.fresh()
            formulas[-1] = Implication(
                fresh_pred_sym(*main.consequent.args), main.antecedent
            )
            formulas.append(
                Query(answer, Conjunction((fresh_pred_sym(*answer.args),)))
            )
        else:
            formulas[-1] = Query(main.consequent, main.antecedent)
        return Union(tuple(formulas))

    @staticmethod
    def _classify_prob_predicate(pred):
        """Extract (prob_vars, subject, is_marg) from a PROB/MARG spec predicate.

        Returns a tuple ``(prob_vars, subject, is_marg)`` or *None* for
        unsupported predicate types.
        """
        if isinstance(pred, FunctionApplication):
            return pred.args, pred, False
        elif isinstance(pred, (Conjunction, Disjunction)):
            return (), pred, True
        elif isinstance(pred, (Negation, ExistentialPredicate)):
            return tuple(extract_logic_free_variables(pred)), pred, False
        return None

    @staticmethod
    def _is_compound(subject):
        """A disjunction, or a conjunction of several formulas."""
        return isinstance(subject, Disjunction) or (
            isinstance(subject, Conjunction) and len(subject.formulas) > 1
        )

    @staticmethod
    def _filter_prob_vars_outside(prob_vars, outside_connect):
        """Keep only prob_vars that connect outside the probabilistic expression."""
        return tuple(v for v in prob_vars if v in outside_connect)

    @staticmethod
    def _prob_vars_from_conjunction(subject, outside_connect):
        """Extract prob_vars from a Conjunction, filtered to outside-connecting vars."""
        return tuple(
            v for v in extract_logic_free_variables(subject)
            if v in outside_connect
        )

    @staticmethod
    def _prob_vars_for_condition(subject, cond_body, outside_connect):
        """Extract prob_vars from both sides of a ``//`` Condition, outside-connect filtered."""
        all_vars = extract_logic_free_variables(subject)
        all_vars |= extract_logic_free_variables(cond_body)
        return tuple(v for v in all_vars if v in outside_connect)

    def _build_prob_rule(self, head, prob_specs, body):
        """Build rules from PROB/MARG markers in the body.

        Each PROB[pred(x)]=p in the body desugars into a fresh predicate rule::

            fresh(x, PROB(x)) :- pred(x)

        and the main query uses the fresh predicate to extract the probability::

            ans(x, p) :- fresh(x, p)
        """
        head_args = list(head.args) if head.args else []
        body_formulas = (
            list(body.formulas) if isinstance(body, Conjunction) else []
        )
        fresh_rules = []
        query_body_atoms = []

        # Compute outside-connecting variables: variables appearing in the head
        # (excluding the probability result variable) or in non-prob body atoms.
        # Only these should be projected out of PROB/MARG as grouping variables.
        # Variables only inside the prob formula are marginalized by the solver.
        outside_var_set: set[Expression] = set()
        for arg in head_args:
            if isinstance(arg, Symbol):
                outside_var_set.add(arg)
        for f in body_formulas:
            if isinstance(f, FunctionApplication):
                for arg in f.args:
                    if isinstance(arg, Symbol):
                        outside_var_set.add(arg)

        for spec in prob_specs:
            if spec[0] == "__COUNT__":
                rules, atom = self._count_rules(
                    *spec[1], outside_var_set - {spec[1][-1]}
                )
                fresh_rules += rules
                query_body_atoms.append(atom)
                if spec[1][-1] not in head_args:
                    head_args.append(spec[1][-1])
                continue
            # --- unpack spec ---
            if isinstance(spec, tuple) and len(spec) == 2 and isinstance(spec[0], str):
                marker_name, args = spec
                if len(args) == 3:
                    pred, cond_body, result_var = args
                else:
                    pred, result_var = args
                    cond_body = None
            else:
                marker_name = "__PROB__"
                if len(spec) == 3:
                    pred, cond_body, result_var = spec
                else:
                    pred, result_var = spec
                    cond_body = None

            # Unwrap single-formula conjunctions
            inner = pred
            if isinstance(pred, Conjunction) and len(pred.formulas) == 1:
                inner = pred.formulas[0]
            classified = self._classify_prob_predicate(inner)
            if classified is None:
                raise NeuroLangFrontendException(
                    f"PROB and MARG cannot be applied to {inner}"
                )

            _, subject, _ = classified
            is_marg = marker_name == "__MARG__"
            fresh_pred_sym = Symbol.fresh()
            outside_connect = {
                v for v in outside_var_set if v != result_var
            }

            # --- determine prob_vars and body ---
            if cond_body is not None:
                prob_vars = self._prob_vars_for_condition(
                    subject, cond_body, outside_connect
                )
                fresh_body = Condition(subject, cond_body)
            elif is_marg and self._is_compound(subject):
                prob_vars = self._prob_vars_from_conjunction(subject, outside_connect)
                fresh_body = subject
            elif self._is_compound(subject):
                prob_vars = self._prob_vars_from_conjunction(subject, outside_connect)
                fresh_body = subject
            else:
                prob_vars = self._filter_prob_vars_outside(
                    classified[0], outside_connect
                )
                fresh_body = Conjunction((subject,))

            # --- common head / atom (4 of 5 branches) ---
            fresh_head = fresh_pred_sym(
                *prob_vars, FunctionApplication(PROB, prob_vars)
            )
            query_body_atoms.append(fresh_pred_sym(*prob_vars, result_var))
            fresh_rules.append(Implication(fresh_head, fresh_body))

            if result_var not in head_args:
                head_args.append(result_var)

        if hasattr(head, 'functor'):
            new_head = head.functor(*head_args)
        else:
            new_head = head

        all_body_atoms = body_formulas + query_body_atoms
        if all_body_atoms:
            new_body = Conjunction(tuple(all_body_atoms))
        else:
            new_body = Constant(True)

        main_fml = Implication(new_head, new_body)
        return Union(tuple(fresh_rules + [main_fml]))

    @staticmethod
    def _count_rules(x, comparison, k, event, known, result_var, outside):
        """Rules of ``PROB[COUNT(x) θ k | event // known] = result_var``.

        With the variables of the event that occur *outside* it as the
        grouping ones g, ``q(j)`` the probability that the event holds
        for at least ``j`` values of ``x``, that of the query with ``j``
        copies of it, for pairwise different values of ``x`` and other
        variables projected in each copy::

            pa_j(g, PROB(g)) :- event(x1), ..., event(xj), x1 != x2, ...

        the result is ``q(k)``, ``q(k + 1)`` or the complements
        ``1 - q(k)``, ``1 - q(k + 1)``, ``q(k) - q(k + 1)``,
        ``1 - q(k) + q(k + 1)``, ``q(j) = 1`` for ``j <= 0``, summed by
        group over tagged terms, so that a missing ``q(j)`` is 0 and that
        equal terms are not merged. Returns the rules and the atom
        ``ex(g, result_var)`` for the body.
        """
        if not (isinstance(k, Constant) and isinstance(k.value, int)):
            raise NeuroLangFrontendException(
                f"COUNT is compared to an integer, not {k}"
            )
        free = extract_logic_free_variables(event)
        known_free = (
            extract_logic_free_variables(known) if known is not None
            else set()
        )
        if not (isinstance(x, Symbol) and x in free) or x in outside:
            raise NeuroLangFrontendException(
                f"COUNT({x}) counts a variable of its event that does not "
                "occur elsewhere in the rule"
            )
        group = tuple(sorted(
            (free | (known_free & outside)) & outside, key=lambda v: v.name
        ))
        projected = free - set(group) - {x}
        if known_free & ({x} | projected):
            raise NeuroLangFrontendException(
                "the variables of what is known are those of the groups: "
                f"{sorted(v.name for v in known_free & ({x} | projected))}"
                " are projected or counted by the event"
            )
        terms = {
            ge: ((1, k.value),), gt: ((1, k.value + 1),),
            lt: ((1, 0), (-1, k.value)), le: ((1, 0), (-1, k.value + 1)),
            eq: ((1, k.value), (-1, k.value + 1)),
            ne: ((1, 0), (-1, k.value), (1, k.value + 1)),
        }[comparison.value]
        terms = tuple((sign, max(j, 0)) for sign, j in terms)

        def probability(j):
            if j > MAX_UNLIFTED_COUNT and any(
                isinstance(f, Disjunction) for f in extract_conjuncts(event)
            ):
                raise NeuroLangFrontendException(
                    f"COUNT up to {j} values of a disjunction: the lifted "
                    "solvers do not plan it, and model counting is "
                    f"exponential in the count (at most {MAX_UNLIFTED_COUNT})"
                )
            size = j * len(extract_conjuncts(event)) + j * (j - 1) // 2
            if size > MAX_COUNT_CONJUNCTS:
                raise NeuroLangFrontendException(
                    f"COUNT up to {j} values needs a query of {size} "
                    f"conjuncts, more than the {MAX_COUNT_CONJUNCTS} that "
                    "the lifting handles"
                )
            copies, xs = [event], [x]
            for _ in range(j - 1):
                renames = {v: Symbol.fresh() for v in {x} | projected}
                copies.append(ReplaceExpressionWalker(renames).walk(event))
                xs.append(renames[x])
            body = Conjunction(tuple(chain.from_iterable(
                c.formulas if isinstance(c, Conjunction) else (c,)
                for c in copies
            )) + tuple(Constant(ne)(a, b) for a, b in combinations(xs, 2)))
            if known is not None:
                body = Condition(body, known)
            pa = Symbol.fresh()
            return pa, Implication(
                pa(*group, FunctionApplication(PROB, group)), body
            )

        probabilities = {
            j: probability(j) for j in {j for _, j in terms} | {1}
            if j >= 1 and (j > 1 or any(j == 0 for _, j in terms) or
                           len(terms) > 1 or terms[0][1] == 1)
        }
        if len(terms) == 1 and terms[0][1] >= 1:
            pa, rule = probabilities[terms[0][1]]
            return [rule], pa(*group, result_var)
        rules = [rule for _, rule in probabilities.values()]
        anchor = probabilities[1][0]
        value, weight, tag, total = (Symbol.fresh() for _ in range(4))
        terms_symbol, sum_symbol = Symbol.fresh(), Symbol.fresh()
        for index, (sign, j) in enumerate(terms):
            source = probabilities[j][0] if j >= 1 else anchor
            scaled = (
                Constant(mul)(Constant(float(sign)), weight) if j >= 1
                else Constant(float(sign))
            )
            rules.append(Implication(
                terms_symbol(*group, tag, value),
                Conjunction((
                    source(*group, weight),
                    Constant(eq)(value, scaled),
                    Constant(eq)(tag, Constant(index)),
                ))
            ))
        rules.append(Implication(
            sum_symbol(
                *group, AggregationApplication(Symbol("sum"), (value,))
            ),
            Conjunction((terms_symbol(*group, tag, value),))
        ))
        return rules, sum_symbol(*group, result_var)

    def _build_aggregate_rule(self, head, group_vars, conjunction, agg_fn_call, result_var):
        fresh_pred_sym = Symbol.fresh()

        fresh_rules = []
        if isinstance(conjunction, Conjunction):
            regular, prob_specs = self._extract_special_body_atoms(conjunction)
            if any(isinstance(f, Expectation) for f in regular):
                raise NeuroLangFrontendException(
                    "EXPECT cannot be inside an AGGREGATE: compute it in a "
                    "rule of its own, m(g, e) :- EXPECT[x | a(g, x)] = e, "
                    "and aggregate that rule: "
                    "AGGREGATE[g](m(g, e) @ sum(e)) = n."
                )
            if any(spec[0] == "__COUNT__" for spec in prob_specs):
                raise NeuroLangFrontendException(
                    "PROB[COUNT(...)] cannot be inside an AGGREGATE: "
                    "aggregate the values of a rule that holds it"
                )
            # Separate MARG specs (which need desugaring) from PROB specs
            # (which stay as markers in the conjunction body).
            marg_specs = []
            prob_marker_atoms = []
            for spec in prob_specs:
                marker_name = spec[0] if isinstance(spec, tuple) and len(spec) == 2 and isinstance(spec[0], str) else "__PROB__"
                if marker_name == "__MARG__":
                    marg_specs.append(spec)
                else:
                    # Reconstruct the __PROB__ marker atom to keep it in the body
                    if isinstance(spec, tuple) and len(spec) == 2 and isinstance(spec[0], str):
                        prob_marker_atoms.append(
                            FunctionApplication(Symbol(marker_name), spec[1])
                        )

            if marg_specs:
                # MARG specs need desugaring. When aggregating over MARG,
                # the fresh predicate carries the group vars so that the
                # aggregate can group over them.
                fresh_rules_marg = []
                for spec in marg_specs:
                    spec_result_var = self._extract_prob_result_var(spec)
                    if spec_result_var is None:
                        continue
                    spec_args = spec[1] if isinstance(spec, tuple) and len(spec) == 2 and isinstance(spec[0], str) else spec[1:]
                    pred = spec_args[0] if len(spec_args) < 3 else spec_args[0]

                    inner = pred
                    if isinstance(pred, Conjunction) and len(pred.formulas) == 1:
                        inner = pred.formulas[0]

                    fresh_sym = Symbol.fresh()
                    prob_vars = tuple(
                        v for v in extract_logic_free_variables(pred)
                        if v in set(group_vars)
                    )
                    prob_arg = FunctionApplication(PROB, prob_vars) if prob_vars else FunctionApplication(PROB, (Conjunction((pred,) if not isinstance(pred, Conjunction) else pred.formulas),))

                    if isinstance(inner, FunctionApplication) and prob_vars:
                        fresh_head = fresh_sym(*prob_vars, prob_arg)
                        fresh_body = inner
                    elif isinstance(inner, FunctionApplication):
                        fresh_head = fresh_sym(prob_arg)
                        fresh_body = Conjunction((inner,))
                    else:
                        fresh_head = fresh_sym(prob_arg)
                        fresh_body = Conjunction((inner,)) if not isinstance(inner, Conjunction) else inner

                    fresh_rules_marg.append(Implication(fresh_head, fresh_body))
                    marg_fresh_sym = fresh_sym
                    marg_result_var = spec_result_var

                head_args = list(head.args) if hasattr(head, 'args') and head.args else []

                aggregation = AggregationApplication(agg_fn_call.functor, agg_fn_call.args)
                new_head_args = []
                for arg in head_args:
                    if (isinstance(arg, Symbol)
                            and result_var is not None
                            and isinstance(result_var, Symbol)
                            and arg.name == result_var.name):
                        new_head_args.append(aggregation)
                    else:
                        new_head_args.append(arg)
                new_head = head.functor(*new_head_args)

                body_atoms = []
                if prob_vars:
                    body_atoms.append(marg_fresh_sym(*prob_vars, marg_result_var))
                else:
                    body_atoms.append(marg_fresh_sym(marg_result_var))

                new_body = Conjunction(tuple(body_atoms))

                main_rule = Implication(new_head, new_body)
                return Union(tuple(fresh_rules_marg + [main_rule]))

            elif prob_marker_atoms:
                conjunction = Conjunction(tuple(regular + prob_marker_atoms)) if (regular + prob_marker_atoms) else conjunction

        head_args = list(head.args) if hasattr(head, 'args') and head.args else []

        if group_vars:
            aggregation = AggregationApplication(agg_fn_call.functor, agg_fn_call.args)
            new_args = []
            for arg in head_args:
                if (isinstance(arg, Symbol)
                        and result_var is not None
                        and isinstance(result_var, Symbol)
                        and arg.name == result_var.name):
                    new_args.append(aggregation)
                else:
                    new_args.append(arg)
            new_head = head.functor(*new_args)
            return Implication(new_head, conjunction)
        else:
            fresh_head = fresh_pred_sym(agg_fn_call)
            fresh_rules.append(Implication(fresh_head, conjunction))

            main_args = []
            for arg in head_args:
                if (isinstance(arg, Symbol)
                        and result_var is not None
                        and isinstance(result_var, Symbol)
                        and arg.name == result_var.name):
                    continue
                main_args.append(arg)

            fresh_query_atom = fresh_pred_sym(result_var)
            main_body = Conjunction((fresh_query_atom,))
            main_head = head.functor(*main_args, result_var)
            main_rule = Implication(main_head, main_body)

            return Union(tuple(fresh_rules + [main_rule]))

    @staticmethod
    def _extract_prob_result_var(spec):
        """Extract the result variable from a PROB/MARG spec tuple."""
        if isinstance(spec, tuple) and len(spec) == 2 and isinstance(spec[0], str):
            _, spec_args = spec
            if len(spec_args) == 3:
                _, _, rv = spec_args
            else:
                _, rv = spec_args
            return rv
        elif isinstance(spec, tuple):
            if len(spec) == 3:
                _, _, rv = spec
            else:
                _, rv = spec
            return rv
        return None

    @staticmethod
    def _refuse_expectation_in_prob(*events):
        if any(e is not None and contains_expectation(e) for e in events):
            raise NeuroLangFrontendException(
                "EXPECT cannot be inside PROB or MARG, which take a "
                "probabilistic event: compute the expectation in a rule of "
                "its own, m(e) :- EXPECT[x | a(x)] = e, and use m in the "
                "rule."
            )

    def prob_body_predicate(self, ast):
        # PROB[pred] = var              → ast = [predicate, argument] (2 elements)
        # PROB[pred // body] = var      → ast = [predicate, SEP_token, body, argument] (4)
        if len(ast) == 4:
            pred = ast[0]
            cond_body = ast[2]   # ast[1] is the separator token
            result_var = ast[3]
        else:
            pred = ast[0]
            cond_body = None
            result_var = ast[1]
        self._refuse_expectation_in_prob(pred, cond_body)
        return FunctionApplication(
            Symbol("__PROB__"),
            (pred, cond_body, result_var)
        )

    def count_body_predicate(self, ast):
        # PROB[COUNT(x) θ k | event] = p            → [x, θ, k, OR, event, p]
        # PROB[COUNT(x) θ k | event // known] = p   → [x, θ, k, OR, event, SEP, known, p]
        known = ast[6] if len(ast) == 8 else None
        return FunctionApplication(
            Symbol("__COUNT__"),
            (ast[0], Constant(OPERATOR[ast[1].value]), ast[2], ast[4],
             known, ast[-1])
        )

    def expect_body_predicate(self, ast):
        # EXPECT[f | event // known] = e → [f, OR, event, SEP, known, e],
        # SEP and known None without "//"
        f, _, event, _, known, result = ast
        return expectation(f, event, result, known)

    def expect_norm_body_predicate(self, ast):
        f, _, event, _, known, result = ast
        return expectation(f, event, result, known, normalised=True)

    def resample_body_predicate(self, ast):
        # RESAMPLE[boot](pred(x)) = b → ast = [boot, pred(x), b]
        return FunctionApplication(RESAMPLE_MARKER, tuple(ast))

    def marg_body_predicate(self, ast):
        # MARG[pred] = var              → ast = [conjunction, argument] (2 elements)
        # MARG[pred // body] = var      → ast = [conjunction, SEP_token, body, argument] (4)
        self._refuse_expectation_in_prob(ast[0], *ast[2:3])
        if len(ast) == 4:
            pred = ast[0]
            cond_body = ast[2]
            result_var = ast[3]
            return FunctionApplication(
                Symbol("__MARG__"),
                (pred, cond_body, result_var)
            )
        pred = ast[0]
        result_var = ast[1]
        return FunctionApplication(
            Symbol("__MARG__"),
            (pred, result_var)
        )

    def succ_body_predicate(self, ast):
        # SUCC[...] = var → skipped (no-op in execution)
        # Return a __SUCC__ marker that _extract_special_body_atoms discards
        return FunctionApplication(
            Symbol("__SUCC__"),
            (ast[1],)
        )

    def cond_prob_predicate(self, ast):
        left = ast[0]
        right = ast[2]
        return Condition(left, right)

    def condition(self, ast):
        conditioned = ast[0]
        condition = ast[2]
        return Condition(conditioned, condition)

    def constraint(self, ast):
        return RightImplication(ast[0], ast[2])

    def conjunction(self, ast):
        conj = []
        for c in ast:
            if isinstance(c, Expression):
                if (isinstance(c, FunctionApplication)
                        and isinstance(c.functor, Symbol)
                        and c.functor.name == "__SUCC__"):
                    # SUCC markers are no-ops — discard at conjunction level
                    continue
                if isinstance(c, Conjunction):
                    # A parenthesised conjunction: (a(x), b(x))
                    conj.extend(c.formulas)
                else:
                    conj.append(c)
        if len(conj) == 0:
            return Constant(True)
        if len(conj) == 1 and isinstance(conj[0], Disjunction):
            # A parenthesised disjunction alone: (a(x) | b(x))
            return conj[0]
        return Conjunction(conj)

    def disjunction(self, ast):
        disjuncts = [c for c in ast if isinstance(c, Expression)]
        if len(disjuncts) == 1:
            # A formula in parentheses, (x < 3) or (a(x), b(x)): itself
            formula = disjuncts[0]
            if isinstance(formula, Conjunction) and len(formula.formulas) == 1:
                formula = formula.formulas[0]
            return formula
        return Disjunction(tuple(
            self._hide_anonymous(
                c.formulas[0]
                if isinstance(c, Conjunction) and len(c.formulas) == 1 else c
            )
            for c in ast if isinstance(c, Expression)
        ))

    def existential_predicate(self, ast):
        ast1 = ast[1].children
        # Every predicate of the body: atoms and comparisons, but also
        # negations and nested existentials, which are not function
        # applications. The variables and the separator are left out.
        exp = [i for i in ast1[1:] if isinstance(i, Expression)]

        if len(exp) == 1:
            exp = exp[0]
        else:
            exp = Conjunction(tuple(exp))

        for arg in ast1[0]:
            exp = ExistentialPredicate(arg, exp)

        return exp

    def negated_predicate(self, ast):
        formula = ast[-1]  # after the "¬" token, if any
        if isinstance(formula, Conjunction) and len(formula.formulas) == 1:
            # A formula in parentheses: ~(a(x))
            formula = formula.formulas[0]
        return Negation(self._hide_anonymous(formula))

    def comparison(self, ast):
        operator = Constant(OPERATOR[ast[1].value])
        return operator(ast[0], ast[2])

    def predicate(self, ast):
        if not isinstance(ast, Expression):
            if isinstance(ast, list):
                if len(ast) == 1:
                    ast = ast[0]
                else:
                    ast = ast[0](*ast[1])
        return ast

    @staticmethod
    def _wrap_aggregation_args(arguments):
        """Replace FunctionApplication nodes whose functor is an
        aggregation function name with AggregationApplication."""
        result = []
        for arg in arguments:
            if (isinstance(arg, FunctionApplication)
                    and isinstance(arg.functor, Symbol)
                    and arg.functor.name in AGGREGATION_FUNCS):
                result.append(
                    AggregationApplication(arg.functor, arg.args)
                )
            elif (isinstance(arg, FunctionApplication)
                    and isinstance(arg.functor, FunctionApplication)
                    and isinstance(arg.functor.functor, Symbol)
                    and arg.functor.functor.name in AGGREGATION_FUNCS):
                result.append(
                    AggregationApplication(arg.functor, arg.args)
                )
            else:
                result.append(arg)
        return result

    @staticmethod
    def _expand_implicit_prob(arguments):
        """
        Return the head *arguments* with a bare ``PROB`` made explicit.

        ``PROB`` alone stands for the probability of the other head
        terms: ``p(x, PROB, y)`` is ``p(x, PROB(x, y), y)``.
        """
        if PROB not in arguments:
            return arguments
        ix_prob = arguments.index(PROB)
        others = arguments[:ix_prob] + arguments[ix_prob + 1:]
        return (
            arguments[:ix_prob] + [PROB(*others)] + arguments[ix_prob + 1:]
        )

    def head_predicate(self, ast):
        if ast[1] is not None:
            arguments = list(ast[1])
            arguments = self._wrap_aggregation_args(arguments)
            arguments = self._expand_implicit_prob(arguments)
            ast = ast[0](*arguments)
        else:
            ast = ast[0]()
        return ast

    def query(self, ast):
        return self._query_head(query_symbol(), ast[0])

    def named_query(self, ast):
        return self._query_head(query_symbol(ast[0].name), ast[1])

    def _query_head(self, symbol, arguments_raw):
        if arguments_raw is None:
            return symbol()
        arguments = list(arguments_raw) if arguments_raw else []
        arguments = self._wrap_aggregation_args(arguments)
        arguments = self._expand_implicit_prob(arguments)
        return symbol(*arguments)

    def statement(self, ast):
        return Statement(ast[0], ast[2])

    def statement_function(self, ast):
        return Statement(
            ast[0],
            Lambda(ast[1], ast[3])
        )

    def probabilistic_fact(self, ast):
        return Implication(
            ProbabilisticFact(ast[0], ast[2]),
            Constant(True),
        )

    def probabilistic_choice_fact(self, ast):
        return Implication(
            ProbabilisticChoice(ast[0], ast[2]),
            Constant(True),
        )

    def probabilistic_choice_rule(self, ast):
        head = ast[0]
        probability = ast[2]
        body = ast[4]
        return Implication(
            ProbabilisticChoice(probability, head),
            body,
        )

    def command(self, ast):
        if ast[1] is None:
            cmd = Command(ast[0], (), ())
        else:
            # only args, only kwargs or both
            name = ast[0]
            args, kwargs = ast[1]
            cmd = Command(name, args, kwargs)
        return cmd

    def cmd_args(self, ast):
        args = ()
        kwargs = ()
        for a in ast:
            if isinstance(a, tuple):
                kwargs = kwargs + (a,)
            else:
                args = args + (a,)
        return args, kwargs

    def keyword_args(self, ast):
        return tuple(ast)

    def keyword_item(self, ast):
        key = ast[0]
        return (key, ast[1])

    def pos_args(self, ast):
        return tuple(ast)

    def pos_item(self, ast):
        return ast[0]

    def lambda_application(self, ast):
        if not isinstance(ast[0], Expression):
            f = Symbol(ast[0])
        else:
            f = ast[0]

        return FunctionApplication(f, args=ast[1])

    def id_application(self, ast):
        if not isinstance(ast[0], Expression):
            f = Symbol(ast[0])
        else:
            f = ast[0]

        return FunctionApplication(f, args=ast[1])

    def minus_signed_id(self, ast):
        return Constant(mul)(Constant(-1), ast[0])

    def signed_int_ext_identifier(self, ast):
        return ast[0]

    def lambda_expression(self, ast):
        return Lambda(ast[0], ast[1])

    def arguments(self, ast):
        return tuple(ast)

    def argument(self, ast):
        ast = ast[0]
        if isinstance(ast, Expression):
            if isinstance(ast, Symbol) and ast.name == "_":
                fresh = Symbol.fresh()
                self.anonymous.add(fresh)
                return fresh
            return ast
        else:
            return Symbol.fresh()

    def minus_op(self, ast):
        if len(ast) == 1:
            if isinstance(ast[0], Expression):
                return ast[0]

            else:
                return ast[0]

        op_str = "-"
        op = Constant(OPERATOR[op_str])
        return op(*ast)

    def plus_op(self, ast):
        if len(ast) == 1:
            if isinstance(ast[0], Expression):
                return ast[0]
            else:
                return ast[0]

        op_str = "+"
        op = Constant(OPERATOR[op_str])
        return op(*ast)

    def sing_op(self, ast):
        if len(ast) == 1:
            if isinstance(ast[0], Expression):
                return ast[0]

            else:
                return ast[0]
        return 0

    def term(self, ast):
        if isinstance(ast, Expression):
            return ast
        elif len(ast) == 1:
            return ast[0]

    def div_term(self, ast):
        if len(ast) == 1:
            if isinstance(ast[0], Expression):
                return ast[0]
            else:
                return 0

        op_str = "/"
        op = Constant(OPERATOR[op_str])

        return op(ast[0], ast[1])

    def mul_term(self, ast):
        if len(ast) == 1:
            if isinstance(ast[0], Expression):
                return ast[0]
            else:
                return 0

        op_str = "*"
        op = Constant(OPERATOR[op_str])

        return op(ast[0], ast[1])

    def sing_term(self, ast):
        if len(ast) == 1:
            if isinstance(ast[0], Expression):
                return ast[0]
            else:
                return 0
        else:
            return 0

    def factor(self, ast):
        if isinstance(ast[0], Expression):
            return ast[0]
        elif len(ast) == 1:
            return 0
        else:
            return 0

    def pow_factor(self, ast):
        if len(ast) == 1:
            if isinstance(ast[0], Expression):
                return ast[0]
            else:
                return 0
        else:
            return Constant(pow)(ast[0], ast[2])

    def sing_factor(self, ast):
        if len(ast) == 1:
            if isinstance(ast[0], Expression):
                return ast[0]
            else:
                return 0
        else:
            return 0

    def fact(self, ast):
        args = ast[0].args
        if not all(isinstance(a, (Constant, ExternalSymbol)) for a in args):
            written = ", ".join(
                a.name if isinstance(a, Symbol) else repr(a.value)
                for a in args
            )
            raise NeuroLangFrontendException(
                f"{ast[0].functor.name}({written}) is read as a fact, which "
                "has only constants: is a ',' or ':-' missing?"
            )
        return Fact(ast[0])

    def constant_predicate(self, ast):
        predicate_name = ast[0]
        del ast[0]
        return predicate_name(*ast)

    def ext_identifier(self, ast):
        ast = ast[0]
        return ExternalSymbol[ast.type](ast.name)

    def identifier(self, ast):
        ast = ast[0]
        if not isinstance(ast, Symbol):
            return Symbol(ast)

        return ast

    def identifier_regexp(self, ast):
        return (ast[0]).value.replace('`', '')

    def cmd_identifier(self, ast):
        return Symbol((ast[0]).value)

    def text(self, ast):
        return Constant(ast[0][1:-1])

    def iri(self, ast):
        return Constant(ast[0][1:-1])

    def iri_identifier(self, ast):
        return Symbol(ast[0][1:-1])

    def tuple_literal(self, ast):
        # Filter out Lark terminal tokens (commas, parens) which are str/Token
        # instances. Actual values are already transformed to Constant/Symbol
        # by other grammar rules, so no string value slips through here.
        values = tuple(a for a in ast if not isinstance(a, str))
        # Explicitly mark each element's type as Unknown since at parse time
        # we cannot determine the concrete types of tuple elements.
        value_types = tuple(Unknown for _ in values)
        result = Constant[Tuple[value_types]](
            values, auto_infer_type=False, verify_type=False
        )
        for v in values:
            if isinstance(v, Symbol):
                result._symbols.add(v)
        return result

    def pos_int(self, ast):
        return Constant(int((ast[0]).value))

    def neg_int(self, ast):
        return Constant(0 - int((ast[0]).value))

    def pos_float(self, ast):
        return Constant(float((ast[0]).value))

    def neg_float(self, ast):
        return Constant(0 - float((ast[0]).value))

    def _default(self, ast):
        return ast


_IRI = re.compile(r'<[a-zA-Z][a-zA-Z0-9+.-]*:[^<>"{}|^`\\\s]*>')


def strip_comment(line):
    """
    Return *line* without its ``%`` comment, if any.

    A ``%`` within a string or an IRI does not start a comment.
    """
    in_single = False
    in_double = False
    i = 0
    while i < len(line):
        c = line[i]
        if c == "'" and not in_double:
            in_single = not in_single
        elif c == '"' and not in_single:
            in_double = not in_double
        elif c == '<' and not in_single and not in_double:
            iri = _IRI.match(line, i)
            if iri:
                i = iri.end()
                continue
        elif c == '%' and not in_single and not in_double:
            return line[:i]
        i += 1
    return line


def _preprocess(code):
    """Strip % comments and trailing Prolog-style dots before Lark parsing.

    LLMs sometimes emit Prolog-style trailing dots (``.``) and ``%``
    line comments.  Lark would choke on both.
    """
    lines = code.split('\n')
    processed = []
    for line in lines:
        line = strip_comment(line)
        # Strip trailing Prolog-style dot
        stripped = line.rstrip()
        if stripped.endswith('.') and stripped != '.':
            line = stripped[:-1]
        else:
            line = stripped
        processed.append(line)
    return '\n'.join(processed)


# The command a ``%%`` documentation block is read as.
DOCUMENT_COMMAND = Symbol("document")

_DOC_LINE = re.compile(r"\s*%%(?P<text>.*)")
_DOC_ARGUMENT = re.compile(
    r"\s*(?P<name>[A-Za-z_]\w*)\s*(?::\s*(?P<sort>[A-Za-z_][\w-]*)\s*)?"
)


def _doc_blocks(code):
    """
    Return the ``%%`` documentation blocks of *code*, by the line they
    document.

    A block is a run of lines starting with ``%%``, each without the
    ``%%`` and the space after it; it documents the statement starting
    on the line right after it, numbered from 1. A block followed by a
    blank line, a ``%`` comment or the end of the code documents
    nothing: it is a comment.
    """
    blocks = {}
    block = []
    for number, line in enumerate(code.split('\n'), start=1):
        doc = _DOC_LINE.match(line)
        if doc:
            text = doc.group("text").rstrip()
            block.append(text[1:] if text.startswith(" ") else text)
            continue
        if block and strip_comment(line).strip():
            blocks[number] = block
        block = []
    return blocks


class _DocumentedHead(PatternWalker):
    """
    Return the name and the arity of the predicate a statement defines,
    or None: a query, a command and a constraint define none. A
    statement ``x := ...`` defines ``x``, of no arity.
    """

    @add_match(Union)
    def union(self, union):
        heads = (self.walk(formula) for formula in union.formulas)
        return next((head for head in heads if head is not None), None)

    @add_match(Implication(ProbabilisticFact(..., FunctionApplication), ...))
    def probabilistic_fact(self, implication):
        return self.walk(
            Implication(implication.consequent.body, Constant(True))
        )

    @add_match(
        Implication(ProbabilisticChoice(..., FunctionApplication), ...)
    )
    def probabilistic_choice(self, implication):
        return self.walk(
            Implication(implication.consequent.body, Constant(True))
        )

    @add_match(Implication(FunctionApplication(Symbol, ...), ...))
    def rule(self, implication):
        head = implication.consequent
        return head.functor.name, len(head.args)

    @add_match(Statement(Symbol, ...))
    def statement(self, statement):
        return statement.lhs.name, None

    @add_match(Expression)
    def other(self, expression):
        return None


def _doc_signature(lines, name, arity, line):
    """
    Return the arguments of the signature *lines* start with, or None.

    The signature is the first line when it reads ``name(a, b: sort)``
    for the predicate *name*; it must give its *arity* arguments, if
    known. *line* is the number of that line, for the errors.
    """
    signature = re.fullmatch(
        rf"\s*{re.escape(name)}\s*\((?P<args>[^()]*)\)\s*", lines[0]
    )
    if signature is None:
        return None
    texts = signature.group("args").split(",")
    if len(texts) == 1 and not texts[0].strip():
        texts = []
    arguments = []
    for text in texts:
        argument = _DOC_ARGUMENT.fullmatch(text)
        if argument is None:
            raise ParserError(
                f"The documentation of {name} gives the argument "
                f"{text.strip()!r}: write name or name: sort",
                line=line,
            )
        arguments.append(
            (argument.group("name"), argument.group("sort") or "")
        )
    if arity is not None and len(arguments) != arity:
        raise ParserError(
            f"The documentation of {name} gives {len(arguments)} "
            f"arguments, its statement has {arity}",
            line=line,
        )
    return tuple(arguments)


def documentation_command(name, description, arguments=(), replace=False):
    """
    Return the command documenting the predicate *name*: its
    *description* and its *arguments*, ``(name, sort)`` pairs, the sort
    ``""`` when not given; with *replace*, in place of the description it
    had.
    """
    return Command(DOCUMENT_COMMAND, (
        Symbol(name), Constant[str](description),
        Constant[Tuple](
            tuple(tuple(a) for a in arguments),
            auto_infer_type=False, verify_type=False,
        ),
    ), ((Symbol("replace"), Constant[bool](True)),) if replace else ())


def _documentation(expression, lines, line):
    """
    Return the commands documenting the statement *expression* with the
    ``%%`` *lines*, which end before the *line* it starts on.
    """
    head = _DocumentedHead().walk(expression)
    if head is None:
        return ()
    name, arity = head
    arguments = _doc_signature(lines, name, arity, line - len(lines))
    if arguments is not None:
        lines = lines[1:]
    description = "\n".join(lines).strip()
    if not description and not arguments:
        return ()
    return (documentation_command(name, description, arguments or ()),)


def _transform(tree, docs):
    """
    Return the expressions of the parse *tree*, each statement preceded
    by the command documenting it when *docs* has a block for its line.
    """
    transformer = DatalogTransformer()
    if not docs:
        return transformer.transform(tree)
    formulas = []
    for statement in tree.children[0].children:
        expression = transformer.transform(statement)
        lines = docs.get(statement.meta.line)
        if lines:
            formulas.extend(
                _documentation(expression, lines, statement.meta.line)
            )
        formulas.append(expression)
    return transformer.expressions(formulas)


def parser(code, locals=None, globals=None, interactive=False):
    """
    Return the expressions of the Datalog program *code*.

    A ``%%`` block documenting a statement (see :func:`_doc_blocks`) is
    read as a ``.document`` command before it (see
    :func:`documentation_command`).
    """
    with lark_errors_as_neurolang():
        if (interactive):
            completer = LarkCompleter(compiled_grammar())
            res = completer.complete(code.strip())
            return res.token_options
        else:
            docs = _doc_blocks(code)
            code = _preprocess(code)
            # Keep leading blank lines so error positions match the input.
            jp = compiled_grammar().parse(code.rstrip())
            return _transform(jp, docs)


def parse_rules():
    curdir = os.path.dirname(os.path.realpath(__file__))
    rules_file = os.path.join(
        curdir,
        "rules.json"
    )

    # Opening JSON file
    with open(rules_file, 'r') as f:
        # json.load() returns JSON object as a dictionary
        rules_dico = json.load(f)
    return rules_dico
