"""Lifted queries run through the frontend: the solver's tests are in
``neurolang/probabilistic/tests/test_dalvi_suciu_lift.py``."""

import pytest

from nl_core.probabilistic import dalvi_suciu_lift
from nl_core.relational_algebra_provenance import DisjointProjection


@pytest.mark.parametrize("rules, expected", [
    # Disjuncts sharing studies, and disjoint: P[A and B] is 0, left out
    # of the plan of the conjunction.
    ((("language",), ("speech",)), 0.5),
    ((("language",), ("pain",)), 0.75),
    # Three disjuncts: the tail is the disjunction of the two others.
    ((("language",), ("speech",), ("pain",)), 0.75),
    ((("pain",), ("speech",), ("memory",)), 0.75),
    # A conjunctive disjunct.
    ((("language", "speech"), ("pain",)), 0.5),
])
def test_union_of_rules_joining_a_choice(rules, expected):
    """
    A union of rules each joining the probabilistic choice, under PROB,
    crashed: it is lifted by the disjoint separator, one disjoint
    projection on the study.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL()
    nl.add_uniform_probabilistic_choice_over_set(
        [(1,), (2,), (3,), (4,)], name="selected_study"
    )
    nl.add_tuple_set(
        [(1, "language"), (2, "speech"), (2, "language"), (3, "pain"),
         (4, "memory")],
        name="mentions",
    )
    program = "\n".join(
        "a(s) :- " + ", ".join(f"mentions(s, '{t}')" for t in terms)
        + ", selected_study(s)"
        for terms in rules
    ) + "\nans(p) :- PROB[a(s)] = p"
    result = nl.execute_datalog_program(program)
    assert [p for p, in result] == [pytest.approx(expected)]


LIFTED_ONLY = dict(
    probabilistic_solvers=(dalvi_suciu_lift.solve_succ_query,),
    probabilistic_marg_solvers=(dalvi_suciu_lift.solve_marg_query,),
)


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_union_by_term_with_a_variable_of_a_rule_alone(solvers):
    """
    A union whose rules have a variable that their head has not
    (``s2``): the deterministic ``mentions(s2, t)`` is factored out of the
    conjunctive normal form, whose clauses then do not all have ``t``,
    and whose components are not lifted; the disjoint projection lifts
    the union as it is.
    """
    from .. import NeurolangPDL

    mentions = [
        (0, "a"), (0, "c"), (1, "a"), (1, "d"), (1, "e"), (2, "a"),
        (2, "c"), (2, "e"), (3, "a"), (3, "c"), (3, "d"), (4, "b"),
        (5, "b"), (5, "c"), (5, "d"),
    ]
    nl = NeurolangPDL(**solvers)
    nl.add_uniform_probabilistic_choice_over_set(
        [(s,) for s in range(6)], name="selected_study"
    )
    nl.add_tuple_set(mentions, name="mentions")
    result = nl.execute_datalog_program(
        "a(t, s) :- mentions(s, t), selected_study(s)\n"
        "a(t, s) :- mentions(s, 'a'), mentions(s, 'c'), mentions(s2, t), "
        "selected_study(s)\n"
        "a(t, s) :- mentions(s, 'd'), mentions(s2, t), selected_study(s)\n"
        "ans(t, p) :- PROB[a(t, s)] = p"
    )
    m = set(mentions)
    expected = {
        t: sum(
            (s, t) in m or ((s, "a") in m and (s, "c") in m)
            or (s, "d") in m
            for s in range(6)
        ) / 6
        for t in "abcde"
    }
    assert dict(result) == pytest.approx(expected)


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_union_with_a_choice_on_a_free_and_on_a_bound_variable(solvers):
    """
    The choice is on the free variable s in one rule and on a variable of
    its own, f, in the other: the choice optimisation unified C(s) and
    C(f) across the disjuncts, as if they were a conjunction, and the
    first solver gave no answer; the disjuncts are now optimised apart,
    and C(s) is C(f') ∧ f' = s for the disjoint projection.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_uniform_probabilistic_choice_over_set(
        [(1,), (2,), (3,), (4,)], name="selected_study"
    )
    nl.add_tuple_set([(1,), (2,), (3,), (4,)], name="study")
    nl.add_tuple_set(
        [(1, "x"), (2, "y"), (3, "x"), (4, "z")], name="mentions"
    )
    result = nl.execute_datalog_program(
        "a(s) :- selected_study(s), mentions(s, 'x')\n"
        "a(s) :- study(s), selected_study(f), mentions(f, 'y')\n"
        "ans(s, p) :- PROB[a(s)] = p"
    )
    assert dict(result) == pytest.approx({1: 0.5, 2: 0.25, 3: 0.5, 4: 0.25})


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
@pytest.mark.parametrize("rules, expected", [
    # Σ_(a, b) P[C(a, b)] P[R(a) ∨ T(b)]
    (
        "h() :- C(x, y), R(x)\nh() :- C(y, x), T(x)",
        0.5 * 0.4 + 0.3 * (1 - 0.3 * 0.4) + 0.2 * (1 - 0.6 * 0.4),
    ),
    # Σ_(a, b) P[C(a, b)] P[R(a) ∨ T(b) ∨ U(b)]
    (
        "h() :- C(x, y), R(x)\nh() :- C(y, x), T(x)\nh() :- C(x, y), U(y)",
        0.5 * (1 - 0.6 * 0.9) + 0.3 * (1 - 0.3 * 0.4 * 0.5)
        + 0.2 * (1 - 0.6 * 0.4 * 0.5),
    ),
])
def test_union_with_the_arguments_of_a_choice_permuted(
    solvers, rules, expected
):
    """
    The second rule has the choice atom C(y, x): renamed, the rest of the
    tuple (a, b) is R(a) ∨ T(b), whose disjuncts have different columns,
    lifted joined with the tuples of C.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_probabilistic_choice_from_tuples(
        [(0.5, "a", "b"), (0.3, "b", "a"), (0.2, "a", "a")], name="C"
    )
    nl.add_probabilistic_facts_from_tuples(
        [(0.4, "a"), (0.7, "b")], name="R"
    )
    nl.add_probabilistic_facts_from_tuples([(0.6, "a")], name="T")
    nl.add_probabilistic_facts_from_tuples(
        [(0.5, "a"), (0.1, "b")], name="U"
    )
    result = nl.execute_datalog_program(rules + "\nans(PROB) :- h()")
    assert [p for p, in result] == [pytest.approx(expected)]


def _choice_union_engine():
    from .. import NeurolangPDL

    nl = NeurolangPDL()
    nl.add_uniform_probabilistic_choice_over_set(
        [(1,), (2,), (3,), (4,)], name="selected_study"
    )
    nl.add_tuple_set(
        [(1, "language"), (2, "speech"), (2, "language"), (3, "pain"),
         (4, "memory")],
        name="mentions",
    )
    return nl


def _plan_of(program):
    """The plan of the lifted query of *program*, whose solving is
    stopped once the plan is made."""
    plans = []
    original = dalvi_suciu_lift.is_pure_lifted_plan

    def record(plan):
        plans.append(plan)
        return original(plan)

    dalvi_suciu_lift.is_pure_lifted_plan = record
    try:
        _choice_union_engine().execute_datalog_program(program)
    finally:
        dalvi_suciu_lift.is_pure_lifted_plan = original
    return plans[-1]


def test_union_of_a_self_join_and_a_choice_unrelated_to_the_head():
    """
    The separator declines a union with a rule whose choice is on a
    variable unrelated to the head (the deterministic atom binding the
    head is factored out of the union, leaving a disjunct without it),
    and weighted model counting solves it. The equality that the
    rewriting of the choices leaves between the two choice atoms of the
    self-join was translated to a projection overwriting the column of
    an atom, which the provenance sets reject.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL()
    nl.add_tuple_set(
        [(0, "b"), (0, "c"), (1, "a"), (1, "d")], name="mentions"
    )
    nl.add_uniform_probabilistic_choice_over_set(
        [(0,), (1,)], name="selected_study"
    )
    result = nl.execute_datalog_program(
        "a(t) :- mentions(s, t), selected_study(s).\n"
        "a(t) :- mentions(s, t), selected_study(s), selected_study(f), "
        "mentions(f, 'e').\n"
        "a(t) :- mentions(s, t), selected_study(f), mentions(f, 'e').\n"
        "ans(t, p) :- PROB[a(t)] = p."
    )
    assert dict(result) == pytest.approx(
        {"a": 0.5, "b": 0.5, "c": 0.5, "d": 0.5}
    )


def test_conjunctive_query_with_a_choice_and_a_negation():
    from .. import NeurolangPDL

    nl = NeurolangPDL()
    nl.add_tuple_set(
        [(0, "a"), (0, "b"), (1, "b"), (1, "c"), (2, "a")], name="mentions"
    )
    nl.add_tuple_set([("a",)], name="lang")
    nl.add_uniform_probabilistic_choice_over_set(
        [(0,), (1,), (2,)], name="selected_study"
    )
    result = nl.execute_datalog_program(
        "a(t) :- selected_study(s), mentions(s, t), ~lang(t).\n"
        "ans(t, p) :- PROB[a(t)] = p."
    )
    assert dict(result) == pytest.approx({"b": 2 / 3, "c": 1 / 3})


def test_union_with_a_choice_and_a_negation():
    """
    A union whose rule negates an atom of the study chosen: the negation
    removes the tuples of the studies that have it, which a support that
    kept the probability of the choice in it (a difference of
    probabilities, not of sets) did not.
    """
    from .. import NeurolangPDL

    mentions = {
        0: "deab", 1: "da", 2: "cab", 3: "e", 4: "dcab"
    }
    nl = NeurolangPDL()
    nl.add_tuple_set(
        [(s, t) for s, terms in mentions.items() for t in terms],
        name="mentions",
    )
    nl.add_uniform_probabilistic_choice_over_set(
        [(s,) for s in mentions], name="selected_study"
    )
    result = nl.execute_datalog_program(
        "a(t) :- mentions(s, t), selected_study(s), ~mentions(s, 'a').\n"
        "a(t) :- mentions(s, t), selected_study(s), mentions(s, 'c').\n"
        "ans(t, p) :- PROB[a(t)] = p."
    )
    assert dict(result) == pytest.approx(
        {"a": 0.4, "b": 0.4, "c": 0.4, "d": 0.2, "e": 0.2}
    )


def test_union_with_a_rule_local_variable_and_a_negation():
    """
    A rule with a variable its head has not (``s`` of ``mentions(s, t)``,
    the choice being on ``f``) in a union with a negation. The variables a
    disjunct alone has are projected in the disjunct, so that the branches
    of the union of the deterministic part have the same columns, and the
    projection is a support: it would sum the labels of the tuples it
    merges, and a label above 1 is not one of a set (the union of the
    labels is ``1 - prod(1 - l)``).
    """
    from .. import NeurolangPDL

    mentions = {0: "ab", 1: "bc", 2: "cd"}
    nl = NeurolangPDL()
    nl.add_tuple_set(
        [(s, t) for s, terms in mentions.items() for t in terms],
        name="mentions",
    )
    nl.add_uniform_probabilistic_choice_over_set(
        [(s,) for s in mentions], name="selected_study"
    )
    result = nl.execute_datalog_program(
        "a(t) :- mentions(s, t), selected_study(s), ~mentions(s, 'a').\n"
        "a(t) :- mentions(s, t), selected_study(f), mentions(f, 'c').\n"
        "ans(t, p) :- PROB[a(t)] = p."
    )
    assert dict(result) == pytest.approx(
        {"a": 2 / 3, "b": 2 / 3, "c": 2 / 3, "d": 2 / 3}
    )


def test_union_whose_normal_form_has_an_unsafe_clause():
    """
    The union of a rule with a negation and a rule with a choice unrelated
    to its head: factoring out the atom they share gives the clause
    ``exists s M(s, t) or not L(t)``, which is not safe range and was lifted
    apart (``ValueError``). The conjunctive normal form is not used then.
    """
    from .. import NeurolangPDL

    mentions = {0: "ab", 1: "bc", 2: "cd"}
    nl = NeurolangPDL()
    nl.add_tuple_set(
        [(s, t) for s, terms in mentions.items() for t in terms],
        name="mentions",
    )
    nl.add_tuple_set([("a",)], name="lang")
    nl.add_uniform_probabilistic_choice_over_set(
        [(s,) for s in mentions], name="selected_study"
    )
    result = nl.execute_datalog_program(
        "a(t) :- mentions(s, t), selected_study(s), ~lang(t).\n"
        "a(t) :- mentions(s, t), selected_study(f), mentions(f, 'c').\n"
        "ans(t, p) :- PROB[a(t)] = p."
    )
    assert dict(result) == pytest.approx(
        {"a": 2 / 3, "b": 1.0, "c": 2 / 3, "d": 2 / 3}
    )


def test_union_with_a_self_join_of_the_choice_in_a_rule():
    """
    A rule of a union joins the choice twice: the equality that makes the
    two atoms the same tuple holds in that rule only, which the unification
    of the variables took for the whole body, turning the union into a
    conjunction.
    """
    from .. import NeurolangPDL

    mentions = [
        (0, "b"), (0, "c"), (1, "a"), (1, "d"), (2, "a"), (2, "c"), (3, "a")
    ]
    nl = NeurolangPDL()
    nl.add_uniform_probabilistic_choice_over_set(
        [(s,) for s in range(4)], name="selected_study"
    )
    nl.add_tuple_set(mentions, name="mentions")
    result = nl.execute_datalog_program(
        "a(t) :- selected_study(s), selected_study(f), mentions(s, t), "
        "mentions(f, 'b')\n"
        "a(t) :- selected_study(s), mentions(s, t), mentions(s, 'c')\n"
        "ans(t, p) :- PROB[a(t)] = p"
    )
    assert dict(result) == pytest.approx({"a": 0.25, "b": 0.25, "c": 0.5})


def test_disjoint_separator_plans_a_union_in_one_projection():
    """The union over the choice is one disjoint projection on the study,
    of the choice joined with the deterministic union."""
    plan = _plan_of(
        "a(s) :- mentions(s, 'language'), selected_study(s)\n"
        "a(s) :- mentions(s, 'speech'), selected_study(s)\n"
        "a(s) :- mentions(s, 'pain'), selected_study(s)\n"
        "ans(p) :- PROB[a(s)] = p"
    )
    assert isinstance(plan, DisjointProjection)
    assert "Σ" not in repr(plan)
    # The deterministic union is a relation computed as a set.
    assert "∪" not in repr(plan)


def test_integer_constant_of_a_deterministic_atom():
    """mentions(1, t) selects the rows of study 1: its integer constant,
    equal as a constant to the column 1, was renamed into that column by
    the optimisers, and the selection kept every row."""
    from .. import NeurolangPDL

    nl = NeurolangPDL(
        probabilistic_solvers=(dalvi_suciu_lift.solve_succ_query,),
        probabilistic_marg_solvers=(dalvi_suciu_lift.solve_marg_query,),
    )
    nl.add_uniform_probabilistic_choice_over_set(
        [(1,), (2,), (3,), (4,)], name="selected_study"
    )
    nl.add_tuple_set(
        [(1, "x"), (2, "y"), (3, "x"), (4, "z"), (1, "y")], name="mentions"
    )
    result = nl.execute_datalog_program(
        "a(t) :- selected_study(f), mentions(f, t), mentions(1, t)\n"
        "ans(t, p) :- PROB[a(t)] = p"
    )
    assert dict(result) == pytest.approx({"x": 0.5, "y": 0.5})


def test_union_of_rules_one_without_a_variable_of_the_head():
    """In a(s, r) :- R(r), C(s), A(s, r) and a(s, r) :- R(r), C(s),
    M(s), the conjunctive normal form factors R(r) and C(s) out, leaving
    the clause A(s, r) ∨ M(s), whose union of plans had columns (s, r) and
    (s); it is declined, and solved by model counting."""
    from .. import NeurolangPDL

    nl = NeurolangPDL()
    nl.add_tuple_set(
        [("s1", "r1"), ("s2", "r1"), ("s3", "r2")], name="activates"
    )
    nl.add_tuple_set([("s1", "t1"), ("s3", "t1")], name="mentions")
    nl.add_tuple_set([("r1",), ("r2",)], name="region")
    nl.add_uniform_probabilistic_choice_over_set(
        [("s1",), ("s2",), ("s3",)], name="selected_study"
    )
    result = nl.execute_datalog_program(
        "a(s, r) :- region(r), selected_study(s), activates(s, r)\n"
        "a(s, r) :- region(r), selected_study(s), mentions(s, 't1')\n"
        "p(s, r, PROB) :- a(s, r)\n"
        "ans(s, r, x) :- p(s, r, x)"
    )
    expected = {
        ("s1", "r1"), ("s2", "r1"), ("s3", "r2"), ("s1", "r2"), ("s3", "r1")
    }
    assert {(s, r) for s, r, _ in result} == expected
    assert [x for _, _, x in result] == pytest.approx([1 / 3] * 5)


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_peaks_of_the_studies_of_a_term(solvers):
    """
    Each peak is reported by one study: the study of a peak is a function
    of the peak, and the study separates the query, which joins the
    reliable peaks of the region to the terms of their studies.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_probabilistic_facts_from_tuples(
        [(0.5, 1), (0.4, 2), (0.3, 3)], name="reliable_peak"
    )
    nl.add_tuple_set([(1, "s1"), (2, "s1"), (3, "s2")], name="peak_study")
    nl.add_probabilistic_facts_from_tuples(
        [(0.6, "pain", "s1"), (0.7, "pain", "s2"), (0.2, "memory", "s2")],
        name="term_in_study",
    )
    nl.execute_datalog_program(
        "q(t, PROB) :- reliable_peak(p), peak_study(p, s), "
        "term_in_study(t, s)"
    )
    result = dict(
        nl.solve_all()["q"].as_pandas_dataframe().itertuples(index=False)
    )
    assert result.keys() == {"pain", "memory"}
    pain = 1 - (1 - 0.6 * (1 - 0.5 * 0.6)) * (1 - 0.7 * 0.3)
    assert result["pain"] == pytest.approx(pain)
    assert result["memory"] == pytest.approx(0.2 * 0.3)


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_union_of_a_deterministic_and_a_probabilistic_rule(solvers):
    """
    The probability of the deterministic rule is a count, an integer:
    the union of the provenances must not truncate those of the other rule.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_tuple_set([(0, 1)], name="G")
    nl.add_probabilistic_facts_from_tuples(
        [(0.78, 0), (0.5, 2), (0.62, 3)], name="R"
    )
    nl.execute_datalog_program(
        "h(x) :- G(x, 1)\nh(x) :- R(x)\nq(x, PROB) :- h(x)"
    )
    result = dict(
        nl.solve_all()["q"].as_pandas_dataframe().itertuples(index=False)
    )
    assert result == pytest.approx({0: 1.0, 2: 0.5, 3: 0.62})


@pytest.mark.parametrize("comparison, expected", [
    ("y > 1", 1 - (1 - 0.5 * 0.7) * (1 - 0.4 * 0.8)),
    ("1 < y", 1 - (1 - 0.5 * 0.7) * (1 - 0.4 * 0.8)),
    ("y != 1", 1 - (1 - 0.5 * 0.7) * (1 - 0.4 * 0.8)),
    ("y >= 3", 0.4 * 0.8),
    ("y <= 1", 0.5 * 0.6),
])
@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_comparison_with_a_constant_of_a_bound_variable(
    solvers, comparison, expected
):
    """
    The comparison of y with a constant, outside the existential of x
    once the quantifiers are pushed down, selects the tuples of S.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_probabilistic_facts_from_tuples([(0.5, 1), (0.4, 2)], name="R")
    nl.add_probabilistic_facts_from_tuples(
        [(0.6, 1, 1), (0.7, 1, 2), (0.8, 2, 3)], name="S"
    )
    nl.execute_datalog_program(
        f"q(PROB) :- R(x), S(x, y), ({comparison})"
    )
    result = nl.solve_all()["q"].as_pandas_dataframe()
    assert len(result) == 1
    assert result.iloc[0, 0] == pytest.approx(expected)


@pytest.mark.parametrize("head, body", [
    ("x, y", "R(x), R(y), S(x, y)"),
    ("x, y, w", "R(x), R(y), R(w), S(x, y), V(y, w)"),
    ("x, y, w", "R(x), R(y), R(w), S(x, y), V(y, w), T(y)"),
    ("x, y, w", "R(x), R(y), R(w), T(x), T(y), S(x, y)"),
    ("x, y, w, z", "R(x), R(y), R(w), R(z), S(x, y), V(w, z)"),
])
def test_answer_variables_at_the_same_position(head, body):
    """
    The atoms of R, and of T, with free variables at the same position are
    lifted on each partition of the equalities of the variables, and have
    the probabilities weighted model counting gives.
    """
    from .. import NeurolangPDL
    from ..probabilistic_frontend import (
        wmc_solve_marg_query,
        wmc_solve_succ_query
    )

    def solve(**solvers):
        nl = NeurolangPDL(**solvers)
        facts = {
            "R": [(0.2, 0), (0.5, 1), (0.7, 2)],
            "T": [(0.9, 0), (0.4, 1), (0.6, 2)],
            "S": [(0.3, 0, 1), (0.8, 1, 1), (0.6, 2, 0), (0.5, 1, 2)],
            "V": [(0.4, 1, 0), (0.7, 1, 1), (0.9, 2, 2), (0.2, 0, 2)],
        }
        for name, tuples in facts.items():
            nl.add_probabilistic_facts_from_tuples(tuples, name=name)
        nl.execute_datalog_program(f"q({head}, PROB) :- {body}")
        return {
            tuple(row[:-1]): row[-1]
            for row in nl.solve_all()["q"].as_pandas_dataframe().itertuples(
                index=False
            )
        }

    expected = solve(
        probabilistic_solvers=(wmc_solve_succ_query,),
        probabilistic_marg_solvers=(wmc_solve_marg_query,),
    )
    assert solve(**LIFTED_ONLY) == pytest.approx(expected)


@pytest.mark.parametrize("head, body", [
    # The variables of a choice need no order.
    ("", "C(x, y), S(y, x)"),
    ("", "C(x, y), S(y, x), R(x)"),
    ("", "C(x, y), S(x, y), S(y, x)"),
    # A comparison of the ranked variables decides their order.
    ("", "S(x, y), S(y, x), (x < y)"),
    ("", "S(x, y), S(y, x), (x > y)"),
    ("", "S(x, y), S(y, x), (x != y)"),
    ("", "S(x, y), S(y, x), V(y, x), (x < y)"),
    # A bound variable at the position of an answer variable.
    ("x", "S(x, y), S(y, x)"),
    ("x", "S(x, y), S(y, x), R(y)"),
    ("x", "S(x, y), S(y, x), V(x, y)"),
    ("x, z", "S(x, y), S(y, x), V(z, y)"),
    ("", "D(x), S(x, y), S(y, x)"),
])
def test_choices_comparisons_and_a_bound_variable_in_ranking(head, body):
    """
    Queries that were not ranked, or whose bound variable at the position
    of an answer variable was not split from it, are lifted with the
    probabilities weighted model counting gives.
    """
    from .. import NeurolangPDL
    from ..probabilistic_frontend import (
        wmc_solve_marg_query,
        wmc_solve_succ_query
    )

    def solve(**solvers):
        nl = NeurolangPDL(**solvers)
        facts = {
            "R": [(0.2, 0), (0.5, 1), (0.7, 2)],
            "S": [
                (0.3, 0, 1), (0.8, 1, 1), (0.6, 2, 0), (0.5, 1, 2),
                (0.4, 1, 0), (0.9, 0, 2), (0.7, 2, 1), (0.2, 0, 0),
            ],
            "V": [(0.4, 1, 0), (0.7, 1, 1), (0.9, 2, 2), (0.2, 0, 2)],
        }
        for name, tuples in facts.items():
            nl.add_probabilistic_facts_from_tuples(tuples, name=name)
        nl.add_probabilistic_choice_from_tuples(
            [(0.1, 0, 1), (0.3, 1, 0), (0.2, 2, 2), (0.4, 1, 2)], name="C"
        )
        nl.add_uniform_probabilistic_choice_over_set(
            [(0,), (1,), (2,)], name="D"
        )
        nl.execute_datalog_program(
            f"q({head + ', ' if head else ''}PROB) :- {body}"
        )
        return {
            tuple(row[:-1]): row[-1]
            for row in nl.solve_all()["q"].as_pandas_dataframe().itertuples(
                index=False
            )
        }

    expected = solve(
        probabilistic_solvers=(wmc_solve_succ_query,),
        probabilistic_marg_solvers=(wmc_solve_marg_query,),
    )
    assert solve(**LIFTED_ONLY) == pytest.approx(expected)


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_function_of_a_variable_separates_the_query(solvers):
    """
    In R(x) ∧ T(y) ∧ y = x + 1, y is a function of x: it separates the
    query, whose atoms R(x) and T(y) share no variable otherwise.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_probabilistic_facts_from_tuples(
        [(0.5, 0), (0.4, 1), (0.3, 3)], name="R"
    )
    nl.add_probabilistic_facts_from_tuples(
        [(0.6, 1), (0.7, 2), (0.2, 3)], name="T"
    )
    nl.execute_datalog_program("q(PROB) :- R(x), T(y), (y == x + 1)")
    result = nl.solve_all()["q"].as_pandas_dataframe()
    assert len(result) == 1
    assert result.iloc[0, 0] == pytest.approx(
        1 - (1 - 0.5 * 0.6) * (1 - 0.4 * 0.7)
    )


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
@pytest.mark.parametrize("rules", [
    "h(y) :- R(x), F(x, y), T(y)\nh(y) :- R(x), F(x, y), U(y)",
    "h(y) :- R(x), F1(x, z), F2(z, y), T(y)\n"
    "h(y) :- R(v), F1(v, w), F2(w, y), U(y)",
])
def test_function_through_the_same_path_in_several_rules(solvers, rules):
    """
    y is the same function of x in both rules, directly or through a
    chain of functions: a tuple of R is in the subquery of one y only,
    and y separates the union.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_probabilistic_facts_from_tuples(
        [(0.5, 1), (0.4, 2), (0.3, 3)], name="R"
    )
    nl.add_probabilistic_facts_from_tuples(
        [(0.6, "a"), (0.7, "b")], name="T"
    )
    nl.add_probabilistic_facts_from_tuples(
        [(0.2, "a"), (0.9, "b")], name="U"
    )
    nl.add_tuple_set([(1, "a"), (2, "a"), (3, "b")], name="F")
    nl.add_tuple_set([(1, 10), (2, 10), (3, 30)], name="F1")
    nl.add_tuple_set([(10, "a"), (30, "b")], name="F2")
    nl.execute_datalog_program(rules + "\nq(PROB) :- h(y)")
    result = nl.solve_all()["q"].as_pandas_dataframe()
    assert len(result) == 1
    assert result.iloc[0, 0] == pytest.approx(1 - (
        (1 - (1 - 0.5 * 0.6) * (1 - 0.8 * 0.4)) *
        (1 - 0.3 * (1 - 0.3 * 0.1))
    ))


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_function_both_ways_in_several_rules(solvers):
    """
    G is a bijection, so that x and y determine each other: y, of every
    probabilistic atom, separates the union first, and x then has T(y)
    without it, which another rule lifts.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_probabilistic_facts_from_tuples(
        [(0.5, 1, "a"), (0.4, 2, "b")], name="S"
    )
    nl.add_probabilistic_facts_from_tuples(
        [(0.6, "a"), (0.7, "b")], name="T"
    )
    nl.add_probabilistic_facts_from_tuples(
        [(0.2, 1, "a"), (0.9, 2, "b")], name="V"
    )
    nl.add_tuple_set([(1, "a"), (2, "b")], name="G")
    nl.execute_datalog_program(
        "h(y) :- S(x, y), G(x, y), T(y)\n"
        "h(y) :- S(x, y), G(x, y), V(x, y)\n"
        "q(PROB) :- h(y)"
    )
    result = nl.solve_all()["q"].as_pandas_dataframe()
    assert len(result) == 1
    assert result.iloc[0, 0] == pytest.approx(1 - (
        (1 - 0.5 * (1 - 0.4 * 0.8)) * (1 - 0.4 * (1 - 0.3 * 0.1))
    ))


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_function_of_a_deterministic_atom_inline_or_in_a_rule(solvers):
    """
    A function the engine knows by name, applied to the choice, and a
    threshold on it, within PROB, are the same query as the deterministic
    rule computing them: the same probabilities, and not an error for
    functions that the probabilistic program did not know.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_symbol(
        lambda term, study: {1: 0.9, 2: 0.8, 3: 0.2}[study],
        name="query_similarity"
    )
    nl.add_uniform_probabilistic_choice_over_set(
        [(1,), (2,), (3,)], name="selected_study"
    )
    nl.add_tuple_set([(1,), (2,), (3,)], name="study")
    nl.add_tuple_set([(10, 1), (11, 2), (12, 3), (13, 3)], name="peak")
    inline = nl.execute_datalog_program(
        "ans(i, p) :- PROB[selected_study(s), peak(i, s), "
        "(v == query_similarity('tom', s)), (v > 0.75)] = p"
    )
    in_a_rule = nl.execute_datalog_program(
        "similar(s) :- study(s), (v == query_similarity('tom', s)), "
        "(v > 0.75)\n"
        "ans(i, p) :- PROB[selected_study(s), peak(i, s), similar(s)] = p"
    )
    assert dict(inline) == pytest.approx({10: 1 / 3, 11: 1 / 3})
    assert dict(in_a_rule) == pytest.approx(dict(inline))


def _solve_random(query, seed, solvers, facts=None):
    """Probabilities of the answers of `query` on random tuple-independent
    relations over a small domain, whose values collide, but those of
    probability 0, which the lifted plans of differences can keep."""
    import itertools
    import random

    from .. import NeurolangPDL

    random.seed(seed)
    nl = NeurolangPDL(**solvers)
    for name, arity in dict(R=1, T=1, S=2, V=2, U=1).items():
        tuples = [
            (round(random.uniform(.1, .9), 2),) + t
            for t in itertools.product(range(4), repeat=arity)
            if random.random() < .7
        ]
        nl.add_probabilistic_facts_from_tuples(
            (facts or {}).get(name, tuples), name=name
        )
    nl.execute_datalog_program(query)
    result = nl.solve_all()
    if "q" not in result:
        return {}
    return {
        tuple(row[:-1]): row[-1]
        for row in result["q"].as_pandas_dataframe().itertuples(index=False)
        if abs(row[-1]) > 1e-12
    }


ORDER_AND_COUNT_QUERIES = [
    "q(PROB) :- R(x), T(y), (x < y)",
    "q(PROB) :- R(x), T(y), (x <= y)",
    "q(PROB) :- R(x), T(y), (y > x)",
    "q(PROB) :- R(x), T(y), (x >= y), (x != 1)",
    "q(w, PROB) :- V(w, x), T(y), (x < y)",
    "q(PROB) :- R(x), R(y), (x != y)",
    "q(PROB) :- R(x), R(y), (x < y)",
    "q(x, PROB) :- S(x, y), S(x, z), (y != z)",
    "q(PROB) :- R(x), T(y), U(z), (x < y), (y < z)",
    "q(PROB) :- R(x), T(y), V(z, z), (x < y), (y < z)",
    "q(PROB) :- R(x), T(y), (x + 1 < y)",
    "q(PROB) :- R(x), T(y), (x < y + 1)",
    "q(y, PROB) :- R(x), T(y), (x * 2 > y)",
    "q(PROB) :- R(x), S(x, y), T(z), (y < z)",
    "q(w, PROB) :- R(x), S(x, y), V(w, z), (y <= z)",
    "q(PROB) :- S(x, y), V(z, w), (y < w)",
    "q(PROB) :- R(x), T(y), (x < y), ~U(y)",
]


@pytest.mark.parametrize("seed", [0, 1, 7])
@pytest.mark.parametrize("query", ORDER_AND_COUNT_QUERIES)
def test_order_across_atoms_and_at_least_two(query, seed):
    """
    An order comparison between atoms is lifted by projecting on the
    least, or greatest, value of a variable, and two values of a relation
    as the complement of one, with the probabilities of weighted model
    counting, ties included.
    """
    from ..probabilistic_frontend import (
        wmc_solve_marg_query,
        wmc_solve_succ_query
    )

    expected = _solve_random(query, seed, dict(
        probabilistic_solvers=(wmc_solve_succ_query,),
        probabilistic_marg_solvers=(wmc_solve_marg_query,),
    ))
    assert _solve_random(query, seed, LIFTED_ONLY) == pytest.approx(expected)


@pytest.mark.parametrize("query, facts, expected", [
    (
        "q(PROB) :- R(x), T(y), (x < y)",
        dict(R=[(.5, 1), (.4, 2)], T=[(.6, 2), (.7, 3)]),
        .5 * (1 - .4 * .3) + .4 * .5 * .7
    ),
    ("q(PROB) :- R(x), T(y), (x < y)", dict(R=[(.5, 3)], T=[(.6, 2)]), None),
    (
        "q(PROB) :- R(x), R(y), (x != y)",
        dict(R=[(.5, 1), (.4, 2), (.3, 3)]),
        1 - .5 * .6 * .7 - (.5 * .6 * .7 + .5 * .4 * .7 + .5 * .6 * .3)
    ),
    ("q(PROB) :- R(x), R(y), (x != y)", dict(R=[(.5, 1)]), None),
    ("q(PROB) :- T(y), (y < y * 2)", dict(T=[(.5, -1), (.5, 2)]), .5),
])
def test_order_across_atoms_and_at_least_two_formulas(
    query, facts, expected
):
    """
    The probabilities are those of the formulas: for R(x) ∧ T(y) ∧ x < y
    the sum, on the least value a of R, of p_R(a) ∏_{b<a} (1 - p_R(b))
    (1 - ∏_{c>a} (1 - p_T(c))), and for two values of R
    1 - ∏ (1 - p) - Σ_a p_a ∏_{b≠a} (1 - p_b).
    Without the tuples needed, there is no answer. The least value of y,
    -1, does not satisfy y < y * 2, which 2 does: y is not projected on
    its least value.
    """
    result = _solve_random(query, 0, LIFTED_ONLY, facts)
    if expected is None:
        assert result == {}
    else:
        assert result == {(): pytest.approx(expected)}


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
@pytest.mark.parametrize("query, facts, expected", [
    (
        "q(PROB) :- R(x), S(x, y), T(z), (y < z)",
        dict(R=[(.5, 1)], S=[(.6, 1, 1), (.7, 1, 3)], T=[(.8, 2), (.4, 4)]),
        .5 * (.4 * (1 - .4 * .3) + .6 * .8 * .6)
    ),
    (
        "q(PROB) :- S(x, y), V(z, w), (y < w)",
        dict(S=[(.5, 1, 1), (.4, 2, 3)], V=[(.6, 1, 2), (.7, 2, 4)]),
        .7 * (1 - .5 * .6) + .3 * .6 * .5
    ),
    (
        "q(PROB) :- R(x), T(y), (x < y), ~U(y)",
        dict(R=[(.5, 1)], T=[(.6, 2), (.7, 3)], U=[(.2, 3)]),
        .5 * (1 - .4 * (1 - .7 * .8))
    ),
    (
        "q(PROB) :- R(x), S(x, y), T(z), (y < z)",
        dict(R=[(.5, 1)], S=[(.6, 1, 3)], T=[(.8, 2)]),
        None
    ),
])
def test_order_across_subqueries_formulas(query, facts, expected, solvers):
    """
    A side of the comparison can be a subquery independent for different
    values of its variable: P[∃x ∃y ∃z R(x) ∧ S(x, y) ∧ T(z) ∧ y < z] is
    the sum, on the greatest value m of T, of p_T(m) ∏_{c>m} (1 - p_T(c))
    P[∃x R(x) ∧ ∃y (S(x, y) ∧ y < m)], ∃z V(z, w) and T(y) ∧ ¬U(y) being
    such sides too.
    """
    result = _solve_random(query, 0, solvers, facts)
    if expected is None:
        assert result == {}
    else:
        assert result == {(): pytest.approx(expected)}


AT_LEAST_THREE = "R(x), R(y), R(z), (x != y), (y != z), (x != z)"


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
@pytest.mark.parametrize("query, facts, expected", [
    (
        f"q(PROB) :- {AT_LEAST_THREE}",
        dict(R=[(.5, 1), (.4, 2), (.3, 3)]),
        {(): .5 * .4 * .3}
    ),
    (
        f"q(PROB) :- {AT_LEAST_THREE}",
        dict(R=[(.5, 1), (.4, 2), (.3, 3), (.2, 4)]),
        {(): .5 * .4 * .3 * .2 + .5 * .4 * .3 * .8 + .5 * .4 * .7 * .2 +
         .5 * .6 * .3 * .2 + .5 * .4 * .3 * .2}
    ),
    (
        "q(PROB) :- R(x), R(y), R(z), (x < y), (y < z), (x != z)",
        dict(R=[(.5, 1), (.4, 2), (.3, 3)]),
        {(): .5 * .4 * .3}
    ),
    (f"q(PROB) :- {AT_LEAST_THREE}", dict(R=[(.5, 1), (.4, 2)]), {}),
    (f"q(PROB) :- {AT_LEAST_THREE}", dict(R=[(.5, 1)]), {}),
    (
        f"q(PROB) :- {AT_LEAST_THREE}, R(u), "
        "(u != x), (u != y), (u != z)",
        dict(R=[(.5, 1), (.4, 2), (.3, 3), (.2, 4)]),
        {(): .5 * .4 * .3 * .2}
    ),
    (
        "q(t, PROB) :- S(t, x), S(t, y), S(t, z), "
        "(x != y), (y != z), (x != z)",
        dict(S=[
            (.5, 0, 1), (.4, 0, 2), (.3, 0, 3), (.9, 1, 1), (.8, 1, 2),
            (.7, 2, 1)
        ]),
        {(0,): .5 * .4 * .3}
    ),
])
def test_at_least_k(query, facts, expected, solvers):
    """
    At least three, or four, values of R: the sum, on the worlds with
    that many tuples or more, of their probabilities; per answer t for
    S(t, x). Without enough tuples, there is no answer.
    """
    result = _solve_random(query, 0, solvers, facts)
    assert result == pytest.approx(expected)


@pytest.mark.parametrize("query", [
    "q(PROB) :- R(x), S(x, y), T(y), U(z), (y < z)",
])
def test_order_across_atoms_declined(query):
    """
    A comparison with a #P-hard side, R(x) ∧ S(x, y) ∧ T(y), is declined.
    """
    from nl_expr.exceptions import NonLiftableException

    with pytest.raises(NonLiftableException):
        _solve_random(query, 0, LIFTED_ONLY)


DETERMINISTIC_UNION_QUERIES = [
    "seed(s) :- A(l, s), startswith('a', l), C(s)\n"
    "seed(s) :- A(l, s), startswith('b', l), C(s)\n"
    "active(l, s) :- B(l, s), C(s)\n"
    "ans(l, p) :- PROB[active(l, s) // seed(s)] = p",
    "seed(s) :- A(l, s), startswith('a', l), C(s)\n"
    "seed(s) :- B(l, s), C(s), ~A(l, s)\n"
    "ans(p) :- PROB[seed(s)] = p",
    "seed(s, l) :- A(l, s), C(s)\n"
    "seed(s, l) :- B(l, s), startswith('b', l), C(s)\n"
    "ans(l, p) :- PROB[seed(s, l)] = p",
]


@pytest.mark.parametrize("seed", [0, 1])
@pytest.mark.parametrize("query", DETERMINISTIC_UNION_QUERIES)
def test_union_of_rules_joining_a_choice_and_deterministic_atoms(
    query, seed
):
    """
    The deterministic union that a choice is joined with by the disjoint
    separator is computed as a set, with the probabilities of weighted
    model counting.
    """
    import itertools
    import random

    from .. import NeurolangPDL
    from ..probabilistic_frontend import (
        wmc_solve_marg_query,
        wmc_solve_succ_query
    )

    def startswith(prefix: str, label: str) -> bool:
        return label.startswith(prefix)

    def solve(solvers):
        random.seed(seed)
        nl = NeurolangPDL(**solvers)
        nl.add_symbol(startswith, name="startswith")
        nl.add_uniform_probabilistic_choice_over_set(
            [(s,) for s in range(6)], name="C"
        )
        for name in "AB":
            labels = ("a1", "a2", "b1", "c1")
            nl.add_tuple_set([
                t for t in itertools.product(labels, range(6))
                if random.random() < .4
            ], name=name)
        return {
            tuple(row[:-1]): row[-1]
            for row in nl.execute_datalog_program(query)
        }

    expected = solve(dict(
        probabilistic_solvers=(wmc_solve_succ_query,),
        probabilistic_marg_solvers=(wmc_solve_marg_query,),
    ))
    assert expected
    assert solve(LIFTED_ONLY) == pytest.approx(expected)


# P[∃x R(x) ∧ x ≠ a] for each a, and P[∃x R(x)]; the tuple (a, b) of the
# choice C2 is (1, 1), (1, 2) or (2, 1) with probabilities .2, .3 and .5.
R_NOT_1, R_NOT_2, R_ANY = 1 - .3 * .6, 1 - .4 * .6, 1 - .4 * .3 * .6


@pytest.mark.parametrize("query, expected", [
    (
        "q(PROB) :- R(x), ~C2(x, 1)",
        {(): .2 * R_NOT_1 + .3 * R_ANY + .5 * R_NOT_2},
    ),
    (
        "q(PROB) :- R(x), ~C2(x, x)",
        {(): .2 * R_NOT_1 + .3 * R_ANY + .5 * R_ANY},
    ),
    (
        "q(PROB) :- R(x), C2(y, z), ~C2(x, 1)",
        {(): .2 * R_NOT_1 + .3 * R_ANY + .5 * R_NOT_2},
    ),
    (
        "q(PROB) :- R(x), T(y), ~C2(x, 1), ~C2(y, 2)",
        {(): (
            .2 * R_NOT_1 * (1 - .5 * .1) + .3 * R_ANY * .9 +
            .5 * R_NOT_2 * (1 - .5 * .1)
        )},
    ),
    (
        "q(y, PROB) :- S(x, y), ~C2(x, y)",
        {(1,): .2 * .6 + .3 * (1 - .5 * .4) + .5 * .5, (2,): .8},
    ),
])
@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_negated_choice_of_several_columns(solvers, query, expected):
    """
    ¬C2(ū) ≡ ∃f̄ (C2(f̄) ∧ f̄ ≠ ū), exactly one tuple of the choice being
    true: the disjoint projection on f̄ of C2(f̄) ∧ ∃x (R(x) ∧ f̄ ≠ ū),
    whose comparison of tuples selects the tuples of R, a disjunction
    of comparisons of their columns.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_probabilistic_choice_from_tuples(
        [(.2, 1, 1), (.3, 1, 2), (.5, 2, 1)], name="C2"
    )
    nl.add_probabilistic_facts_from_tuples(
        [(.6, 1), (.7, 2), (.4, 3)], name="R"
    )
    nl.add_probabilistic_facts_from_tuples([(.5, 1), (.9, 2)], name="T")
    nl.add_probabilistic_facts_from_tuples(
        [(.5, 1, 1), (.6, 2, 1), (.8, 3, 2)], name="S"
    )
    nl.execute_datalog_program(query)
    result = {
        tuple(row[:-1]): row[-1]
        for row in nl.solve_all()["q"].as_pandas_dataframe().itertuples(
            index=False
        )
    }
    assert result == pytest.approx(expected)



@pytest.mark.parametrize("seed", range(4))
@pytest.mark.parametrize("thalamus, lifted", [
    ([1, 2, 3], True),    # without the constant: lifted
    ([0, 1, 2], False),   # with it: a self-join, declined
])
def test_self_join_through_a_constant_a_deterministic_atom_excludes(
    seed, thalamus, lifted
):
    """
    ``q(l) :- S(0, t), T(t), S(t, l)`` (via_thalamus): with 0 in no tuple
    of the deterministic T, the conjunction implies t ≠ 0, which shatters
    S(t, l) into the tuples without 0: no self-join, lifted, with the
    probabilities of model counting. With 0 in T, it is declined.
    """
    import itertools
    import random

    from .. import NeurolangPDL
    from .. import probabilistic_frontend as pf

    wmc = dict(
        probabilistic_solvers=(pf.wmc_solve_succ_query,),
        probabilistic_marg_solvers=(pf.wmc_solve_marg_query,),
    )

    def solve(solvers):
        rng = random.Random(seed)
        nl = NeurolangPDL(**solvers)
        nl.add_probabilistic_facts_from_tuples(
            [(round(rng.uniform(.1, .9), 2),) + t
             for t in itertools.product(range(5), repeat=2)
             if rng.random() < .7],
            name="S",
        )
        nl.add_tuple_set([(t,) for t in thalamus], name="T")
        nl.execute_datalog_program("q(l, PROB) :- S(0, t), T(t), S(t, l)")
        return dict(nl.solve_all()["q"].as_pandas_dataframe().values)

    expected = solve(wmc)
    if not lifted:
        with pytest.raises(dalvi_suciu_lift.NonLiftableException):
            solve(LIFTED_ONLY)
        return
    result = solve(LIFTED_ONLY)
    assert result.keys() == expected.keys()
    for key, value in expected.items():
        assert result[key] == pytest.approx(value)


def _by_enumeration(probabilistic, satisfies):
    """The probability that a world of the tuple-independent relations
    *probabilistic*, a mapping of their names to tuples whose first value
    is the probability, satisfies *satisfies*, a function of the mapping
    of the names to the tuples of the world."""
    import itertools

    facts = [
        (name, t) for name, tuples in probabilistic.items() for t in tuples
    ]
    probability = 0.
    for world in itertools.product([False, True], repeat=len(facts)):
        weight = 1.
        tuples = {name: set() for name in probabilistic}
        for present, (name, (p, *t)) in zip(world, facts):
            weight *= p if present else 1 - p
            if present:
                tuples[name].add(tuple(t))
        if satisfies(tuples):
            probability += weight
    return probability


def _solve(program, probabilistic, deterministic, solvers):
    """The probabilities of *program*'s Boolean ``ans``."""
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    for name, tuples in probabilistic.items():
        nl.add_probabilistic_facts_from_tuples(tuples, name=name)
    for name, tuples in deterministic.items():
        nl.add_tuple_set(tuples, name=name)
    return [p for p, in nl.execute_datalog_program(program)]


@pytest.fixture
def renamed(monkeypatch):
    """Whether `rename_disjoint_restrictions` rewrote the queries lifted,
    appended to a list."""
    rename = dalvi_suciu_lift.rename_disjoint_restrictions
    result = []

    def recorded(query, symbol_table):
        renamed_query = rename(query, symbol_table)
        result.append(renamed_query is not query)
        return renamed_query

    monkeypatch.setattr(
        dalvi_suciu_lift, "rename_disjoint_restrictions", recorded
    )
    return result


TE = [
    (.8, "b1", "G1", "AD"), (.3, "b2", "G1", "AD"), (.6, "l1", "G1", "AD"),
    (.5, "b1", "G2", "AD"), (.7, "l2", "G2", "AD"), (.4, "l1", "G2", "PD"),
    (.9, "b2", "G2", "PD"),
]
ORGAN = [("b1", "brain"), ("b2", "brain"), ("l1", "blood"), ("l2", "blood")]
DETERMINISTIC = dict(
    organ=ORGAN, target=[("X", "G1"), ("X", "G2")],
    adult=[("b1",), ("l1",), ("l2",)],
)


def _evidence_in(world, organ, gene, organ_name, adult=False):
    """Whether *world* has evidence for AD of *gene* in a dataset of
    *organ_name*, and of an adult."""
    return any(
        g == gene and s == "AD" and (d, organ_name) in organ
        and (not adult or (d,) in DETERMINISTIC["adult"])
        for d, g, s in world["te"]
    )


def _brain_and_blood(adult=False, organ=ORGAN):
    def satisfies(world):
        return any(
            _evidence_in(world, organ, g, "brain", adult)
            and _evidence_in(world, organ, g, "blood")
            for g in ("G1", "G2")
        )
    return satisfies


def test_separator_with_a_deterministic_relation_in_two_atoms():
    """
    ``organ`` in two atoms, without the separator ``g``: deterministic,
    its atoms need no position of ``g`` for the subqueries of two values
    of ``g`` to be independent, and ``g`` separates the query.
    """
    organ = dict(ORGAN)
    probabilistic = {
        "te_brain": [t for t in TE if organ[t[1]] == "brain"],
        "te_blood": [t for t in TE if organ[t[1]] == "blood"],
    }
    program = (
        "ans(PROB) :- target('X', g), te_brain(d1, g, 'AD'),"
        " organ(d1, 'brain'), te_blood(d2, g, 'AD'), organ(d2, 'blood')"
    )

    def satisfies(world):
        return any(
            any(t[1:] == (g, "AD") for t in world["te_brain"]) and
            any(t[1:] == (g, "AD") for t in world["te_blood"])
            for g in ("G1", "G2")
        )

    result = _solve(program, probabilistic, DETERMINISTIC, LIFTED_ONLY)
    assert result == [
        pytest.approx(_by_enumeration(probabilistic, satisfies))
    ]


@pytest.mark.parametrize("program, adult", [
    (
        "both(g) :- te(d1, g, 'AD'), organ(d1, 'brain'),"
        " te(d2, g, 'AD'), organ(d2, 'blood')\n"
        "ans(PROB) :- target('X', g), both(g)",
        False,
    ),
    (   # with the constants of the drug and the disease, as in P4d
        "ans(PROB) :- target('X', g), te(d1, g, 'AD'), organ(d1, 'brain'),"
        " te(d2, g, 'AD'), organ(d2, 'blood')",
        False,
    ),
    (   # restricted by two deterministic atoms
        "ans(PROB) :- target('X', g), te(d1, g, 'AD'), organ(d1, 'brain'),"
        " adult(d1), te(d2, g, 'AD'), organ(d2, 'blood')",
        True,
    ),
])
def test_self_join_on_tuples_disjoint_deterministic_atoms_select(
    program, adult, renamed
):
    """
    ``te(d1, g, 'AD') ∧ organ(d1, 'brain') ∧ te(d2, g, 'AD') ∧ organ(d2,
    'blood')``: a dataset having a single organ, the atoms of ``te``
    select disjoint sets of tuples, renamed as relations without the
    self-join, lifted with the probability of the enumeration of the
    worlds.
    """
    result = _solve(program, {"te": TE}, DETERMINISTIC, LIFTED_ONLY)
    assert result == [pytest.approx(
        _by_enumeration({"te": TE}, _brain_and_blood(adult))
    )]
    assert renamed == [True]


def test_self_join_on_tuples_overlapping_deterministic_atoms_select(
    renamed
):
    """A dataset of the brain and of the blood: the tuples the atoms of
    ``te`` select overlap, and are not renamed; the query is lifted by
    the separator ``g`` and inclusion–exclusion."""
    program = (
        "ans(PROB) :- target('X', g), te(d1, g, 'AD'), organ(d1, 'brain'),"
        " te(d2, g, 'AD'), organ(d2, 'blood')"
    )
    organ = ORGAN + [("b1", "blood")]
    result = _solve(
        program, {"te": TE}, dict(DETERMINISTIC, organ=organ), LIFTED_ONLY
    )
    assert result == [pytest.approx(
        _by_enumeration({"te": TE}, _brain_and_blood(organ=organ))
    )]
    assert renamed == [False]


def test_self_join_with_an_atom_no_deterministic_atom_selects(renamed):
    """A third atom of ``te``, on any dataset: its tuples overlap those of
    the other two, none is renamed, and the query is declined."""
    program = (
        "ans(PROB) :- target('X', g), te(d1, g, 'AD'), organ(d1, 'brain'),"
        " te(d2, g, 'AD'), organ(d2, 'blood'), te(d3, g, s), (s != 'AD')"
    )

    def satisfies(world):
        return any(
            _evidence_in(world, ORGAN, g, "brain")
            and _evidence_in(world, ORGAN, g, "blood")
            and any(t[1] == g and t[2] != "AD" for t in world["te"])
            for g in ("G1", "G2")
        )

    with pytest.raises(dalvi_suciu_lift.NonLiftableException):
        _solve(program, {"te": TE}, DETERMINISTIC, LIFTED_ONLY)
    assert not any(renamed)
    result = _solve(program, {"te": TE}, DETERMINISTIC, {})
    expected = _by_enumeration({"te": TE}, satisfies)
    assert result == [pytest.approx(expected)]


@pytest.mark.parametrize("d2, lifted", [
    ([(20,)], True),            # D1 and D2 disjoint
    ([(10,), (20,)], False),    # both with 10
])
def test_union_with_disjoint_restrictions_of_a_relation(d2, lifted, renamed):
    """
    ``R(x) ∧ S(x, y) ∧ D1(y)  ∨  S(x, y) ∧ T(y) ∧ D2(y)``, the #P-hard
    union ``H1`` with deterministic ``D1`` and ``D2``: disjoint, the atoms
    of ``S`` select disjoint tuples, relations of a union of independent
    queries, lifted; otherwise it is declined.
    """
    probabilistic = {
        "R": [(.5, 1), (.6, 2)],
        "S": [(.7, 1, 10), (.4, 1, 20), (.3, 2, 10), (.8, 2, 20)],
        "T": [(.9, 10), (.2, 20)],
    }
    deterministic = {"D1": [(10,)], "D2": d2}
    program = (
        "q() :- R(x), S(x, y), D1(y)\n"
        "q() :- S(x, y), T(y), D2(y)\n"
        "ans(PROB) :- q()"
    )

    def satisfies(world):
        return any(
            (x,) in world["R"] and (y,) in deterministic["D1"] or
            (y,) in world["T"] and (y,) in deterministic["D2"]
            for x, y in world["S"]
        )

    expected = _by_enumeration(probabilistic, satisfies)
    if lifted:
        result = _solve(program, probabilistic, deterministic, LIFTED_ONLY)
    else:
        with pytest.raises(dalvi_suciu_lift.NonLiftableException):
            _solve(program, probabilistic, deterministic, LIFTED_ONLY)
        result = _solve(program, probabilistic, deterministic, {})
    assert result == [pytest.approx(expected)]
    assert renamed[0] is lifted


TIROFIBAN = "'Tirofiban Hydrochloride'"


@pytest.mark.parametrize("program", [
    # Disjoint constants, a negated nullary rule.
    f"pd_hit() :- drug_target({TIROFIBAN}, g), test_evidence(d, g, 'PD')\n"
    f"ad_hit() :- drug_target({TIROFIBAN}, g), test_evidence(d, g, 'AD')\n"
    "nad() :- ~ad_hit()\n"
    "both() :- pd_hit(), nad()\n"
    "ans(probability) :- PROB[both()] = probability",
    f"pd_ev() :- drug_target({TIROFIBAN}, g), test_evidence(d, g, 'PD')\n"
    f"ad_ev() :- drug_target({TIROFIBAN}, g), test_evidence(d, g, 'AD')\n"
    "good() :- pd_ev(), ~ad_ev()\n"
    "ans(probability) :- PROB[good()] = probability",
    # A constant at another position too.
    f"pd_ev() :- drug_target({TIROFIBAN}, g), test_evidence(1, g, 'PD')\n"
    f"ad_ev() :- drug_target({TIROFIBAN}, g), test_evidence(d, g, 'AD')\n"
    "good() :- pd_ev(), ~ad_ev()\n"
    "ans(probability) :- PROB[good()] = probability",
    # The same constant, the drugs sharing a gene: the atoms are not
    # disjoint.
    f"pd_ev() :- drug_target({TIROFIBAN}, g), test_evidence(d, g, 'PD')\n"
    "ad_ev() :- drug_target('Aspirin', g), test_evidence(d, g, 'PD')\n"
    "good() :- pd_ev(), ~ad_ev()\n"
    "ans(probability) :- PROB[good()] = probability",
])
def test_negated_atoms_of_a_relation_selected_by_different_constants(
    program
):
    """
    ``test_evidence`` positive and negated, with 'PD' in one atom and 'AD'
    in the other, raised NotUnateException: the non-repeating planner ran
    before shattering. Shattered on the constants, the atoms are of
    disjoint, independent relations, and the query is planned as
    P[pd] (1 - P[ad]). With the same constant, the atoms can be the same
    tuples. Each has the probability of weighted model counting.
    """
    from .. import NeurolangPDL
    from .. import probabilistic_frontend as pf

    wmc = dict(
        probabilistic_solvers=(pf.wmc_solve_succ_query,),
        probabilistic_marg_solvers=(pf.wmc_solve_marg_query,),
    )

    def solve(solvers):
        nl = NeurolangPDL(**solvers)
        nl.add_probabilistic_facts_from_tuples([
            (.3, 1, "g1", "PD"), (.6, 2, "g1", "AD"), (.5, 1, "g2", "AD"),
            (.4, 2, "g2", "PD"), (.7, 3, "g3", "AD"), (.2, 1, "g1", "AD"),
            (.45, 1, "g3", "PD"),
        ], name="test_evidence")
        nl.add_tuple_set([
            ("Tirofiban Hydrochloride", "g1"),
            ("Tirofiban Hydrochloride", "g2"),
            ("Aspirin", "g3"), ("Aspirin", "g2"),
        ], name="drug_target")
        return [p for p, in nl.execute_datalog_program(program)]

    assert solve(LIFTED_ONLY) == pytest.approx(solve(wmc))
