from pytest import raises

from operator import eq
import typing

import numpy as np

from nl_expr.exceptions import SymbolNotFoundError
from nl_expr.expression_walker import (
    ExpressionBasicEvaluator,
    ExpressionWalker,
)
from nl_expr.expressions import Constant, ExpressionBlock, Symbol
from nl_expr.logic import (
    ExistentialPredicate,
    Implication,
    Negation,
    Conjunction,
    Union,
)
from .. import DatalogProgram, Fact
from ..expression_processing import (
    TranslateToDatalogSemantics,
    is_conjunctive_expression,
    is_conjunctive_expression_with_nested_predicates,
    dependency_matrix,
    stratify, reachable_code, is_linear_rule,
    implication_has_existential_variable_in_antecedent,
    is_ground_predicate,
    extract_logic_free_variables,
    extract_logic_predicates,
    conjunct_if_needed,
    conjunct_formulas,
    program_has_loops,
    is_rule_with_builtin,
    HeadConstantToBodyEquality,
    HeadRepeatedVariableToBodyEquality,
    maybe_deconjunct_single_pred,
    is_to_be_sorted_equality,
)
from ..instance import MapInstance


S_ = Symbol
C_ = Constant
Imp_ = Implication
B_ = ExpressionBlock
EP_ = ExistentialPredicate
T_ = Fact

EQ = Constant(eq)


DT = TranslateToDatalogSemantics()


def test_conjunctive_expression():
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    x = S_('x')
    y = S_('y')

    assert is_conjunctive_expression(
        Q()
    )

    assert is_conjunctive_expression(
        Q(x)
    )

    assert is_conjunctive_expression(
        DT.walk(Q(x) & R(y, C_(1)))
    )

    assert not is_conjunctive_expression(
        DT.walk(R(x) | R(y))
    )

    assert not is_conjunctive_expression(
        DT.walk(R(x) & R(y) | R(x))
    )

    assert not is_conjunctive_expression(
        DT.walk(~R(x))
    )

    assert not is_conjunctive_expression(
        R(Q(x))
    )


def test_conjunctive_expression_with_nested():
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    x = S_('x')
    y = S_('y')

    assert is_conjunctive_expression_with_nested_predicates(
        Q()
    )

    assert is_conjunctive_expression_with_nested_predicates(
        Q(x)
    )

    assert is_conjunctive_expression_with_nested_predicates(
        Q(x) & R(y, C_(1))
    )

    assert is_conjunctive_expression_with_nested_predicates(
        Q(x) & R(Q(y), C_(1))
    )

    assert not is_conjunctive_expression_with_nested_predicates(
        R(x) | R(y)
    )

    assert not is_conjunctive_expression_with_nested_predicates(
        R(x) & R(y) | R(x)
    )

    assert not is_conjunctive_expression_with_nested_predicates(
        ~R(x)
    )


def test_extract_free_variables():
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    x = S_('x')
    y = S_('y')

    emptyset = set()
    assert extract_logic_free_variables(Q()) == emptyset
    assert extract_logic_free_variables(Q(C_(1))) == emptyset
    assert extract_logic_free_variables(x) == {x}
    assert extract_logic_free_variables(Q(x, y)) == {x, y}
    assert extract_logic_free_variables(Q(x, C_(1))) == {x}
    assert extract_logic_free_variables(Q(x) & R(y)) == {x, y}
    assert extract_logic_free_variables(EP_(x, Q(x, y))) == {y}
    assert extract_logic_free_variables(Imp_(R(x), Q(x, y))) == {y}
    assert extract_logic_free_variables(Imp_(R(x), Q(y) & Q(x))) == {y}
    assert extract_logic_free_variables(Q(R(y))) == {y}
    assert extract_logic_free_variables(Q(x) | R(y)) == {x, y}
    assert extract_logic_free_variables(~(R(y))) == {y}
    assert extract_logic_free_variables(B_([Q(x), R(y)])) == {x, y}


def test_extract_datalog_predicates():
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    x = S_('x')
    y = S_('y')

    assert extract_logic_predicates(C_(1)) == set()
    assert extract_logic_predicates(Q) == set()

    expression = Q(x)
    assert extract_logic_predicates(expression) == {Q(x)}

    expression = DT.walk(Q(x) & R(y))
    assert extract_logic_predicates(expression) == {Q(x), R(y)}

    expression = DT.walk(B_([Q(x), Q(y) & R(y)]))
    assert extract_logic_predicates(expression) == {Q(x), Q(y), R(y)}

    expression = DT.walk(B_([Q(x), Q(y) & ~R(y)]))
    assert extract_logic_predicates(expression) == {
        Q(x), Q(y), Negation(R(y))
    }


def test_is_linear_rule():
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    x = S_('x')
    y = S_('y')

    assert is_linear_rule(T_(Q(C_(1))))
    assert is_linear_rule(T_(Q(C_(x))))
    assert is_linear_rule(Imp_(Q(x), R(x, y)))
    assert is_linear_rule(Imp_(Q(x), Q(x)))
    assert is_linear_rule(DT.walk(Imp_(Q(x), R(x, y) & Q(x))))
    assert is_linear_rule(DT.walk(Imp_(Q(x), R(x, y) & ~Q(x))))
    assert not is_linear_rule(DT.walk(Imp_(Q(x), R(x, y) & Q(x) & Q(y))))
    assert not is_linear_rule(DT.walk(Imp_(Q(x), R(x, y) & Q(x) & ~Q(y))))


class Datalog(
    DatalogProgram,
    ExpressionBasicEvaluator
):
    pass


def test_stratification():
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    S = S_('S')  # noqa: N806
    T = S_('T')  # noqa: N806
    x = S_('x')
    y = S_('y')

    code = DT.walk(B_([
        T_(Q(C_(1), C_(2))),
        Imp_(R(x, y), Q(x, y)),
        Imp_(R(x, y), Q(y, x)),
        Imp_(S(x), R(x, y) & S(y))
    ]))

    datalog = Datalog()
    datalog.walk(code)

    strata, stratifyiable = stratify(code, datalog)

    assert stratifyiable
    assert strata == [
        list(code.formulas[:1]),
        list(code.formulas[1: 3]),
        list(code.formulas[3:])
    ]

    code = DT.walk(B_([
        Imp_(Q(x, y), C_(eq)(x, y)),
        Imp_(R(x, y), Q(x, y)),
        Imp_(R(x, y), Q(y, x)),
        Imp_(S(x), R(x, y) & T(y)),
        Imp_(T(x), R(x, y) & S(x))
    ]))

    datalog = Datalog()
    datalog.walk(code)

    strata, stratifyiable = stratify(code, datalog)

    assert not stratifyiable
    assert strata == [
        list(code.formulas[:1]),
        list(code.formulas[1: 3]),
        list(code.formulas[3:])
    ]



def test_stratification_after_mutual_recursion():
    """
    The rules of a mutually recursive component form a stratum, before
    the rules depending on it, e.g. an aggregation, which a chase cannot
    solve in the stratum of a recursion.
    """
    E = S_('E')  # noqa: N806
    R = S_('R')  # noqa: N806
    S = S_('S')  # noqa: N806
    U = S_('U')  # noqa: N806
    x = S_('x')
    y = S_('y')

    code = DT.walk(B_([
        Imp_(R(x), E(x, y) & S(y)),
        Imp_(S(x), R(x)),
        Imp_(S(x), E(x, x)),
        Imp_(U(x), S(x) & R(x)),
    ]))

    datalog = Datalog()
    datalog.walk(code)
    datalog.add_extensional_predicate_from_tuples(E, {(1, 1)})

    strata, stratifyiable = stratify(code, datalog)

    assert not stratifyiable
    assert strata == [
        [code.formulas[2]],
        list(code.formulas[:2]),
        list(code.formulas[3:]),
    ]


def test_stratification_defers_rules_on_deferred_heads():
    """
    A rule whose body predicate has a rule left for a later stratum is
    left for it too: here S, whose body P has the rule P(x) :- C(x)
    waiting for C(x) :- S(x), is solved with P and C, before U.
    """
    E = S_('E')  # noqa: N806
    C = S_('C')  # noqa: N806
    P = S_('P')  # noqa: N806
    S = S_('S')  # noqa: N806
    U = S_('U')  # noqa: N806
    x = S_('x')

    code = DT.walk(B_([
        Imp_(P(x), E(x)),
        Imp_(C(x), E(x)),
        Imp_(P(x), C(x)),
        Imp_(C(x), S(x)),
        Imp_(S(x), P(x)),
        Imp_(U(x), S(x)),
    ]))

    datalog = Datalog()
    datalog.walk(code)
    datalog.add_extensional_predicate_from_tuples(E, {(1,)})

    strata, _ = stratify(code, datalog)

    assert [set(stratum) for stratum in strata] == [
        set(code.formulas[:2]),
        set(code.formulas[2:5]),
        {code.formulas[5]},
    ]


def test_stratification_with_consequent_in_multiple_rules():
    x = S_('X')
    y = S_('Y')
    z = S_('Z')
    anc = S_('anc')
    par = S_('par')
    q = S_('q')
    M = S_('M')
    N = S_('N')
    O = S_('O')
    a = C_('a')
    b = C_('b')
    c = C_('c')
    d = C_('d')

    code = DT.walk(B_([
        Fact(par(a, b)),
        Fact(par(b, c)),
        Fact(par(c, d)),
        Fact(M(a)),
        Imp_(N(a), M(a)),
        Imp_(anc(x, y), par(x, y)),
        Imp_(O(x), N(x)),
        Imp_(q(x), anc(a, x)),
        Imp_(anc(x, y), anc(x, z) & par(z, y) & O(a)),
    ]))

    datalog = Datalog()
    datalog.walk(code)

    strata, stratifyiable = stratify(code, datalog)

    assert stratifyiable
    assert strata == [
        list(code.formulas[:4]),
        list(code.formulas[4:6]),
        list((code.formulas[6],)),
        list(code.formulas[7:]),
    ]


def test_reachable():
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    S = S_('S')  # noqa: N806
    T = S_('T')  # noqa: N806
    x = S_('x')
    y = S_('y')

    code = DT.walk(B_([
        Imp_(R(x, y), Q(x, y)),
        Imp_(R(x, y), Q(y, x)),
        Imp_(S(x), R(x, y) & S(y)),
        Imp_(T(x), Q(x, y)),
    ]))

    datalog = Datalog()
    datalog.walk(code)

    reached = reachable_code(code.formulas[-2], datalog)

    assert set(reached.formulas) == set(code.formulas[:-1])


def test_dependency_matrix():
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    S = S_('S')  # noqa: N806
    T = S_('T')  # noqa: N806
    x = S_('x')
    y = S_('y')

    code = DT.walk(B_([
        Fact(Q(C_(0), C_(1))),
        Imp_(R(x, y), Q(x, y)),
        Imp_(R(x, y), T(y, x)),
        Imp_(S(x), R(x, y) & S(y) & C_(eq)(x, y)),
        Imp_(T(x), Q(x, y)),
    ]))

    datalog = Datalog()
    datalog.walk(code)

    idb_symbols, dep_matrix = dependency_matrix(datalog)

    assert idb_symbols == (R, S, T)
    assert np.array_equiv(dep_matrix, np.array(
        [
            [0, 0, 1],
            [1, 1, 0],
            [0, 0, 0]
        ]
    ))

    rules = Union(
        datalog.intensional_database()[R].formulas +
        datalog.intensional_database()[T].formulas
    )

    idb_symbols_2, dep_matrix_2 = dependency_matrix(
       datalog, rules=rules
    )

    assert idb_symbols_2 == (R, T)
    assert np.array_equiv(dep_matrix[(0, 2), :][:, (0, 2)], dep_matrix_2)

    code = DT.walk(B_([
        Fact(Q(C_(0), C_(1))),
        Imp_(R(x, y), Q(x, y)),
        Imp_(R(x, y), T(y, x)),
        Imp_(S(x), R(x, y) & S_('X')(y) & C_(eq)(x, y)),
        Imp_(T(x), Q(x, y)),
    ]))

    datalog = Datalog()
    datalog.walk(code)

    with raises(SymbolNotFoundError):
        dependency_matrix(datalog)


def test_dependency_matrix_with_instance_update():
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    S = S_('S')  # noqa: N806
    T = S_('T')  # noqa: N806
    x = S_('x')
    y = S_('y')
    z = S_('z')

    code = DT.walk(B_([
        Fact(Q(C_(0), C_(1))),
        Imp_(R(x, y), Q(x, y)),
        Imp_(R(x, y), T(y, x)),
        Imp_(S(x), R(x, y) & S_('X')(y) & C_(eq)(x, y)),
        Imp_(T(x), Q(x, y)),
    ]))

    datalog = Datalog()
    datalog.walk(code)

    # Assume X was solved in previous stratum of program
    instance = MapInstance({S_('X'): datalog.new_set([(0,)])})
    idb_symbols, dep_matrix = dependency_matrix(
        datalog, instance=instance
    )
    assert idb_symbols == (R, S, T)
    assert np.array_equiv(dep_matrix, np.array(
        [
            [0, 0, 1],
            [1, 0, 0],
            [0, 0, 0]
        ]
    ))

    code = DT.walk(B_([
        Imp_(R(x, y), R(x, z) & Q(z, y)),
        Imp_(S(x), R(C_(0), x)),
    ]))
    datalog = Datalog()
    datalog.walk(code)

    instance = MapInstance({
        Q: datalog.new_set([(0, 1), (1, 2), (2, 3)]),
        R: datalog.new_set([(0, 1), (1, 2), (2, 3)])
    })
    idb_symbols, dep_matrix = dependency_matrix(
        datalog, instance=instance
    )
    assert idb_symbols == (R, S)
    assert np.array_equiv(dep_matrix, np.array(
        [
            [1, 0],
            [1, 0],
        ]
    ))


def test_program_has_loops():
    Q = S_('Q')  # noqa: N806
    R = S_('R')  # noqa: N806
    S = S_('S')  # noqa: N806
    T = S_('T')  # noqa: N806
    x = S_('x')
    y = S_('y')

    code = DT.walk(B_([
        Fact(Q(C_(0), C_(1))),
        Imp_(R(x, y), Q(x, y) & S(x)),
        Imp_(R(x, y), T(y, x)),
        Imp_(S(x), R(x, y) & C_(eq)(x, y)),
        Imp_(T(x, y), Q(x, y)),
    ]))

    datalog = Datalog()
    datalog.walk(code)

    assert program_has_loops(datalog)

    code = DT.walk(B_([
        Fact(Q(C_(0), C_(1))),
        Imp_(R(x, y), Q(x, y)),
        Imp_(R(x, x), T(x, x)),
        Imp_(S(x), R(x, y) & C_(eq)(x, y)),
        Imp_(T(x), Q(x, x))
    ]))

    datalog = Datalog()
    datalog.walk(code)

    assert not program_has_loops(datalog)


def test_implication_has_existential_variable_in_antecedent():
    Q = S_('Q')
    R = S_('R')
    x = S_('x')
    y = S_('y')
    assert implication_has_existential_variable_in_antecedent(
        Implication(Q(x), R(x, y)),
    )
    assert not implication_has_existential_variable_in_antecedent(
        Implication(Q(x), R(x)),
    )


def test_is_ground_predicate():
    P = S_("P")
    x = S_("x")
    a = C_("a")
    assert not is_ground_predicate(P(x))
    assert is_ground_predicate(P(a))


def test_conjunct_if_needed():
    P = S_("P")
    Q = S_("Q")
    x = S_("x")
    predicates = (P(x),)
    assert conjunct_if_needed(predicates) == P(x)
    predicates = (P(x), Q(x))
    assert conjunct_if_needed(predicates) == Conjunction(predicates)


def test_conjunct_formulas():
    P = S_("P")
    Q = S_("Q")
    x = S_("x")
    y = S_("y")
    f1 = Conjunction((P(x), Q(x, x)))
    f2 = Conjunction((Q(x, y), Q(y, y)))
    assert conjunct_formulas(f1, f2) == Conjunction(
        (P(x), Q(x, x), Q(x, y), Q(y, y))
    )
    assert conjunct_formulas(P(x), Q(x)) == Conjunction((P(x), Q(x)))



def test_is_rule_with_builtin():
    P = Symbol("P")
    Q = Symbol("Q")
    x = Symbol("x")
    y = Symbol("y")
    some_builtin = Constant(eq)
    rule = Implication(P(x), Conjunction((some_builtin(x, y), Q(x), Q(y))))
    assert is_rule_with_builtin(rule)
    rule = Implication(Q(x), P(x))
    assert not is_rule_with_builtin(rule)
    dl = Datalog()
    some_builtin = Symbol[typing.Callable[[int, int], str]]("some_builtin")
    my_builtin_fun = lambda u, v: str(u + v)
    dl.symbol_table[some_builtin] = Constant[typing.Callable[[int, int], str]](
        my_builtin_fun, auto_infer_type=False, verify_type=False,
    )
    rule = Implication(Q(x), some_builtin(x, y))
    assert is_rule_with_builtin(rule, known_builtins=dl.builtins())


class TestHeadConstantToBodyEquality(
    HeadConstantToBodyEquality,
    ExpressionWalker
):
    pass


class TestHeadRepeatedVariableToBodyEquality(
    HeadRepeatedVariableToBodyEquality,
    ExpressionWalker
):
    pass


def test_head_constant_to_body_equality():
    P = Symbol("P")
    Q = Symbol("Q")
    x = Symbol("x")
    a = Constant("a")
    walker = TestHeadConstantToBodyEquality()
    rule = Implication(P(x, a), Q(x))
    result = walker.walk(rule)
    assert result.consequent.args[1].is_fresh
    assert EQ(result.consequent.args[1], a) in result.antecedent.formulas


def test_head_repeated_variable_to_body_equality():
    P = Symbol("P")
    Q = Symbol("Q")
    x = Symbol("x")
    walker = TestHeadRepeatedVariableToBodyEquality()
    rule = Implication(P(x, x), Q(x))
    result = walker.walk(rule)
    assert result.consequent.args[1].is_fresh
    assert EQ(result.consequent.args[1], x) in result.antecedent.formulas



def test_maybe_deconjunct():
    P = Symbol("P")
    Q = Symbol("Q")
    x = Symbol("x")
    assert maybe_deconjunct_single_pred(Conjunction(tuple())) == Conjunction(
        tuple()
    )
    assert maybe_deconjunct_single_pred(
        Conjunction((P(x), Q(x)))
    ) == Conjunction((P(x), Q(x)))
    assert maybe_deconjunct_single_pred(Conjunction((P(x),))) == P(x)


def test_is_to_be_sorted_equality_with_unknown_type():
    """
    Regression test for GH-821: is_to_be_sorted_equality should return False
    (not raise ValueError) when the functor has an uninferred/Unknown type
    that causes is_leq_informative to raise ValueError internally.
    """
    from nl_expr.type_system import Unknown

    # Create a functor with Callable[..., Unknown] type — this happens when a
    # function's signature cannot be inspected (infer_type_builtins fallback).
    # Comparing such a type via is_leq_informative raises ValueError because
    # Ellipsis is not a valid type according to is_type().
    functor_with_uninferred_type = Constant[typing.Callable[..., Unknown]](
        eq, auto_infer_type=False
    )
    x = S_("x")
    y = S_[str]("y")
    formula = functor_with_uninferred_type(x, y)

    # Should return False without raising ValueError
    assert not is_to_be_sorted_equality(formula)
