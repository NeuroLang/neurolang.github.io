"""
Utilities to process intermediate representations of
Datalog programs.
"""


import collections
import operator
import typing
from typing import Iterable

import numpy as np
from scipy import sparse

from nl_expr.exceptions import (
    RuleNotFoundError,
    SymbolNotFoundError,
    UnsupportedProgramError,
)
from nl_expr.expression_pattern_matching import (
    NeuroLangPatternMatchingNoMatch,
    add_match,
)
from nl_expr.expression_walker import (
    ExpressionWalker,
    PatternWalker,
    ReplaceExpressionWalker,
    ReplaceSymbolWalker,
)
from nl_expr.expressions import (
    Constant,
    Expression,
    FunctionApplication,
    Symbol,
)
from nl_expr.logic import (
    ExistentialPredicate,
    FALSE,
    TRUE,
    Conjunction,
    Disjunction,
    Implication,
    Negation,
    Quantifier,
    Union,
)
from nl_expr.logic import expression_processing as elp
from nl_expr.logic.transformations import (
    CollapseConjunctions,
    ExtractBoundVariables,
    GuaranteeConjunction,
    LogicExpressionWalker,
    RemoveTrivialOperations,
)
from nl_expr.logic.unification import most_general_unifier
from nl_expr.utils.orderedset import OrderedSet
from .exceptions import AggregatedVariableReplacedByConstantError
from .expressions import AggregationApplication, TranslateToLogic

EQ = Constant(operator.eq)


class TranslateToDatalogSemantics(TranslateToLogic, ExpressionWalker):
    pass


def implication_has_existential_variable_in_antecedent(implication):
    """
    Whether an implication has at least one existential variable in its
    antecedent.
    """
    c_free_vars = set(extract_logic_free_variables(implication.consequent))
    a_free_vars = set(extract_logic_free_variables(implication.antecedent))
    return a_free_vars > c_free_vars


def is_conjunctive_expression(expression):
    if isinstance(expression, Conjunction):
        formulas = expression.formulas
    else:
        formulas = [expression]

    return all(
        expression == Constant(True)
        or expression == Constant(False)
        or (
            isinstance(expression, FunctionApplication)
            and not any(
                isinstance(arg, FunctionApplication) for arg in expression.args
            )
        )
        for expression in formulas
    )


def is_conjunctive_expression_with_nested_predicates(expression):
    tr = TranslateToDatalogSemantics()
    expression = tr.walk(expression)
    stack = [expression]
    while stack:
        exp = stack.pop()
        if exp == Constant(True) or exp == Constant(False):
            pass
        elif isinstance(exp, FunctionApplication):
            stack += [
                arg for arg in exp.args if isinstance(arg, FunctionApplication)
            ]
        elif isinstance(exp, Conjunction):
            stack += exp.formulas
        elif isinstance(exp, Quantifier):
            stack.append(exp.body)
        else:
            return False

    return True


def is_linear_rule(rule):
    """Check if a rule is linear

    Parameters
    ----------
    rule : Implication
        rule to analyse

    Returns
    -------
    bool
        True if the rule is linear

    """
    predicates = extract_logic_predicates(rule.antecedent)
    return (
        sum(
            int(
                (predicate.formula.functor == rule.consequent.functor)
                if isinstance(predicate, Negation)
                else predicate.functor == rule.consequent.functor
            )
            for predicate in predicates
        )
        < 2
    )


def all_body_preds_in_set(implication, predicate_set):
    """Checks whether all predicates in the antecedent
    are in the functor_set or are the consequent functor.

    Parameters
    ----------
    implication :
        Implication
    predicate_set :
        set or functors of the consequent

    Returns
    -------
    bool
        True is all predicates in the antecedent are
        in the prediacte_set

    """
    preds = (e.functor for e in extract_logic_atoms(implication.antecedent))
    predicate_set = predicate_set | {implication.consequent.functor}
    return all(not isinstance(e, Symbol) or e in predicate_set for e in preds)


def any_body_preds_in_set(implication, predicate_set):
    """Checks whether any predicates in the antecedent
    are in the predicate_set.

    Parameters
    ----------
    implication :
        Implication
    predicate_set :
        set of functors

    Returns
    -------
    bool
        True is any predicates in the antecedent are
        in the predicate_set

    """
    preds = (e.functor for e in extract_logic_atoms(implication.antecedent))
    return any(e in predicate_set for e in preds)


def extract_logic_free_variables(expression):
    """Extract variables from expression assuming it's in datalog format.

    Parameters
    ----------
    expression : Expression


    Returns
    -------
        OrderedSet
            set of all free variables in the expression.
    """
    translator = TranslateToDatalogSemantics()
    datalog_code = translator.walk(expression)
    return elp.extract_logic_free_variables(datalog_code)


def extract_logic_predicates(expression):
    """Extract predicates from expression
    knowing that it's in Datalog format

    Parameters
    ----------
    expression : Expression
        expression to extract predicates from


    Returns
    -------
    OrderedSet
        set of all predicates in the expression in lexicographical
        order.

    """
    return elp.extract_logic_predicates(expression)


def extract_logic_atoms(expression):
    """Extract atoms from expression
    knowing that it's in Datalog format

    Parameters
    ----------
    expression : Expression
        expression to extract atoms from


    Returns
    -------
    OrderedSet
        set of all predicates in the atoms in lexicographical
        order.

    """
    return elp.extract_logic_atoms(expression)


def stratify(union, datalog_instance):
    """Given an expression block containing `Implication` instances
     and a datalog instance, return the stratification of the formulas
     in the block as a list of lists..

    Parameters
    ----------
    union : Union
        union of implications to be stratified.

    datalog_instance : DatalogProgram
        Datalog instance containing the EDB and IDB databases


    Returns
    -------
        list of lists of `Implications`, boolean
            Strata and whether it was stratisfiable.
            If it was not, all non-stratified predicates
            will be in the last strata.

    """
    strata = []
    seen = set(k for k in datalog_instance.extensional_database().keys())
    seen |= set(k for k in datalog_instance.builtins())
    to_process = union.formulas
    stratifiable = True

    stratum, new_to_process = stratify_obtain_facts_stratum(to_process, seen)

    if len(stratum) > 0:
        strata.append(stratum)
    to_process = new_to_process

    while len(to_process) > 0:
        new_seen, new_to_process, stratum = stratify_obtain_new_stratum(
            to_process, seen
        )
        to_process = new_to_process
        if len(new_seen) == 0:
            stratifiable = False
            stratum, to_process = stratify_obtain_recursive_stratum(
                to_process, seen
            )
            new_seen = {r.consequent.functor for r in stratum}
        strata.append(stratum)
        seen |= new_seen

    return strata, stratifiable


def stratify_obtain_facts_stratum(to_process, seen):
    new_to_process = []
    stratum = []
    true_ = Constant(True)
    for r in to_process:
        if r.antecedent == true_:
            stratum.append(r)
            seen.add(r.consequent.functor)
        else:
            new_to_process.append(r)
    return stratum, new_to_process


def stratify_obtain_recursive_stratum(to_process, seen):
    """
    The rules of a recursive component of *to_process* whose other body
    predicates are in *seen*, as a stratum, and the rules left to
    process. The rules depending on the component are left for later
    strata. Without such a component, every rule of *to_process* is in
    the stratum.
    """
    for component in _recursive_components(to_process):
        rules = [r for r in to_process if r.consequent.functor in component]
        if all(all_body_preds_in_set(r, seen | component) for r in rules):
            rest = [r for r in to_process if r not in rules]
            return rules, rest
    return list(to_process), []


def _recursive_components(rules):
    """The sets of the predicates defined by *rules* which depend on
    each other, by the order of their first rule."""
    heads = {r.consequent.functor for r in rules}
    depends_on = {head: set() for head in heads}
    for r in rules:
        depends_on[r.consequent.functor] |= _body_predicates(r) & heads
    reachable = _reachable_predicates(depends_on)
    for head in dict.fromkeys(r.consequent.functor for r in rules):
        yield {
            other for other in reachable[head] | {head}
            if head in reachable[other] | {other}
        }


def _body_predicates(implication):
    return {
        atom.functor for atom in extract_logic_atoms(implication.antecedent)
    }


def _reachable_predicates(depends_on):
    """The predicates each predicate of *depends_on* depends on, through
    the dependencies of *depends_on*."""
    reachable = {}
    for head in depends_on:
        pending, found = list(depends_on[head]), set()
        while pending:
            predicate = pending.pop()
            if predicate not in found:
                found.add(predicate)
                pending += depends_on.get(predicate, ())
        reachable[head] = found
    return reachable


def stratify_obtain_new_stratum(to_process, seen):
    # 1. add all the rule for which we've seen the body predicates
    temp_stratum = []
    new_to_process = []
    for r in to_process:
        if all_body_preds_in_set(r, seen):
            temp_stratum.append(r)

        else:
            new_to_process.append(r)

    # 2. remove all the rules which have body predicates that will be updated
    # by rules in later strata, those removed included.
    will_see_later = {r.consequent.functor for r in new_to_process}
    stratum, later = temp_stratum, True
    while later:
        later = [
            r for r in stratum if any_body_preds_in_set(r, will_see_later)
        ]
        stratum = [
            r for r in stratum if not any_body_preds_in_set(r, will_see_later)
        ]
        new_to_process = later[::-1] + new_to_process
        will_see_later |= {r.consequent.functor for r in later}
    new_seen = {r.consequent.functor for r in stratum}

    return new_seen, new_to_process, stratum


def reachable_code(query, datalog):
    """Produces the code reachable by a query

    Parameters
    ----------
    query : Implication
        Rule to figure out the reachable program from
    datalog : DatalogProgram
        datalog instance containing the EDB and IDB.

    Returns
    -------
    ExpressionBlock
        Code needed to solve the query.
    """
    if not isinstance(query, Iterable):
        query = [query]

    reachable_code = []
    idb = datalog.intensional_database()
    to_reach = [q.consequent.functor for q in query]
    reached = set()
    seen_rules = set()
    while to_reach:
        p = to_reach.pop()
        reached.add(p)
        rules = idb[p]
        if isinstance(rules, Constant):
            continue
        for rule in rules.formulas:
            seen_rules.add(rule)
            reachable_code.append(rule)
            for predicate in extract_logic_atoms(rule.antecedent):
                functor = predicate.functor
                if functor not in reached and functor in idb:
                    to_reach.append(functor)

    return Union(reachable_code[::-1])


def dependency_matrix(datalog, rules=None, instance=None):
    """Produces the dependency matrix for a datalog's
    instance intentional database (IDB).

    Parameters
    ----------
    datalog : DatalogProgram
        datalog instance containing the EDB and IDB.
    rules : None or Union of rules
        an optional subset of rules from the datalog
        program's IDB.
    instance: Instance
        an optional instance, meant to represent the current
        DatalogProgram resolution, and whose's symbols won't raise
        a SymbolNotFoundError if found as a dependency in the given
        rules.

    Returns
    -------
    idb_symbols: list
        A list of IDB symbols
        in the dependency matrix.
    dependency_matrix: ndarray
        The dependency matrix
        where row is the origin symbol and column is the
        dependency. It is the adjacency matrix of the
        graph where each node is a predicate of the IDB.

    Raises
    ------
    SymbolNotFoundError
        If there is a predicate in the antecedent of a rule which
        is not a constant or an extensional/intentional predicate.

    """
    idb = datalog.intensional_database()
    if rules is None:
        to_reach = []
        for rule_union in idb.values():
            to_reach += rule_union.formulas
        idb_symbols = idb.keys()
    else:
        if isinstance(rules, Union):
            to_reach = list(rules.formulas)
        else:
            to_reach = list(rules)
        idb_symbols = set()
        for rule in to_reach:
            functor = rule.consequent.functor
            if rule not in idb[functor].formulas:
                raise RuleNotFoundError(
                    f"Rule {rule} not contained in the datalog " "instance."
                )
            idb_symbols.add(functor)

    idb_symbols = tuple(sorted(idb_symbols, key=lambda s: s.name))
    edb = datalog.extensional_database()
    previous_symbols = set()
    if instance is not None:
        previous_symbols = instance.as_map().keys()
    if hasattr(datalog, "constraints"):
        constraint_symbols = set(
            formula.consequent.functor
            for formula in datalog.constraints().formulas
        )
        existential_symbols = set(
            rule.functor for rule in datalog.existential_rules.keys()
        )
    else:
        constraint_symbols = set()
        existential_symbols = set()

    dependency_matrix = np.zeros(
        (len(idb_symbols), len(idb_symbols)), dtype=int
    )

    while to_reach:
        rule = to_reach.pop()
        head_functor = rule.consequent.functor
        ix_head = idb_symbols.index(head_functor)
        for predicate in extract_logic_atoms(rule.antecedent):
            functor = predicate.functor
            if (
                functor in edb or functor in constraint_symbols
                or functor in existential_symbols
            ):
                continue
            elif functor in idb_symbols:
                ix_functor = idb_symbols.index(functor)
                dependency_matrix[ix_head, ix_functor] += 1
            elif (
                isinstance(functor, Symbol)
                and functor not in previous_symbols
                and (
                    functor not in datalog.symbol_table
                    or functor in datalog.intensional_database()
                )
            ):
                raise SymbolNotFoundError(f"Symbol not found {functor.name}")

    return idb_symbols, dependency_matrix


def program_has_loops(program_representation):
    if not isinstance(program_representation, np.ndarray):
        _, program_representation = dependency_matrix(program_representation)
    program_representation = sparse.csr_matrix(program_representation)
    reachable = program_representation
    for _ in range(program_representation.shape[0]):
        if any(reachable.diagonal()):
            return True
        else:
            reachable = np.dot(reachable, program_representation)

    return False


def conjunct_if_needed(formulas):
    """
    Only conjunct the given list of formulas if there is more than one. If
    an empty list of formulas is passed, `Constant[bool](True)` is returned
    instead.

    """
    if len(formulas) == 0:
        return TRUE
    if len(formulas) == 1:
        return formulas[0]
    return Conjunction(formulas)


def conjunct_formulas(f1, f2):
    """Conjunct two logical formulas."""
    if isinstance(f1, Conjunction) and isinstance(f2, Conjunction):
        return Conjunction(tuple(f1.formulas) + tuple(f2.formulas))
    elif isinstance(f1, Conjunction):
        return Conjunction(tuple(f1.formulas) + (f2,))
    elif isinstance(f2, Conjunction):
        return Conjunction((f1,) + tuple(f2.formulas))
    else:
        return Conjunction((f1, f2))


def is_ground_predicate(predicate):
    """Whether all the predicate's terms are all constant."""
    return all(isinstance(arg, Constant) for arg in predicate.args)


def order_conjunction_by_shared_variables(
    formulas: typing.Tuple[Expression, ...],
) -> typing.Tuple[Expression, ...]:
    """
    Order flat conjunction atoms to avoid structural cross products.

    Relational algebra plans execute the atoms of a conjunction as a
    left-deep natural join in the order they appear.  Joining two atoms
    that share no variable first materialises their cross product, which
    can be enormous for domains such as ``voxel(x, y, z) x study(s)``.
    Conjunctions commute, so the atoms are reordered (greedy
    nearest-neighbour) so that each atom shares at least one variable
    with the atoms selected so far, keeping intermediate relations as
    small as possible.

    The original order is kept whenever it does not contain a structural
    cross product, so already-efficient conjunctions are left untouched.

    Only flat conjunctions of predicate applications are reordered; any
    other formula (negation, disjunction, nested quantifier, ...) is left
    untouched in its original position.
    """
    if not conjunction_needs_reordering(formulas):
        return formulas
    remaining = list(formulas)
    vars_remaining = [
        extract_logic_free_variables(f) for f in remaining
    ]
    start = max(
        range(len(remaining)), key=lambda i: len(vars_remaining[i])
    )
    ordered = [remaining.pop(start)]
    bound = vars_remaining.pop(start)
    while remaining:
        best = max(
            range(len(remaining)),
            key=lambda i: len(vars_remaining[i] & bound),
        )
        ordered.append(remaining.pop(best))
        bound |= vars_remaining.pop(best)
    return tuple(ordered)


def conjunction_needs_reordering(
    formulas: typing.Tuple[Expression, ...],
) -> bool:
    """
    Whether a flat conjunction requires reordering to avoid a cross product.

    True when some atom's variables share nothing with all the variables
    of the atoms preceding it in the given order, i.e. when a left-deep
    natural join in that order would materialise a structural cross
    product.  Non-flat formulas (negation, disjunction, nested
    quantifier, ...) are never considered for reordering.
    """
    if not all(isinstance(f, FunctionApplication) for f in formulas):
        return False
    bound = set()
    for var_set in (
        extract_logic_free_variables(f) for f in formulas
    ):
        if bound and not var_set & bound:
            return True
        bound |= var_set
    return False


def enforce_conjunctive_antecedent(implication):
    antecedent = GuaranteeConjunction().walk(implication.antecedent)
    return implication.apply(implication.consequent, antecedent)


def maybe_deconjunct_single_pred(expression):
    """
    Remove the conjunction from single-conjunct conjunctions.

    The conjunction remains unchanged if it has multiple conjuncts or if it
    already is a single predicate.

    """
    if isinstance(expression, FunctionApplication):
        return expression
    if len(expression.formulas) == 1:
        return expression.formulas[0]
    return expression


def maybe_disjunct(
    formulas: typing.Iterable[Expression],
) -> typing.Union[Expression, Disjunction]:
    formulas = tuple(formulas)
    if len(formulas) > 1:
        return Disjunction(formulas)
    return formulas[0]


class HeadConstantToBodyEquality(PatternWalker):
    """
    Transform rules whose head (consequent) predicate contains constant terms
    into an equivalent rule where the head predicate only contains variable
    terms and the body (antecedent) of the rule contains variable-to-constant
    equalities. A fresh variable is generated for each constant term in the
    head predicate.

    Examples
    --------
    The rule `Q(x, 2) :- P(x, y)` is transformed into the rule `Q(x, _f_) :-
    P(x, y), _f_ = 2`, where `_f_` is a fresh variable.

    """

    @add_match(
        Implication(FunctionApplication, ...),
        lambda implication: any(
            isinstance(term, Constant) for term in implication.consequent.args
        ),
    )
    def implication_with_constant_term_in_head(self, implication):
        body_formulas = list(
            GuaranteeConjunction().walk(implication.antecedent).formulas
        )
        new_consequent_vars = list()
        for term in implication.consequent.args:
            if isinstance(term, Constant):
                var = Symbol.fresh()
                body_formulas.append(EQ(var, term))
            else:
                var = term
            new_consequent_vars.append(var)
        new_consequent = implication.consequent.functor(*new_consequent_vars)
        new_antecedent = Conjunction(tuple(body_formulas))
        new_antecedent = maybe_deconjunct_single_pred(new_antecedent)
        return self.walk(Implication(new_consequent, new_antecedent))


class HeadRepeatedVariableToBodyEquality(PatternWalker):
    """
    Transform rules whose head (consequent) predicate contains repeated
    variables (symbols) to an equivalent rule without repeated variables and
    corresponding variable equalities. New fresh variables are generated to
    replace variable repetitions.

    Examples
    --------
    The rule `Q(x, x) :- P(x, y)` is transformed into the rule `Q(x, _f_) :-
    P(x, y), _f_ = x`, where `_f_` is a fresh variable.

    """

    @add_match(
        Implication(FunctionApplication, ...),
        lambda implication: (
            len(implication.consequent.args) > 0 and
            max(collections.Counter(
                (
                    arg
                    for arg in implication.consequent.args
                    if isinstance(arg, Symbol)
                )
            ).values()) > 1
        )
    )
    def implication_with_repeated_variable_in_head(self, implication):
        seen_args = set()
        new_csqt_args = list()
        vareq_formulas = list()
        for csqt_arg in implication.consequent.args:
            if isinstance(csqt_arg, Symbol) and csqt_arg in seen_args:
                new_csqt_arg = Symbol.fresh()
                vareq_formulas.append(EQ(new_csqt_arg, csqt_arg))
            else:
                new_csqt_arg = csqt_arg
                seen_args.add(csqt_arg)
            new_csqt_args.append(new_csqt_arg)
        new_consequent = implication.consequent.functor(*new_csqt_args)
        new_antecedent = conjunct_formulas(
            implication.antecedent, Conjunction(tuple(vareq_formulas))
        )
        new_antecedent = maybe_deconjunct_single_pred(new_antecedent)
        return self.walk(Implication(new_consequent, new_antecedent))


class FreshenFreeVariables(PatternWalker):
    @add_match(
        Implication(FunctionApplication, ...),
        lambda implication: any(
            not var.is_fresh
            for var in extract_logic_free_variables(implication)
        ),
    )
    def implication_with_free_variables(self, implication):
        replacements = {
            var: Symbol.fresh()
            for var in extract_logic_free_variables(implication)
        }
        implication = ReplaceExpressionWalker(replacements).walk(implication)
        return self.walk(implication)


def flatten_query(query, program):
    """
    Construct the conjunction corresponding to a query on a program.

    TODO: currently this only handles programs without conjunctions.

    Parameters
    ----------
    query : predicate or conjunction of predicates
        The query for which the conjunction is constructed.
    program : a program with an intentional database
        Program with logical rules that will be used to construct the
        conjunction corresponding to the given query.

    Returns
    -------
    disjunction or conjunction of predicates

    """
    if not hasattr(program, "intensional_database"):
        raise UnsupportedProgramError(
            "Only program with an intentional database are supported"
        )
    try:
        res = FlattenQueryInNonRecursiveUCQ(program).walk(query)
        res = RemoveTrivialOperations().walk(res)
        if not isinstance(res, Constant):
            return GuaranteeConjunction().walk(res)
    except RecursionError:
        raise UnsupportedProgramError(
            "Flattening of recursive programs is not supported."
        )
    except NeuroLangPatternMatchingNoMatch:
        raise UnsupportedProgramError("Expression not supported.")
    return res


class FlattenQueryInNonRecursiveUCQ(PatternWalker):
    """Flatten a query defined by a non-recursive
    union of conjunctive queries (UCQ)
    """

    def __init__(self, program):
        self.program = program
        self.idb = self.program.intensional_database()
        self._rule_normaliser = FlattenQueryInNonRecursiveUCQ._RuleNormaliser()

    class _RuleNormaliser(
        HeadConstantToBodyEquality,
        HeadRepeatedVariableToBodyEquality,
        FreshenFreeVariables,
        ExpressionWalker,
    ):
        pass

    @add_match(
        FunctionApplication(Symbol, ...),
        lambda fa: all(isinstance(arg, (Constant, Symbol)) for arg in fa.args),
    )
    def query_predicate(self, qpred):
        pred_symb = qpred.functor
        if pred_symb not in self.idb:
            return qpred
        ucq = self.idb[pred_symb]
        cqs = []
        for cq in ucq.formulas:
            cq = self._rule_normaliser.walk(cq)
            exp = self._unify_cq_antecedent(cq, qpred)
            if exp != FALSE:
                exp = self.walk(exp)
            cqs.append(exp)
        return maybe_disjunct(cqs)

    @add_match(FunctionApplication(Constant, ...))
    def builtin_application(self, fa):
        return fa

    def _unify_cq_antecedent(self, cq, qpred):
        mgu = most_general_unifier(cq.consequent, qpred)
        # if we cannot unify, this is always a false statement
        if mgu is None:
            return FALSE
        antecedent = ReplaceExpressionWalker(mgu[0]).walk(cq.antecedent)
        if isinstance(
            antecedent, Conjunction
        ) and not self._check_compatibility_symb_to_const_eqs(antecedent):
            return FALSE
        return maybe_deconjunct_single_pred(antecedent)

    @staticmethod
    def _check_compatibility_symb_to_const_eqs(conjunction):
        """
        Statically analyse variable-to-constant equalities within the
        conjunction to check for compatibility. For example, if the two
        conjuncts `x = 2` and `x = 3` are present, this function will return
        `False`. It also handles equalities where the order is `const =
        symbol`, such as `2 = 3, x = 3`.

        """
        symb_to_const = dict()
        symb_to_const_eq_formulas = (
            conjunct
            for conjunct in conjunction.formulas
            if is_symb_to_const_equality(conjunct)
        )
        for equality in symb_to_const_eq_formulas:
            symbol = next(
                arg for arg in equality.args if isinstance(arg, Symbol)
            )
            constant = next(
                arg for arg in equality.args if isinstance(arg, Constant)
            )
            if symbol in symb_to_const:
                return False
            symb_to_const[symbol] = constant
        return True

    @add_match(Conjunction)
    def conjunction(self, expression):
        formulas = collections.deque(expression.formulas)
        new_formulas = tuple()
        while len(formulas) > 0:
            formula = formulas.popleft()
            new_formula = self.walk(formula)
            if isinstance(new_formula, Conjunction):
                new_formulas += new_formula.formulas
            else:
                new_formulas += (new_formula,)
        if len(new_formulas) > 0:
            res = Conjunction(tuple(new_formulas))
        else:
            res = new_formulas[0]
        return res

    @add_match(Negation(FunctionApplication))
    def negation_function_application(self, expression):
        formula = expression.formula
        flattened_formula = self.walk(formula)
        existential_variables = (
            extract_logic_free_variables(flattened_formula) -
            extract_logic_free_variables(formula)
        )
        for e_var in existential_variables:
            flattened_formula = ExistentialPredicate(e_var, flattened_formula)
        return Negation(flattened_formula)

    @add_match(Negation)
    def negation(self, expression):
        return Negation(self.walk(expression.formula))


def is_rule_with_builtin(rule, known_builtins=None):
    if known_builtins is None:
        known_builtins = set()
    return any(
        isinstance(pred.functor, Constant) or pred.functor in known_builtins
        for pred in extract_logic_predicates(rule.antecedent)
    )


def remove_conjunction_duplicates(conjunction):
    return maybe_deconjunct_single_pred(
        Conjunction(tuple(OrderedSet(conjunction.formulas)))
    )


def is_aggregation_rule(rule):
    return is_aggregation_predicate(rule.consequent)


def is_aggregation_predicate(predicate):
    return any(
        isinstance(arg, AggregationApplication) for arg in predicate.args
    )


def is_var_equality_to_var_or_const(formula):
    return (
        isinstance(formula, FunctionApplication)
        and formula.functor == EQ
        and len(formula.args) == 2
        and all(isinstance(arg, (Symbol, Constant)) for arg in formula.args)
        and any(isinstance(arg, Symbol) for arg in formula.args)
    )


def is_symb_to_const_equality(formula):
    return (
        isinstance(formula, FunctionApplication)
        and formula.functor == EQ
        and len(formula.args) == 2
        and any(isinstance(arg, Symbol) for arg in formula.args)
        and any(isinstance(arg, Constant) for arg in formula.args)
    )


class RemoveDuplicatedAntecedentPredicates(PatternWalker):
    @add_match(
        Implication(FunctionApplication, Conjunction),
        lambda implication: any(
            count > 1
            for count in collections.Counter(
                implication.antecedent.formulas
            ).values()
        ),
    )
    def implication_with_duplicated_antecedent_predicate(self, implication):
        return self.walk(
            implication.apply(
                implication.consequent,
                remove_conjunction_duplicates(implication.antecedent),
            )
        )


class UnifyVariableEqualitiesMixin(PatternWalker):
    @add_match(
        Implication(FunctionApplication(Symbol, ...), Disjunction),
        lambda implication: any(
            is_var_equality_to_var_or_const(formula)
            for formula in extract_logic_predicates(implication.antecedent)
        ),
    )
    def unify_var_eqs_in_each_disjunct(self, implication):
        """
        An equality holds in its disjunct only: the variables it makes the
        same are unified in each disjunct of a union apart, rebuilding the
        body as a conjunction of the predicates would turn the union into
        a conjunction. A disjunct whose unification would change the head,
        which every disjunct shares, keeps its equalities.
        """
        disjuncts = []
        for disjunct in implication.antecedent.formulas:
            unified = self.walk(Implication(implication.consequent, disjunct))
            disjuncts.append(
                unified.antecedent
                if unified.consequent == implication.consequent
                else disjunct
            )
        return Implication(
            implication.consequent, Disjunction(tuple(disjuncts))
        )

    @add_match(
        Implication(FunctionApplication(Symbol, ...), ...),
        lambda implication: all(
            isinstance(arg, (Symbol, Constant))
            or (
                isinstance(arg, FunctionApplication)
                and all(isinstance(a, (Symbol, Constant)) for a in arg.args)
            )
            for arg in implication.consequent.args
        )
        and any(
            is_var_equality_to_var_or_const(formula)
            for formula in extract_logic_predicates(implication.antecedent)
        ),
    )
    def extract_and_unify_var_eqs_in_implication(self, implication):
        eq_sets = self.extract_variable_equalities(implication.antecedent)
        substitutions = self.build_substitutions_from_equalities(eq_sets)
        replacer = ReplaceSymbolWalker(substitutions)
        antecedent = Conjunction(
            tuple(
                formula
                for formula in extract_logic_predicates(implication.antecedent)
                if not is_var_equality_to_var_or_const(formula)
            )
        )
        antecedent = replacer.walk(antecedent)
        if len(antecedent.formulas) == 0:
            antecedent = TRUE
        else:
            antecedent = remove_conjunction_duplicates(antecedent)
        consequent = replacer.walk(implication.consequent)
        self._check_no_agg_var_replaced_by_const(
            implication.consequent, consequent
        )
        new_implication = Implication(consequent, antecedent)
        return self.walk(new_implication)

    @staticmethod
    def build_substitutions_from_equalities(eq_sets):
        substitutions = dict()
        for eq_set in eq_sets:
            if any(isinstance(term, Constant) for term in eq_set):
                const = next(
                    term for term in eq_set if isinstance(term, Constant)
                )
                update = {
                    term: const for term in eq_set if isinstance(term, Symbol)
                }
            else:
                chosen_symb = max(eq_set, key=lambda symb: symb.name)
                update = {
                    symb: chosen_symb for symb in eq_set if symb != chosen_symb
                }
            substitutions.update(update)
        return substitutions

    @staticmethod
    def extract_variable_equalities(expression):
        equality_predicates = set(
            predicate
            for predicate in extract_logic_predicates(expression)
            if is_var_equality_to_var_or_const(predicate)
        )
        eq_sets = list()
        for equality_predicate in equality_predicates:
            if all(isinstance(arg, Symbol) for arg in equality_predicate.args):
                UnifyVariableEqualities.add_equality_with_symbol(
                    eq_sets, *equality_predicate.args
                )
            elif isinstance(equality_predicate.args[0], Symbol):
                UnifyVariableEqualities.add_equality_with_constant(
                    eq_sets, *equality_predicate.args
                )
            else:
                UnifyVariableEqualities.add_equality_with_constant(
                    eq_sets, *reversed(equality_predicate.args)
                )
        return eq_sets

    @staticmethod
    def add_equality_with_constant(eq_sets, symb, const):
        found_eq_set = False
        for eq_set in eq_sets:
            if any(term == symb for term in eq_set):
                eq_set.add(const)
                found_eq_set = True
        if not found_eq_set:
            eq_sets.append({symb, const})

    @staticmethod
    def add_equality_with_symbol(eq_sets, first, second):
        found_eq_set = False
        for eq_set in eq_sets:
            if any(term == first for term in eq_set):
                eq_set.add(second)
                found_eq_set = True
            elif any(term == second for term in eq_set):
                eq_set.add(first)
                found_eq_set = True
        if not found_eq_set:
            eq_sets.append({first, second})

    @staticmethod
    def _check_no_agg_var_replaced_by_const(old_csqt, new_csqt) -> None:
        for old_arg, new_arg in zip(old_csqt.args, new_csqt.args):
            if isinstance(old_arg, AggregationApplication) and any(
                isinstance(a1, Symbol) and isinstance(a2, Constant)
                for a1, a2 in zip(old_arg.args, new_arg.args)
            ):
                problematic_replacements = set(
                    (a1, a2)
                    for a1, a2 in zip(old_arg.args, new_arg.args)
                    if isinstance(a1, Symbol) and isinstance(a2, Constant)
                )
                raise AggregatedVariableReplacedByConstantError(
                    "Variable equalities cannot lead to aggregation variables "
                    "to be replaced by a constant. Problematic replacements "
                    "that were found are {}".format(
                        ", ".join(
                            f"{a1} / {a2}"
                            for a1, a2 in problematic_replacements
                        )
                    )
                )


class UnifyVariableEqualities(UnifyVariableEqualitiesMixin, ExpressionWalker):
    pass


class UnifyExistentialVariableEqualitiesMixin(PatternWalker):
    """
    Replace an existentially quantified variable `v` equal to a term `e`,
    by a conjunct `v = e` of the body of its quantifiers, by `e`, as
    ∃v (v = e ∧ φ) ≡ φ[e/v]. Equalities within nested formulas, which
    `UnifyVariableEqualitiesMixin` leaves, are so eliminated. The
    replacement is not done if a variable of `e`, or `v`, is quantified
    within `φ`, where it would be captured.
    """
    @add_match(
        ExistentialPredicate,
        lambda existential: (
            _existential_variable_equality(existential) is not None
        )
    )
    def unify_existential_variable_equality(self, existential):
        variables = []
        body = existential
        while isinstance(body, ExistentialPredicate):
            variables.append(body.head)
            body = body.body
        equality, variable, term = _existential_variable_equality(existential)
        replacer = ReplaceExpressionWalker({variable: term})
        body = Conjunction(tuple(
            replacer.walk(formula) for formula in body.formulas
            if formula is not equality
        ))
        for head in reversed(variables):
            if head != variable:
                body = ExistentialPredicate(head, body)
        return self.walk(body)


def _existential_variable_equality(existential):
    """The first conjunct `v = e` of the body of the quantifiers of
    `existential`, with `v` one of their variables, that can be
    eliminated, as `(equality, v, e)`, or None."""
    variables = set()
    body = existential
    while isinstance(body, ExistentialPredicate):
        variables.add(body.head)
        body = body.body
    if not isinstance(body, Conjunction) or len(body.formulas) < 2:
        return None
    bound = set(ExtractBoundVariables().walk(body))
    for formula in body.formulas:
        if not is_var_equality_to_var_or_const(formula):
            continue
        for variable, term in (formula.args, formula.args[::-1]):
            if (
                variable in variables and variable != term and
                not ({variable, term} & bound)
            ):
                return formula, variable, term
    return None


class UnifyExistentialVariableEqualities(
    UnifyExistentialVariableEqualitiesMixin, LogicExpressionWalker
):
    pass


class CollapseConjunctiveAntecedents(CollapseConjunctions):
    @add_match(
        Implication(FunctionApplication, Conjunction),
        lambda implication: any(
            isinstance(formula, Conjunction)
            for formula in implication.antecedent.formulas
        ),
    )
    def implication_with_collapsable_conjunctive_antecedent(self, implication):
        return self.walk(
            implication.apply(
                implication.consequent, self.walk(implication.antecedent)
            )
        )


def is_to_be_sorted_equality(formula):
    try:
        is_eq_functor = formula.functor == Constant(operator.eq)
    except (ValueError, AttributeError):
        return False
    return (
        is_eq_functor
        and isinstance(formula.args[1], Symbol)
        and not isinstance(formula.args[0], Symbol)
    )


class EqualitySymbolLeftHandSideNormaliseMixin(PatternWalker):
    # Only the top-level conjuncts are rewritten, so only they are
    # checked: an equality within an existential or a negation would
    # otherwise match the rule again and again.
    @add_match(
        Implication(FunctionApplication, Conjunction),
        lambda implication: any(
            is_to_be_sorted_equality(conjunct)
            for conjunct in implication.antecedent.formulas
        ),
    )
    def sort_antecedent_equalities(self, implication):
        new_conjuncts = tuple(
            self.reverse_equality(conjunct)
            if is_to_be_sorted_equality(conjunct)
            else conjunct
            for conjunct in implication.antecedent.formulas
        )
        new_implication = Implication(
            implication.consequent, Conjunction(new_conjuncts)
        )
        return self.walk(new_implication)

    @staticmethod
    def reverse_equality(equality):
        new_type = typing.Callable[
            [equality.args[1].type, equality.args[0].type], bool
        ]
        return Constant[new_type](operator.eq, auto_infer_type=False)(
            *reversed(equality.args)
        )


def is_inlineable_equality(formula):
    """Check if *formula* is ``eq(Symbol, Constant)``.

    This pattern appears in SQUALL queries such as
    ``?x is 'value'`` which the frontend translates to
    ``eq(x, Constant('value'))``.
    """
    try:
        is_eq_functor = formula.functor == Constant(operator.eq)
    except (ValueError, AttributeError):
        return False
    return (
        is_eq_functor
        and isinstance(formula.args[0], Symbol)
        and isinstance(formula.args[1], Constant)
    )


class InlineEqualityConstantsMixin(PatternWalker):
    """Rewrite ``eq(var, Constant)`` atoms in query rules by inlining the
    constant into IDB predicate arguments.

    Magic-sets (SIPS) skips builtin predicates (those whose functor is a
    ``Constant``), so ``eq`` atoms with a constant argument never propagate
    bindings.  This walker transforms::

        h(x, y) :- p(x, y), eq(x, Constant('a'))

    into::

        h(Constant('a'), y) :- p(Constant('a'), y)

    so that magic-sets sees the bound argument in a non-builtin predicate and
    propagates the ``'b'`` adornment.

    Must run *after* `EqualitySymbolLeftHandSideNormaliseMixin` so that all
    equality atoms have the Symbol as the first argument.
    """

    # As for `sort_antecedent_equalities`, only the top-level conjuncts
    # are rewritten and checked.
    @add_match(
        Implication(FunctionApplication, Conjunction),
        lambda implication: any(
            is_inlineable_equality(conjunct)
            for conjunct in implication.antecedent.formulas
        ),
    )
    def inline_equality_constants(self, implication):
        eq_map = {}
        other_formulas = []
        for f in implication.antecedent.formulas:
            if is_inlineable_equality(f):
                eq_map[f.args[0]] = f.args[1]
            else:
                other_formulas.append(f)
        inlined_formulas = []
        for f in other_formulas:
            if isinstance(f, FunctionApplication) and not isinstance(
                f.functor, Constant
            ):
                new_args = tuple(eq_map.get(arg, arg) for arg in f.args)
                if new_args != f.args:
                    f = f.functor(*new_args)
            inlined_formulas.append(f)
        new_body = (
            Conjunction(tuple(inlined_formulas))
            if len(inlined_formulas) > 1
            else inlined_formulas[0]
        )
        new_head_args = tuple(
            eq_map.get(arg, arg) for arg in implication.consequent.args
        )
        new_head = implication.consequent.functor(*new_head_args)
        new_implication = Implication(new_head, new_body)
        return self.walk(new_implication)
