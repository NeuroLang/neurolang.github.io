"""Lifted queries run through the frontend: the solver's tests are in
``neurolang/probabilistic/tests/test_dalvi_suciu_lift.py``."""

import pytest

from nl_core.probabilistic import dalvi_suciu_lift
from nl_core.relational_algebra_provenance import DisjointProjection


@pytest.mark.parametrize("rules, expected", [
    # Disjuncts sharing studies, and disjoint: P[A and B] is 0, left out
    # of the plan of the conjunction.
    ((("language",), ("speech",)), 0.5),
    ((("language",), ("pain",)), 0.75),
    # Three disjuncts: the tail is the disjunction of the two others.
    ((("language",), ("speech",), ("pain",)), 0.75),
    ((("pain",), ("speech",), ("memory",)), 0.75),
    # A conjunctive disjunct.
    ((("language", "speech"), ("pain",)), 0.5),
])
def test_union_of_rules_joining_a_choice(rules, expected):
    """
    A union of rules each joining the probabilistic choice, under PROB,
    crashed: it is lifted by the disjoint separator, one disjoint
    projection on the study.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL()
    nl.add_uniform_probabilistic_choice_over_set(
        [(1,), (2,), (3,), (4,)], name="selected_study"
    )
    nl.add_tuple_set(
        [(1, "language"), (2, "speech"), (2, "language"), (3, "pain"),
         (4, "memory")],
        name="mentions",
    )
    program = "\n".join(
        "a(s) :- " + ", ".join(f"mentions(s, '{t}')" for t in terms)
        + ", selected_study(s)"
        for terms in rules
    ) + "\nans(p) :- PROB[a(s)] = p"
    result = nl.execute_datalog_program(program)
    assert [p for p, in result] == [pytest.approx(expected)]


LIFTED_ONLY = dict(
    probabilistic_solvers=(dalvi_suciu_lift.solve_succ_query,),
    probabilistic_marg_solvers=(dalvi_suciu_lift.solve_marg_query,),
)


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_union_by_term_with_a_variable_of_a_rule_alone(solvers):
    """
    A union whose rules have a variable that their head has not
    (``s2``): the deterministic ``mentions(s2, t)`` is factored out of the
    conjunctive normal form, whose clauses then do not all have ``t``,
    and whose components are not lifted; the disjoint projection lifts
    the union as it is.
    """
    from .. import NeurolangPDL

    mentions = [
        (0, "a"), (0, "c"), (1, "a"), (1, "d"), (1, "e"), (2, "a"),
        (2, "c"), (2, "e"), (3, "a"), (3, "c"), (3, "d"), (4, "b"),
        (5, "b"), (5, "c"), (5, "d"),
    ]
    nl = NeurolangPDL(**solvers)
    nl.add_uniform_probabilistic_choice_over_set(
        [(s,) for s in range(6)], name="selected_study"
    )
    nl.add_tuple_set(mentions, name="mentions")
    result = nl.execute_datalog_program(
        "a(t, s) :- mentions(s, t), selected_study(s)\n"
        "a(t, s) :- mentions(s, 'a'), mentions(s, 'c'), mentions(s2, t), "
        "selected_study(s)\n"
        "a(t, s) :- mentions(s, 'd'), mentions(s2, t), selected_study(s)\n"
        "ans(t, p) :- PROB[a(t, s)] = p"
    )
    m = set(mentions)
    expected = {
        t: sum(
            (s, t) in m or ((s, "a") in m and (s, "c") in m)
            or (s, "d") in m
            for s in range(6)
        ) / 6
        for t in "abcde"
    }
    assert dict(result) == pytest.approx(expected)


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_union_with_a_choice_on_a_free_and_on_a_bound_variable(solvers):
    """
    The choice is on the free variable s in one rule and on a variable of
    its own, f, in the other: the choice optimisation unified C(s) and
    C(f) across the disjuncts, as if they were a conjunction, and the
    first solver gave no answer; the disjuncts are now optimised apart,
    and C(s) is C(f') ∧ f' = s for the disjoint projection.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_uniform_probabilistic_choice_over_set(
        [(1,), (2,), (3,), (4,)], name="selected_study"
    )
    nl.add_tuple_set([(1,), (2,), (3,), (4,)], name="study")
    nl.add_tuple_set(
        [(1, "x"), (2, "y"), (3, "x"), (4, "z")], name="mentions"
    )
    result = nl.execute_datalog_program(
        "a(s) :- selected_study(s), mentions(s, 'x')\n"
        "a(s) :- study(s), selected_study(f), mentions(f, 'y')\n"
        "ans(s, p) :- PROB[a(s)] = p"
    )
    assert dict(result) == pytest.approx({1: 0.5, 2: 0.25, 3: 0.5, 4: 0.25})


def _choice_union_engine():
    from .. import NeurolangPDL

    nl = NeurolangPDL()
    nl.add_uniform_probabilistic_choice_over_set(
        [(1,), (2,), (3,), (4,)], name="selected_study"
    )
    nl.add_tuple_set(
        [(1, "language"), (2, "speech"), (2, "language"), (3, "pain"),
         (4, "memory")],
        name="mentions",
    )
    return nl


def _plan_of(program):
    """The plan of the lifted query of *program*, whose solving is
    stopped once the plan is made."""
    plans = []
    original = dalvi_suciu_lift.is_pure_lifted_plan

    def record(plan):
        plans.append(plan)
        return original(plan)

    dalvi_suciu_lift.is_pure_lifted_plan = record
    try:
        _choice_union_engine().execute_datalog_program(program)
    finally:
        dalvi_suciu_lift.is_pure_lifted_plan = original
    return plans[-1]


def test_union_of_a_self_join_and_a_choice_unrelated_to_the_head():
    """
    The separator declines a union with a rule whose choice is on a
    variable unrelated to the head (the deterministic atom binding the
    head is factored out of the union, leaving a disjunct without it),
    and weighted model counting solves it. The equality that the
    rewriting of the choices leaves between the two choice atoms of the
    self-join was translated to a projection overwriting the column of
    an atom, which the provenance sets reject.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL()
    nl.add_tuple_set(
        [(0, "b"), (0, "c"), (1, "a"), (1, "d")], name="mentions"
    )
    nl.add_uniform_probabilistic_choice_over_set(
        [(0,), (1,)], name="selected_study"
    )
    result = nl.execute_datalog_program(
        "a(t) :- mentions(s, t), selected_study(s).\n"
        "a(t) :- mentions(s, t), selected_study(s), selected_study(f), "
        "mentions(f, 'e').\n"
        "a(t) :- mentions(s, t), selected_study(f), mentions(f, 'e').\n"
        "ans(t, p) :- PROB[a(t)] = p."
    )
    assert dict(result) == pytest.approx(
        {"a": 0.5, "b": 0.5, "c": 0.5, "d": 0.5}
    )


def test_conjunctive_query_with_a_choice_and_a_negation():
    from .. import NeurolangPDL

    nl = NeurolangPDL()
    nl.add_tuple_set(
        [(0, "a"), (0, "b"), (1, "b"), (1, "c"), (2, "a")], name="mentions"
    )
    nl.add_tuple_set([("a",)], name="lang")
    nl.add_uniform_probabilistic_choice_over_set(
        [(0,), (1,), (2,)], name="selected_study"
    )
    result = nl.execute_datalog_program(
        "a(t) :- selected_study(s), mentions(s, t), ~lang(t).\n"
        "ans(t, p) :- PROB[a(t)] = p."
    )
    assert dict(result) == pytest.approx({"b": 2 / 3, "c": 1 / 3})


def test_union_with_a_choice_and_a_negation():
    """
    A union whose rule negates an atom of the study chosen: the negation
    removes the tuples of the studies that have it, which a support that
    kept the probability of the choice in it (a difference of
    probabilities, not of sets) did not.
    """
    from .. import NeurolangPDL

    mentions = {
        0: "deab", 1: "da", 2: "cab", 3: "e", 4: "dcab"
    }
    nl = NeurolangPDL()
    nl.add_tuple_set(
        [(s, t) for s, terms in mentions.items() for t in terms],
        name="mentions",
    )
    nl.add_uniform_probabilistic_choice_over_set(
        [(s,) for s in mentions], name="selected_study"
    )
    result = nl.execute_datalog_program(
        "a(t) :- mentions(s, t), selected_study(s), ~mentions(s, 'a').\n"
        "a(t) :- mentions(s, t), selected_study(s), mentions(s, 'c').\n"
        "ans(t, p) :- PROB[a(t)] = p."
    )
    assert dict(result) == pytest.approx(
        {"a": 0.4, "b": 0.4, "c": 0.4, "d": 0.2, "e": 0.2}
    )


def test_union_with_a_rule_local_variable_and_a_negation():
    """
    A rule with a variable its head has not (``s`` of ``mentions(s, t)``,
    the choice being on ``f``) in a union with a negation. The variables a
    disjunct alone has are projected in the disjunct, so that the branches
    of the union of the deterministic part have the same columns, and the
    projection is a support: it would sum the labels of the tuples it
    merges, and a label above 1 is not one of a set (the union of the
    labels is ``1 - prod(1 - l)``).
    """
    from .. import NeurolangPDL

    mentions = {0: "ab", 1: "bc", 2: "cd"}
    nl = NeurolangPDL()
    nl.add_tuple_set(
        [(s, t) for s, terms in mentions.items() for t in terms],
        name="mentions",
    )
    nl.add_uniform_probabilistic_choice_over_set(
        [(s,) for s in mentions], name="selected_study"
    )
    result = nl.execute_datalog_program(
        "a(t) :- mentions(s, t), selected_study(s), ~mentions(s, 'a').\n"
        "a(t) :- mentions(s, t), selected_study(f), mentions(f, 'c').\n"
        "ans(t, p) :- PROB[a(t)] = p."
    )
    assert dict(result) == pytest.approx(
        {"a": 2 / 3, "b": 2 / 3, "c": 2 / 3, "d": 2 / 3}
    )


def test_union_whose_normal_form_has_an_unsafe_clause():
    """
    The union of a rule with a negation and a rule with a choice unrelated
    to its head: factoring out the atom they share gives the clause
    ``exists s M(s, t) or not L(t)``, which is not safe range and was lifted
    apart (``ValueError``). The conjunctive normal form is not used then.
    """
    from .. import NeurolangPDL

    mentions = {0: "ab", 1: "bc", 2: "cd"}
    nl = NeurolangPDL()
    nl.add_tuple_set(
        [(s, t) for s, terms in mentions.items() for t in terms],
        name="mentions",
    )
    nl.add_tuple_set([("a",)], name="lang")
    nl.add_uniform_probabilistic_choice_over_set(
        [(s,) for s in mentions], name="selected_study"
    )
    result = nl.execute_datalog_program(
        "a(t) :- mentions(s, t), selected_study(s), ~lang(t).\n"
        "a(t) :- mentions(s, t), selected_study(f), mentions(f, 'c').\n"
        "ans(t, p) :- PROB[a(t)] = p."
    )
    assert dict(result) == pytest.approx(
        {"a": 2 / 3, "b": 1.0, "c": 2 / 3, "d": 2 / 3}
    )


def test_union_with_a_self_join_of_the_choice_in_a_rule():
    """
    A rule of a union joins the choice twice: the equality that makes the
    two atoms the same tuple holds in that rule only, which the unification
    of the variables took for the whole body, turning the union into a
    conjunction.
    """
    from .. import NeurolangPDL

    mentions = [
        (0, "b"), (0, "c"), (1, "a"), (1, "d"), (2, "a"), (2, "c"), (3, "a")
    ]
    nl = NeurolangPDL()
    nl.add_uniform_probabilistic_choice_over_set(
        [(s,) for s in range(4)], name="selected_study"
    )
    nl.add_tuple_set(mentions, name="mentions")
    result = nl.execute_datalog_program(
        "a(t) :- selected_study(s), selected_study(f), mentions(s, t), "
        "mentions(f, 'b')\n"
        "a(t) :- selected_study(s), mentions(s, t), mentions(s, 'c')\n"
        "ans(t, p) :- PROB[a(t)] = p"
    )
    assert dict(result) == pytest.approx({"a": 0.25, "b": 0.25, "c": 0.5})


def test_disjoint_separator_plans_a_union_in_one_projection():
    """The union over the choice is one disjoint projection on the study,
    of the choice joined with the support of the deterministic union."""
    plan = _plan_of(
        "a(s) :- mentions(s, 'language'), selected_study(s)\n"
        "a(s) :- mentions(s, 'speech'), selected_study(s)\n"
        "a(s) :- mentions(s, 'pain'), selected_study(s)\n"
        "ans(p) :- PROB[a(s)] = p"
    )
    assert isinstance(plan, DisjointProjection)
    assert "Σ" not in repr(plan)


def test_integer_constant_of_a_deterministic_atom():
    """mentions(1, t) selects the rows of study 1: its integer constant,
    equal as a constant to the column 1, was renamed into that column by
    the optimisers, and the selection kept every row."""
    from .. import NeurolangPDL

    nl = NeurolangPDL(
        probabilistic_solvers=(dalvi_suciu_lift.solve_succ_query,),
        probabilistic_marg_solvers=(dalvi_suciu_lift.solve_marg_query,),
    )
    nl.add_uniform_probabilistic_choice_over_set(
        [(1,), (2,), (3,), (4,)], name="selected_study"
    )
    nl.add_tuple_set(
        [(1, "x"), (2, "y"), (3, "x"), (4, "z"), (1, "y")], name="mentions"
    )
    result = nl.execute_datalog_program(
        "a(t) :- selected_study(f), mentions(f, t), mentions(1, t)\n"
        "ans(t, p) :- PROB[a(t)] = p"
    )
    assert dict(result) == pytest.approx({"x": 0.5, "y": 0.5})


def test_union_of_rules_one_without_a_variable_of_the_head():
    """In a(s, r) :- R(r), C(s), A(s, r) and a(s, r) :- R(r), C(s),
    M(s), the conjunctive normal form factors R(r) and C(s) out, leaving
    the clause A(s, r) ∨ M(s), whose union of plans had columns (s, r) and
    (s); it is declined, and solved by model counting."""
    from .. import NeurolangPDL

    nl = NeurolangPDL()
    nl.add_tuple_set(
        [("s1", "r1"), ("s2", "r1"), ("s3", "r2")], name="activates"
    )
    nl.add_tuple_set([("s1", "t1"), ("s3", "t1")], name="mentions")
    nl.add_tuple_set([("r1",), ("r2",)], name="region")
    nl.add_uniform_probabilistic_choice_over_set(
        [("s1",), ("s2",), ("s3",)], name="selected_study"
    )
    result = nl.execute_datalog_program(
        "a(s, r) :- region(r), selected_study(s), activates(s, r)\n"
        "a(s, r) :- region(r), selected_study(s), mentions(s, 't1')\n"
        "p(s, r, PROB) :- a(s, r)\n"
        "ans(s, r, x) :- p(s, r, x)"
    )
    expected = {
        ("s1", "r1"), ("s2", "r1"), ("s3", "r2"), ("s1", "r2"), ("s3", "r1")
    }
    assert {(s, r) for s, r, _ in result} == expected
    assert [x for _, _, x in result] == pytest.approx([1 / 3] * 5)


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_peaks_of_the_studies_of_a_term(solvers):
    """
    Each peak is reported by one study: the study of a peak is a function
    of the peak, and the study separates the query, which joins the
    reliable peaks of the region to the terms of their studies.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_probabilistic_facts_from_tuples(
        [(0.5, 1), (0.4, 2), (0.3, 3)], name="reliable_peak"
    )
    nl.add_tuple_set([(1, "s1"), (2, "s1"), (3, "s2")], name="peak_study")
    nl.add_probabilistic_facts_from_tuples(
        [(0.6, "pain", "s1"), (0.7, "pain", "s2"), (0.2, "memory", "s2")],
        name="term_in_study",
    )
    nl.execute_datalog_program(
        "q(t, PROB) :- reliable_peak(p), peak_study(p, s), "
        "term_in_study(t, s)"
    )
    result = dict(
        nl.solve_all()["q"].as_pandas_dataframe().itertuples(index=False)
    )
    assert result.keys() == {"pain", "memory"}
    pain = 1 - (1 - 0.6 * (1 - 0.5 * 0.6)) * (1 - 0.7 * 0.3)
    assert result["pain"] == pytest.approx(pain)
    assert result["memory"] == pytest.approx(0.2 * 0.3)


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_union_of_a_deterministic_and_a_probabilistic_rule(solvers):
    """
    The probability of the deterministic rule is a count, an integer:
    the union of the provenances must not truncate those of the other rule.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_tuple_set([(0, 1)], name="G")
    nl.add_probabilistic_facts_from_tuples(
        [(0.78, 0), (0.5, 2), (0.62, 3)], name="R"
    )
    nl.execute_datalog_program(
        "h(x) :- G(x, 1)\nh(x) :- R(x)\nq(x, PROB) :- h(x)"
    )
    result = dict(
        nl.solve_all()["q"].as_pandas_dataframe().itertuples(index=False)
    )
    assert result == pytest.approx({0: 1.0, 2: 0.5, 3: 0.62})


@pytest.mark.parametrize("comparison, expected", [
    ("y > 1", 1 - (1 - 0.5 * 0.7) * (1 - 0.4 * 0.8)),
    ("1 < y", 1 - (1 - 0.5 * 0.7) * (1 - 0.4 * 0.8)),
    ("y != 1", 1 - (1 - 0.5 * 0.7) * (1 - 0.4 * 0.8)),
    ("y >= 3", 0.4 * 0.8),
    ("y <= 1", 0.5 * 0.6),
])
@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_comparison_with_a_constant_of_a_bound_variable(
    solvers, comparison, expected
):
    """
    The comparison of y with a constant, outside the existential of x
    once the quantifiers are pushed down, selects the tuples of S.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_probabilistic_facts_from_tuples([(0.5, 1), (0.4, 2)], name="R")
    nl.add_probabilistic_facts_from_tuples(
        [(0.6, 1, 1), (0.7, 1, 2), (0.8, 2, 3)], name="S"
    )
    nl.execute_datalog_program(
        f"q(PROB) :- R(x), S(x, y), ({comparison})"
    )
    result = nl.solve_all()["q"].as_pandas_dataframe()
    assert len(result) == 1
    assert result.iloc[0, 0] == pytest.approx(expected)


@pytest.mark.parametrize("head, body", [
    ("x, y", "R(x), R(y), S(x, y)"),
    ("x, y, w", "R(x), R(y), R(w), S(x, y), V(y, w)"),
    ("x, y, w", "R(x), R(y), R(w), S(x, y), V(y, w), T(y)"),
    ("x, y, w", "R(x), R(y), R(w), T(x), T(y), S(x, y)"),
])
def test_answer_variables_at_the_same_position(head, body):
    """
    The atoms of R, and of T, with free variables at the same position are
    lifted on each partition of the equalities of the variables, and have
    the probabilities weighted model counting gives.
    """
    from .. import NeurolangPDL
    from ..probabilistic_frontend import (
        wmc_solve_marg_query,
        wmc_solve_succ_query
    )

    def solve(**solvers):
        nl = NeurolangPDL(**solvers)
        facts = {
            "R": [(0.2, 0), (0.5, 1), (0.7, 2)],
            "T": [(0.9, 0), (0.4, 1), (0.6, 2)],
            "S": [(0.3, 0, 1), (0.8, 1, 1), (0.6, 2, 0), (0.5, 1, 2)],
            "V": [(0.4, 1, 0), (0.7, 1, 1), (0.9, 2, 2), (0.2, 0, 2)],
        }
        for name, tuples in facts.items():
            nl.add_probabilistic_facts_from_tuples(tuples, name=name)
        nl.execute_datalog_program(f"q({head}, PROB) :- {body}")
        return {
            tuple(row[:-1]): row[-1]
            for row in nl.solve_all()["q"].as_pandas_dataframe().itertuples(
                index=False
            )
        }

    expected = solve(
        probabilistic_solvers=(wmc_solve_succ_query,),
        probabilistic_marg_solvers=(wmc_solve_marg_query,),
    )
    assert solve(**LIFTED_ONLY) == pytest.approx(expected)


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_function_of_a_variable_separates_the_query(solvers):
    """
    In R(x) ∧ T(y) ∧ y = x + 1, y is a function of x: it separates the
    query, whose atoms R(x) and T(y) share no variable otherwise.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_probabilistic_facts_from_tuples(
        [(0.5, 0), (0.4, 1), (0.3, 3)], name="R"
    )
    nl.add_probabilistic_facts_from_tuples(
        [(0.6, 1), (0.7, 2), (0.2, 3)], name="T"
    )
    nl.execute_datalog_program("q(PROB) :- R(x), T(y), (y == x + 1)")
    result = nl.solve_all()["q"].as_pandas_dataframe()
    assert len(result) == 1
    assert result.iloc[0, 0] == pytest.approx(
        1 - (1 - 0.5 * 0.6) * (1 - 0.4 * 0.7)
    )


@pytest.mark.parametrize("solvers", [{}, LIFTED_ONLY])
def test_function_of_a_deterministic_atom_inline_or_in_a_rule(solvers):
    """
    A function the engine knows by name, applied to the choice, and a
    threshold on it, within PROB, are the same query as the deterministic
    rule computing them: the same probabilities, and not an error for
    functions that the probabilistic program did not know.
    """
    from .. import NeurolangPDL

    nl = NeurolangPDL(**solvers)
    nl.add_symbol(
        lambda term, study: {1: 0.9, 2: 0.8, 3: 0.2}[study],
        name="query_similarity"
    )
    nl.add_uniform_probabilistic_choice_over_set(
        [(1,), (2,), (3,)], name="selected_study"
    )
    nl.add_tuple_set([(1,), (2,), (3,)], name="study")
    nl.add_tuple_set([(10, 1), (11, 2), (12, 3), (13, 3)], name="peak")
    inline = nl.execute_datalog_program(
        "ans(i, p) :- PROB[selected_study(s), peak(i, s), "
        "(v == query_similarity('tom', s)), (v > 0.75)] = p"
    )
    in_a_rule = nl.execute_datalog_program(
        "similar(s) :- study(s), (v == query_similarity('tom', s)), "
        "(v > 0.75)\n"
        "ans(i, p) :- PROB[selected_study(s), peak(i, s), similar(s)] = p"
    )
    assert dict(inline) == pytest.approx({10: 1 / 3, 11: 1 / 3})
    assert dict(in_a_rule) == pytest.approx(dict(inline))
