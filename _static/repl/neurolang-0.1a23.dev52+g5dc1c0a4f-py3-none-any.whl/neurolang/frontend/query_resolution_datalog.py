r"""
Query Builder Datalog
=====================
Complements QueryBuilderBase with query capabilities,
as well as Region and Neurosynth capabilities
"""
import warnings
from collections import defaultdict
from nl_core.datalog.magic_sets import magic_rewrite
from nl_core.datalog.range_restriction import check_range_restriction
from nl_expr.exceptions import (
    ForbiddenDisjunctionError,
    NeuroLangException,
    UnsupportedProgramError,
)
from nl_expr.exceptions import UnboundVariablesError
from typing import (
    AbstractSet,
    Any,
    Dict,
    Iterable,
    List,
    Optional,
    Tuple,
    Type,
    Union,
)
from uuid import uuid1

import pandas as pd

from nl_expr.exceptions import SquallSemanticError
from nl_expr.logic.expression_processing import extract_logic_atoms

from nl_core import datalog
from nl_expr import expressions as ir
from nl_expr import logic
from nl_core.datalog.chase import Chase
from nl_core.datalog.constraints_representation import RightImplication
from nl_core.datalog.exceptions import InvalidMagicSetError
from nl_core.datalog.expression_processing import (
    remove_conjunction_duplicates,
    stratify,
    TranslateToDatalogSemantics,
    reachable_code,
)
from nl_core.datalog.expressions import (
    AggregationApplication,
    predicate_identity,
)
from nl_expr.logic.transformations import RemoveTrivialOperations
from nl_expr.type_system import Unknown
from nl_core.utils.relational_algebra_set import (
    NamedRelationalAlgebraFrozenSet,
    RelationalAlgebraFrozenSet,
)
from nl_core.datalog.pretty_printer import DatalogPrettyPrinter
from .resampling import uses_resampling
from .datalog.squall_syntax_lark import (
    parser as squall_parser,
    EquiprobableChoiceDef,
    SquallProgram,
    WeightedChoiceDef,
)
from .datalog.standard_syntax import (
    documentation_command,
    parser as datalog_parser,
    query_name,
)
from .datalog.squall import CheckPredicateArities, predicate_arity
from .query_resolution import NeuroSynthMixin, QueryBuilderBase, RegionMixin
from nl_core.datalog import DatalogProgram
from nl_core.datalog.wrapped_collections import (
    WrappedRelationalAlgebraFrozenSet,
)
from nl_core.datalog.horn_clauses import Fol2DatalogTranslationException
from . import query_resolution_expressions as fe
from .show_ra import (
    generated_query_symbol,
    print_deterministic_ra_plan,
    show_ra_options,
)

__all__ = ["QueryBuilderDatalog"]


def _wrap_fol_error_for_squall(exc: Fol2DatalogTranslationException) -> Exception:
    orig = exc.__cause__
    if orig and "Variables in head" in str(orig):
        new_msg = (
            f"SQUALL semantic error: Variable mismatch between rule definition and query.\n\n"
            f"The rule head uses a variable that doesn't appear in the body, "
            f"or the query uses variables that don't match the rule head.\n\n"
            f"Common fixes:\n"
            f"1. Add explicit labels in rule definitions:\n"
            f"   'define as X for every Noun ?x that...' (not just 'every Noun')\n"
            f"2. Ensure query variables match rule head variables:\n"
            f"   'obtain every X (?x; ?y)' must match the rule head\n"
            f"3. Check that rule body variables are used in the head\n\n"
            f"Original error: {orig}"
        )
        exc.args = (new_msg,)
    return exc


def _names_whole_relation(head_vars, body):
    """
    Return whether *body* is a single atom on the only head variable.

    Such a SQUALL clause, as ``every Voxel``, names a relation without a
    tuple label.
    """
    if len(head_vars) != 1 or not isinstance(body, ir.FunctionApplication):
        return False
    return (
        isinstance(head_vars[0], ir.Symbol)
        and isinstance(body.functor, ir.Symbol)
        and tuple(body.args) == tuple(head_vars)
    )


class QueryBuilderDatalog(RegionMixin, NeuroSynthMixin, QueryBuilderBase):
    """
    Complements QueryBuilderBase with query capabilities,
    as well as Region and Neurosynth capabilities
    """

    def __init__(
        self,
        program_ir: DatalogProgram,
        chase_class: Type[Chase] = Chase,
    ) -> "QueryBuilderDatalog":
        """
        Query builder with query, Region, Neurosynth capabilities

        Parameters
        ----------
        program_ir : DatalogProgram
            Datalog program's intermediate representation,
            usually blank
        chase_class : Type[Chase], optional
            used to compute deterministic solutions,
            by default Chase

        Returns
        -------
        QueryBuilderDatalog
            see description
        """
        super().__init__(program_ir, logic_programming=True)
        self.chase_class = chase_class
        self.frontend_translator = fe.TranslateExpressionToFrontEndExpression(
            self
        )
        self.translate_expression_to_datalog = TranslateToDatalogSemantics()
        self.datalog_parser = datalog_parser

    @staticmethod
    def _simplify_rewritten_rules(reachable_rules):
        """Simplify reachable rules using existing expression walkers.

        Applies RemoveTrivialOperations (unwraps single-element n-ary
        operators, removes double negation) and remove_conjunction_duplicates
        (deduplicates body predicates), then deduplicates rules.

        Note: TRUE removal from conjunctions is not covered by
        the current MRO walkers — the LogicSimplifier in the SQUALL
        parser handles that but is not in the general MRO.
        """
        if reachable_rules is None:
            return None

        trivial = RemoveTrivialOperations()

        def _simplify_single_rule(rule):
            try:
                rule = trivial.walk(rule)
            except Exception:
                pass
            if isinstance(rule.antecedent, logic.Conjunction):
                try:
                    deduped = remove_conjunction_duplicates(rule.antecedent)
                    if deduped is not rule.antecedent:
                        rule = logic.Implication(rule.consequent, deduped)
                except Exception:
                    pass
            return rule

        simplified = [_simplify_single_rule(rule) for rule in reachable_rules.formulas]

        seen = set()
        unique = []
        for rule in simplified:
            key = repr(rule)
            if key not in seen:
                seen.add(key)
                unique.append(rule)

        return logic.Union(tuple(unique))

    def _print_rewritten_program(
        self, query_expression, reachable_rules=None
    ):
        """
        Print the Datalog program after magic-sets rewriting, of the
        query rule *query_expression*, or of a list of them.
        """
        reachable_rules = self._simplify_rewritten_rules(reachable_rules)
        queries = (
            query_expression if isinstance(query_expression, list)
            else [query_expression]
        )

        print("── rewritten program ──")
        printer = DatalogPrettyPrinter()
        for query in queries:
            print(printer.walk(query))
        if reachable_rules is not None:
            strata, _ = stratify(reachable_rules, self.program_ir)
            query_functors = {query.consequent.functor for query in queries}
            for stratum in strata:
                for rule in stratum:
                    if rule.consequent.functor not in query_functors:
                        print(printer.walk(rule))
        print()

    def _handle_rewritten_output(
        self, query_expression, show_rewritten: bool, dry_run: bool,
        show_ra=False,
    ) -> bool:
        """Print rewritten program if requested and return True if dry-running.

        Returns True when dry_run is active and show_ra is not active
        (caller should short-circuit), False when execution should continue.
        When show_ra is True, the caller still needs to build the RA plan,
        and the rewritten program is only printed if show_rewritten is.
        *query_expression* is a query rule, or a list of the rules of
        queries solved together.
        """
        if show_rewritten or (dry_run and not show_ra):
            queries = (
                query_expression if isinstance(query_expression, list)
                else [query_expression]
            )
            reachable_rules = self._union_of_rules(
                reachable_code(query, self.program_ir) for query in queries
            )
            self._print_rewritten_program(query_expression, reachable_rules)
        return dry_run and not show_ra

    @property
    def current_program(self) -> List[fe.Expression]:
        """
        Returns the list of expressions that have currently been
        declared in the program

        Returns
        -------
        List[fe.Expression]
            see description

        Examples
        --------
        >>> p_ir = DatalogProgram()
        >>> nl = QueryBuilderDatalog(program_ir=p_ir)
        >>> nl.add_tuple_set([(1, 2), (2, 2)], name="l")
        l: typing.AbstractSet[typing.Tuple[int, int]] = [(1, 2), (2, 2)]
        >>> with nl.scope as e:
        ...     e.l2[e.x] = e.l[e.x, e.y] & (e.x == e.y)
        ...     cp = nl.current_program
        >>> cp
        [
            l2(x) ← ( l(x, y) ) ∧ ( x eq y )
        ]
        """
        cp = []
        for rules in self.program_ir.intensional_database().values():
            for rule in rules.formulas:
                cp.append(self.frontend_translator.walk(rule))
        return cp

    def _declare_implication(
        self, consequent: fe.Expression, antecedent: fe.Expression
    ) -> fe.Expression:
        """
        Creates an implication of the consequent by the antecedent
        and adds the rule to the current program:
            consequent <- antecedent

        Parameters
        ----------
        consequent : fe.Expression
            see description, will be processed to a logic form before
            creating the implication rule
        antecedent : fe.Expression
            see description, will be processed to a logic form before
            creating the implication rule

        Returns
        -------
        fe.Expression
            see description

        Examples
        --------
        >>> p_ir = DatalogProgram()
        >>> nl = QueryBuilderDatalog(program_ir=p_ir)
        >>> nl.add_tuple_set([(1, 2), (2, 2)], name="l")
        l: typing.AbstractSet[typing.Tuple[int, int]] = [(1, 2), (2, 2)]
        >>> with nl.scope as e:
        ...     nl._declare_implication(e.l2[e.x], e.l2[e.x, e.y])
        ...     cp = nl.current_program
        >>> cp
        [
            l2(x) ← l(x, y)
        ]
        """
        consequent = self.translate_expression_to_datalog.walk(
            consequent.expression
        )
        antecedent = self.translate_expression_to_datalog.walk(
            antecedent.expression
        )
        rule = datalog.Implication(consequent, antecedent)
        self.program_ir.walk(rule)
        return rule

    def add_constraint(
        self, antecedent: fe.Expression, consequent: fe.Expression
    ) -> fe.Expression:
        """
        Creates an right implication of the consequent by the antecedent
        and adds the rule to the current program:

        .. code-block:: text

            antecedent -> consequent

        Parameters
        ----------
        antecedent : fe.Expression
            see description, will be processed to a logic form before
            creating the right implication rule
        consequent : fe.Expression
            see description, will be processed to a logic form before
            creating the right implication rule

        Returns
        -------
        fe.Expression
            see description

        Examples
        --------
        >>> p_ir = DatalogProgram()
        >>> nl = QueryBuilderDatalog(program_ir=p_ir)
        >>> nl.add_tuple_set([(1, 2), (2, 2)], name="l")
        l: typing.AbstractSet[typing.Tuple[int, int]] = [(1, 2), (2, 2)]
        >>> with nl.scope as e:
        ...     nl.add_constraint(e.l2[e.x, e.y], e.l2[e.x])
        """
        consequent = self.translate_expression_to_datalog.walk(
            consequent.expression
        )
        antecedent = self.translate_expression_to_datalog.walk(
            antecedent.expression
        )
        rule = RightImplication(antecedent, consequent)
        self.program_ir.walk(rule)
        return rule

    def execute_datalog_program(
        self, code: str, show_rewritten: bool = False, dry_run: bool = False,
        show_ra=False,
    ) -> Union[None, bool, RelationalAlgebraFrozenSet]:
        """
        Execute a Datalog program in classical syntax.
        If the program contains a query, in the form `ans(x) :- R(x)`,
        then this query is executed against the program and the result is
        returned. Otherwise returns None. The rules of the program stay in
        it after the query: a later rule of the same head is added to them,
        with a warning if its program has a query; run the query in
        ``with nl.scope:`` to keep its rules local to it.

        Parameters
        ----------
        code : string
            Datalog program.
        show_rewritten : bool
            If True, print the Datalog program after magic-sets rewriting.
        dry_run : bool
            If True, print the rewritten program and return None without
            running the chase.
        show_ra : bool or ShowRAOptions
            If True, print the named relational algebra expression
            of each rule instead of evaluating it. A
            :class:`~neurolang.frontend.show_ra.ShowRAOptions` selects
            how the plans are displayed.

        Examples
        --------
        >>> p_ir = DatalogProgram()
        >>> nl = QueryBuilderDatalog(program_ir=p_ir)
        >>> nl.add_tuple_set([(1, 2), (2, 2)], name="l")
        l: typing.AbstractSet[typing.Tuple[int, int]] = [(1, 2), (2, 2)]
        >>> prog = '''
        ...        l2(x, y) :- l(x, y), (x == y)
        ...        ans(x) :- l2(x, y)
        ...        '''
        >>> with nl.environment as e:
        ...     q = nl.execute_datalog_program(prog)
        >>> q
        ... q: typing.AbstractSet[typing.Tuple[int]] = [(2,)]
        """
        intermediate_representation = self.datalog_parser(code)
        queries = [
            rule
            for rule in intermediate_representation.formulas
            if isinstance(rule, ir.Query)
        ]
        if len(queries) == 0:
            self._walk_program(intermediate_representation.formulas)
            return
        elif len(queries) == 1:
            counts = self._rule_counts()
            self._walk_program(
                [
                    rule
                    for rule in intermediate_representation.formulas
                    if not isinstance(rule, ir.Query)
                ]
            )
            self._warn_added_rules(counts)
            query = self.frontend_translator.walk(
                self._expand_resamplings(queries[0])
            )
            return self.query(
                query.head.arguments, query.body,
                show_rewritten=show_rewritten, dry_run=dry_run,
                show_ra=show_ra,
            )
        else:
            return self._execute_named_queries(
                intermediate_representation, queries,
                show_rewritten=show_rewritten, dry_run=dry_run,
                show_ra=show_ra,
            )

    def _execute_named_queries(
        self, intermediate_representation, queries, show_rewritten=False,
        dry_run=False, show_ra=False,
    ):
        """
        Execute the several queries of a program, ``ans[name](...) :-
        ...``, together, and return their answers by name.

        The queries are solved as one: see :meth:`_solve_queries`.
        """
        names = [query_name(q.head) for q in queries]
        if len(set(names)) < len(names):
            raise UnsupportedProgramError(
                "The queries of a program have each a name, in the form "
                "of ans[name](...) :- R(...); the name of more than one "
                "query is {}".format(
                    ", ".join(
                        sorted(n for n in set(names) if names.count(n) > 1)
                    )
                )
            )
        counts = self._rule_counts()
        self._walk_program(
            [
                rule
                for rule in intermediate_representation.formulas
                if not isinstance(rule, ir.Query)
            ]
        )
        self._warn_added_rules(counts)
        queries = [
            self.frontend_translator.walk(self._expand_resamplings(q))
            for q in queries
        ]
        heads_and_bodies = [(q.head.arguments, q.body) for q in queries]
        if show_ra:
            # the plans are those of each query, solved apart
            answers = []
            for name, (head, body) in zip(names, heads_and_bodies):
                print(f"── {name} ──")
                answers.append(self.query(
                    head, body, show_rewritten=show_rewritten,
                    dry_run=dry_run, show_ra=show_ra,
                ))
        else:
            answers = self._solve_queries(
                heads_and_bodies, show_rewritten=show_rewritten,
                dry_run=dry_run,
            )
        if answers is None:
            return None
        return dict(zip(names, answers))

    def _solve_queries(self, queries, show_rewritten=False, dry_run=False):
        """
        Solve the *queries*, pairs of a head and a body as
        :meth:`query` takes them, together, and return their answers as
        :meth:`query` does, or None if nothing was solved.

        The queries are rewritten with magic sets, each for its own
        bindings, into the rules of a single program, which is run once:
        the predicates that queries share are computed once, for the
        bindings of all the queries that use them.
        """
        self.program_ir.symbol_table = self.symbol_table.create_scope()
        try:
            rewritten = [
                self._magic_sets_rewrite_query(head, body)
                for head, body in queries
            ]
            goals = [query for query, _ in rewritten]
            rules = self._union_of_rules(rules for _, rules in rewritten)
            if self._handle_rewritten_output(goals, show_rewritten, dry_run):
                return None
            solution = self.chase_class(
                self.program_ir, rules=rules
            ).build_chase_solution()
            return [
                self._query_answer(head, goal, solution)
                for (head, _), goal in zip(queries, goals)
            ]
        finally:
            self.program_ir.symbol_table = self.symbol_table.enclosing_scope

    @staticmethod
    def _union_of_rules(unions):
        """Return the rules of the *unions*, each of them once."""
        rules = dict.fromkeys(
            rule for union in unions for rule in union.formulas
        )
        return logic.Union(tuple(rules))

    def _query_answer(self, head, goal, solution):
        """Return the answer of the query *head* from the *solution*."""
        solution_set = solution.get(
            goal.consequent.functor,
            ir.Constant(WrappedRelationalAlgebraFrozenSet())
        )
        if isinstance(head, tuple):
            row_type = solution_set.value.row_type
            solution_set = NamedRelationalAlgebraFrozenSet(
                self._parameter_names(s.expression for s in head),
                solution_set.value.unwrap()
            )
            solution_set.row_type = row_type
        if not isinstance(head, tuple):
            return solution_set
        if len(head) == 0:
            return len(solution_set) > 0
        return solution_set

    def import_datalog_module(self, path):
        """
        Import the Datalog module at *path*, as ``.import("path")`` in a
        program does: its facts, rules and commands are added to the
        program, once. ``"package:path/module.dl"`` is a module shipped
        in the Python package ``package``.
        """
        self.program_ir.walk(
            ir.Command(ir.Symbol("import"), (ir.Constant(str(path)),), ())
        )

    def _rule_counts(self):
        """Return the number of rules of each predicate of the IDB."""
        return {
            symbol: len(getattr(rules, "formulas", ()))
            for symbol, rules in self.program_ir.intensional_database().items()
        }

    def _warn_added_rules(self, counts):
        """
        Warn that a query's rules were added to predicates that had
        *counts* rules: the predicate is the union of all its rules.
        """
        added = sorted({
            symbol.name for symbol, count in self._rule_counts().items()
            if counts.get(symbol, count) < count
        })
        if added:
            warnings.warn(
                f"{', '.join(added)} already defined: the rules of the "
                "query are added to the earlier ones, not replacing them; "
                "rename them, or run the queries in `with nl.scope:` to "
                "keep their rules local.", stacklevel=3,
            )

    def _walk_program(self, rules):
        """
        Add *rules* to the program; those with ``RESAMPLE`` after the
        others, as they rewrite the rules they depend on, and the rules
        over theirs last.
        """
        later = {id(r) for r in rules if uses_resampling(r)}
        heads = set()
        while later:
            heads |= {r.consequent.functor for r in rules if id(r) in later}
            more = {
                id(r) for r in rules
                if id(r) not in later and isinstance(r, logic.Implication)
                and any(
                    atom.functor in heads
                    for atom in extract_logic_atoms(r.antecedent)
                )
            }
            if not more:
                break
            later |= more
        self.program_ir.walk(
            logic.Union([r for r in rules if id(r) not in later])
        )
        for rule in rules:
            if id(rule) in later:
                self.program_ir.walk(logic.Union(
                    (self._expand_resamplings(rule),)
                ))

    def _expand_resamplings(self, rule):
        if uses_resampling(rule):
            raise UnsupportedProgramError(
                "RESAMPLE needs a probabilistic program (NeurolangPDL)"
            )
        return rule

    def _expand_whole_relation(self, head_vars, body):
        """
        Make a SQUALL clause naming a relation alone use all its columns.

        ``every Voxel`` without a tuple label stands for the whole
        relation: the head variables and the body atom are expanded to
        the columns of the relation instead of keeping only the first.
        """
        if not _names_whole_relation(head_vars, body):
            return head_vars, body
        arity = predicate_arity(self.program_ir, body.functor)
        if arity is None or arity < 2:
            return head_vars, body
        terms = self.program_ir.predicate_terms(body.functor)[-arity:]
        head_vars = tuple(
            t if isinstance(t, ir.Symbol) else ir.Symbol.fresh()
            for t in terms
        )
        return head_vars, body.functor(*head_vars)

    def _expand_whole_relation_rule(self, rule):
        """
        Expand a SQUALL rule whose body names a relation alone.

        ``obtain every Voxel as Voxels`` defines ``voxels`` with all the
        columns of ``voxel``, as the query itself obtains them.
        """
        head = getattr(rule, "consequent", None)
        if not isinstance(head, ir.FunctionApplication):
            return rule
        head_vars, body = self._expand_whole_relation(
            tuple(head.args), rule.antecedent
        )
        if body is rule.antecedent:
            return rule
        return rule.apply(head.functor(*head_vars), body)

    @staticmethod
    def _process_squall_commands(parsed):
        """Process SQUALL directives (#set_backend, etc.)."""
        if not (isinstance(parsed, SquallProgram) and parsed.commands):
            return
        from nl_expr.config import config as nl_config
        from nl_expr.expressions import Constant

        _KNOWN_COMMANDS = {"set_backend"}
        for cmd in parsed.commands:
            name = cmd.functor.name if hasattr(cmd, 'functor') else None
            if name is None or name not in _KNOWN_COMMANDS:
                continue
            if name == "set_backend":
                if cmd.args and isinstance(cmd.args[0], Constant):
                    nl_config.set_query_backend(cmd.args[0].value)
                else:
                    raise NeuroLangException(
                        "#set_backend requires a string argument, "
                        "e.g. #set_backend('pandas')."
                    )

    def _walk_squall_rule(self, rule):
        """Walk a single SQUALL rule or choice definition into the engine."""
        self._check_squall_rule_body(rule)
        if isinstance(rule, EquiprobableChoiceDef):
            self._handle_equiprobable_choice(rule)
        elif isinstance(rule, WeightedChoiceDef):
            self._handle_weighted_choice(rule)
        else:
            rule = self._expand_whole_relation_rule(rule)
            CheckPredicateArities(self.program_ir).walk(rule)
            try:
                self.program_ir.walk(rule)
            except Fol2DatalogTranslationException as e:
                raise _wrap_fol_error_for_squall(e) from e

    def _walk_squall_rules(self, parsed):
        """Walk all rule definitions from a parsed SQUALL program into the engine."""
        if not isinstance(parsed, SquallProgram):
            # Legacy non-SquallProgram parse tree
            if isinstance(parsed, (EquiprobableChoiceDef, WeightedChoiceDef)):
                self._walk_squall_rule(parsed)
            elif isinstance(parsed, logic.Union):
                for r in parsed.formulas:
                    self._walk_squall_rule(r)
            else:
                self._walk_squall_rule(parsed)
            return
        for rule in parsed.rules_and_choice_defs:
            self._walk_squall_rule(rule)

    def _execute_single_squall_query(self, query, rules_and_choice_defs,
                                     show_rewritten=False, dry_run=False,
                                     show_ra=False):
        """Execute one obtain clause from a SQUALL program.

        Builds a fresh helper predicate h(head_vars) :- query.body and
        delegates to _execute_query, exactly as execute_datalog_program
        does for ans(...) :- R(...).
        """
        self._check_squall_aggregation_columns(
            query.head if isinstance(query.head, tuple) else (query.head,),
            query.body,
        )
        head = query.head
        if isinstance(head, AggregationApplication):
            head_vars = (head,)
        elif isinstance(head, ir.FunctionApplication):
            head_vars = tuple(head.args)
        elif isinstance(head, ir.Symbol):
            head_vars = (head,)
        else:
            head_vars = tuple(head)

        head_vars, body = self._expand_whole_relation(head_vars, query.body)
        CheckPredicateArities(self.program_ir).walk(body)

        h = ir.Symbol.fresh()
        query_impl = datalog.Implication(h(*head_vars), body)

        self.program_ir.push_scope()
        try:
            # Rules are already walked into the global scope by
            # execute_squall_program; re-walking them here duplicates
            # intentional rules and makes --show-rewritten output contain
            # repeated rules (fresh probability variables defeat repr-based
            # deduplication). Choice definitions are already registered
            # globally as well, so nothing from rules_and_choice_defs needs
            # to be re-added in this per-query scope.
            self.program_ir.walk(query_impl)
            fe_pred = fe.Expression(self, h(*head_vars))
            fe_head = tuple(
                fe.Expression(self, s) if isinstance(s, ir.Symbol)
                else fe.Expression(self, ir.Symbol.fresh())
                for s in head_vars
            )
            ra, _ = self._execute_query(
                fe_head, fe_pred,
                show_rewritten=show_rewritten, dry_run=dry_run,
                show_ra=show_ra,
            )
        finally:
            self.program_ir.pop_scope()
        return ra

    def execute_squall_program(
        self, code: str, show_rewritten: bool = False, dry_run: bool = False,
        show_ra=False,
    ) -> Union[None, NamedRelationalAlgebraFrozenSet, Dict[str, NamedRelationalAlgebraFrozenSet]]:
        """
        Execute a SQUALL (controlled English) program.

        Parses *code* as a SQUALL program, walks rule definitions into the
        engine, and executes ``obtain`` queries the same way
        `execute_datalog_program` handles ``ans(x) :- R(x)`` — by building a
        fresh helper implication and delegating to `self.query` (or
        `self._execute_query` for probabilistic engines).

        Parameters
        ----------
        code : str
            SQUALL program text.  May contain any mixture of
            ``define as …`` rule definitions and ``obtain …`` queries.
        show_rewritten : bool
            If True, print the Datalog program after magic-sets rewriting.
        dry_run : bool
            If True, print the rewritten program and return None without
            running the chase.
        show_ra : bool or ShowRAOptions
            If True, print the named relational algebra expression
            of each rule instead of evaluating it. A
            :class:`~neurolang.frontend.show_ra.ShowRAOptions` selects
            how the plans are displayed.

        Returns
        -------
        None
            When *code* contains only rule definitions (no ``obtain``).
        NamedRelationalAlgebraFrozenSet
            When *code* contains exactly one ``obtain`` clause.
        Dict[str, NamedRelationalAlgebraFrozenSet]
            When *code* contains two or more ``obtain`` clauses, keyed
            ``"obtain_0"``, ``"obtain_1"``, … in declaration order.

        Examples
        --------
        >>> from neurolang.frontend import NeurolangPDL
        >>> nl = NeurolangPDL()
        >>> _ = nl.add_tuple_set([("alice",), ("bob",)], name="person")
        >>> _ = nl.add_tuple_set([("alice",)], name="plays")
        >>> nl.execute_squall_program(
        ...     "define as Active every person that plays."
        ... ) is None
        True
        >>> result = nl.execute_squall_program("obtain every Person that plays.")
        >>> sorted(result.as_pandas_dataframe().iloc[:, 0].tolist())
        ['alice']
        """
        parsed = squall_parser(code)

        self._process_squall_commands(parsed)

        # Rules-only (no obtain) — backward-compat: returns Union/Implication
        if not isinstance(parsed, SquallProgram):
            self._walk_squall_rules(parsed)
            return None

        # Walk all rule definitions into the engine (global scope).
        self._walk_squall_rules(parsed)

        if not parsed.queries:
            return None

        # Execute each obtain query
        results = {}
        for i, q in enumerate(parsed.queries):
            key = parsed.query_names.get(i, f"obtain_{i}")
            ra = self._execute_single_squall_query(
                q, parsed.rules_and_choice_defs,
                show_rewritten=show_rewritten, dry_run=dry_run,
                show_ra=show_ra,
            )
            if not dry_run:
                results[key] = ra

        if dry_run:
            return None
        if len(results) == 1:
            return next(iter(results.values()))
        return results

    def compute_datalog_program_for_autocompletion(
            self, code: str, autocompletion_code
    ) -> Dict:
        """
        Computes a Datalog program in classical syntax.
        Returns the next accepted tokens of the program.

        Parameters
        ----------
        code : string
            Datalog program.
        autocompletion_code : str
            Datalog program for autocompletion.

        Examples
        --------
        >>> p_ir = DatalogProgram()
        >>> nl = QueryBuilderDatalog(program_ir=p_ir)
        >>> prog_complete = '''
        ...        l2(x, y) :- l(x, y), (x == y)
        ...        ans(x) :- l2(x, y)
        ...        '''
        >>> prog = '''
        ...        l2(x, y) :- l(x, y), (x == y)
        ...        ans(x) :-
        ...        '''
        >>> with nl.environment as e:
        ...     q = nl.compute_datalog_program_for_autocompletion(prog_complete, prog)
        >>> q
        ... {
        ...     'Signs': {'@', '∃', '('}, 'Numbers': set(), 'Text': set(), 'Operators': {'¬', '~'},
        ...     'Cmd_identifier': set(), 'Functions': {'lambda'}, 'Identifier_regexp': set(),
        ...     'Reserved words': {'exists', 'EXISTS'}, 'Boleans': {'⊤', '⊥', 'False', 'True'},
        ...     'Expression symbols': set(), 'Python string': set(),
        ...     'Strings': {'<identifier regular expression>', '<command identifier>'}, 'commands': set(),
        ...     'functions': set(), 'base symbols': set(), 'query symbols': set()
        ... }
        """
        # All the following code before return is mandatory to retrieve
        # the query symbols without actually running the query
        intermediate_representation = self.datalog_parser(code)
        queries = [
            rule
            for rule in intermediate_representation.formulas
            if isinstance(rule, ir.Query)
        ]
        if len(queries) == 1:
            self.frontend_translator.walk(queries[0])
            program = logic.Union(
                [
                    rule
                    for rule in intermediate_representation.formulas
                    if not isinstance(rule, ir.Query)
                ]
            )
            self.program_ir.walk(program)
        else:
            self.program_ir.walk(intermediate_representation)
        res = self.datalog_parser(autocompletion_code, None, None, True)
        return res

    def _handle_equiprobable_choice(self, choice_def):
        """Register a SQUALL equiprobable choice in the program IR.

        Looks up the source EDB set in the symbol table, computes uniform
        probabilities (1 / N) for each tuple, and calls
        ``add_probabilistic_choice_from_tuples``.
        """
        body_formula = choice_def.body_formula

        # Extract the source predicate symbol from the body formula.
        if isinstance(body_formula, logic.Conjunction):
            # Filtered source — extract first predicate as the base source.
            source_pred_sym = body_formula.formulas[0].functor
        elif isinstance(body_formula, ir.FunctionApplication):
            source_pred_sym = body_formula.functor
        else:
            raise NeuroLangException(
                f"Cannot extract source predicate from body formula: "
                f"{body_formula}"
            )

        # Look up the source EDB set in the program symbol table.
        if source_pred_sym not in self.program_ir.symbol_table:
            raise NeuroLangException(
                f"Source predicate '{source_pred_sym.name}' not found in the "
                f"program. Make sure the data is loaded before defining the "
                f"probabilistic choice."
            )
        source_rel = self.program_ir.symbol_table[source_pred_sym]
        if not isinstance(source_rel, ir.Constant):
            raise NeuroLangException(
                f"Source predicate '{source_pred_sym.name}' is not a "
                f"concrete set. Equiprobable choices currently require an "
                f"extensional (ground) source predicate."
            )

        # Build choice tuples with uniform probability.
        # source_rel.value is a WrappedRelationalAlgebraSet — use itervalues
        # to get raw Python tuples for each row.
        source_rows = list(source_rel.value.itervalues())
        n = len(source_rows)
        if n == 0:
            prob = 1.0
        else:
            prob = 1.0 / n
        choice_tuples = [(prob,) + row for row in source_rows]

        self.program_ir.add_probabilistic_choice_from_tuples(
            choice_def.head_symbol, choice_tuples
        )

    def _handle_weighted_choice(self, choice_def):
        """Register a SQUALL weighted probabilistic choice in the program IR.

        Evaluates the probability expression per tuple from the source set,
        normalises to sum to 1, and calls ``add_probabilistic_choice_from_tuples``.
        """
        raise NeuroLangException(
            "Weighted probabilistic choices (with explicit probability "
            "expressions) are not yet implemented. "
            "Use 'define as X as an equiprobable choice over every Y' for now."
        )

    @staticmethod
    def _aggregation_column_message(aggregation, functor, arity):
        """
        Explain how to name the aggregated column of a multi-column relation.
        """
        func = aggregation.functor
        func = getattr(func, 'value', func)
        name = getattr(func, '__name__', getattr(func, 'name', str(func)))
        name = {
            'len': 'count', 'count_distinct': 'count', 'mean': 'average'
        }.get(name, name)
        name = name[:1].upper() + name[1:]
        noun = functor.name[:1].upper() + functor.name[1:]
        blanks = '; '.join(['_'] * (arity - 1))
        return (
            f"Cannot aggregate '{name}' over '{noun}': the relation has "
            f"{arity} columns but the aggregation names a single one, so "
            "it would silently aggregate the first column.  Name the column "
            "to aggregate with a tuple label, using _ for the other "
            f"columns, e.g. 'the {name} of the {noun} ({blanks}; ?v)'; add "
            "'per ?x' to aggregate per value of a labelled column, e.g. "
            f"'every {name} of the {noun} (?x; ...; ?v) per ?x'."
        )

    def _relation_columns(self, functor):
        """
        Return the number of value columns of ``functor``, or 0 if unknown.

        The probability column of stored probabilistic facts and choices
        is not counted.
        """
        try:
            columns = len(self.program_ir.predicate_terms(functor))
        except NeuroLangException:
            return 0
        probabilistic = (
            getattr(self.program_ir, 'pfact_pred_symbs', set())
            | getattr(self.program_ir, 'pchoice_pred_symbs', set())
        )
        if functor in probabilistic and isinstance(
            self.program_ir.symbol_table[functor], ir.Constant
        ):
            columns -= 1
        return columns

    def _check_squall_aggregation_columns(self, head_args, body):
        """
        Reject a one-variable aggregation over a multi-column relation.

        ``the Max of the R`` with a 3-column ``R`` binds only ``R``'s first
        column, so the aggregate would be computed over it without warning.
        """
        for aggregation in head_args:
            if not (
                isinstance(aggregation, AggregationApplication)
                and len(aggregation.args) == 1
            ):
                continue
            for atom in extract_logic_atoms(body):
                if atom.args != aggregation.args:
                    continue
                columns = self._relation_columns(atom.functor)
                if columns > 1:
                    raise SquallSemanticError(
                        self._aggregation_column_message(
                            aggregation, atom.functor, columns
                        )
                    )

    def _check_squall_rule_body(self, rule):
        """
        Apply ``_check_squall_aggregation_columns`` to a SQUALL rule.
        """
        if isinstance(rule, datalog.Implication) and isinstance(
            rule.consequent, ir.FunctionApplication
        ):
            self._check_squall_aggregation_columns(
                rule.consequent.args, rule.antecedent
            )

    def query(
        self, *args, show_rewritten: bool = False, dry_run: bool = False,
        show_ra=False,
    ) -> Union[bool, RelationalAlgebraFrozenSet, fe.Symbol]:
        """
        Performs an inferential query on the database.
        There are three modalities
        1. If there is only one argument, the query returns `True` or `False`
        depending on whether the query could be inferred.
        2. If there are two arguments and the first is a tuple of `fe.Symbol`,
        it returns the set of results meeting the query in the second argument.
        3. If the first argument is a predicate (e.g. `Q(x)`) it performs the
        query, adds it to the engine memory, and returns the
        corresponding symbol.
        See example for 3 modalities

        Parameters
        ----------
        show_rewritten : bool
            If True, print the Datalog program after magic-sets rewriting.
        dry_run : bool
            If True, print the rewritten program and return immediately
            without running the chase.
        show_ra : bool or ShowRAOptions
            If True, print the named relational algebra expression
            of each rule instead of evaluating it. A
            :class:`~neurolang.frontend.show_ra.ShowRAOptions` selects
            how the plans are displayed.

        Returns
        -------
        Union[bool, RelationalAlgebraFrozenSet, fe.Symbol]
            read the descrpition.

        Examples
        --------
        Note: example ran with pandas backend
        >>> p_ir = DatalogProgram()
        >>> nl = QueryBuilderDatalog(program_ir=p_ir)
        >>> nl.add_tuple_set([(1, 2), (2, 2)], name="l")
        l: typing.AbstractSet[typing.Tuple[int, int]] = [(1, 2), (2, 2)]
        >>> with nl.environment as e:
        ...     e.l2[e.x, e.y] = e.l[e.x, e.y] & (e.x == e.y)
        ...     s1 = nl.query(e.l2[e.x, e.y])
        ...     s2 = nl.query((e.x,), e.l2[e.x, e.y])
        ...     s3 = nl.query(e.l3[e.x], e.l2[e.x, e.y])
        """
        if len(args) == 1:
            predicate = args[0]
            head = tuple()
        elif len(args) == 2:
            head, predicate = args
            if (
                isinstance(head, (fe.Symbol, fe.Expression)) and
                isinstance(head.expression, ir.Symbol)
            ):
                head = (head,)
        else:
            raise ValueError("query takes 1 or 2 arguments")

        solution_set, functor_orig = self._execute_query(
            head, predicate, show_rewritten=show_rewritten, dry_run=dry_run,
            show_ra=show_ra,
        )

        if not isinstance(head, tuple):
            out_symbol = ir.Symbol[solution_set.type](functor_orig.name)
            self.add_tuple_set(solution_set.value, name=functor_orig.name)
            return fe.Symbol(self, out_symbol.name)
        elif len(head) == 0:
            return not (dry_run or show_ra) and len(solution_set) > 0
        else:
            return solution_set

    def _declare_query(
        self, head: fe.Expression, predicate: fe.Expression
    ) -> logic.Implication:
        """
        Declare the query rule *head* :- *predicate*, checking that all
        its variables are bound.
        """
        try:
            query_expression = self._declare_implication(head, predicate)
            check_range_restriction(
                query_expression, self.program_ir.symbol_table, query=True
            )
        except UnboundVariablesError as error:
            raise error.located(query=True) from None
        return query_expression

    def _magic_sets_rewrite_query(
        self,
        head: Union[fe.Symbol, Tuple[fe.Expression, ...]],
        predicate: fe.Expression,
    ) -> Tuple[logic.Implication, logic.Union]:
        """Build query expression and run magic-sets rewriting.

        Returns the rewritten query expression and the reachable rules.
        If magic-sets rewriting is not applicable, returns the original
        query expression and reachable rules.

        NOTE: The caller must have already created a sub-scope on the
        symbol table via ``self.program_ir.symbol_table =
        self.symbol_table.create_scope()`` and must restore it after
        the chase or printing is complete.

        Parameters
        ----------
        head : Union[fe.Symbol, Tuple[fe.Expression, ...]]
            Query head.
        predicate : fe.Expression
            Query body.

        Returns
        -------
        Tuple[logic.Implication, logic.Union]
            Rewritten query expression and reachable rules.

        """
        if isinstance(head, fe.Operation):
            new_head = self.new_symbol()(*head.arguments)
        elif isinstance(head, tuple):
            new_head = self.new_symbol()(*head)
        else:
            raise ValueError("Wrong head syntax")
        query_expression = self._declare_query(new_head, predicate)

        try:
            magic_query_expression = self.magic_sets_rewrite_program(
                query_expression)
            reachable_rules = reachable_code(
                magic_query_expression, self.program_ir)
            return magic_query_expression, reachable_rules
        except InvalidMagicSetError:
            reachable_rules = reachable_code(query_expression, self.program_ir)
            return query_expression, reachable_rules

    def _execute_query(
        self,
        head: Union[fe.Symbol, Tuple[fe.Expression, ...]],
        predicate: fe.Expression,
        show_rewritten: bool = False,
        dry_run: bool = False,
        show_ra=False,
    ) -> Tuple[AbstractSet, Optional[ir.Symbol]]:
        """
        [Internal usage - documentation for developers]

        Performs an inferential query. Will return as first output
        an AbstractSet with as many elements as solutions of the
        predicate query. The AbstractSet's columns correspond to the
        expressions in the head.
        If head expressions are arguments of a functor, the latter will
        be returned as the second output, defaulted as None.

        Parameters
        ----------
        head : Union[fe.Symbol, Tuple[fe.Expression, ...]]
            see description
        predicate : fe.Expression
            see description
        show_rewritten : bool
            If True, print the Datalog program after magic-sets rewriting.
        dry_run : bool
            If True, print the rewritten program and return immediately
            without running the chase.
        show_ra : bool or ShowRAOptions
            If True, print the named relational algebra expression
            of each rule instead of evaluating it. A
            :class:`~neurolang.frontend.show_ra.ShowRAOptions` selects
            how the plans are displayed.

        Returns
        -------
        Tuple[AbstractSet, Optional[fe.Symbol]]
            see description

        Examples
        --------
        Note: example ran with pandas backend
        >>> p_ir = DatalogProgram()
        >>> nl = QueryBuilderDatalog(program_ir=p_ir)
        >>> nl.add_tuple_set([(1, 2), (2, 2)], name="l")
        l: typing.AbstractSet[typing.Tuple[int, int]] = [(1, 2), (2, 2)]
        >>> with nl.scope as e:
        ...     e.l2[e.x, e.y] = e.l[e.x, e.y] & (e.x == e.y)
        ...     s1 = nl._execute_query(tuple(), e.l2[e.x, e.y])
        ...     s2 = nl._execute_query((e.x,), e.l2[e.x, e.y])
        ...     s3 = nl._execute_query(e.l2[e.x, e.y], e.l2[e.x, e.y])
        >>> s1
        (
            C{
                Empty DataFrame
                Columns: []
                Index: [0]
                : typing.AbstractSet
            },
            None
        )
        >>> s2
        (
            C{
                    x
                0   2
                : typing.AbstractSet
            },
            None
        )
        >>> s3
        (
            C{
                    x   y
                0   2   2
                : typing.AbstractSet
            },
            S{
                l2: Unknown
            }
        )
        """
        functor_orig = None
        if isinstance(head, fe.Operation):
            functor_orig = head.expression.functor

        self.program_ir.symbol_table = self.symbol_table.create_scope()
        try:
            magic_query_expression, reachable_rules = self._magic_sets_rewrite_query(
                head, predicate
            )
            if self._handle_rewritten_output(
                magic_query_expression, show_rewritten, dry_run, show_ra
            ):
                solution_set = ir.Constant(WrappedRelationalAlgebraFrozenSet())
            elif show_ra:
                print_deterministic_ra_plan(
                    self.chase_class, self.program_ir, reachable_rules,
                    show_ra_options(show_ra),
                    generated_query_symbol(magic_query_expression),
                )
                solution_set = ir.Constant(WrappedRelationalAlgebraFrozenSet())
            else:
                solution = self.chase_class(
                    self.program_ir, rules=reachable_rules
                ).build_chase_solution()

                solution_set = solution.get(
                    magic_query_expression.consequent.functor,
                    ir.Constant(WrappedRelationalAlgebraFrozenSet())
                )

                if isinstance(head, tuple):
                    row_type = solution_set.value.row_type
                    solution_set = NamedRelationalAlgebraFrozenSet(
                        self._parameter_names(s.expression for s in head),
                        solution_set.value.unwrap()
                    )
                    solution_set.row_type = row_type
        finally:
            self.program_ir.symbol_table = self.symbol_table.enclosing_scope

        return solution_set, functor_orig

    def magic_sets_rewrite_program(self, query_expression):
        try:
            goal, mr = magic_rewrite(
                query_expression.consequent, self.program_ir
            )
        except InvalidMagicSetError:
            goal, mr = magic_rewrite(
                query_expression.consequent, self.program_ir,
                seed_from_edb=False
            )
        self.program_ir.walk(mr)
        new_query_expression = self.program_ir.symbol_table[goal].formulas[0]
        return new_query_expression

    def solve_all(self) -> Dict[str, NamedRelationalAlgebraFrozenSet]:
        """
        Returns a dictionary of "predicate_name": "Content"
        for all elements in the solution of the Datalog program.

        Returns
        -------
        Dict[str, NamedRelationalAlgebraFrozenSet]
            extensional and intentional facts that have been derived
            through the current program

        Examples
        --------
        Note: example ran with pandas backend
        >>> p_ir = DatalogProgram()
        >>> nl = QueryBuilderDatalog(program_ir=p_ir)
        >>> nl.add_tuple_set([(1, 2), (2, 2)], name="l")
        l: typing.AbstractSet[typing.Tuple[int, int]] = [(1, 2), (2, 2)]
        >>> with nl.scope as e:
        ...     e.l2[e.x] = e.l[e.x, e.y] & (e.x == e.y)
        ...     solution = nl.solve_all()
        """
        solution_ir = self.chase_class(self.program_ir).build_chase_solution()
        return self._solution_to_named_sets(solution_ir)

    def _solution_to_named_sets(
        self, solution_ir
    ) -> Dict[str, NamedRelationalAlgebraFrozenSet]:
        """
        Convert a chase solution to named sets keyed by predicate name.

        Each relation is wrapped in a ``NamedRelationalAlgebraFrozenSet``
        whose columns are the predicate's parameter names.
        """
        solution = {}
        for k, v in solution_ir.items():
            solution[predicate_identity(k)] = NamedRelationalAlgebraFrozenSet(
                self.predicate_parameter_names(k),
                v.value.unwrap(),
            )
            solution[predicate_identity(k)].row_type = v.value.row_type
        return solution

    def reset_program(self) -> None:
        """Clears current symbol table"""
        self.symbol_table.clear()

    def add_tuple_set(
        self, iterable: Iterable, type_: Type = Unknown, name: str = None
    ) -> fe.Symbol:
        """
        Creates an AbstractSet fe.Symbol containing the elements specified in
        the iterable with a List[Tuple[Any, ...]] format (see examples).
        Typically used to create extensional facts from existing databases

        Parameters
        ----------
        iterable : Iterable
            typically a list of tuples of values, other formats will
            be interpreted as the latter
        type_ : Type, optional
            type of elements for the tuples, if not specified
            will be inferred from the first element, by default Unknown
        name : str, optional
            name for the AbstractSet symbol, by default None

        Returns
        -------
        fe.Symbol
            see description

        Examples
        --------
        >>> p_ir = DatalogProgram()
        >>> nl = QueryBuilderDatalog(program_ir=p_ir)
        >>> nl.add_tuple_set([(1, 2), (3, 4)], name="l1")
        l1: typing.AbstractSet[typing.Tuple[int, int]] = \
            [(1, 2), (3, 4)]
        >>> nl.add_tuple_set([[1, 2, 3], (3, 4)], name="l2")
        l2: typing.AbstractSet[typing.Tuple[int, int, float]] = \
            [(1, 2, 3.0), (3, 4, nan)]
        >>> nl.add_tuple_set((1, 2, 3), name="l3")
        l3: typing.AbstractSet[typing.Tuple[int]] = \
            [(1,), (2,), (3,)]
        """
        if name is None:
            name = str(uuid1())

        if isinstance(type_, tuple):
            type_ = Tuple[type_]
        symbol = ir.Symbol[AbstractSet[type_]](name)
        if isinstance(iterable, pd.DataFrame):
            iterable = iterable.rename(
                columns={n: i for i, n in enumerate(iterable.columns)}
            )
        self.program_ir.add_extensional_predicate_from_tuples(
            symbol, iterable, type_=type_
        )

        return fe.Symbol(self, name)

    def predicate_documentation(self) -> Dict[str, Any]:
        """
        Return the documentation of the predicates of the program, by
        name: the ``%%`` blocks of their rules and facts, a
        :class:`~neurolang.commands.PredicateDocumentation` each, with
        their ``description`` and ``arguments``, ``(name, sort)`` pairs.

        Examples
        --------
        >>> from neurolang.frontend import NeurolangDL
        >>> nl = NeurolangDL()
        >>> nl.execute_datalog_program('''
        ... %% p(x: number)
        ... %% The numbers of p.
        ... p(1)
        ... ''')
        >>> nl.predicate_documentation()["p"].arguments
        (('x', 'number'),)
        """
        documentation = getattr(
            self.program_ir, "predicate_documentation", None
        )
        return documentation() if documentation is not None else {}

    def document_predicate(
        self, name: str, description: str,
        arguments: Iterable[Tuple[str, str]] = (),
    ) -> None:
        """
        Document the predicate *name* with its *description* and its
        *arguments*, ``(name, sort)`` pairs, as a ``%%`` block before its
        rule does (see :meth:`predicate_documentation`).
        """
        self.program_ir.walk(
            documentation_command(name, description, arguments)
        )

    def predicate_parameter_names(
        self, predicate_name: Union[str, fe.Symbol, fe.Expression]
    ) -> Tuple[str]:
        """
        Get the names of the parameters for the given predicate

        Parameters
        ----------
        predicate_name : Union[str, fe.Symbol, fe.Expression]
            predicate to obtain the names from

        Returns
        -------
        tuple[str]
            parameter names
        """
        predicate_name = self._get_predicate_name(predicate_name)
        return self._parameter_names(
            self.program_ir.predicate_terms(predicate_name)
        )

    def _parameter_names(self, parameters) -> Tuple[str]:
        """
        Return the column names of the head *parameters* of a rule.

        A variable gives its name and an aggregation, such as
        ``count(s)``, the name of its function, ``count``. Repeated
        names get a ``_1``, ``_2``... suffix.
        """
        parameter_names = []
        pcount = defaultdict(lambda: 0)
        for s in parameters:
            param_name = self._obtain_parameter_name(s)
            pcount[param_name] += 1
            if pcount[param_name] > 1:
                param_name = f"{param_name}_{pcount[param_name] - 1}"
            parameter_names.append(param_name)
        return tuple(parameter_names)

    def _obtain_parameter_name(self, parameter_expression):
        if hasattr(parameter_expression, "name"):
            param_name = parameter_expression.name
        elif hasattr(parameter_expression, "functor") and hasattr(
            parameter_expression.functor, "name"
        ):
            param_name = parameter_expression.functor.name
        else:
            param_name = ir.Symbol.fresh().name
        return param_name

    def _get_predicate_name(self, predicate_name):
        if isinstance(predicate_name, ir.Symbol):
            return predicate_name
        elif isinstance(predicate_name, fe.Symbol):
            predicate_name = predicate_name.neurolang_symbol
        elif isinstance(predicate_name, fe.Expression) and isinstance(
            predicate_name.expression, ir.Symbol
        ):
            predicate_name = predicate_name.expression
        elif not isinstance(predicate_name, str):
            raise ValueError(f"{predicate_name} is not a string or symbol")
        return predicate_name
