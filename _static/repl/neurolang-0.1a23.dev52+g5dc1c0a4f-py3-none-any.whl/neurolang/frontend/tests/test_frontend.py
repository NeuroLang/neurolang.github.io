import multiprocessing
from collections import namedtuple
from operator import add, contains
from typing import AbstractSet, Callable, Tuple
from unittest.mock import patch

import numpy as np
import pandas as pd
import pytest

from nl_expr import exceptions, expressions as exp
from ... import frontend
from nl_core.datalog import DatalogProgram, Fact, Implication
from nl_core.datalog.horn_clauses import Fol2DatalogTranslationException
from nl_expr.exceptions import (
    NeuroLangException,
    UnsupportedProgramError,
    WrongArgumentsInPredicateError,
)
from nl_expr.expression_walker import ExpressionBasicEvaluator
from ...regions import ExplicitVBR, SphericalVolume
from nl_expr.type_system import Unknown
from .. import query_resolution, query_resolution_expressions as qre


def test_symbol_management():
    class Solver(DatalogProgram, ExpressionBasicEvaluator):
        pass

    neurolang = query_resolution.QueryBuilderBase(Solver())

    sym = neurolang.new_symbol(int)
    assert sym.expression.type is int

    sym_ = neurolang.new_symbol(type_=(float, int))
    assert sym_.expression.type is Tuple[float, int]
    assert sym.expression.name != sym_.expression.name

    a = neurolang.new_symbol(int, name="a")
    assert a.expression.name == "a"

    b = neurolang.add_symbol(1, name="b")
    assert "b" in neurolang.symbols
    assert b.value == 1
    assert b.type is int
    assert neurolang.symbols.b == b

    with pytest.raises(AttributeError):
        assert neurolang.symbols.c

    @neurolang.add_symbol
    def id(x: int) -> int:
        return x

    assert "id" in neurolang.symbols
    assert id == neurolang.symbols.id
    assert id == neurolang.symbols["id"]
    assert id.type == Callable[[int], int]

    f = neurolang.new_symbol()
    new_expression = f(..., 1)
    assert isinstance(new_expression.expression, exp.FunctionApplication)
    assert new_expression.expression.functor == f.expression
    assert isinstance(new_expression.expression.args[0], exp.Symbol)
    assert new_expression.expression.args[0].is_fresh
    assert isinstance(new_expression.expression.args[1], exp.Constant)
    assert new_expression.expression.args[1].value == 1


def test_symbol_environment():
    class Solver(DatalogProgram, ExpressionBasicEvaluator):
        pass

    neurolang = query_resolution.QueryBuilderBase(Solver())

    b = neurolang.add_symbol(1, name="b")
    neurolang.symbols._dynamic_mode = True
    assert "c" not in neurolang.symbols
    c = neurolang.symbols.c
    assert c.type is Unknown
    assert c.expression.name == "c"
    del neurolang.symbols.b
    assert b not in neurolang.symbols
    neurolang.symbols._dynamic_mode = False

    with neurolang.environment as e:
        assert "c" not in e
        c = e.c
        assert c.type is Unknown
        assert c.expression.name == "c"

        e.d = 5
        assert e.d.value == 5
        assert e.d.type is int

    assert neurolang.symbols.d.value == 5
    assert neurolang.symbols.d.type is int

    with neurolang.scope as e:
        assert "f" not in e
        f = e.f
        assert f.type is Unknown
        assert f.expression.name == "f"

        e.g = 5
        assert e.g.value == 5
        assert e.g.type is int

    assert "f" not in neurolang.symbols
    assert "g" not in neurolang.symbols


def test_add_set():
    neurolang = frontend.NeurolangDL()

    s = neurolang.add_tuple_set(range(10), int)
    res = neurolang[s]

    assert s.type is AbstractSet[int]
    assert res.type is AbstractSet[int]
    assert res.value == frozenset((i,) for i in range(10))
    assert isinstance(repr(res), str)

    v = frozenset(zip(("a", "b", "c"), range(3)))
    s = neurolang.add_tuple_set(v, (str, int))
    res = neurolang[s]

    assert s.type is AbstractSet[Tuple[str, int]]
    assert res.type is AbstractSet[Tuple[str, int]]
    assert res.value == v
    assert isinstance(repr(res), str)

    v = pd.DataFrame([[0, 's', .1], [1, 'p', .3]], columns=['A', 'B', 'C'])
    s = neurolang.add_tuple_set(v)
    res = neurolang[s]

    assert s.type is AbstractSet[Tuple[int, str, float]]
    assert res.type is AbstractSet[Tuple[int, str, float]]
    assert res.value == set(v.itertuples(index=False))
    assert isinstance(repr(res), str)


def test_add_set_neurolangdl():
    neurolang = frontend.NeurolangDL()

    s = neurolang.add_tuple_set(range(10), int)
    res = neurolang[s]

    assert s.type is AbstractSet[int]
    assert res.type is AbstractSet[int]
    assert res.value == frozenset((i,) for i in range(10))

    v = frozenset(zip(("a", "b", "c"), range(3)))
    s = neurolang.add_tuple_set(v, (str, int))
    res = neurolang[s]

    assert s.type is AbstractSet[Tuple[str, int]]
    assert res.type is AbstractSet[Tuple[str, int]]
    assert res.value == v


def test_query_regions_from_region_set():
    neurolang = frontend.NeurolangDL()

    central = ExplicitVBR(np.array([[0, 0, 5], [1, 1, 8]]), np.eye(4))

    i1 = ExplicitVBR(np.array([[0, 0, 2], [1, 1, 3]]), np.eye(4))
    i2 = ExplicitVBR(np.array([[0, 0, -1], [1, 1, 2]]), np.eye(4))
    i3 = ExplicitVBR(np.array([[0, 0, -10], [1, 1, -5]]), np.eye(4))
    regions_ = {(i1,), (i2,), (i3,)}
    regions = neurolang.add_tuple_set(regions_)

    x = neurolang.new_region_symbol(name="x")
    query_result = neurolang.query(
        (x,), regions(x) & neurolang.symbols.inferior_of(x, central)
    )

    assert len(query_result) == len(regions)
    assert query_result.to_unnamed() == {(i1,), (i2,), (i3,)}


def test_query_new_predicate():
    neurolang = frontend.NeurolangDL()

    central = ExplicitVBR(np.array([[0, 0, 5], [1, 1, 8]]), np.eye(4))
    inferior_posterior = ExplicitVBR(
        np.array([[0, -10, -10], [1, -5, -5]]), np.eye(4)
    )

    inferior_central = ExplicitVBR(
        np.array([[0, 0, -1], [1, 1, 2]]), np.eye(4)
    )
    inferior_anterior = ExplicitVBR(
        np.array([[0, 2, 2], [1, 5, 3]]), np.eye(4)
    )

    regions_ = {
        (inferior_posterior,),
        (inferior_central,),
        (inferior_anterior,),
    }
    regions = neurolang.add_tuple_set(regions_)

    def posterior_and_inferior(y, z):
        return neurolang.symbols.anatomical_posterior_of(
            y, z
        ) & neurolang.symbols.anatomical_inferior_of(y, z)

    x = neurolang.new_region_symbol(name="x")
    query_result = neurolang.query(
        (x,), regions(x) & posterior_and_inferior(x, central)
    )
    assert len(query_result) == 1
    assert next(iter(query_result)) == (inferior_posterior,)


def test_query_single_symbol():
    neurolang = frontend.NeurolangDL()

    s = neurolang.add_tuple_set(
        [(i,) for i in range(5)]
    )

    with neurolang.scope as e:
        e.q[e.x] = s(e.x)

        res = neurolang.query(e.x, e.q(e.x))

    assert res.to_unnamed() == {(i,) for i in range(5)}


def test_query_wrong_head_arguments():
    neurolang = frontend.NeurolangDL()

    s = neurolang.add_tuple_set(
        [(i, i) for i in range(5)]
    )

    with neurolang.scope as e:
        e.q[e.x, e.y] = s(e.x, e.y)

        with pytest.raises(WrongArgumentsInPredicateError):
            neurolang.query((e.x, e.y, e.z), e.q(e.x, e.y, e.z))

        with pytest.raises(NeuroLangException):
            neurolang.query((e.x, e.y, e.z), e.q(e.x, e.y))


def _squall_voxel_engine(engine_class=frontend.NeurolangDL):
    """Return an engine with neurosynth-like voxel, study and report facts."""
    neurolang = engine_class()
    neurolang.add_tuple_set([(1, 2, 3), (4, 5, 6)], name="voxel")
    neurolang.add_tuple_set([(10, 1, 2, 3), (11, 7, 8, 9)], name="reports")
    neurolang.add_tuple_set([(10,), (11,)], name="study")
    neurolang.add_tuple_set([(1, 2)], name="pair")
    return neurolang


def test_squall_noun_with_fewer_arguments_than_columns():
    """
    A SQUALL noun naming a 3-column relation without ``in 3D`` is an error.

    It used to compile to ``voxel(v) ∧ reports(s, v)``, projecting the
    first column of each relation and returning a meaningless result.
    """
    from nl_expr.exceptions import PredicateArityError

    neurolang = _squall_voxel_engine()
    with pytest.raises(PredicateArityError) as info:
        neurolang.execute_squall_program(
            "obtain every Voxel that a Study reports."
        )
    error = info.value
    assert isinstance(error, WrongArgumentsInPredicateError)
    assert (error.predicate, error.arity, error.used) == ("voxel", 3, 1)
    assert str(error) == "`voxel` has 3 columns but is used with 1"
    assert "in 3D" in error.suggestion
    assert "3 variables" in error.suggestion

    result = neurolang.execute_squall_program(
        "obtain every Voxel in 3D that a Study reports."
    )
    assert set(result) == {(1, 2, 3)}


def test_squall_wrong_arity_states_only_the_counts():
    """
    A predicate used with more arguments than its columns, or a verb used
    with too few, reports the counts without guessing a fix.
    """
    from nl_expr.exceptions import PredicateArityError

    neurolang = _squall_voxel_engine()
    with pytest.raises(PredicateArityError) as info:
        neurolang.execute_squall_program("obtain every Pair in 3D.")
    assert (info.value.predicate, info.value.arity, info.value.used) == (
        "pair", 2, 3
    )
    assert "in 3D" not in info.value.suggestion

    with pytest.raises(PredicateArityError) as info:
        neurolang.execute_squall_program(
            "obtain every Study that reports a Voxel in 2D."
        )
    assert (info.value.predicate, info.value.arity, info.value.used) in {
        ("reports", 4, 3), ("voxel", 3, 2)
    }


def test_predicate_arity_error_suggests_tuple_subject_for_extra_objects():
    """
    A predicate used with more arguments than its columns, as a verb with
    too many objects, suggests matching the extra value through a tuple
    subject on the relation that stores it.
    """
    from nl_expr.exceptions import PredicateArityError

    error = PredicateArityError("mentions", 2, 3)
    assert "several objects" in error.suggestion
    assert "(?s; ?t; ?w) is a" in error.suggestion
    assert "in 2D" not in error.suggestion

    neurolang = _squall_voxel_engine()
    with pytest.raises(PredicateArityError) as info:
        neurolang.execute_squall_program("obtain every Pair in 3D.")
    assert "several objects" in info.value.suggestion


def test_squall_defined_relation_with_wrong_arity():
    """
    A relation defined with several columns and used as a unary noun is
    an error, both in a query and in the body of a rule definition.
    """
    from nl_expr.exceptions import PredicateArityError

    neurolang = _squall_voxel_engine()
    neurolang.execute_squall_program("define as Region3 every Voxel in 3D.")
    with pytest.raises(PredicateArityError) as info:
        neurolang.execute_squall_program(
            "obtain every Region3 that a Study reports."
        )
    assert (info.value.predicate, info.value.arity, info.value.used) == (
        "region3", 3, 1
    )
    with pytest.raises(PredicateArityError) as info:
        neurolang.execute_squall_program(
            "define as Active every Voxel that a Study reports."
        )
    assert info.value.predicate == "voxel"

    # The whole relation is still obtained by naming it alone.
    assert set(neurolang.execute_squall_program("obtain every Region3.")) == {
        (1, 2, 3), (4, 5, 6)
    }


def test_squall_obtain_as_defines_the_whole_relation():
    """
    ``obtain every Voxel as Voxels`` defines ``voxels`` with every column
    of ``voxel``, as the query itself obtains them, not only the first.
    """
    neurolang = _squall_voxel_engine()
    result = neurolang.execute_squall_program("obtain every Voxel as Voxels.")
    assert set(result) == {(1, 2, 3), (4, 5, 6)}
    result = neurolang.execute_squall_program("obtain every Voxels.")
    assert set(result) == {(1, 2, 3), (4, 5, 6)}


def test_squall_probabilistic_predicate_arity_excludes_probability():
    """
    The probability column of probabilistic facts and choices is not an
    argument, so using them with their other columns is not an error.
    """
    neurolang = _squall_voxel_engine(frontend.NeurolangPDL)
    neurolang.add_uniform_probabilistic_choice_over_set(
        [(10,), (11,)], name="selected_study"
    )
    neurolang.add_probabilistic_facts_from_tuples(
        [(0.5, 10), (0.2, 11)], name="maybe_study"
    )
    neurolang.execute_squall_program(
        "define as Chosen every Selected_study.\n"
        "define as Maybe_chosen every Maybe_study."
    )


def test_query_with_constant():
    neurolang = frontend.NeurolangDL()

    s = neurolang.add_tuple_set(
        (("a", "b"), ("a", "c"), ("a", "d"), ("b", "c"), ("b", "d"))
    )

    with neurolang.scope as e:
        e.q[e.x, e.y] = s(e.x, e.y)
        res = neurolang.query((e.y), e.q("a", e.y))

    print(res.to_unnamed())
    assert res.to_unnamed() == {("b",), ("c",), ("d",)}


@pytest.mark.skip()
def test_load_spherical_volume_first_order():
    neurolang = frontend.RegionFrontend()

    inferior = ExplicitVBR(np.array([[0, 0, 0], [1, 1, 1]]), np.eye(4))

    neurolang.add_region(inferior, name="inferior_region")
    neurolang.sphere((0, 0, 0), 0.5, name="unit_sphere")
    assert neurolang.symbols["unit_sphere"].value == SphericalVolume(
        (0, 0, 0), 0.5
    )

    x = neurolang.new_region_symbol(name="x")
    query = neurolang.query(
        x, neurolang.symbols.overlapping(x, neurolang.symbols.unit_sphere)
    )
    query_result = query.do()
    assert len(query_result.value) == 1
    assert next(iter(query_result.value)) == inferior

    neurolang.make_implicit_regions_explicit(np.eye(4), (500, 500, 500))
    query = neurolang.query(
        x, neurolang.symbols.overlapping(x, neurolang.symbols.unit_sphere)
    )
    query_result = query.do()
    sphere_constant = neurolang.symbols["unit_sphere"].value
    assert (
        isinstance(sphere_constant, ExplicitVBR)
        and np.array_equal(sphere_constant.affine, np.eye(4))
        and sphere_constant.image_dim == (500, 500, 500)
        and np.array_equal(sphere_constant.voxels, [[0, 0, 0]])
    )
    assert len(query_result.value) == 1
    assert next(iter(query_result.value)) == inferior


def test_load_spherical_volume_datalog():
    neurolang = frontend.NeurolangDL()

    inferior = ExplicitVBR(np.array([[0, 0, 0], [1, 1, 1]]), np.eye(4))

    regions = neurolang.add_tuple_set(
        {(inferior, "inferior_region")}, name="regions"
    )
    neurolang.sphere((0, 0, 0), 0.5, name="unit_sphere")
    assert neurolang.symbols["unit_sphere"].value == SphericalVolume(
        (0, 0, 0), 0.5
    )

    q = neurolang.new_symbol()
    x = neurolang.new_region_symbol(name="x")
    n = neurolang.new_region_symbol(name="n")
    query = neurolang.query(
        q(x),
        neurolang.symbols.overlapping(x, neurolang.symbols.unit_sphere)
        & regions(x, n),
    )

    assert len(query.value) == 1
    assert next(iter(query.value))[0] == inferior

    neurolang.make_implicit_regions_explicit(np.eye(4), (500, 500, 500))
    query = neurolang.query(
        q(x),
        neurolang.symbols.overlapping(x, neurolang.symbols.unit_sphere)
        & regions(x, n),
    )

    assert len(query.value) == 1
    assert next(iter(query.value))[0] == inferior

    sphere_constant = neurolang.symbols["unit_sphere"].value
    assert (
        isinstance(sphere_constant, ExplicitVBR)
        and np.array_equal(sphere_constant.affine, np.eye(4))
        and sphere_constant.image_dim == (500, 500, 500)
        and np.array_equal(sphere_constant.voxels, [[0, 0, 0]])
    )


def test_neurolang_dl_query():
    neurolang = frontend.NeurolangDL()
    r = neurolang.new_symbol(name="r")
    x = neurolang.new_symbol(name="x")
    y = neurolang.new_symbol(name="y")
    z = neurolang.new_symbol(name="z")

    dataset = {(i, i * 2) for i in range(10)}
    q = neurolang.add_tuple_set(dataset, name="q")
    sol = neurolang.query((x, y), q(x, y))
    assert sol.to_unnamed() == dataset
    assert sol.row_type == Tuple[int, int]

    sol = neurolang.query(tuple(), q(x, x))
    assert sol
    assert neurolang.query(q(x, x))

    sol = neurolang.query(tuple(), q(100, x))
    assert not sol
    assert not neurolang.query(q(100, x))

    sol = neurolang.query((x,), q(x, y) & q(y, z)).to_unnamed()
    res = set((x,) for x in range(5))
    assert sol == res

    r[x, y] = q(x, y)
    r[x, z] = r[x, y] & q(y, z)
    sol = neurolang.query((y,), r(1, y)).to_unnamed()
    assert sol == set((x,) for x in (2, 4, 8, 16))


def test_neurolang_dl_solve_all():
    neurolang = frontend.NeurolangDL()
    r = neurolang.new_symbol(name="r")
    x = neurolang.new_symbol(name="x")

    dataset = {(i, i * 2) for i in range(10)}
    q = neurolang.add_tuple_set(dataset, name="q")
    r[x] = q(x, x)
    sol = neurolang.solve_all()
    assert sol["q"].to_unnamed() == dataset
    assert sol["r"].to_unnamed() == set((i,) for i, j in dataset if i == j)
    assert len(sol) == 2
    assert neurolang.predicate_parameter_names(r) == ("x",)


def test_neurolange_dl_get_param_names():
    neurolang = frontend.NeurolangDL()
    r = neurolang.new_symbol(name="r")
    x = neurolang.new_symbol(name="x")

    dataset = {(i, i * 2) for i in range(10)}
    q = neurolang.add_tuple_set(dataset, name="q")
    r[x] = q(x, x)

    @neurolang.add_symbol
    def test_fun(x: int) -> int:
        """
        HELP TEST
        """
        return 0

    assert neurolang.predicate_parameter_names("q") == ("0", "1")
    assert neurolang.predicate_parameter_names(q) == ("0", "1")
    assert neurolang.predicate_parameter_names(r) == ("x",)
    assert neurolang.symbols[r].predicate_parameter_names == ("x",)
    assert r[x].help() is not None
    assert neurolang.symbols["test_fun"].help().strip() == "HELP TEST"


def test_neurolange_dl_named_sets():
    neurolang = frontend.NeurolangDL()
    r = neurolang.new_symbol(name="r")
    s = neurolang.new_symbol(name="s")
    x = neurolang.new_symbol(name="x")
    y = neurolang.new_symbol(name="y")

    dataset = {(i, i * 2) for i in range(10)}
    q = neurolang.add_tuple_set(dataset, name="q")
    r[x] = q(x, x)
    s[x, y] = q(x, x) & (y == x)

    res = neurolang.solve_all()

    assert res["r"].columns == ("x",)
    assert res["r"].row_type == Tuple[int]
    assert res["r"].to_unnamed() == {(i,) for i, j in dataset if i == j}


def test_neurolange_dl_negation():
    neurolang = frontend.NeurolangDL()
    s = neurolang.new_symbol(name="s")
    x = neurolang.new_symbol(name="x")
    y = neurolang.new_symbol(name="y")

    dataset = {(i, i * 2) for i in range(10)}
    q = neurolang.add_tuple_set(dataset, name="q")
    s[x, y] = ~q(x, x) & q(x, y)

    res = neurolang.solve_all()

    assert res["s"].to_unnamed() == {(i, j) for i, j in dataset if i != j}


def test_neurolang_dl_datalog_code_list_symbols():
    neurolang = frontend.NeurolangDL()
    original_symbols = set(neurolang.symbols)
    neurolang.execute_datalog_program(
        """
    A(4, 5)
    A(5, 6)
    A(6, 5)
    B(x,y) :- A(x, y)
    B(x,y) :- B(x, z),A(z, y)
    C(x) :- B(x, y), (y == 5)
    D("x")
    """
    )

    assert set(neurolang.symbols) == {"A", "B", "C", "D"} | original_symbols


def test_neurolang_dl_datalog_code():
    neurolang = frontend.NeurolangDL()
    neurolang.execute_datalog_program(
        """
    A(4, 5)
    A(5, 6)
    A(6, 5)
    B(x,y) :- A(x, y)
    B(x,y) :- B(x, z),A(z, y)
    C(x) :- B(x, y), (y == 5)
    D("x")
    """
    )

    res = neurolang.solve_all()

    assert res["A"].row_type == Tuple[int, int]
    assert res["A"].to_unnamed() == {(4, 5), (5, 6), (6, 5)}
    assert res["B"].to_unnamed() == {
        (4, 5),
        (5, 6),
        (6, 5),
        (4, 6),
        (5, 5),
        (6, 6),
    }
    assert res["C"].to_unnamed() == {(4,), (5,), (6,)}
    assert res["D"].to_unnamed() == {
        ("x",),
    }


def _tracts():
    neurolang = frontend.NeurolangDL()
    neurolang.add_tuple_set(
        [(1, "orbital"), (2, "middle"), (3, "superior"), (4, "middle")],
        name="traverses",
    )
    neurolang.add_tuple_set([(2,), (3,)], name="temporal")
    return neurolang


def test_neurolang_dl_datalog_code_disjunction():
    neurolang = _tracts()
    res = neurolang.execute_datalog_program(
        """
    uncinate(x) :-
        (traverses(x, "orbital") | traverses(x, "middle")
         \N{LOGICAL OR} traverses(x, "inferior")),
        temporal(x)
    frontal(x) :- traverses(x, "orbital") | traverses(x, "superior")
    ans(x) :- uncinate(x) | frontal(x), ~temporal(x)
    """
    )

    assert set(res.to_unnamed()) == {(1,), (2,)}
    assert neurolang.solve_all()["uncinate"].to_unnamed() == {(2,)}


@pytest.mark.parametrize("body", [
    "r(x, t), (t == 'a' | t == 'b')",
    "r(x, t), ((t == 'a') | (t == 'b'))",
    "r(x, t), (t == 'a' | t == 'b', x > 1 | t == 'a')",
])
def test_neurolang_dl_datalog_code_disjunction_of_comparisons(body):
    """In parentheses a comparison is a disjunct of its own."""
    neurolang = frontend.NeurolangDL()
    neurolang.add_tuple_set([(1, "a"), (2, "b"), (3, "c")], name="r")
    res = neurolang.execute_datalog_program(f"ans(x) :- {body}")
    assert set(res.to_unnamed()) == {(1,), (2,)}


@pytest.mark.parametrize("program", [
    "ans(x) :- r(x, t), (startswith('a', t) | startswith('b', t))",
    "ans(x) :- r(x, t), (startswith('a', t) | (t == 'b'))",
    "q(x) :- r(x, t), (startswith('a', t) | startswith('b', t))\n"
    "ans(x) :- q(x)",
    "q(p, x) :- (r(x, t) | s(x, t)), startswith(p, t)\n"
    "ans(x) :- q('a', x) | q('b', x)",
])
def test_neurolang_dl_datalog_code_disjunction_of_functions(program):
    """The variables of a disjunct of functions are bound outside it, or
    by the query (magic sets)."""
    neurolang = frontend.NeurolangDL()
    neurolang.add_tuple_set([(1, "a"), (2, "b"), (3, "c")], name="r")
    neurolang.add_tuple_set([(1, "a")], name="s")
    neurolang.add_symbol(
        lambda prefix, s: s.startswith(prefix), name="startswith"
    )
    res = neurolang.execute_datalog_program(program)
    assert set(res.to_unnamed()) == {(1,), (2,)}


def test_neurolang_dl_datalog_code_disjunction_constant_query():
    neurolang = _tracts()
    res = neurolang.execute_datalog_program(
        """
    q(x, y) :- traverses(x, y), (temporal(x) | (y == "orbital"))
    ans(x) :- q(x, "middle")
    """
    )

    assert set(res.to_unnamed()) == {(2,)}


def test_neurolang_dl_datalog_code_disjunction_under_negation():
    neurolang = _tracts()
    res = neurolang.execute_datalog_program(
        """
    q(x) :- traverses(x, "orbital") | traverses(x, "superior")
    ans(x) :- traverses(x, _), ~q(x)
    """
    )

    assert set(res.to_unnamed()) == {(2,), (4,)}



def test_neurolang_dl_datalog_code_anonymous_variable_negated():
    """``~traverses(x, _)``: no label at all; ``_`` is quantified in the
    negation (and in a disjunct), not a variable of the rule."""
    neurolang = _tracts()
    neurolang.add_tuple_set([(1,), (2,), (5,)], name="streamline")
    res = neurolang.execute_datalog_program(
        """
    ans(x) :- streamline(x), ~traverses(x, _)
    """
    )
    assert set(res.to_unnamed()) == {(5,)}
    res = neurolang.execute_datalog_program(
        """
    ans(x) :- streamline(x), (temporal(x) | traverses(x, _))
    """
    )
    assert set(res.to_unnamed()) == {(1,), (2,)}


def test_neurolang_dl_datalog_code_many_negations():
    """A rule with twenty negated atoms: the answer, in a time that grows
    linearly with the negations (it doubled with each)."""
    neurolang = frontend.NeurolangDL()
    neurolang.add_tuple_set([(i, i % 25) for i in range(100)], name="r")
    neurolang.add_tuple_set([(i, f"t{i}") for i in range(25)], name="s")
    body = ", ".join(f'~s(l, "t{i}")' for i in range(20))
    res = neurolang.execute_datalog_program(f"ans(x) :- r(x, l), {body}")
    assert set(res.to_unnamed()) == {
        (i,) for i in range(100) if i % 25 >= 20
    }

@pytest.mark.parametrize(
    "body", ['traverses(x, "orbital") | temporal(y)', 'temporal(x) | ~q(x)']
)
def test_neurolang_dl_datalog_code_unsafe_disjunct(body):
    neurolang = _tracts()
    neurolang.add_tuple_set([(1,)], name="q")
    with pytest.raises(
        Fol2DatalogTranslationException,
        match="in a positive atom of every disjunct",
    ):
        neurolang.execute_datalog_program(f"p(x) :- {body}")


def test_neurolang_dl_datalog_code_statement():
    neurolang = frontend.NeurolangDL()
    neurolang.execute_datalog_program(
        """
    A(4, 5)
    A(5, 6)
    A(6, 5)
    five := 5
    B(x,y) :- A(x, y)
    B(x,y) :- B(x, z),A(z, y)
    C(x) :- B(x, y), (y == five)
    D("x")
    """
    )

    res = neurolang.solve_all()

    assert res["A"].row_type == Tuple[int, int]
    assert res["A"].to_unnamed() == {(4, 5), (5, 6), (6, 5)}
    assert res["B"].to_unnamed() == {
        (4, 5),
        (5, 6),
        (6, 5),
        (4, 6),
        (5, 5),
        (6, 6),
    }
    assert res["C"].to_unnamed() == {(4,), (5,), (6,)}
    assert res["D"].to_unnamed() == {
        ("x",),
    }


def test_neurolang_dl_datalog_code_statement_autocompletion():
    neurolang = frontend.NeurolangDL()
    res = neurolang.compute_datalog_program_for_autocompletion(
        """
    A(4, 5)
    A(5, 6)
    A(6, 5)
    five := 5
    B(x,y) :- A(x, y)
    B(x,y) :- B(x, z),A(z, y)
    C(x) :- B(x, y), (y == five)
    D("x")
    """,
        """
    A(4, 5)
    A(5, 6)
    A(6, 5)
    five := 5
    B(x,y) :- A(x, y)
    B(x,y) :- 
    """
    )
    expected = {'Signs': {'values': {'@', '∃', '('}}, 'Numbers': {'values': set()}, 'Text': {'values': set()},
                'Operators': {'values': {'~', '¬'}}, 'Cmd_identifier': {'values': set()}, 'Functions': {'values': {'lambda'}}, 'Identifier_regexp': {'values': set()}, 'Reserved words': {'values': {'AGGREGATE', 'EXISTS', 'MARG', 'RESAMPLE', 'PROB', 'SUCC', 'exists'}}, 'Boleans': {'values': {'False', '⊤', '⊥', 'True'}}, 'Expression symbols': {'values': set()}, 'Python string': {'values': set()}, 'Strings': {'values': {'<identifier_regexp>', '<cmd_identifier>'}}, 'commands': {'values': set()}, 'functions': {'values': set()}, 'base symbols': {'values': set()}, 'query symbols': {'values': set()}}
    assert res == expected


@pytest.mark.xfail(
    raises=TypeError,
    strict=True,
    reason=(
        "Named lambda statements (`f := lambda ...`) are never stored in "
        "the program symbol table, so `plus_one` cannot be resolved. "
        "The test used to pass only because `y == plus_one(4)` was "
        "silently dropped for the already bound `y`."
    ),
)
def test_neurolang_dl_datalog_code_lambda_def():
    neurolang = frontend.NeurolangDL()
    neurolang.execute_datalog_program(
        """
    A(4, 5)
    A(5, 6)
    A(6, 5)
    plus_one := lambda x: x + 1
    B(x,y) :- A(x, y)
    B(x,y) :- B(x, z),A(z, y)
    C(x) :- B(x, y), (y == plus_one(4))
    D("x")
    """
    )

    res = neurolang.solve_all()

    assert res["A"].row_type == Tuple[int, int]
    assert res["A"].to_unnamed() == {(4, 5), (5, 6), (6, 5)}
    assert res["B"].to_unnamed() == {
        (4, 5),
        (5, 6),
        (6, 5),
        (4, 6),
        (5, 5),
        (6, 6),
    }
    assert res["C"].to_unnamed() == {(4,), (5,), (6,)}
    assert res["D"].to_unnamed() == {
        ("x",),
    }


def test_neurolang_dl_datalog_code_lambda_app():
    neurolang = frontend.NeurolangDL()
    neurolang.execute_datalog_program(
        """
    A(4, 5)
    A(5, 6)
    A(6, 5)
    B(x,y) :- A(x, y)
    B(x,y) :- B(x, z),A(z, y)
    C(x) :- B(x, y), (y == (lambda x: x + 1)(4))
    D("x")
    """
    )

    res = neurolang.solve_all()

    assert res["A"].row_type == Tuple[int, int]
    assert res["A"].to_unnamed() == {(4, 5), (5, 6), (6, 5)}
    assert res["B"].to_unnamed() == {
        (4, 5),
        (5, 6),
        (6, 5),
        (4, 6),
        (5, 5),
        (6, 6),
    }
    assert res["C"].to_unnamed() == {(4,), (5,), (6,)}
    assert res["D"].to_unnamed() == {
        ("x",),
    }


def test_neurolang_dl_datalog_code_with_query():
    prog = """
        A(4, 5)
        A(5, 6)
        A(6, 5)
        B(x,y) :- A(x, y)
        B(x,y) :- B(x, z), A(z, y)
        """

    neurolang = frontend.NeurolangDL()
    res = neurolang.execute_datalog_program(
        prog + "\nans(x) :- B(x, y), (y == 5)"
    )
    assert res.to_unnamed() == {(4,), (5,), (6,)}
    assert res.row_type == Tuple[int, ]

    res = neurolang.execute_datalog_program(prog + "\nans() :- B(x, y)")
    assert res == True

    with pytest.raises(UnsupportedProgramError):
        neurolang.execute_datalog_program(
            "ans(x) :- A(x, 5)\n" + prog + "\nans(x) :- B(x, y), (y == 5)"
        )


def _voxel_engine(engine_class):
    """
    Return an *engine_class* engine with voxels, peaks and a distance.
    """
    nl = engine_class()

    @nl.add_symbol
    def euclidean(i, j, k, i1, j1, k1) -> float:
        return ((i - i1) ** 2 + (j - j1) ** 2 + (k - k1) ** 2) ** .5

    nl.add_tuple_set([(0, 0, 0), (1, 1, 1), (9, 9, 9)], name="voxel")
    nl.add_tuple_set(
        [(0, 0, 0, "s1"), (1, 1, 2, "s2")], name="peak_reported"
    )
    return nl


ENGINES = pytest.mark.parametrize(
    "engine_class", [frontend.NeurolangDL, frontend.NeurolangPDL],
    ids=["DL", "PDL"],
)


@ENGINES
def test_unbound_variables_rejected_at_definition(engine_class):
    nl = _voxel_engine(engine_class)
    with pytest.raises(exceptions.UnboundVariablesError) as exc_info:
        nl.execute_datalog_program(
            "reports_close(i, j, k, s) :- "
            "(euclidean(i, j, k, i1, j1, k1) < 2.) & voxel(i, j, k) "
            "& peak_reported(i, j, k, s)"
        )
    exc = exc_info.value
    assert exc.rule == "reports_close"
    assert exc.variables == ("i1", "j1", "k1")
    assert str(exc).startswith(
        "In reports_close: the variables i1, j1, k1 appear only in "
        "`euclidean(i, j, k, i1, j1, k1) < 2.0`"
    )
    assert "positive atom" in str(exc)
    assert "voxel(i1, j1, k1)" in exc.suggestion
    assert "normal form" not in exc.suggestion
    assert not nl.current_program


@pytest.mark.parametrize(
    "body, variables",
    [
        ("voxel(i, j, k) & (i < m)", ("m",)),
        ("voxel(i, j, k) & (i == m + 1)", ("m",)),
        ("voxel(i, j, k) & (d < 2) & (e == d + 1)", ("d", "e")),
        ("voxel(i, j, k) & ~peak_reported(i, j, k, s) & (s != 'a')",
         ("s",)),
    ],
    ids=["comparison", "equality-over-unbound", "chain", "negation"],
)
def test_unbound_variables_named_in_error(body, variables):
    nl = _voxel_engine(frontend.NeurolangDL)
    with pytest.raises(exceptions.UnboundVariablesError) as exc_info:
        nl.execute_datalog_program(f"p(i) :- {body}")
    assert exc_info.value.variables == variables
    assert ", ".join(variables) in str(exc_info.value)


def test_unbound_variables_in_aggregation_rule_rejected():
    nl = _voxel_engine(frontend.NeurolangDL)
    with pytest.raises(exceptions.UnboundVariablesError, match="i1, j1"):
        nl.execute_datalog_program(
            "n_close(i, count(s)) :- peak_reported(i, j, k, s) "
            "& (euclidean(i, j, k, i1, j1, k1) < 2.)"
        )


@ENGINES
@pytest.mark.parametrize("program", [
    "ans(s, t) :- title(s, t), ~regexp(t, 'default mode', 'i')",
    "p(s) :- title(s, t), regexp(t, 'default mode')",
])
def test_function_with_wrong_arguments_rejected(engine_class, program):
    nl = engine_class()
    nl.add_tuple_set([(1, "a default mode network")], name="title")
    with pytest.raises(WrongArgumentsInPredicateError) as exc_info:
        nl.execute_datalog_program(program)
    assert str(exc_info.value).startswith(
        "`regexp` is used with "
    )
    assert "but is the function regexp(regexp: str) -> " in str(
        exc_info.value
    )
    assert str(exc_info.value).endswith(
        ": The regions whose symbol name matches the regular expression."
    )


@pytest.mark.parametrize("head", ["ans(i)", "ans(i, m)"])
def test_unbound_variables_in_query_rejected(head):
    nl = _voxel_engine(frontend.NeurolangDL)
    with pytest.raises(exceptions.UnboundVariablesError) as exc_info:
        nl.execute_datalog_program(f"{head} :- voxel(i, j, k) & (i < m)")
    assert exc_info.value.rule is None
    assert str(exc_info.value).startswith(
        "In the query: the variable m appears only in `i < m`"
    )


@ENGINES
def test_unbound_head_variable_named_when_queried_unbound(engine_class):
    nl = _voxel_engine(engine_class)
    nl.execute_datalog_program(
        "far(i, s) :- peak_reported(i0, j, k, s) & (i0 != i)"
    )
    with pytest.raises(exceptions.UnboundVariablesError) as exc_info:
        nl.execute_datalog_program("ans(i, s) :- far(i, s)")
    assert exc_info.value.rule == "far"
    assert exc_info.value.variables == ("i",)


def test_unbound_head_variable_bound_by_query_constant():
    nl = _voxel_engine(frontend.NeurolangDL)
    res = nl.execute_datalog_program(
        """
        far(i, s) :- peak_reported(i0, j, k, s) & (i0 != i)
        ans(s) :- far(0, s)
        """
    )
    assert res.to_unnamed() == {("s2",)}


@ENGINES
def test_variable_defined_from_head_variable_bound_by_query_constant(
    engine_class
):
    """``d`` is defined from the head variable ``i``, bound by the query."""
    nl = _voxel_engine(engine_class)
    res = nl.execute_datalog_program(
        """
        near(i, s) :- peak_reported(i1, j, k, s) \
            & (d == euclidean(i, i, i, i1, j, k)) & (d < 1.5)
        ans(s) :- near(0, s)
        """
    )
    assert res.to_unnamed() == {("s1",)}


def test_variables_only_in_negations_left_to_negation_check():
    nl = _voxel_engine(frontend.NeurolangDL)
    nl.execute_datalog_program(
        "p(i) :- voxel(i, j, k) & ~peak_reported(i, j, k, s)"
    )
    with pytest.raises(exceptions.NegativeFormulaNotSafeRangeException):
        nl.execute_datalog_program("ans(i) :- p(i)")


@ENGINES
def test_functions_and_comparisons_on_bound_variables_accepted(
    engine_class
):
    nl = _voxel_engine(engine_class)
    res = nl.execute_datalog_program(
        """
        close(i, j, k, s) :- voxel(i, j, k) & peak_reported(i1, j1, k1, s) \
            & (euclidean(i, j, k, i1, j1, k1) < 2.)
        ans(i, j, k, s) :- close(i, j, k, s)
        """
    )
    assert res.to_unnamed() == {
        (0, 0, 0, "s1"), (1, 1, 1, "s1"), (1, 1, 1, "s2")
    }


@pytest.mark.parametrize(
    "rule, expected",
    [
        ("p(i, s) :- peak_reported(i0, j, k, s) & (i == i0 + 1)",
         {(1, "s1"), (2, "s2")}),
        ("p(e, s) :- peak_reported(i, j, k, s) & (e == d + 1) "
         "& (d == i * 10)", {(1, "s1"), (11, "s2")}),
        ("p(d, s) :- peak_reported(i, j, k, s) & (d == i)",
         {(0, "s1"), (1, "s2")}),
        ("p(d, s) :- peak_reported(i, j, k, s) & (d == 3)",
         {(3, "s1"), (3, "s2")}),
        ("p(i, s) :- peak_reported(i, j, k, s) & (d == euclidean(i, j, k, "
         "0, 0, 0)) & (d < 1)", {(0, "s1")}),
    ],
    ids=["expression", "chain", "variable", "constant", "function"],
)
def test_equality_defined_variables_accepted(rule, expected):
    nl = _voxel_engine(frontend.NeurolangDL)
    res = nl.execute_datalog_program(f"{rule}\nans(x, s) :- p(x, s)")
    assert res.to_unnamed() == expected


def test_neurolang_dl_aggregation():
    neurolang = frontend.NeurolangDL()
    q = neurolang.new_symbol(name="q")
    p = neurolang.new_symbol(name="p")
    r = neurolang.new_symbol(name="r")
    x = neurolang.new_symbol(name="x")
    y = neurolang.new_symbol(name="y")

    @neurolang.add_symbol
    def sum_(x):
        return sum(x)

    for i in range(10):
        q[i % 2, i] = True

    p[x, sum_(y)] = q[x, y]

    sol = neurolang.query(r(x, y), p(x, y))

    res_q = {(0, 2 + 4 + 6 + 8), (1, 1 + 3 + 5 + 7 + 9)}

    assert len(sol) == 2
    assert sol[r] == res_q
    assert sol[p] == res_q


def test_neurolang_dl_aggregation_direct_query():
    neurolang = frontend.NeurolangDL()
    q = neurolang.new_symbol(name="q")
    p = neurolang.new_symbol(name="p")
    x = neurolang.new_symbol(name="x")
    y = neurolang.new_symbol(name="y")

    @neurolang.add_symbol
    def sum_(x):
        return sum(x)

    for i in range(10):
        q[i % 2, i] = True

    p[x, sum_(y)] = q[x, y]

    sol = neurolang.query((x, y), p(x, y)).to_unnamed()

    res_q = {(0, 2 + 4 + 6 + 8), (1, 1 + 3 + 5 + 7 + 9)}

    assert sol == res_q


def test_neurolang_dl_aggregation_environment():
    neurolang = frontend.NeurolangDL()

    @neurolang.add_symbol
    def sum_(x):
        return sum(x)

    with neurolang.environment as e:
        for i in range(10):
            e.q[i % 2, i] = True

        e.p[e.x, sum_(e.y)] = e.q[e.x, e.y]
        sol = neurolang.query(e.r(e.x, e.y), e.p(e.x, e.y))

    res_q = {(0, 2 + 4 + 6 + 8), (1, 1 + 3 + 5 + 7 + 9)}

    assert len(sol) == 2
    assert sol["r"] == res_q
    assert sol["p"] == res_q


def test_neurolang_dl_aggregation_environment_direct_query():
    neurolang = frontend.NeurolangDL()

    @neurolang.add_symbol
    def sum_(x):
        return sum(x)

    with neurolang.environment as e:
        for i in range(10):
            e.q[i % 2, i] = True

        e.p[e.x, sum_(e.y)] = e.q[e.x, e.y]
        sol = neurolang.query((e.x, e.y), e.p(e.x, e.y)).to_unnamed()

    res_q = {(0, 2 + 4 + 6 + 8), (1, 1 + 3 + 5 + 7 + 9)}

    assert sol == res_q


def test_aggregation_number_of_arrivals():
    neurolang = frontend.NeurolangDL()

    @neurolang.add_symbol
    def agg_count(x) -> int:
        return len(x)

    with neurolang.environment as e:
        e.A[0, 1] = True
        e.A[1, 2] = True
        e.A[2, 3] = True
        e.reachable[e.x, e.y] = e.A[e.x, e.y]
        e.reachable[e.x, e.y] = e.reachable[e.x, e.z] & e.A[e.z, e.y]

        e.count_destinations[e.x, agg_count(e.y)] = e.reachable[e.x, e.y]

        res = neurolang.query((e.x, e.c), e.count_destinations(e.x, e.c))

    assert res.to_unnamed() == {(0, 3), (1, 2), (2, 1)}


def test_frontend_operators():
    neurolang = frontend.NeurolangDL()

    a = neurolang.new_symbol(name='a')

    b = a + 1

    assert isinstance(b, qre.Operation)
    assert b.expression.functor == exp.Constant(add)
    assert b.expression.args == (a.expression, exp.Constant(1))

    c = 1 + a

    assert isinstance(c, qre.Operation)
    assert c.expression.functor == exp.Constant(add)
    assert c.expression.args == (exp.Constant(1), a.expression)


@pytest.mark.parametrize(
    "aggregate, expected",
    [("count", {("a", 2), ("b", 1)}), ("max", {("a", 2), ("b", 5)})],
)
def test_query_with_aggregation_in_head(aggregate, expected):
    neurolang = frontend.NeurolangPDL()
    neurolang.add_tuple_set([(1, "a"), (2, "a"), (5, "b")], name="hits")
    sol = neurolang.execute_datalog_program(
        f"ans(t, {aggregate}(s)) :- hits(s, t)"
    )
    assert sol.columns == ("t", aggregate)
    assert sol.to_unnamed() == expected
    with neurolang.scope as e:
        sol = neurolang.query(
            (e.t, getattr(e, aggregate)(e.s)), e.hits(e.s, e.t)
        )
    assert sol.columns == ("t", aggregate)
    assert sol.to_unnamed() == expected


def test_query_head_with_repeated_variable():
    neurolang = frontend.NeurolangDL()
    neurolang.add_tuple_set([(1, "a"), (2, "b")], name="hits")
    sol = neurolang.execute_datalog_program("ans(t, t) :- hits(s, t)")
    assert sol.columns == ("t", "t_1")
    assert sol.to_unnamed() == {("a", "a"), ("b", "b")}


@pytest.mark.parametrize(
    "frontend_class", [frontend.NeurolangDL, frontend.NeurolangPDL]
)
@pytest.mark.parametrize(
    "body, expected",
    [
        ("q(i1, di), v(i), (i == i1 + di)", {(1,)}),
        ("q(i1, di), (i == i1 + di), v(i)", {(1,)}),
        ("q(i1, di), v(i), (i == (i1 + di))", {(1,)}),
        ("q(i1, di), v(i), (i1 + di == i)", {(1,)}),
        ("q(i1, di), v(i), (i == i1 * 2)", {(0,)}),
        ("q(i1, di), v(i), (i == 2 + 3)", {(5,)}),
        ("q(i1, di), v(i), (i == i1 + di), (i == di * 1)", {(1,)}),
        ("q(i1, di), v(i), (i == i1 + di), (i == di * 5)", set()),
        ("q(i1, di), (i == i1 + di), (i == di * 5)", set()),
        ("q(i1, di), (i == i1 + di), (i == di * 1)", {(1,)}),
        ("q(i1, di), (i == i1 + di)", {(1,)}),
    ],
)
def test_equality_with_expression_on_bound_variable(
    frontend_class, body, expected
):
    nl = frontend_class()
    nl.add_tuple_set([(0,), (1,), (5,)], name="v")
    nl.add_tuple_set([(0, 1)], name="q")
    res = nl.execute_datalog_program(f"p(i) :- {body}\nans(i) :- p(i)")
    assert res.to_unnamed() == expected


@pytest.mark.parametrize(
    "frontend_class", [frontend.NeurolangDL, frontend.NeurolangPDL]
)
@pytest.mark.parametrize(
    "rule, expected",
    [
        ("ans(u) :- act(u, y) & (u == 'u')", {("u",)}),
        ("ans(u) :- act(u, y) & ('u' == u)", {("u",)}),
        ("ans(y) :- act(u, y) & (u == 'u')", {(1,)}),
        ("ans(u, y) :- act(u, y) & (u == 'y')", {("y", 4)}),
        ("ans(u) :- act(u, y) & other(u) & (u == 'u')", {("u",)}),
        ("ans(u, x) :- pair(u, x) & (x == 'x')", {("u", "x")}),
        ("ans(u, x) :- pair(u, x) & (u == 'x')", set()),
        ("ans(u) :- act(u, y) & ~other(u) & (u == 'u')", set()),
        ("ans(u) :- act(u, y) & ~other(u) & (u == 'y')", {("y",)}),
        ("ans(u, z) :- other(u) & (z == 'z')", {("u", "z"), ("a", "z")}),
    ],
)
def test_equality_to_a_string_constant_spelled_as_a_variable(
    frontend_class, rule, expected
):
    """GH-1086: the constant 'u' is a value, not the column of `u`."""
    nl = frontend_class()
    nl.add_tuple_set([("u", 1), ("a", 2), ("b", 3), ("y", 4)], name="act")
    nl.add_tuple_set([("u",), ("a",)], name="other")
    nl.add_tuple_set([("u", "x"), ("a", "u"), ("y", "y")], name="pair")
    res = nl.execute_datalog_program(rule)
    assert set(res.to_unnamed()) == expected


@pytest.mark.parametrize(
    "frontend_class", [frontend.NeurolangDL, frontend.NeurolangPDL]
)
def test_equality_with_expression_3d_neighbourhood(frontend_class):
    nl = frontend_class()
    grid = [(i, j, k) for i in range(4) for j in range(4) for k in range(4)]
    nl.add_tuple_set(grid, name="voxel")
    nl.add_tuple_set([(1, 1, 1, "s1"), (3, 0, 2, "s2")], name="peak_reported")
    nl.add_tuple_set([(0, 0, 0), (1, 0, 0), (0, 1, 0)], name="offset")
    res = nl.execute_datalog_program(
        "reports_close(i, j, k, s) :- peak_reported(i1, j1, k1, s), "
        "offset(di, dj, dk), (i == i1 + di), (j == j1 + dj), "
        "(k == k1 + dk), voxel(i, j, k)\n"
        "ans(i, j, k, s) :- reports_close(i, j, k, s)"
    )
    assert res.to_unnamed() == {
        (1, 1, 1, "s1"),
        (2, 1, 1, "s1"),
        (1, 2, 1, "s1"),
        (3, 0, 2, "s2"),
        (3, 1, 2, "s2"),
    }


GRID_SIDE = 60
N_PEAKS = 2000


def neighbourhood_peaks():
    """Return ``N_PEAKS`` peaks spread over the ``GRID_SIDE`` grid."""
    return [
        (
            (7 * n) % GRID_SIDE,
            (13 * n) % GRID_SIDE,
            (29 * n) % GRID_SIDE,
            n,
        )
        for n in range(N_PEAKS)
    ]


def count_neighbourhood_rows(queue):
    """
    Put in ``queue`` the rows of the one-rule neighbourhood query.

    The engine holds ``N_PEAKS`` peaks, the 27 offsets in
    ``{-1, 0, 1}`` ^ 3 and a ``GRID_SIDE`` ^ 3 voxel grid, so a cross
    product of the three relations would not finish.
    """
    nl = frontend.NeurolangPDL()
    side = range(GRID_SIDE)
    nl.add_tuple_set(
        [(i, j, k) for i in side for j in side for k in side], name="voxel"
    )
    nl.add_tuple_set(neighbourhood_peaks(), name="peak_reported")
    shifts = (-1, 0, 1)
    nl.add_tuple_set(
        [(a, b, c) for a in shifts for b in shifts for c in shifts],
        name="offset",
    )
    res = nl.execute_datalog_program(
        "reports_close(i, j, k, s) :- peak_reported(i1, j1, k1, s), "
        "offset(di, dj, dk), (i == i1 + di), (j == j1 + dj), "
        "(k == k1 + dk), voxel(i, j, k)\n"
        "ans(i, j, k, s) :- reports_close(i, j, k, s)"
    )
    queue.put(len(res))


def test_equality_with_expression_3d_neighbourhood_large_grid():
    ctx = multiprocessing.get_context("spawn")
    queue = ctx.Queue()
    process = ctx.Process(target=count_neighbourhood_rows, args=(queue,))
    process.start()
    process.join(timeout=60)
    if process.is_alive():
        process.terminate()
        process.join()
        pytest.fail("the neighbourhood query did not finish in 60 s")

    def in_grid(c):
        return sum(0 <= c + d < GRID_SIDE for d in (-1, 0, 1))

    expected = sum(
        in_grid(i) * in_grid(j) * in_grid(k)
        for i, j, k, _ in neighbourhood_peaks()
    )
    assert queue.get(timeout=5) == expected


def test_neurolang_dl_attribute_access():
    neurolang = frontend.NeurolangDL()
    one_element = namedtuple("t", ("x", "y"))(1, 2)

    a = neurolang.add_tuple_set([(one_element,)], name="a")
    with neurolang.scope as e:
        e.q[e.x] = a[e.x]
        e.r[e.y] = a[e.w] & (e.y == e.w.x)
        res = neurolang.solve_all()

    q = res["q"]
    r = res["r"]
    assert len(q) == 1
    el = next(iter(q))[0]
    assert el == one_element
    assert r.to_unnamed() == {(one_element.x,)}


def test_neurolang_dl_set_destroy():
    neurolang = frontend.NeurolangDL()
    contains_ = neurolang.add_symbol(contains)

    a = neurolang.add_tuple_set([(frozenset((0, 1, 2)),)], name="a")
    with neurolang.scope as e:
        e.q[e.y] = a[e.x] & contains_(e.x, e.y)
        res = neurolang.solve_all()

    q = res["q"].to_unnamed()
    assert len(q) == 3
    assert set(q) == {(0,), (1,), (2,)}


def test_neurolang_dl_region_destroy():
    neurolang = frontend.NeurolangDL()
    contains_ = neurolang.add_symbol(contains)

    voxels1 = np.array([[1, 0, 0], [1, 1, 0]])
    voxels2 = np.array([[2, 0, 0]])

    region1 = ExplicitVBR(voxels1, np.eye(4))
    region2 = ExplicitVBR(voxels2, np.eye(4))

    regions = neurolang.add_tuple_set(
        [(region1,), (region2,)], name="regions"
    )

    with neurolang.scope as e:
        e.ans[e.v] = regions[e.r] & contains_(e.r, e.v)
        res = neurolang.solve_all()

    ans = res["ans"].to_unnamed()
    assert len(ans) == 3
    expected = {
        ((1, 0, 0),),
        ((1, 1, 0),),
        ((2, 0, 0),),
    }
    assert {tuple(tuple(v) for v in row) for row in ans} == expected


def test_neurolang_dl_region_destroy_non_region_ignored():
    neurolang = frontend.NeurolangDL()
    contains_ = neurolang.add_symbol(contains)

    numbers = neurolang.add_tuple_set(
        [(1,), (2,), (3,)], name="numbers"
    )

    with neurolang.scope as e:
        e.ans[e.v] = numbers[e.n] & contains_(e.n, e.v)
        res = neurolang.solve_all()

    ans = res["ans"].to_unnamed()
    assert len(ans) == 3
    expected = {(1,), (2,), (3,)}
    assert set(ans) == expected


def test_neurolang_dl_region_destroy_tuple_edb_column():
    neurolang = frontend.NeurolangDL()
    contains_ = neurolang.add_symbol(contains)

    numbers = neurolang.add_tuple_set(
        [("a", (1, 2, 3))], name="numbers"
    )

    with neurolang.scope as e:
        e.ans[e.l, e.v] = numbers[e.l, e.t] & contains_(e.t, e.v)
        res = neurolang.solve_all()

    ans = res["ans"].to_unnamed()
    assert len(ans) == 3
    expected = {
        ("a", 1),
        ("a", 2),
        ("a", 3),
    }
    assert set(ans) == expected


def test_neurolang_dl_region_destroy_multicolumn():
    neurolang = frontend.NeurolangDL()
    contains_ = neurolang.add_symbol(contains)

    voxels1 = np.array([[1, 0, 0], [1, 1, 0]])
    voxels2 = np.array([[2, 0, 0]])

    region1 = ExplicitVBR(voxels1, np.eye(4))
    region2 = ExplicitVBR(voxels2, np.eye(4))

    regions = neurolang.add_tuple_set(
        [("A", region1), ("B", region2)], name="regions"
    )

    with neurolang.scope as e:
        e.ans[e.l, e.v] = regions[e.l, e.r] & contains_(e.r, e.v)
        res = neurolang.solve_all()

    ans = res["ans"].to_unnamed()
    assert len(ans) == 3
    expected = {
        ("A", (1, 0, 0)),
        ("A", (1, 1, 0)),
        ("B", (2, 0, 0)),
    }
    assert {
        (row[0], tuple(row[1])) for row in ans
    } == expected


def test_neurolang_dl_region_destroy_tuple_coords():
    neurolang = frontend.NeurolangDL()
    contains_ = neurolang.add_symbol(contains)

    voxels1 = np.array([[1, 0, 0], [1, 1, 0]])
    voxels2 = np.array([[2, 0, 0]])

    region1 = ExplicitVBR(voxels1, np.eye(4))
    region2 = ExplicitVBR(voxels2, np.eye(4))

    regions = neurolang.add_tuple_set(
        [("A", region1), ("B", region2)], name="regions"
    )

    with neurolang.scope as e:
        e.ans[e.l, e.x, e.y, e.z] = regions[e.l, e.r] & contains_(e.r, (e.x, e.y, e.z))
        res = neurolang.solve_all()

    ans = res["ans"].to_unnamed()
    assert len(ans) == 3
    expected = {
        ("A", 1, 0, 0),
        ("A", 1, 1, 0),
        ("B", 2, 0, 0),
    }
    assert set(ans) == expected



SCHAEFER_INIT = """
schaefer_voxels(i, j, k, l) :- schaefer(l, r), contains(r, (i, j, k)).
schaefer_label(l) :- schaefer(l, r)
labels(l, i, j, k) :- schaefer_voxels(i, j, k, l)
"""
SCHAEFER_NAMES = {1: "17Networks_LH_A", 2: "17Networks_LH_B", 3: "17Networks_RH_C"}


def _small_atlas_regions():
    """
    Return the labelled regions of a small 3-parcel atlas image.

    Returns
    -------
    list of tuple
        ``(label, region)`` rows, as the engines load deterministic
        atlases.
    """
    import nibabel

    data = np.zeros((4, 3, 2), dtype=np.int16)
    data[0, :, 0] = 1
    data[1:3, 0, :] = 2
    data[3, 2, 1] = 3
    image = nibabel.Nifti1Image(data, np.diag([2.0, 2.0, 2.0, 1.0]))
    regions = ExplicitVBR.from_spatial_image_labels(image, [1, 2, 3])
    return [(SCHAEFER_NAMES[k], regions[k]) for k in (1, 2, 3)], data


def test_schaefer_shaped_engine_keeps_atlas_regions():
    nl = frontend.NeurolangPDL()
    rows, data = _small_atlas_regions()
    nl.add_tuple_set(rows, name="schaefer")
    declared_type = nl.symbol_table["schaefer"].type

    nl.execute_datalog_program(SCHAEFER_INIT)

    assert nl.symbol_table["schaefer"].type == declared_type
    regions = nl.execute_datalog_program("ans(l, r) :- schaefer(l, r)")
    assert set(regions.to_unnamed()) == set(rows)
    assert all(
        isinstance(region, ExplicitVBR) for _, region in regions.to_unnamed()
    )

    expected = {
        (name, *map(int, voxel))
        for label, name in SCHAEFER_NAMES.items()
        for voxel in np.argwhere(data == label)
    }
    labels = nl.execute_datalog_program("ans(l, i, j, k) :- labels(l, i, j, k)")
    assert set(labels.to_unnamed()) == expected
    voxels = nl.execute_datalog_program(
        "ans(i, j, k, l) :- schaefer_voxels(i, j, k, l)"
    )
    assert {(l, i, j, k) for i, j, k, l in voxels.to_unnamed()} == expected
    label_names = nl.execute_datalog_program("ans(l) :- schaefer_label(l)")
    assert set(label_names.to_unnamed()) == {(name,) for name in SCHAEFER_NAMES.values()}


@pytest.mark.skip
@patch(
    "neurolang.frontend.neurosynth_utils."
    "NeuroSynthHandler.ns_region_set_from_term"
)
def test_neurosynth_region(mock_ns_regions):
    mock_ns_regions.return_value = {
        ExplicitVBR(np.array([[1, 0, 0], [1, 1, 0]]), np.eye(4))
    }
    neurolang = frontend.NeurolangDL()
    s = neurolang.load_neurosynth_term_regions(
        "gambling", 10, "gambling_regions"
    )
    res = neurolang[s]
    mock_ns_regions.assert_called()

    assert res.type is AbstractSet[Tuple[ExplicitVBR]]
    assert res.value == frozenset((t,) for t in mock_ns_regions.return_value)


def test_translate_expression_to_fronted_expression():
    qr = frontend.NeurolangDL()
    tr = qre.TranslateExpressionToFrontEndExpression(qr)

    assert tr.walk(exp.Constant(1)) == 1

    symbol_exp = exp.Symbol("a")
    symbol_fe = tr.walk(symbol_exp)
    assert symbol_fe.expression == symbol_exp
    assert symbol_fe.query_builder == tr.query_builder

    fa_exp = symbol_exp(exp.Constant(1))
    fa_fe = symbol_fe(1)
    fa_fe_tr = tr.walk(fa_exp)
    assert fa_fe_tr.expression == fa_exp
    assert fa_fe_tr == fa_fe

    fact_exp = Fact(fa_exp)
    fact_fe = tr.walk(fact_exp)
    assert fact_fe.expression == fact_exp
    assert fact_fe.consequent == fa_fe

    imp_exp = Implication(
        symbol_exp(exp.Symbol("x")), exp.Symbol("b")(exp.Symbol("x"))
    )
    imp_fe = tr.walk(imp_exp)
    assert imp_fe.expression == imp_exp
    assert imp_fe.consequent == tr.walk(imp_exp.consequent)
    assert imp_fe.antecedent == tr.walk(imp_exp.antecedent)


@pytest.mark.skip(reason="sugar needs to be updated")
def test_first_column_sugar_body_s():
    qr = frontend.NeurolangDL()
    qr.add_tuple_set({
        ('one', 1), ('two', 2)
    }, name='dd')

    with qr.scope as e:
        e.s[e.x] = (e.x == e.y) & e.dd('one', e.y)
        e.r[e.x] = (e.x == (e.dd.s['one']))
        res_all = qr.solve_all()

    assert res_all['r'] == res_all['s']


@pytest.mark.skip(reason="sugar needs to be updated")
def test_first_column_sugar_head_s():
    qr = frontend.NeurolangDL()
    qr.add_tuple_set({
        (1, 'one'), (2, 'two')
    }, name='dd')

    with qr.scope as e:
        e.r.s['one'] = e.dd('one')
        res_all = qr.solve_all()

    assert set(res_all['r']) == {('one', 1)}


def test_head_constant():
    qr = frontend.NeurolangDL()
    qr.add_tuple_set({
        (1,)
    }, name='dd')

    with qr.scope as e:
        e.r['one', e.x] = e.dd(e.x)
        res_all = qr.solve_all()

    assert set(res_all['r']) == {('one', 1)}


def test_numpy_mixin_adds_functions():
    nl = frontend.NeurolangDL()
    functions = ["exp", "log", "log10", "cos", "sin", "tan"]

    p = nl.add_tuple_set([(i,) for i in np.arange(1, 10)], name="P")

    for func in functions:
        assert exp.Symbol(func) in nl.symbol_table
        with nl.scope as e:
            e.q[e.x, e.y] = p[e.x] & (e.y == getattr(e, func)(e.x))
            res = nl.solve_all()

        assert set(res["q"]) == {
            (i, getattr(np, func)(i)) for i in np.arange(1, 10)
        }


def test_symbol_eq_user_function_extended_projection():
    """
    Regression test: `e.out_var == user_func[e.in_var]` inside a scope must
    produce an ExtendedProjection column (not a Python bool).

    Before the fix, `Symbol.__eq__` returned a plain bool in logic-programming
    mode, so the conjunction body contained True/False instead of an IR
    equality expression, and the rule was silently dropped or raised an error.
    """
    nl = frontend.NeurolangDL()

    terms = nl.add_tuple_set([("Hello",), ("World",)], name="terms")

    @nl.add_symbol
    def word_lower(name: str) -> str:
        return name.lower()

    with nl.scope as e:
        e.lower_terms[e.term, e.lower] = (
            terms[e.term] & (e.lower == word_lower[e.term])
        )
        res = nl.solve_all()

    assert set(res["lower_terms"]) == {
        ("Hello", "hello"),
        ("World", "world"),
    }


def _count(x) -> int:
    return len(x)


@pytest.mark.parametrize(
    "frontend_class", [frontend.NeurolangDL, frontend.NeurolangPDL]
)
@pytest.mark.parametrize(
    "query,expected",
    [
        ("ans(n) :- AGGREGATE[](study(s) @ count(s)) = n", {(3,)}),
        (
            "ans(t, n) :- AGGREGATE[t](mentions(s, t) @ count(s)) = n",
            {("pain", 2), ("emotion", 1)},
        ),
    ],
)
def test_aggregate_in_ans_query(frontend_class, query, expected):
    nl = frontend_class()
    if frontend_class is frontend.NeurolangDL:
        nl.add_symbol(_count, name="count")
    nl.add_tuple_set([(1,), (2,), (3,)], name="study")
    nl.add_tuple_set(
        [(1, "pain"), (2, "pain"), (1, "emotion")], name="mentions"
    )
    res = nl.execute_datalog_program(query)
    assert res is not None
    assert set(map(tuple, res.as_pandas_dataframe().values)) == expected


@pytest.mark.parametrize("frontend_class", [
    frontend.NeurolangDL, frontend.NeurolangPDL
])
def test_region_contains_constant_point(frontend_class):
    """The labels of the regions with a voxel: an atlas lookup."""
    neurolang = frontend_class()
    neurolang.add_symbol(contains, name="contains")
    region1 = ExplicitVBR(np.array([[1, 0, 0], [1, 1, 0]]), np.eye(4))
    region2 = ExplicitVBR(np.array([[2, 0, 0]]), np.eye(4))
    neurolang.add_tuple_set(
        [("A", region1), ("B", region2)], name="atlas"
    )

    res = neurolang.execute_datalog_program(
        "ans(l) :- atlas(l, r) & contains(r, (1, 1, 0))"
    )

    assert set(res.to_unnamed()) == {("A",)}
