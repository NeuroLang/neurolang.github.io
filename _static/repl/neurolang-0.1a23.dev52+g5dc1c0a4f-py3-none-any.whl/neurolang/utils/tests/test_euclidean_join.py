import itertools
import math

import numpy
import pandas
import pytest
import scipy.spatial

from .. import euclidean_join as euclidean_join_module
from ..euclidean_join import (
    euclidean_distance,
    euclidean_join,
    euclidean_pairs,
)
from ..euclidean_join_settings import SETTINGS


def _brute_force(first, second, radius, strict):
    result = set()
    for p, q in itertools.product(map(tuple, first), map(tuple, second)):
        dist = math.sqrt(sum((a - b) ** 2 for a, b in zip(p, q)))
        if dist < radius or (not strict and dist == radius):
            result.add(p + q)
    return result


def _as_set(first, second, pairs):
    first_index, second_index, distances = pairs
    assert len(first_index) == len(second_index) == len(distances)
    result = set()
    for i, j, dist in zip(first_index, second_index, distances):
        assert dist == euclidean_distance(*first[i], *second[j])
        result.add(tuple(first[i]) + tuple(second[j]))
    assert len(result) == len(distances)
    return result


def _found(first, second, radius, strict):
    return _as_set(
        first, second, euclidean_pairs(first, second, radius, strict)
    )


@pytest.mark.parametrize("strict", [True, False])
@pytest.mark.parametrize("radius", [0, 1, 1.5, 2, 3])
@pytest.mark.parametrize("dims", [1, 2, 3, 4])
def test_integer_pairs_match_brute_force(strict, radius, dims):
    rng = numpy.random.default_rng(dims)
    first = rng.integers(-4, 5, size=(40, dims))
    second = rng.integers(-4, 5, size=(30, dims))
    first = numpy.unique(first, axis=0)
    second = numpy.unique(second, axis=0)
    expected = _brute_force(first, second, radius, strict)
    assert _found(first, second, radius, strict) == expected
    assert _found(second, first, radius, strict) == {
        p[dims:] + p[:dims] for p in expected
    }


@pytest.mark.parametrize("strict", [True, False])
def test_float_pairs_match_brute_force(strict):
    rng = numpy.random.default_rng(0)
    first = numpy.round(rng.uniform(-3, 3, size=(50, 3)), 1)
    second = numpy.round(rng.uniform(-3, 3, size=(20, 3)), 1)
    second[0] = first[0]
    second[1] = first[1] + numpy.array([2.0, 0.0, 0.0])
    first = numpy.unique(first, axis=0)
    second = numpy.unique(second, axis=0)
    expected = _brute_force(first, second, 2, strict)
    assert _found(first, second, 2, strict) == expected


def test_mixed_integer_and_float_coordinates():
    first = numpy.array([[0, 0, 0], [3, 0, 0]])
    second = numpy.array([[1.5, 0.0, 0.0]])
    assert _found(first, second, 1.5, True) == set()
    assert _found(first, second, 1.5, False) == {
        (0, 0, 0, 1.5, 0.0, 0.0), (3, 0, 0, 1.5, 0.0, 0.0)
    }


def test_sparse_integer_sets_use_exact_distances():
    first = numpy.array([[0, 0, 0], [1000, 0, 0]])
    second = numpy.array([[0, 0, 30], [1000, 40, 0], [500, 500, 500]])
    expected = _brute_force(first, second, 40, False)
    assert _found(first, second, 40, False) == expected
    assert _found(first, second, 40, True) == {
        (0, 0, 0, 0, 0, 30)
    }


@pytest.mark.parametrize(
    "first,second",
    [
        (numpy.empty((0, 3), dtype=int), numpy.array([[0, 0, 0]])),
        (numpy.array([[0, 0, 0]]), numpy.empty((0, 3), dtype=int)),
    ],
)
def test_empty_inputs(first, second):
    result = euclidean_pairs(first, second, 2, True)
    assert all(len(r) == 0 for r in result)


def test_negative_radius_gives_no_pairs():
    first = numpy.array([[0, 0, 0]])
    assert _found(first, first, -1, False) == set()


def test_euclidean_distance_is_vectorised():
    assert euclidean_distance(0, 0, 0, 1, 2, 2) == 3.0
    assert isinstance(euclidean_distance(0, 0, 0, 1, 2, 2), float)
    result = euclidean_distance(
        numpy.array([0, 1]), numpy.array([0, 1]), numpy.array([3, 4]),
        numpy.array([4, 1])
    )
    numpy.testing.assert_allclose(result, [5.0, 3.0])
    with pytest.raises(ValueError):
        euclidean_distance(1, 2, 3)


GRID = pandas.DataFrame(
    list(itertools.product(range(6), repeat=3)), columns=["i", "j", "k"]
)
PEAKS = pandas.DataFrame(
    [
        (2, 2, 2, "s1"), (2, 2, 2, "s2"), (3, 2, 2, "s1"), (4, 3, 2, "s1"),
        (0, 0, 5, "s3"), (9, 9, 9, "s4"),
    ],
    columns=["i1", "j1", "k1", "s"],
)
LABELLED = GRID.assign(l=[f"l{(i + j) % 3}" for i, j in zip(GRID.i, GRID.j)])
POINT, PEAK_POINT = ["i", "j", "k"], ["i1", "j1", "k1"]


def _brute_force_join(first, second, radius, strict, columns, distance):
    (first, first_point), (second, second_point) = first, second
    cross = first.merge(second, how="cross")
    cross[distance] = [
        math.dist(p, q) for p, q in zip(
            cross[first_point].itertuples(index=False),
            cross[second_point].itertuples(index=False),
        )
    ]
    within = cross[distance] < radius
    if not strict:
        within |= cross[distance] == radius
    return set(cross[within][columns].itertuples(index=False, name=None))


def _check_join(first, second, radius, strict, columns):
    result = euclidean_join(first, second, radius, strict, columns, "d")
    assert list(result.columns) == columns
    rows = list(result.itertuples(index=False, name=None))
    assert len(rows) == len(set(rows))
    expected = _brute_force_join(first, second, radius, strict, columns, "d")
    assert set(rows) == expected
    return result


@pytest.mark.parametrize("strict", [True, False])
@pytest.mark.parametrize("radius", [1, 2, 2.5])
@pytest.mark.parametrize(
    "columns",
    [
        ["i", "j", "k", "s"],
        ["i", "j", "k", "i1", "j1", "k1", "s", "d"],
        ["s"],
        ["s", "d"],
        ["i1", "j1", "k1"],
        ["d", "k"],
    ],
)
def test_join_of_points_with_rows_of_other_columns(strict, radius, columns):
    _check_join((GRID, POINT), (PEAKS, PEAK_POINT), radius, strict, columns)
    _check_join((PEAKS, PEAK_POINT), (GRID, POINT), radius, strict, columns)


@pytest.mark.parametrize("strict", [True, False])
@pytest.mark.parametrize(
    "columns",
    [
        ["l", "s"],
        ["l"],
        ["i", "j", "k", "l", "i1", "j1", "k1", "s"],
        ["i", "l", "d"],
    ],
)
def test_join_of_two_tables_with_other_columns(strict, columns):
    _check_join(
        (LABELLED, POINT), (PEAKS, PEAK_POINT), 2, strict, columns
    )


def test_join_of_float_points():
    rng = numpy.random.default_rng(0)
    first = pandas.DataFrame(
        numpy.round(rng.uniform(0, 4, size=(40, 2)), 1), columns=["x", "y"]
    )
    second = pandas.DataFrame({
        "u": numpy.round(rng.uniform(0, 4, size=15), 1),
        "v": numpy.round(rng.uniform(0, 4, size=15), 1),
        "name": [f"n{n % 4}" for n in range(15)],
    })
    for strict in (True, False):
        _check_join(
            (first, ["x", "y"]), (second, ["u", "v"]), 1.5, strict,
            ["x", "name"],
        )


def test_join_of_empty_tables():
    result = euclidean_join(
        (GRID.iloc[:0], POINT), (PEAKS, PEAK_POINT), 2, True,
        ["i", "s", "d"], "d",
    )
    assert list(result.columns) == ["i", "s", "d"] and len(result) == 0


def test_join_columns_default_to_all():
    result = euclidean_join(
        (GRID, POINT), (PEAKS, PEAK_POINT), 1, False, distance="d"
    )
    assert list(result.columns) == POINT + list(PEAKS.columns) + ["d"]


def test_integer_join_does_not_build_kd_trees(monkeypatch):
    def fail(*args, **kwargs):
        raise AssertionError("a k-d tree was built")

    monkeypatch.setattr(scipy.spatial, "cKDTree", fail)
    _check_join(
        (GRID, POINT), (PEAKS, PEAK_POINT), 2, True, ["i", "j", "k", "s"]
    )


def test_join_holds_little_more_than_its_result():
    """
    Joining a grid with the peaks of studies, as an activation within a
    radius does, holds little more memory than the rows it returns: the
    result is not copied, the distances are not kept when not asked for,
    and the pairs of rows are numbered with the smallest integers.
    """
    import tracemalloc

    rng = numpy.random.default_rng(0)
    axis = numpy.arange(40)
    grid = pandas.DataFrame(
        numpy.stack(numpy.meshgrid(axis, axis, axis), -1).reshape(-1, 3),
        columns=["i", "j", "k"],
    )
    peaks = pandas.DataFrame(
        rng.integers(0, 40, size=(20_000, 3)), columns=["i1", "j1", "k1"]
    ).assign(s=rng.integers(0, 2_000, 20_000)).drop_duplicates()
    tracemalloc.start()
    try:
        result = euclidean_join(
            (grid, ["i", "j", "k"]), (peaks, ["i1", "j1", "k1"]), 3, True,
            ["i", "j", "k", "s"], "d",
        )
        peak = tracemalloc.get_traced_memory()[1]
    finally:
        tracemalloc.stop()
    assert len(result) > 1_000_000
    assert peak < 1.8 * result.memory_usage(index=False).sum()


def _force_kdtree(monkeypatch):
    monkeypatch.setattr(SETTINGS, "stencil_min_work", 0)
    monkeypatch.setattr(SETTINGS, "stencil_work_per_point", 0)
    monkeypatch.setattr(SETTINGS, "stencil_grid_cells_per_point", 0)


@pytest.mark.parametrize("integers", [True, False])
@pytest.mark.parametrize("strict", [True, False])
def test_kdtree_chunks_give_the_pairs_of_one_search(
    monkeypatch, integers, strict
):
    rng = numpy.random.default_rng(1)
    first = rng.integers(0, 12, size=(120, 3))
    second = rng.integers(0, 12, size=(300, 3))
    if not integers:
        first, second = first + 0.25, second - 0.5
    first, second = numpy.unique(first, axis=0), numpy.unique(second, axis=0)
    _force_kdtree(monkeypatch)
    expected = _found(first, second, 2, strict)
    assert expected == _brute_force(first, second, 2, strict)
    for chunk_pairs in (1, 200, 10 ** 9):
        monkeypatch.setattr(SETTINGS, "kdtree_chunk_pairs", chunk_pairs)
        assert _found(first, second, 2, strict) == expected


@pytest.mark.parametrize("force_kdtree", [True, False])
def test_distances_are_not_returned_when_not_asked_for(
    monkeypatch, force_kdtree
):
    if force_kdtree:
        _force_kdtree(monkeypatch)
    with_distances = euclidean_join_module._pairs(
        GRID.to_numpy(), PEAKS[PEAK_POINT].drop_duplicates().to_numpy(), 2,
        numpy.less,
    )
    without = euclidean_join_module._pairs(
        GRID.to_numpy(), PEAKS[PEAK_POINT].drop_duplicates().to_numpy(), 2,
        numpy.less, with_distances=False,
    )
    assert without[2] is None
    for found, other in zip(with_distances[:2], without[:2]):
        numpy.testing.assert_array_equal(found, other)
    assert len(with_distances[2]) == len(with_distances[0]) > 0


def _count_kdtrees(monkeypatch):
    built = []
    build = scipy.spatial.cKDTree
    monkeypatch.setattr(
        scipy.spatial, "cKDTree",
        lambda *args, **kwargs: built.append(1) or build(*args, **kwargs),
    )
    return built


def test_dense_integer_sets_are_joined_with_a_stencil(monkeypatch):
    """
    A stencil look-up costs far less than a pair found by a k-d tree, so
    that a dense set is searched with a stencil however many look-ups.
    """
    monkeypatch.setattr(SETTINGS, "stencil_min_work", 0)
    monkeypatch.setattr(SETTINGS, "stencil_work_per_point", 0)
    built = _count_kdtrees(monkeypatch)
    axis = numpy.arange(12)
    large = numpy.stack(numpy.meshgrid(axis, axis, axis), -1).reshape(-1, 3)
    small = large[::7] + 1
    pairs = _found(small, large, 3, True)
    assert not built
    assert pairs == _brute_force(small, large, 3, True)


def test_sparse_integer_sets_are_joined_with_k_d_trees(monkeypatch):
    monkeypatch.setattr(SETTINGS, "stencil_min_work", 0)
    monkeypatch.setattr(SETTINGS, "stencil_work_per_point", 0)
    built = _count_kdtrees(monkeypatch)
    rng = numpy.random.default_rng(2)
    large = numpy.unique(rng.integers(0, 300, size=(200, 3)), axis=0)
    small = numpy.unique(rng.integers(0, 300, size=(100, 3)), axis=0)
    pairs = _found(small, large, 40, True)
    assert built
    assert pairs == _brute_force(small, large, 40, True)


def _join_peak_memory(grid, peaks, radius):
    import tracemalloc

    tracemalloc.start()
    try:
        result = euclidean_join(
            (grid, ["i", "j", "k"]), (peaks, ["i1", "j1", "k1"]), radius,
            True, ["i", "j", "k", "s"], "d",
        )
        peak = tracemalloc.get_traced_memory()[1]
    finally:
        tracemalloc.stop()
    return result, peak


def test_k_d_tree_join_holds_little_more_than_its_result(monkeypatch):
    """
    The pairs the k-d trees return are searched in chunks: the arrays of
    the trees' pairs, which are more than the result's, are never all alive.
    """
    _force_kdtree(monkeypatch)
    monkeypatch.setattr(SETTINGS, "kdtree_chunk_pairs", 200_000)
    rng = numpy.random.default_rng(0)
    axis = numpy.arange(40)
    grid = pandas.DataFrame(
        numpy.stack(numpy.meshgrid(axis, axis, axis), -1).reshape(-1, 3),
        columns=["i", "j", "k"],
    )
    peaks = pandas.DataFrame(
        rng.integers(0, 40, size=(20_000, 3)), columns=["i1", "j1", "k1"]
    ).assign(s=rng.integers(0, 2_000, 20_000)).drop_duplicates()
    result, peak = _join_peak_memory(grid, peaks, 3)
    assert len(result) > 1_000_000
    assert peak < 1.8 * result.memory_usage(index=False).sum()


@pytest.mark.parametrize("strict", [True, False])
@pytest.mark.parametrize("step,radius", [(0.5, 1.5), (0.1, 0.3), (0.25, 1.0)])
def test_float_grids_are_joined_with_a_stencil(
    monkeypatch, strict, step, radius
):
    """
    Float points on a grid, ties at the radius included, are joined as
    integers, with the distances of the floats.
    """
    built = _count_kdtrees(monkeypatch)
    rng = numpy.random.default_rng(3)
    first = numpy.unique(rng.integers(-8, 9, size=(60, 3)), axis=0) * step
    second = numpy.unique(rng.integers(-8, 9, size=(200, 3)), axis=0) * step
    pairs = _found(first, second, radius, strict)
    assert not built
    assert pairs == _brute_force(first, second, radius, strict)
    assert any(
        euclidean_distance(*p[:3], *p[3:]) == radius for p in pairs
    ) or strict


def test_float_points_off_a_grid_are_joined_with_k_d_trees(monkeypatch):
    built = _count_kdtrees(monkeypatch)
    rng = numpy.random.default_rng(4)
    first = rng.uniform(0, 5, size=(30, 3))
    second = rng.uniform(0, 5, size=(80, 3))
    assert _found(first, second, 1.5, True) == _brute_force(
        first, second, 1.5, True
    )
    assert built


def test_float_grid_distances_are_those_of_the_floats():
    first = numpy.array([[0.1, 0.2, 0.3]])
    second = numpy.array([[0.4, 0.6, 0.3], [0.1, 0.2, 0.6]])
    first_index, second_index, distances = euclidean_pairs(
        first, second, 0.6, False
    )
    assert len(distances) == 2
    for i, j, dist in zip(first_index, second_index, distances):
        assert dist == euclidean_distance(*first[i], *second[j])
